-- Pursuer.lua
-- Botões PNG no layout da screenshot + botão Run circular à direita
-- Place in: UhhhhhhReanim/Modules/Pursuer.lua

local modules = {}

table.insert(modules, function()

local m = {}

m.ModuleType   = "MOVESET"
m.Name         = "Pursuer"
m.Description  = "Fresh meat"
m.InternalName = "Pursuer"

m.Assets = {
    "idle pursuer.anim",
    "walk pursuer.anim",
    "sprint pursuer.anim",
    "swing pursuer.anim",
    "Cleave pursuer.anim",
    "Pursuer cleave end.anim",
    "howl pursuer.anim",
    "Stalk.anim",
    "StalkIdle.anim",
    "StalkWalk.anim",
    "stalk pursuer.anim",
    "Invisible.anim",
    "pursuer chase.mp3",
    "swing.mp3",
    "pursuer cleave.mp3",
    "cleave end.mp3",
    "howl.mp3",
    "stalk pursuer.mp3",
    "Swing_119451856807100.png",
    "Cleave_135005619881200.png",
    "Howl_102103089289560.png",
    "Stalk_106723990557565.png",
    "Runbuttow_135198000760756.png",
}

m.FlingEnabled = {
    ["Swing"] = true,
    ["Cleave"] = true,
    ["Howl"]  = false,
}

m.Config = function(parent)
    Util_CreateText(parent, "PURSUER", 20, Enum.TextXAlignment.Center)
end

m.SaveConfig = function() return {} end
m.LoadConfig = function(save) end

-- STATE
local figureRef
local gui
local bgMusic
local runBtn

-- Locomotion
local idleAnim
local walkAnim
local runAnim

-- Attacks / abilities
local swingAnim
local cleaveAnim
local cleaveEndAnim
local howlAnim
local stalkEntryAnim
local stalkIdleAnim
local stalkWalkAnim

local currentAnim
local isSprinting = false
local action = false
local actionStart = 0
local actionDuration = 0
local actionName = nil
local cleavePhase = 0

-- Stalk (rage)
local isStalking = false
local stalkTimer = 0
local STALK_DURATION = 14
local stalkEntryTimer = 0
local stalkHeadGlow = nil
local sndStalk = nil

-- Sounds
local snd_Swing
local snd_Cleave
local snd_CleaveEnd
local snd_Howl

local WALK_SPEED   = 13
local SPRINT_SPEED = 28
local STALK_WALK   = 19
local STALK_SPRINT = 32

local flingActive = false
local touchConns  = {}

-- HELPERS
local function loadAnim(file, looped)
    local anim = AnimLib.Animator.new()
    anim.rig    = figureRef
    anim.track  = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
    anim.looped = looped or false
    anim.speed  = 1
    anim.weight = 0
    return anim
end

local function makeSound(filename, parent, volume, looped)
    local s = Instance.new("Sound")
    s.SoundId = AssetGetContentId(filename)
    s.Volume  = volume or 0.8
    s.Looped  = looped or false
    s.Parent  = parent
    return s
end

local function play(anim)
    if currentAnim == anim then return end
    if currentAnim then currentAnim.weight = 0 end
    currentAnim = anim
    if currentAnim then
        currentAnim.weight = 1
        currentAnim._start = os.clock()
    end
end

local function freeze()
    local hum = figureRef and figureRef:FindFirstChildOfClass("Humanoid")
    if hum then hum.WalkSpeed = 0 end
end

local function restoreSpeed()
    local hum = figureRef and figureRef:FindFirstChildOfClass("Humanoid")
    if not hum then return end
    if isStalking then
        hum.WalkSpeed = isSprinting and STALK_SPRINT or STALK_WALK
    else
        hum.WalkSpeed = isSprinting and SPRINT_SPEED or WALK_SPEED
    end
end

local function unfreeze()
    restoreSpeed()
end

local function stopAllAnimSounds()
    if snd_Swing     then snd_Swing:Stop()     end
    if snd_Cleave    then snd_Cleave:Stop()    end
    if snd_CleaveEnd then snd_CleaveEnd:Stop() end
    if snd_Howl      then snd_Howl:Stop()      end
end

local function updateRunBtnVisual()
    if not runBtn then return end
    if isSprinting then
        runBtn.ImageTransparency = 0
        runBtn.BackgroundTransparency = 0.1
    else
        runBtn.ImageTransparency = 0.15
        runBtn.BackgroundTransparency = 0.35
    end
end

local function endStalking()
    if not isStalking then return end
    isStalking = false
    stalkTimer = 0
    stalkEntryTimer = 0
    if bgMusic then bgMusic:Resume() end
    if stalkHeadGlow then stalkHeadGlow:Destroy() stalkHeadGlow = nil end
    if sndStalk then sndStalk:Stop() end
    if stalkEntryAnim then stalkEntryAnim.weight = 0 end
    if stalkIdleAnim  then stalkIdleAnim.weight  = 0 end
    if stalkWalkAnim  then stalkWalkAnim.weight  = 0 end
    restoreSpeed()
end

local function startStalking()
    if isStalking or action then return end
    isStalking = true
    stalkTimer = STALK_DURATION
    stalkEntryTimer = 0
    restoreSpeed()

    if bgMusic then bgMusic:Pause() end

    if figureRef then
        local head = figureRef:FindFirstChild("Head")
        if head then
            stalkHeadGlow = Instance.new("PointLight", head)
            stalkHeadGlow.Color = Color3.fromRGB(255, 50, 50)
            stalkHeadGlow.Brightness = 2
            stalkHeadGlow.Range = 8
            stalkHeadGlow.Shadows = false
        end
    end

    if sndStalk then sndStalk:Play() end

    if stalkEntryAnim then
        action = true
        actionName = "StalkEntry"
        actionStart = os.clock()
        local entryDur = (stalkEntryAnim.track and stalkEntryAnim.track.Time or 1) / (stalkEntryAnim.speed or 1)
        actionDuration = entryDur
        stalkEntryTimer = entryDur
        -- pode se mover durante o entry do Stalk
        restoreSpeed()
        play(stalkEntryAnim)
    end
end

local function setupFlingTouched(figure)
    local function hookPart(part)
        local conn = part.Touched:Connect(function(hit)
            if not flingActive then return end
            if not hit or not hit.Parent then return end
            local target = hit.Parent
            if target:IsA("Accessory") then target = target.Parent end
            if target == figure then return end
            if not target:FindFirstChildOfClass("Humanoid") then return end
            ReanimateFling(target)
        end)
        table.insert(touchConns, conn)
    end
    for _, part in ipairs(figure:GetDescendants()) do
        if part:IsA("BasePart") then hookPart(part) end
    end
    table.insert(touchConns, figure.DescendantAdded:Connect(function(part)
        if part:IsA("BasePart") then hookPart(part) end
    end))
end

local function fireHitbox(anchorName, fwdOffset, upOffset, shapeType, radius)
    local anchor = figureRef and (figureRef:FindFirstChild(anchorName) or figureRef:FindFirstChild("HumanoidRootPart"))
    if not anchor then return end
    local pos = anchor.CFrame * CFrame.new(0, upOffset, fwdOffset)
    local hitPos = pos.Position
    local parts = shapeType == "Sphere"
        and workspace:GetPartBoundsInRadius(hitPos, radius)
        or  workspace:GetPartBoundsInBox(pos, Vector3.one * radius * 2)
    local hit = {}
    for _, part in parts do
        if part.Parent then
            local hum = part.Parent:FindFirstChildOfClass("Humanoid")
            if hum and not hit[part.Parent] then
                hit[part.Parent] = true
                ReanimateFling(part.Parent)
            end
        end
    end
end

-- ACTIONS
local function doSwing()
    if action then return end
    action = true
    actionName = "Swing"
    cleavePhase = 0
    actionStart = os.clock()
    actionDuration = swingAnim.track and swingAnim.track.Time or 1.0
    -- pode se mover durante o ataque
    restoreSpeed()
    play(swingAnim)
    flingActive = true
    if snd_Swing then snd_Swing:Play() end
    fireHitbox("HumanoidRootPart", -2, 0, "Caja", 4)
end

local function doCleave()
    if action then return end
    action = true
    actionName = "Cleave"
    cleavePhase = 1
    actionStart = os.clock()
    actionDuration = cleaveAnim.track and cleaveAnim.track.Time or 1.2
    -- pode se mover durante o ataque
    restoreSpeed()
    play(cleaveAnim)
    flingActive = true
    if snd_Cleave then snd_Cleave:Play() end
    fireHitbox("HumanoidRootPart", -2, 0, "Caja", 4)
end

local function doHowl()
    if action then return end
    action = true
    actionName = "Howl"
    cleavePhase = 0
    actionStart = os.clock()
    actionDuration = howlAnim.track and howlAnim.track.Time or 2.0
    -- pode se mover durante o ataque
    restoreSpeed()
    play(howlAnim)
    flingActive = false
    if snd_Howl then snd_Howl:Play() end
end

local function doStalk()
    if action then return end
    if not isStalking then
        startStalking()
    end
end

local function setSprint(sprinting)
    isSprinting = sprinting
    updateRunBtnVisual()
    -- sempre aplica velocidade (ataques não travam mais o movimento)
    restoreSpeed()
end

local function toggleSprint()
    setSprint(not isSprinting)
end

-- UI — layout da screenshot:
-- 4 botões centrados no fundo: Swing | Cleave | Howl | Stalk
-- Botão Run circular à direita
local function createPNGButtons()
    local player = game:GetService("Players").LocalPlayer
    local pg = player:WaitForChild("PlayerGui")

    gui = Instance.new("ScreenGui")
    gui.Name = "PursuerButtons"
    gui.ResetOnSpawn = false
    gui.Parent = pg

    local function makeAbilityButton(imageName, position, size, callback, name)
        local btn = Instance.new("ImageButton")
        btn.Name = name or imageName
        btn.Size = size
        btn.Position = position
        btn.AnchorPoint = Vector2.new(0.5, 1)
        btn.BackgroundColor3 = Color3.fromRGB(12, 12, 14)
        btn.BackgroundTransparency = 0.15
        btn.BorderSizePixel = 0
        btn.Image = AssetGetContentId(imageName)
        btn.ScaleType = Enum.ScaleType.Fit
        btn.Parent = gui

        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 8)
        corner.Parent = btn

        if callback then
            btn.MouseButton1Click:Connect(function()
                if not action then
                    callback()
                end
            end)
        end
        return btn
    end

    -- ===== 4 habilidades no fundo (ordem da foto) =====
    -- Swing | Cleave | Howl | Stalk
    local SIZE  = 72
    local GAP   = 10
    local Y_OFF = -24
    local totalW = (SIZE * 4) + (GAP * 3)
    local startX = -totalW / 2 + SIZE / 2

    makeAbilityButton("Swing_119451856807100.png",
        UDim2.new(0.5, startX + 0 * (SIZE + GAP), 1, Y_OFF),
        UDim2.new(0, SIZE, 0, SIZE), doSwing, "Swing")

    makeAbilityButton("Cleave_135005619881200.png",
        UDim2.new(0.5, startX + 1 * (SIZE + GAP), 1, Y_OFF),
        UDim2.new(0, SIZE, 0, SIZE), doCleave, "Cleave")

    makeAbilityButton("Howl_102103089289560.png",
        UDim2.new(0.5, startX + 2 * (SIZE + GAP), 1, Y_OFF),
        UDim2.new(0, SIZE, 0, SIZE), doHowl, "Howl")

    makeAbilityButton("Stalk_106723990557565.png",
        UDim2.new(0.5, startX + 3 * (SIZE + GAP), 1, Y_OFF),
        UDim2.new(0, SIZE, 0, SIZE), doStalk, "Stalk")

    -- ===== Botão Run circular (direita, como na foto) =====
    runBtn = Instance.new("ImageButton")
    runBtn.Name = "Run"
    runBtn.Size = UDim2.new(0, 64, 0, 64)
    runBtn.Position = UDim2.new(1, -90, 0.55, 0)
    runBtn.AnchorPoint = Vector2.new(0.5, 0.5)
    runBtn.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    runBtn.BackgroundTransparency = 0.35
    runBtn.BorderSizePixel = 0
    runBtn.Image = AssetGetContentId("Runbuttow_135198000760756.png")
    runBtn.ScaleType = Enum.ScaleType.Fit
    runBtn.ImageTransparency = 0.15
    runBtn.Parent = gui

    local runCorner = Instance.new("UICorner")
    runCorner.CornerRadius = UDim.new(1, 0) -- círculo
    runCorner.Parent = runBtn

    runBtn.MouseButton1Click:Connect(function()
        toggleSprint()
    end)

    updateRunBtnVisual()
end

local function startBackgroundMusic()
    if bgMusic then
        bgMusic:Stop()
        bgMusic:Destroy()
        bgMusic = nil
    end

    bgMusic = Instance.new("Sound")
    bgMusic.Name = "PursuerTheme"
    bgMusic.SoundId = AssetGetContentId("pursuer chase.mp3")
    bgMusic.Looped = true
    bgMusic.Volume = 0.5

    local player = game:GetService("Players").LocalPlayer
    if player then
        bgMusic.Parent = player:FindFirstChild("PlayerGui") or player
    else
        bgMusic.Parent = workspace
    end

    bgMusic:Play()
end

-- INIT
m.Init = function(figure)
    figureRef = figure
    local hrp = figure:FindFirstChild("HumanoidRootPart") or figure

    idleAnim       = loadAnim("idle pursuer.anim", true)
    walkAnim       = loadAnim("walk pursuer.anim", true)
    runAnim        = loadAnim("sprint pursuer.anim", true)
    swingAnim      = loadAnim("swing pursuer.anim", false)
    cleaveAnim     = loadAnim("Cleave pursuer.anim", false)
    cleaveEndAnim  = loadAnim("Pursuer cleave end.anim", false)
    howlAnim       = loadAnim("howl pursuer.anim", false)
    stalkEntryAnim = loadAnim("Stalk.anim", false)
    stalkIdleAnim  = loadAnim("StalkIdle.anim", true)
    stalkWalkAnim  = loadAnim("StalkWalk.anim", true)

    snd_Swing     = makeSound("swing.mp3", hrp, 1, false)
    snd_Cleave    = makeSound("pursuer cleave.mp3", hrp, 0.9, false)
    snd_CleaveEnd = makeSound("cleave end.mp3", hrp, 0.9, false)
    snd_Howl      = makeSound("howl.mp3", hrp, 1, false)
    sndStalk      = makeSound("stalk pursuer.mp3", hrp, 1, false)

    isStalking = false
    action = false
    flingActive = false
    isSprinting = false
    play(idleAnim)
    unfreeze()
    createPNGButtons()
    startBackgroundMusic()
    setupFlingTouched(figure)

    -- Sprint também por teclado (hold LeftControl)
    local cas = game:GetService("ContextActionService")

    cas:BindActionAtPriority("PURSUER_SPRINT", function(_, state)
        if state == Enum.UserInputState.Begin then
            setSprint(true)
        elseif state == Enum.UserInputState.End then
            setSprint(false)
        end
        return Enum.ContextActionResult.Sink
    end, false, 2000, Enum.KeyCode.LeftControl)
end

-- UPDATE
m.Update = function(dt, figure)
    if not figureRef then return end
    local hum = figureRef:FindFirstChildOfClass("Humanoid")
    if not hum then return end

    local now = os.clock()

    -- Stalk timer
    if isStalking then
        stalkTimer = stalkTimer - dt
        if stalkEntryTimer > 0 then
            stalkEntryTimer = stalkEntryTimer - dt
        end
        if stalkTimer <= 0 then
            endStalking()
        end
    end

    if action then
        -- mantém velocidade enquanto ataca (pode se mexer)
        restoreSpeed()
        if now - actionStart >= actionDuration then
            if actionName == "StalkEntry" then
                action = false
                actionName = nil
                stalkEntryTimer = 0
                if stalkEntryAnim then stalkEntryAnim.weight = 0 end
                unfreeze()
                play(stalkIdleAnim)
            elseif actionName == "Cleave" and cleavePhase == 1 then
                cleavePhase = 2
                actionName = "CleaveEnd"
                actionStart = now
                actionDuration = cleaveEndAnim.track and cleaveEndAnim.track.Time or 1.0
                play(cleaveEndAnim)
                if snd_CleaveEnd then snd_CleaveEnd:Play() end
            else
                action = false
                actionName = nil
                cleavePhase = 0
                flingActive = false
                stopAllAnimSounds()
                unfreeze()
                if isStalking then
                    play(stalkIdleAnim)
                else
                    play(idleAnim)
                end
            end
        end
    else
        -- Locomotion
        if isStalking and stalkEntryTimer <= 0 then
            if hum.MoveDirection.Magnitude > 0.1 then
                play(stalkWalkAnim)
            else
                play(stalkIdleAnim)
            end
            unfreeze()
        else
            if hum.MoveDirection.Magnitude > 0.1 then
                play(isSprinting and runAnim or walkAnim)
            else
                play(idleAnim)
            end
            unfreeze()
        end
    end

    -- Step anims
    local anims = {
        idleAnim, walkAnim, runAnim,
        swingAnim, cleaveAnim, cleaveEndAnim, howlAnim,
        stalkEntryAnim, stalkIdleAnim, stalkWalkAnim
    }
    for _, anim in ipairs(anims) do
        if anim and anim.weight > 0 and anim._start then
            anim:Step(now - anim._start)
        end
    end
end

-- DESTROY
m.Destroy = function()
    local cas = game:GetService("ContextActionService")
    cas:UnbindAction("PURSUER_SPRINT")

    for _, conn in ipairs(touchConns) do
        conn:Disconnect()
    end
    table.clear(touchConns)

    if bgMusic then
        bgMusic:Stop()
        bgMusic:Destroy()
        bgMusic = nil
    end

    stopAllAnimSounds()
    if snd_Swing     then snd_Swing:Stop()     snd_Swing:Destroy()     snd_Swing     = nil end
    if snd_Cleave    then snd_Cleave:Stop()    snd_Cleave:Destroy()    snd_Cleave    = nil end
    if snd_CleaveEnd then snd_CleaveEnd:Stop() snd_CleaveEnd:Destroy() snd_CleaveEnd = nil end
    if snd_Howl      then snd_Howl:Stop()      snd_Howl:Destroy()      snd_Howl      = nil end
    if sndStalk      then sndStalk:Stop()      sndStalk:Destroy()      sndStalk      = nil end

    if isStalking then endStalking() end
    if stalkHeadGlow then stalkHeadGlow:Destroy() stalkHeadGlow = nil end

    if gui then gui:Destroy() gui = nil end
    runBtn = nil

    local hum = figureRef and figureRef:FindFirstChildOfClass("Humanoid")
    if hum then hum.WalkSpeed = 16 end

    figureRef = nil
    currentAnim = nil
    action = false
    isSprinting = false
    isStalking = false
    flingActive = false
end

return m
end)

return modules
