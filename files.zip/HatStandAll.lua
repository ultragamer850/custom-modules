--==============================================================
-- HatStandAll.lua  (STANDALONE: no HatCore.lua needed)
-- Full module: every feature included.
-- Shared claim registry _G.__HatStandClaims still stops two modules grabbing the same hat.
--==============================================================

local modules = {}

local function makeHatModule(cfg)
	local SUF = cfg.suffix or ""
	local INSTANCE_ID = cfg.id or "ALL"
	_G.__HatStandClaims = _G.__HatStandClaims or setmetatable({}, { __mode = "k" })
	local Claims = _G.__HatStandClaims
	pcall(function() warn("[HatStand] module factory running: " .. tostring(cfg.name)) end)

	local m = {}
	m.ModuleType = "MOVESET"
	m.Name = cfg.name or "Hat Stand"
	m.Description = cfg.desc or "Stand + Link Rigs + JoJo loco v2 + dance list + Clone + 10-slot BTools (real FE) + orbit + Gaster + Weapons + Shield + Car + Ravenger Claws (Go-Kart is a separate moveset)."
	m.InternalName = cfg.internal or "HAT_STAND"
	m.Assets = {}

	m.Enabled = true
	m.UseWithOtherMovesets = true
	m.StopOnExit = true -- leaving the moveset fully stops loops, hats, sounds, connections
	m.FEMode = true

	m.ActiveMode = cfg.mode or 1
	m.StandInOrbitMode = (cfg.standInOrbit ~= false) -- only used by the All module
	m.ActiveModeNames = {
		"1 Stand",
		"2 Place (BTools)",
		"3 Hat Orbit",
		"4 All (Stand+Place+Orbit)",
		"5 Feature module (no Stand/Place/Orbit)",
	}

	-- Stand
	m.SideOffset = 3.5
	m.ForwardOffset = 0
	m.HeightOffset = 0
	m.Smoothness = 60
	m.FaceSameWay = true
	m.OrbitStand = false
	m.OrbitSpeed = 0.7
	m.OrbitRadius = 5
	m.AutoBuild = true
	m.AutoLimbHats = true
	m.AutoSpareHats = true
	m.AllowUsedHats = false
	m.Keybinds = true
	m.StandScale = 1
	m.AnimSpeed = 1.1
	m.ShowHatNames = true
	m.IdleStyle = 1
	m.IdleStyleNames = {
		"1 Breathe", "2 Bounce", "3 Combat Ready",
		"4 Sway Dance", "5 Float", "6 None", "7 Baller",
	}
	m.MethodIndex = 1
	m.MethodNames = {
		"1 Side Stand", "2 Front Stand", "3 Orbit Stand",
		"4 Mirror Stand", "5 Freeze Place",
	}
	m.HatHead = ""
	m.HatTorso = ""
	m.HatLeftArm = ""
	m.HatRightArm = ""
	m.HatLeftLeg = ""
	m.HatRightLeg = ""
	m.SelectedOtherMoveset = ""
	m.PreviewText = "(refresh hats)"

	m.RotHeadX, m.RotHeadY, m.RotHeadZ = 0, 0, 0
	m.RotTorsoX, m.RotTorsoY, m.RotTorsoZ = 0, 0, 0
	m.RotLeftArmX, m.RotLeftArmY, m.RotLeftArmZ = 0, 0, 0
	m.RotRightArmX, m.RotRightArmY, m.RotRightArmZ = 0, 0, 0
	m.RotLeftLegX, m.RotLeftLegY, m.RotLeftLegZ = 0, 0, 0
	m.RotRightLegX, m.RotRightLegY, m.RotRightLegZ = 0, 0, 0

	-- Per-limb position offsets (side / up / forward) — move head, arms, torso, legs freely
	m.OffHeadX, m.OffHeadY, m.OffHeadZ = 0, 0, 0
	m.OffTorsoX, m.OffTorsoY, m.OffTorsoZ = 0, 0, 0
	m.OffLeftArmX, m.OffLeftArmY, m.OffLeftArmZ = 0, 0, 0
	m.OffRightArmX, m.OffRightArmY, m.OffRightArmZ = 0, 0, 0
	m.OffLeftLegX, m.OffLeftLegY, m.OffLeftLegZ = 0, 0, 0
	m.OffRightLegX, m.OffRightLegY, m.OffRightLegZ = 0, 0, 0

	m.ShowLimbPreview = false

	m.AutoCorrectDist = 25
	m.AutoCorrect = true

	-- Walk / Dance
	m.WalkWithMe = false
	m.WalkSideOffset = 2.8
	m.WalkForwardOffset = 0.5
	m.WalkHeightOffset = 0
	m.WalkSmoothness = 18
	m.WalkStrength = 1.0
	m.RunStrength = 1.15
	m.JumpStrength = 1.2
	m.WalkCycleSpeed = 8.5
	m.RunCycleSpeed = 12.5
	m.JumpHoldPose = true
	m.RunThreshold = 14
	m.DanceSync = true
	m.DanceStrength = 1.0
	m.DanceKey = true
	m.BallerMode = false
	m.BigRigFix = true
	m.BigRigArmSpread = 1.55
	m.BigRigLegSpread = 0.55
	m.BigRigHeight = 1.0
	m.FixAnyRigPose = true
	m.DanceMirrorCharacter = true

	-- v14: Link / Stand moveset / Loco v2
	m.LinkRigs = false
	m.LinkStrength = 1.0
	m.LinkSmooth = 26
	m.LinkSource = 1
	m.LinkSourceNames = { "1 Auto (Uhhhhhh rig, then avatar)", "2 Uhhhhhh rig only", "3 Avatar only" }
	m.StrictHats = true
	m.SelectFirst = false -- stand/clone auto-grab hats on build (set true if you want to pick hats first)
	m.PoseFix = true
	m.PoseAutoCalib = true
	m.PoseSnapAfterDance = true
	m.PoseSwapArms = false
	m.PoseInvertArmRoll = false
	m.PoseInvertArmPitch = false
	m.StandMoveset = 2
	m.StandMovesetNames = {
		"1 Linked (copy my moveset + dances)", "2 JoJo Stand", "3 Combat Ready", "4 Procedural Dance",
	}
	m.ProcDance = 1
	m.ProcDanceNames = { "1 Sway", "2 Floss", "3 Robot", "4 Disco", "5 Hype", "6 Wave" }
	m.SelectedDance = ""
	m.JojoLoco = true
	m.LocoBlend = 14
	m.LocoLean = 1.0
	m.LocoBob = 1.0
	m.LocoArmOut = 1.0
	m.FallSpread = 1.0
	m.LandSquash = 1.0

	-- v14: Clone (second body from spare hats) + 10 accessory slots with rot/offset/effects
	m.CloneEnabled = false
	m.CloneSide = -3.5
	m.CloneForward = 0.5
	m.CloneHeight = 0
	m.CloneSmooth = 22
	m.CloneFaceSame = true
	m.CloneAutoHats = true
	m.CloneHatHead = ""
	m.CloneHatTorso = ""
	m.CloneHatLeftArm = ""
	m.CloneHatRightArm = ""
	m.CloneHatLeftLeg = ""
	m.CloneHatRightLeg = ""
	-- per-limb rotation & position for clone (independent of stand)
	m.CloneRotHeadX, m.CloneRotHeadY, m.CloneRotHeadZ = 0, 0, 0
	m.CloneRotTorsoX, m.CloneRotTorsoY, m.CloneRotTorsoZ = 0, 0, 0
	m.CloneRotLeftArmX, m.CloneRotLeftArmY, m.CloneRotLeftArmZ = 0, 0, 0
	m.CloneRotRightArmX, m.CloneRotRightArmY, m.CloneRotRightArmZ = 0, 0, 0
	m.CloneRotLeftLegX, m.CloneRotLeftLegY, m.CloneRotLeftLegZ = 0, 0, 0
	m.CloneRotRightLegX, m.CloneRotRightLegY, m.CloneRotRightLegZ = 0, 0, 0
	m.CloneOffHeadX, m.CloneOffHeadY, m.CloneOffHeadZ = 0, 0, 0
	m.CloneOffTorsoX, m.CloneOffTorsoY, m.CloneOffTorsoZ = 0, 0, 0
	m.CloneOffLeftArmX, m.CloneOffLeftArmY, m.CloneOffLeftArmZ = 0, 0, 0
	m.CloneOffRightArmX, m.CloneOffRightArmY, m.CloneOffRightArmZ = 0, 0, 0
	m.CloneOffLeftLegX, m.CloneOffLeftLegY, m.CloneOffLeftLegZ = 0, 0, 0
	m.CloneOffRightLegX, m.CloneOffRightLegY, m.CloneOffRightLegZ = 0, 0, 0
	-- 10 extra accessory slots on the clone (hand/weapon/effect style)
	for i = 1, 10 do
		m["CloneSlotHat" .. i] = ""
		m["CloneSlotOffX" .. i] = 0
		m["CloneSlotOffY" .. i] = (i - 1) * 0.4 - 1.8
		m["CloneSlotOffZ" .. i] = 0
		m["CloneSlotRotX" .. i] = 0
		m["CloneSlotRotY" .. i] = 0
		m["CloneSlotRotZ" .. i] = 0
		m["CloneSlotKind" .. i] = 1 -- 1 float 2 weapon 3 effect 4 hand
	end
	m.CloneSlotKindNames = { "1 Float", "2 Weapon", "3 Effect", "4 Hand" }

	-- clone slots: 15 total (10 original + 5 new)
	for i = 11, 15 do
		m["CloneSlotHat" .. i] = ""
		m["CloneSlotOffX" .. i] = 0
		m["CloneSlotOffY" .. i] = (i - 11) * 0.4 - 1.8
		m["CloneSlotOffZ" .. i] = 0
		m["CloneSlotRotX" .. i] = 0
		m["CloneSlotRotY" .. i] = 0
		m["CloneSlotRotZ" .. i] = 0
		m["CloneSlotKind" .. i] = 1
	end

	-- Own dance (record Steve's Uhhhhhh dance, then stand / clone replay it by themselves)
	m.OwnDanceSpeed = 1
	m.OwnDanceLoop = true
	m.OwnDanceSounds = true
	m.OwnDanceBlend = 30
	m.OwnDanceRecSecs = 12

	-- Low-lag
	m.LowLag = true
	m.LowLagSkip = 2
	m.HatsSolid = false -- EVERY hat I wear becomes solid: hits / pushes NPCs, dummies and any unanchored part I simulate
	m.HatsSolidPush = 1 -- multiplies the real hat velocity that gets applied on contact
	m.HatsSolidIgnorePlayers = true -- no collision with other players
	m.HatsSolidBoost = true -- huge simulation radius so nearby unanchored parts are simulated by me

	-- TITAN (body from hats, placed every frame like Hellcopter)
	m.TitanEnabled = false
	m.TitanScale = 3.5
	m.TitanSmooth = 22
	m.TitanSide, m.TitanHeight, m.TitanForward = 0, 0, 0
	m.TitanRotX, m.TitanRotY, m.TitanRotZ = 0, 0, 0
	m.TitanHatCore = ""
	m.TitanCoreOffX, m.TitanCoreOffY, m.TitanCoreOffZ = 0, 1.0, -0.35
	m.TitanCoreRotX, m.TitanCoreRotY, m.TitanCoreRotZ = 0, 0, 0
	m.TitanHatHead = ""
	m.TitanHatTorso = ""
	m.TitanHatLeftArm = ""
	m.TitanHatRightArm = ""
	m.TitanHatLeftLeg = ""
	m.TitanHatRightLeg = ""
	m.TitanHatJetpack = ""
	m.TitanJetpackOffX, m.TitanJetpackOffY, m.TitanJetpackOffZ = 0, 0.4, 1.4
	m.TitanJetpackRotX, m.TitanJetpackRotY, m.TitanJetpackRotZ = 0, 0, 0
	m.TitanFly = false
	m.TitanFlySpeed = 70
	m.TitanAnim = true
	m.TitanAnimSpeed = 1
	m.TitanAutoRebuild = true
	m.TitanRebuildDelay = 0.08 -- seconds between auto-rebuild checks (lower = faster)
	m.TitanShieldEnabled = false
	m.TitanShieldHat = ""
	m.TitanShieldOffX, m.TitanShieldOffY, m.TitanShieldOffZ = 0, 1, -2.5
	-- Core FIRE: burst hat out fast, trail, snap back to core
	m.TitanCoreFireEnabled = true
	m.TitanCoreFireHat = "" -- hat used as the flame / projectile
	m.TitanCoreTrailHat = "" -- optional second hat for trailing behind the burst
	m.TitanCoreFireDist = 40
	m.TitanCoreFireSpeed = 180 -- outward speed
	m.TitanCoreFireReturn = 220 -- snap-back speed
	m.TitanCoreFireCooldown = 0.45
	m.TitanCoreFireCount = 1 -- how many bursts
	m.KeyTitanFly = "T"
	m.KeyTitanCoreFire = "Y"
	for _, limb in ipairs({ "Head", "Torso", "LeftArm", "RightArm", "LeftLeg", "RightLeg" }) do
		m["TitanOff" .. limb .. "X"] = 0
		m["TitanOff" .. limb .. "Y"] = 0
		m["TitanOff" .. limb .. "Z"] = 0
		m["TitanRot" .. limb .. "X"] = 0
		m["TitanRot" .. limb .. "Y"] = 0
		m["TitanRot" .. limb .. "Z"] = 0
	end
	m.TitanStyle = 1
	m.TitanStyleNames = { "1 Titan Cameraman", "2 Titan Speakerman", "3 Titan TV Man", "4 Custom" }

	-- HELLCOPTER (frames + propellers + weapons with hat bullets + physics ride)
	m.HeliEnabled = false
	m.HeliRide = false
	m.HeliEngine = false
	m.HeliAutoStart = true
	m.HeliPhysics = true
	m.HeliHoverAssist = true
	m.HeliAutoRebuild = true
	m.HeliSide, m.HeliHeight, m.HeliForward, m.HeliRotY = 8, 2, 0, 0
	m.HeliSeatOffY = -1.0
	m.HeliSmooth = 14
	m.HeliMaxSpeed = 120
	m.HeliClimb = 45
	m.HeliYawRate = 1.8
	m.HeliAccel = 2.5
	m.HeliTilt = 22
	m.HeliSpoolUp = 4
	m.HeliSpoolDown = 6
	m.HeliGravity = 1.0
	m.HeliCamLock = false
	m.HeliCamSmooth = 10
	m.HeliSFX = true
	m.HeliVolume = 1.0
	m.HeliPitch = 1
	m.HeliEngineMode = 1 -- 1 startup + idle (Roblox ids), 2 generated sound
	m.HeliEngineModeNames = { "1 Startup + Idle (your ids)", "2 Generated" }
	m.HeliStartSFXId = "rbxassetid://130598569401747" -- helicopter turn on
	m.HeliIdleSFXId = "rbxassetid://9073648220" -- helicopter idle loop
	m.HeliMiniSFX = true
	m.HeliMiniVolume = 1
	m.HeliMiniLoopId = "rbxassetid://138382899505069" -- minigun shoot loop
	m.HeliMiniStopId = "rbxassetid://130364388010467" -- minigun shoot stop
	m.KeyHeliRide = "F6" -- rebindable: Heli Ride (mount/dismount)
	m.KeyHeliEngine = "F7"
	m.KeyHeliFire = "F8"
	for i = 1, 12 do
		m["HeliFrameHat" .. i] = ""
		for _, p in ipairs({ "OffX", "OffY", "OffZ", "RotX", "RotY", "RotZ" }) do m["HeliFrame" .. p .. i] = 0 end
	end
	for i = 1, 4 do
		m["HeliPropHat" .. i] = ""
		for _, p in ipairs({ "OffX", "OffY", "OffZ", "RotX", "RotY", "RotZ" }) do m["HeliProp" .. p .. i] = 0 end
		m["HeliPropAxis" .. i] = 2
		m["HeliPropSpd" .. i] = 40
	end
	for i = 1, 4 do
		m["HeliWpnHat" .. i] = ""
		m["HeliWpnBullet" .. i] = ""
		m["HeliWpnBullet2" .. i] = ""
		m["HeliWpnFire" .. i] = true
		for _, p in ipairs({ "OffX", "OffY", "OffZ", "RotX", "RotY", "RotZ" }) do m["HeliWpn" .. p .. i] = 0 end
	end
	m.HeliAxisNames = { "1 X", "2 Y", "3 Z" }
	m.HeliFireStyle = 2
	m.HeliFireStyleNames = { "1 Single (click)", "2 Rapid", "3 Minigun", "4 Triple burst" }
	m.HeliBulletSpeed = 260
	m.HeliBulletRange = 260
	m.HeliCooldown = 0.14
	m.HeliSpread = 1.5
	m.HeliBulletSpin = true
	m.HeliTrail = true
	m.HeliBulletFallback = true
	m.HeliAimMouse = true
	m.HeliFireSFX = true
	m.HeliBulletRotX, m.HeliBulletRotY, m.HeliBulletRotZ = 0, 0, 0
	m.HeliFly = true -- off = the hellcopter can't be ridden / flown (P toggles, rebindable)
	m.KeyHeliOff = "P"
	m.HeliRebuildDelay = 0.1 -- seconds between auto-rebuild checks (how fast lost hats get put back)
	-- missile launcher
	m.HeliMissileEnabled = true
	m.KeyHeliMissile = "R"
	m.HeliMissileSFX = true
	m.HeliMissileVolume = 1 -- master
	m.HeliMissileLockVol = 0.8 -- lock-on beep
	m.HeliMissileLockSpeed = 1 -- lock sound playback speed (1 = normal)
	m.HeliMissileLockKeep = true -- lock sound keeps playing while locked, stops when the lock is lost
	m.HeliMissileLoopVol = 1 -- missile flying loop
	m.HeliMissileExplodeVol = 1 -- explosion
	m.HeliMissileLockSFXId = "rbxassetid://80778827175175" -- GTA V missile lock sound (loops while locking)
	m.HeliMissileExplodeSFXId = "rbxassetid://134741557832342" -- loud missile explosion
	m.HeliMissileLoopSFXId = "rbxassetid://117162697204649" -- missile flying loop
	m.HeliMissileCooldown = 1.5
	m.HeliMissileSpeed = 150
	m.HeliMissileTurn = 3.5
	m.HeliMissileLife = 8
	m.HeliMissileRange = 600
	m.HeliMissileLockTime = 1.0
	m.HeliMissileLockRadius = 140
	m.HeliMissileExplosion = true
	m.HeliMissileExplosionSize = 12
	m.HeliMissileNPC = false
	m.HeliMissileRotX, m.HeliMissileRotY, m.HeliMissileRotZ = 0, 0, 0
	for i = 1, 4 do m["HeliMissileHat" .. i] = "" end
	-- missile launcher hats (the visible launchers mounted on the helicopter): hat + position + rotation each
	m.HeliLaunchAim = true -- launchers swing toward your lock target / mouse
	m.HeliLaunchSmooth = false -- false = stays rigidly in place on the helicopter, true = smooth follow (lags a little)
	m.HeliLaunchSmoothSpeed = 6
	m.KeyHeliLauncher = "T" -- missile launcher ON / OFF (armed / disarmed)
	for i = 1, 4 do -- each missile can have its own position + rotation
		m["HeliMissileOffX" .. i], m["HeliMissileOffY" .. i], m["HeliMissileOffZ" .. i] = 0, 0, 0
		m["HeliMissileRotX" .. i], m["HeliMissileRotY" .. i], m["HeliMissileRotZ" .. i] = 0, 0, 0
	end
	for i = 1, 2 do
		m["HeliLaunchHat" .. i] = ""
		m["HeliLaunchOffX" .. i] = (i == 1) and -2.5 or 2.5
		m["HeliLaunchOffY" .. i], m["HeliLaunchOffZ" .. i] = -1, 0
		m["HeliLaunchRotX" .. i], m["HeliLaunchRotY" .. i], m["HeliLaunchRotZ" .. i] = 0, 0, 0
	end
	-- mouse flight control
	m.HeliMouseCtl = false
	m.HeliMouseMode = 1
	m.HeliMouseModeNames = { "1 Flight stick (cursor left/right of center turns)", "2 Face the mouse (heli turns toward where the mouse points)" }
	m.HeliMouseSens = 1.5
	m.HeliMouseDead = 0.12
	m.HeliMouseClimb = false -- cursor above / below screen center = climb / descend
	m.KeyHeliMouse = "F9"
	m.HeliHoming = true -- bullets curve toward the mouse (mouse tracker)
	m.HeliSolid = false -- heli hats become solid so they hit / push NPCs and dummies
	m.HeliSolidFrames, m.HeliSolidProps, m.HeliSolidWpns = true, true, true
	m.HeliSolidPush = 1 -- how hard the moving hats push (multiplies the heli's real velocity)
	m.HeliSolidIgnorePlayers = true -- never collide with other players (only NPCs / dummies / map)
	m.HeliSolidBoost = true -- keep the simulation radius huge so nearby NPC parts are simulated by me
	m.HeliAimAssist = true -- aim snaps onto a player / NPC / missile near the cursor (bullets chase it instead of the ground behind it)
	m.HeliAimAssistRadius = 90 -- pixels around the cursor
	m.HeliHomingStrength = 4
	m.HeliTrailColor = 1
	m.HeliTrailColorNames = { "1 Fire orange", "2 Ice blue", "3 Toxic green", "4 Purple", "5 Red", "6 White", "7 Rainbow" }
	m.HeliTrailLife = 0.35
	m.HeliTrailWidth = 1.2
	for i = 1, 8 do m["HeliAmmoHat" .. i] = "" end -- shared bullet hats: any weapon can shoot these
	-- group offsets: move ALL frames / ALL propellers / ALL weapons together (side, up/down, forward/back)
	for _, g in ipairs({ "HeliFramesAll", "HeliPropsAll", "HeliWpnsAll" }) do
		m[g .. "X"], m[g .. "Y"], m[g .. "Z"] = 0, 0, 0
	end


	-- Place
	m.PlaceEnabled = false
	m.PlacePreviewOn = true
	m.PlaceSpin = false
	m.PlaceSpinSpeed = 2.0
	m.PlaceBob = false
	m.PlaceBobSpeed = 1.5
	m.PlaceBobHeight = 0.4
	m.PlaceSnapGrid = 0
	m.PlaceMax = 80
	m.PlaceActiveSlot = 1
	m.PlaceBuildAnim = true
	m.PlaceBuildAnimSpeed = 1.2
	m.PlacePersist = true
	m.PlaceLock = true -- placed real hats stay: kept visible, repaired, and re-grabbed if the rig reloads
	m.PlaceCustomAnim = true
	m.PlaceYeetForce = 80
	m.PlaceYeetUp = 40
	m.PlaceUndergroundOnSelect = false -- when you pick a place slot, stash that hat underground until place
	m.PlaceUndergroundDepth = 12
	m.PlaceUndergroundSpeed = 0.25 -- rise/sink time
	m.PlaceStayAfterRespawn = true -- even on loop respawns, placed hats stay at last CF
	m.PlaceSolid = true -- placed / built hats are solid: your rig can stand and walk on them
	for i = 1, 10 do
		m["PlaceHat" .. i] = ""
		m["PlaceRot" .. i .. "X"] = 0
		m["PlaceRot" .. i .. "Y"] = 0
		m["PlaceRot" .. i .. "Z"] = 0
		m["PlaceOff" .. i .. "X"] = 0
		m["PlaceOff" .. i .. "Y"] = 0
		m["PlaceOff" .. i .. "Z"] = 0
	end
	-- BTools Build Modes (presets that arrange place slots into structures)
	m.BToolsMode = 1
	m.BToolsModeNames = {
		"1 Free / Manual", "2 Wall", "3 Floor", "4 House", "5 Tower",
		"6 Bridge", "7 Platform", "8 Stairs", "9 Fence", "10 Gate",
		"11 Car Frame", "12 Helicopter", "13 Boat", "14 Plane", "15 Throne",
		"16 Arch", "17 Pyramid", "18 Dome", "19 Ring", "20 Fort",
		"21 Table", "22 Chair", "23 Cage", "24 Ramp", "25 Spiral Stairs",
		"26 Double Wall", "27 Corridor", "28 Zigzag Wall", "29 Descending Stairs", "30 Pillars",
		"31 Cross", "32 X Shape", "33 Diamond", "34 Star", "35 Heart",
		"36 Floor Spiral", "37 Double Ring", "38 Cube Frame", "39 Skyscraper", "40 Windmill",
		"41 Pen / Enclosure", "42 Ziggurat", "43 Lighthouse", "44 Totem", "45 Couch",
		"46 Bench", "47 Shelf", "48 Ladder", "49 Slide", "50 Half-Pipe",
		"51 Vertical Loop", "52 Wave Wall", "53 Snake Path", "54 Parkour Path", "55 Bed",
		"56 Bunker", "57 Pier", "58 Torii Gate", "59 Crown", "60 Ferris Wheel",
		"61 Rocket", "62 Hourglass", "63 DNA Helix", "64 Tornado", "65 Podium",
	}
	m.BToolsScale = 1.0 -- overall size of preset
	m.BToolsSpacing = 2.5 -- stud spacing between parts
	m.BToolsPreviewAll = true -- show full structure ghost preview
	m.BToolsClickBuild = true -- click / Y places the WHOLE structure from every filled Place Slot
	m.BToolsCarry = false -- after build, carry the whole structure with you
	m.BToolsCarrySmooth = 14
	m.BToolsBuildName = "MyBuild"
	m.BToolsSavedBuilds = {} -- { name = { slots = { {hat,offX,offY,offZ,rotX,rotY,rotZ}, ... } } }
	m.BToolsLastSaved = ""

	-- Orbit (per-slot extras) — Undertale Finale style + modes
	m.OrbitEnabled = false
	for i = 1, 10 do
		m["OrbitHat" .. i] = ""
		m["OrbitSpdMult" .. i] = 1
		m["OrbitRadOff" .. i] = 0
		m["OrbitRotX" .. i] = 0
		m["OrbitRotY" .. i] = 0
		m["OrbitRotZ" .. i] = 0
		m["OrbitVertOff" .. i] = 0 -- per-slot vertical offset
	end
	m.OrbitRad = 6
	m.OrbitSpd = 1.0
	m.OrbitH = 2.0
	m.OrbitFaceOut = true
	m.OrbitSpinSelf = false
	m.OrbitSpinSelfSpd = 3
	m.OrbitMode = 1 -- 1..30+ modes
	m.OrbitModeNames = {
		"1 Circle", "2 Line", "3 Solar System", "4 Figure-8", "5 Helix",
		"6 Wave", "7 Spiral", "8 Ring Stack", "9 Random Drift", "10 Undertale Finale",
		"11 Rose Curve", "12 Infinity", "13 DNA Double Helix", "14 Cube Faces", "15 Pyramid",
		"16 Star Path", "17 Tornado", "18 Butterfly", "19 Flower Bloom", "20 Orbit Rings",
		"21 Sine Weave", "22 Pendulum", "23 Galaxy Spiral", "24 Grid Lattice", "25 Sphere Surface",
		"26 Triangle Path", "27 Heart Shape", "28 Cross Orbit", "29 Chaotic Swarm", "30 Rain Fall",
		"31 Vertical Circle", "32 Horizontal Figure-8", "33 Expanding Pulse", "34 Zigzag", "35 Crown Arc",
		"36 Vertical Figure-8", "37 Angel Wings", "38 Halo", "39 Saturn Ring", "40 Atom",
		"41 Gyroscope", "42 Shield Arc (front)", "43 Cape Arc (back)", "44 Elevator Ring", "45 Bounce Ring",
		"46 Square Path", "47 Hexagon Path", "48 Pentagram Path", "49 Spirograph", "50 Lissajous",
		"51 Trefoil Knot", "52 Torus Knot", "53 Hourglass Swirl", "54 Cone", "55 Funnel",
		"56 Fountain", "57 Bubbles", "58 Conga Line", "59 Snake Weave", "60 Comet Ellipse",
		"61 Shockwave", "62 Counter-Rotate", "63 Forward Wheel", "64 Triple Helix", "65 Fibonacci Sphere",
		"66 Möbius Strip", "67 Dual Ring", "68 Orbit Ladder", "69 Pulsar", "70 Diamond Path",
		"71 Crescent Moon", "72 Vortex Tunnel", "73 Ribbon Wave", "74 Cage Box", "75 Solar Flare",
		"76 Twin Orbit", "77 Vertical Helix", "78 Orbit Cascade", "79 Star Cross", "80 Planetary Dance",
	}
	m.OrbitVertical = true -- allow up/down motion
	m.OrbitVertAmp = 1.5 -- amplitude of vertical bob/orbit
	m.OrbitVertSpd = 0.8
	m.OrbitFinalePulse = true -- finale mode: pulse radius like Undyne/Finale
	m.OrbitFinalePulseAmt = 2.0
	m.OrbitFinalePulseSpd = 2.5
	m.OrbitAutoRebuild = true -- auto rebuild when hats change / slot set

	-- Gaster Blaster
	m.GasterEnabled = false
	m.GasterHat = "" -- legacy / slot 1 fallback
	m.GasterActiveSlot = 1
	for i = 1, 5 do
		m["GasterHat" .. i] = ""
		m["GasterSide" .. i] = 4.5 + (i - 1) * 0.8
		m["GasterHeight" .. i] = 1.2
		m["GasterForward" .. i] = -1
		m["GasterRotX" .. i] = 0
		m["GasterRotY" .. i] = 0
		m["GasterRotZ" .. i] = 0
		m["GasterFire" .. i] = true -- included in fire rotation
	end
	m.GasterSide = 4.5
	m.GasterHeight = 1.2
	m.GasterForward = -1
	m.GasterSize = 1.4
	m.GasterLaserLength = 80
	m.GasterLaserThick = 1.2
	m.GasterCooldown = 1.4
	m.GasterChargeTime = 0.35
	m.GasterPush = 45
	m.GasterColor = Color3.fromRGB(255, 255, 255)
	m.GasterUseHatBullet = false -- toggle: fire real hat bullet instead of / with laser
	m.GasterHatBullet = "" -- hat to use as bullet
	m.GasterTrailOsc = true -- after fire: hat bullet goes back & forth creating trails
	m.GasterTrailOscSpeed = 18 -- how fast the oscillation
	m.GasterTrailOscDist = 12 -- distance of back-forth
	m.GasterTrailOscTime = 1.2 -- how long oscillation lasts
	m.GasterSFX = true
	m.GasterSFXId = "rbxassetid://138081500" -- charge-ish default (change freely)
	m.GasterFireSFXId = "rbxassetid://138081308"
	m.GasterVolume = 1.0
	m.GasterTrackMouse = true -- aim / orient blasters toward mouse
	m.GasterTrackOnlyFire = false -- if true, only track while charging/firing
	m.GasterFireMode = 1 -- 1 = active slot only, 2 = all enabled slots at once
	m.GasterFireModeNames = { "1 Active slot only", "2 All enabled slots at once" }

	-- Bone attack (hat-based, Sans-style)
	m.BoneEnabled = false
	m.BoneHat = ""
	m.BoneSide = -3.5
	m.BoneHeight = 0.5
	m.BoneForward = -1
	m.BoneCount = 5 -- how many bones spawn in a row
	m.BoneSpread = 2.5
	m.BoneSpeed = 90
	m.BoneLife = 1.8
	m.BoneCooldown = 0.9
	m.BoneRise = 0.25
	m.BoneColor = Color3.fromRGB(255, 255, 255)
	m.BoneUseRealHat = true -- use the real FE hat as the bone projectile
	m.BoneSFX = true
	m.BoneSFXId = "rbxassetid://138081308"
	m.BoneVolume = 0.9
	m.BoneTrackMouse = true
	-- Sans attacks (Gaster / Bone / Omega): hats sit underground until you fire, then rise + attack + sink
	m.SansUnderground = true
	m.SansStashDepth = 12
	m.SansStashRise = 0.35
	m.SansStashHold = 1.0

	-- Omega Blaster (big dual/single hat blast)
	m.OmegaEnabled = false
	m.OmegaHat = ""
	m.OmegaHat2 = "" -- second hat when dual mode
	m.OmegaDual = true -- toggle: 2 bullets/blasters or 1
	m.OmegaSide = 0
	m.OmegaHeight = 2.5
	m.OmegaForward = -2
	m.OmegaSize = 2.2
	m.OmegaLaserLength = 120
	m.OmegaLaserThick = 2.4
	m.OmegaCooldown = 2.2
	m.OmegaChargeTime = 0.55
	m.OmegaPush = 80
	m.OmegaColor = Color3.fromRGB(180, 220, 255)
	m.OmegaTrackMouse = true
	m.OmegaSFX = true
	m.OmegaSFXId = "rbxassetid://138081500"
	m.OmegaFireSFXId = "rbxassetid://138081308"
	m.OmegaVolume = 1.2
	m.OmegaSpread = 3.5 -- horizontal split when dual
	m.OmegaRotX, m.OmegaRotY, m.OmegaRotZ = 0, 0, 0
	m.OmegaTrackOnlyFire = false -- if true, only aim at mouse while charging/firing
	m.OmegaStashDepth = 0 -- 0 = use SansStashDepth
	m.OmegaStashRise = 0 -- 0 = use SansStashRise
	m.OmegaStashHold = 0 -- 0 = use SansStashHold
	m.OmegaRiseBeforeFire = true -- wait until fully up before laser
	m.OmegaUseHatBullet = false -- fly a real hat down each beam
	m.OmegaActiveSlot = 1
	m.OmegaFireMode = 2 -- 1 = active slot only, 2 = all enabled slots at once
	m.OmegaFireModeNames = { "1 Active slot only", "2 All enabled slots at once" }
	m.OmegaTrailOsc = true -- after the hat bullet reaches the end it goes back & forth along the beam
	m.OmegaTrailOscSpeed = 18
	m.OmegaTrailOscDist = 12
	m.OmegaTrailOscTime = 1.2
	do
		local sides = { -1.75, 1.75, -5.25, 5.25, 0 }
		local heights = { 2.5, 2.5, 3.5, 3.5, 5 }
		for i = 1, 5 do
			if i >= 3 then
				m["OmegaHat" .. i] = ""
				m["OmegaBulletHat" .. i] = ""
			end
			m["OmegaSide" .. i] = sides[i]
			m["OmegaHeight" .. i] = heights[i]
			m["OmegaForward" .. i] = -2
			m["OmegaRotX" .. i] = 0
			m["OmegaRotY" .. i] = 0
			m["OmegaRotZ" .. i] = 0
			m["OmegaFire" .. i] = true
		end
	end
	m.KeyOmegaCycle = "O"
	m.KeySansToggle = "U" -- sink / raise ALL sans attacks (Gaster + Bone + Omega)
	m.OmegaBulletHat = "" -- bullet hat for blaster 1
	m.OmegaBulletHat2 = "" -- bullet hat for blaster 2 (dual)
	m.OmegaBulletSpeed = 220
	m.OmegaBulletSpin = true
	m.OmegaBulletTrail = true
	m.OmegaKeepUpWhileCharge = true -- stay up for whole charge + hold

	-- Weapons (10 slots, all float next to you; each has its own hat / position / rotation)
	m.WeaponEnabled = false
	m.WeaponStayUp = false -- toggle: weapons stay raised above you until you turn this off
	m.WeaponStayUpHeight = 3.5 -- extra height when Stay Up is ON
	m.WeaponActiveSlot = 1
	m.WeaponFloatSide = 1.8
	m.WeaponFloatHeight = 0.6
	m.WeaponFloatForward = -0.4
	m.WeaponRotX, m.WeaponRotY, m.WeaponRotZ = 0, 90, 0
	m.WeaponFireSpeed = 120
	m.WeaponFireCooldown = 0.25
	m.WeaponBulletLife = 2.5
	for i = 1, 10 do
		m["WeaponHat" .. i] = ""
		m["WeaponBullet" .. i] = 1 -- 1=beam 2=orb 3=spike 4=hat
		m["WeaponBulletHat" .. i] = ""
		m["WeaponFire" .. i] = (i <= 6) -- in the fire rotation (max 6 enabled)
		m["WeaponOffsetX" .. i] = 0
		m["WeaponOffsetY" .. i] = (i - 1) * 0.5 - 2.25 -- spread so slots do not stack
		m["WeaponOffsetZ" .. i] = 0
		m["WeaponRot" .. i .. "X"] = 0
		m["WeaponRot" .. i .. "Y"] = 0
		m["WeaponRot" .. i .. "Z"] = 0
	end
	m.WeaponBulletNames = { "1 Beam", "2 Orb", "3 Spike", "4 Hat", "5 Gaster Blaster", "6 Laser" }
	m.WeaponAntiSnap = true -- keep weapon / bullet hats free of Uhhhhhh (re-apply position pre-physics + before render)
	m.WeaponTrackMouse = true
	m.WeaponTrackMode = 2 -- 1 always, 2 only while firing (plus hold time)
	m.WeaponTrackModeNames = { "1 Always track mouse", "2 Only when I use the weapon" }
	m.WeaponTrackStrength = 1
	m.WeaponTrackSmooth = 12
	m.WeaponTrackPitch = true
	m.WeaponTrackHold = 1.5
	m.WeaponAimMouse = true
	m.WeaponAutoFire = false
	m.WeaponMuzzleFlash = true
	m.WeaponRecoil = 0.6
	m.WeaponRecoilSpeed = 7
	m.WeaponBobAmt = 0
	m.WeaponBobSpeed = 2
	m.WeaponFireMode = 1 -- 1 = one bullet per press, rotating through enabled slots; 2 = all enabled slots at once
	m.WeaponFireModeNames = { "1 One then next (rotate)", "2 All enabled at once" }
	m.UndergroundStash = false -- weapons / hat bullets / Gaster / blaster wait underground until used
	m.StashDepth = 10
	m.StashRise = 0.3
	m.StashHold = 1.2
	m.WeaponBlasterScale = 1
	m.WeaponBlasterCharge = 0.5
	m.WeaponLaserLength = 200
	m.WeaponLaserTime = 0.2
	m.WeaponRealHat = true -- hat bullets are the real FE hat (flies out and returns); off = local clones
	m.WeaponBulletSize = 1
	m.WeaponBulletR, m.WeaponBulletG, m.WeaponBulletB = 255, 220, 80
	m.WeaponBulletSpin = 0
	m.WeaponHoming = 0
	m.WeaponGravity = 0
	m.WeaponBurst = 1
	m.WeaponSpread = 8
	m.WeaponStopOnHit = true
	m.WeaponHitFX = true
	m.WeaponReturnSpeed = 140
	m.WeaponTrail = true
	m.WeaponRainbow = false
	m.WeaponTrailLife = 0.6
	m.WeaponTrailWidth = 1
	m.WeaponTrailR, m.WeaponTrailG, m.WeaponTrailB = 255, 180, 60
	-- Per-slot multi-bullet (5+ bullets per slot, hat bullets allowed)
	for i = 1, 10 do
		m["WeaponBurst" .. i] = 1 -- 1..12 bullets this slot fires
		m["WeaponHatBulletCount" .. i] = 1 -- how many hat-bullets this slot can use at once
	end
	m.WeaponMaxBurst = 12
	m.WeaponSFX = true
	m.WeaponFireSFXId = "rbxassetid://131961136" -- generic shot
	m.WeaponHitSFXId = "rbxassetid://9116382851"
	m.WeaponVolume = 0.85

	-- Shield
	m.ShieldEnabled = false
	m.ShieldHat = ""
	m.ShieldMode = 1 -- 1=hold front 2=free place 3=grab
	m.ShieldModeNames = { "1 Hold Front", "2 Free Place", "3 Grab" }
	m.ShieldSide = 0
	m.ShieldHeight = 1
	m.ShieldForward = -2.2
	m.ShieldRotX, m.ShieldRotY, m.ShieldRotZ = 0, 0, 0
	m.ShieldScale = 1.3
	m.ShieldAutoFace = true
	m.ShieldBob = false
	m.ShieldBobSpeed = 1.2
	m.ShieldBobAmt = 0.25
	m.ShieldSpin = false
	m.ShieldSpinSpeed = 2
	m.ShieldUnderground = false -- stash shield underground until you press the shield key
	m.ShieldStashDepth = 10
	m.ShieldStashRise = 0.3

	m.ShieldStashHold = 0 -- 0 = stay up until you press the key again, >0 = sink after N seconds

	-- Ravenger Claws (left/right claws or arms + optional head; per-piece place + rot)
	m.ClawsEnabled = false
	m.ClawsLeftHat = ""
	m.ClawsRightHat = ""
	m.ClawsHeadHat = ""
	m.ClawsScale = 1.8
	m.ClawsSide = 1.6
	m.ClawsHeight = 0.4
	m.ClawsForward = -0.8
	m.ClawsRotX, m.ClawsRotY, m.ClawsRotZ = 0, 0, 0
	m.ClawsLeftOffX, m.ClawsLeftOffY, m.ClawsLeftOffZ = 0, 0, 0
	m.ClawsLeftRotX, m.ClawsLeftRotY, m.ClawsLeftRotZ = 0, 0, 0
	m.ClawsRightOffX, m.ClawsRightOffY, m.ClawsRightOffZ = 0, 0, 0
	m.ClawsRightRotX, m.ClawsRightRotY, m.ClawsRightRotZ = 0, 0, 0
	m.ClawsHeadOffX, m.ClawsHeadOffY, m.ClawsHeadOffZ = 0, 1.4, 0
	m.ClawsHeadRotX, m.ClawsHeadRotY, m.ClawsHeadRotZ = 0, 0, 0
	m.ClawsIdleBob = true
	m.ClawsBobSpeed = 2.2
	m.ClawsBobAmt = 0.12
	m.ClawsComboCooldown = 0.28
	m.ClawsPushCooldown = 1.1
	m.ClawsSpinCooldown = 2.4
	m.ClawsComboRange = 8
	m.ClawsPushForce = 55
	m.ClawsPushUp = 18
	m.ClawsSpinSpeed = 14
	m.ClawsSpinDuration = 0.85
	m.ClawsSpinRadius = 4.5
	m.ClawsTrackMouse = false
	m.ClawsBloodTrail = true
	m.ClawsSFX = true
	m.ClawsSlashSFXId = "rbxassetid://131961136"
	m.ClawsPushSFXId = "rbxassetid://138081308"
	m.ClawsSpinSFXId = "rbxassetid://138081500"
	m.ClawsVolume = 0.95
	m.ClawsAnims = true -- idle / walk / run / jump / fall animations for the claws
	m.ClawsAnimStrength = 1.0
	m.ClawsAnimBlend = 12
	m.ClawsKeysEnabled = true -- attack keybinds ON/OFF (toggle with KeyClawsKeysToggle)
	m.KeyClawsKeysToggle = "F6" -- attack keys ON/OFF
	m.KeyClawsTrackToggle = "F7" -- mouse tracking ON/OFF
	m.KeyClawsRage = "F8" -- rage mode ON/OFF
	m.KeyClawsLaser = "H"
	m.KeyClawsSlam = "I"
	m.ClawsRage = false
	m.ClawsRageMul = 1.6 -- cooldowns / anim speed multiplier while raging
	m.ClawsLaserUseHat = true -- fly the bullet hat down the beam
	m.ClawsLaserHat = "" -- bullet hat (must be a different hat than the claws)
	m.ClawsLaserDual = true -- fire from both claws (off = alternate L/R)
	m.ClawsLaserAim = true -- aim at mouse (off = straight ahead)
	m.ClawsLaserCooldown = 1.6
	m.ClawsLaserCharge = 0.25
	m.ClawsLaserLength = 140
	m.ClawsLaserThick = 1.2
	m.ClawsLaserR, m.ClawsLaserG, m.ClawsLaserB = 255, 60, 60
	m.ClawsLaserBulletSpeed = 220
	m.ClawsLaserBulletSpin = true
	m.ClawsLaserTrail = true
	m.ClawsLaserTrailOsc = true -- after reaching the end the hat goes back & forth
	m.ClawsLaserTrailOscDist = 12
	m.ClawsLaserTrailOscSpeed = 18
	m.ClawsLaserTrailOscTime = 1.0
	m.ClawsSlamCooldown = 2.0
	m.ClawsSlamRadius = 14
	m.KeyClawsCombo = "Z"
	m.KeyClawsPush = "X"
	m.KeyClawsSpin = "C"

	-- Rebindable keys (KeyCode names)
	m.KeyGaster = "Q"
	m.KeyGasterCycle = "M"
	m.KeyBone = "L"
	m.KeyOmega = "K"
	m.KeyShield = "J" -- raise / lower shield from underground (when Shield Underground Stash is ON)
	m.KeyShieldPlace = "Y"
	m.KeySans = "P" -- fires every enabled Sans attack at once (Gaster + Bone + Omega)
	m.KeyNames = {
		"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
		"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Zero",
		"F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12",
		"MouseButton2","MouseButton3",
	}

	-- Car
	m.CarEnabled = false
	m.CarRide = false
	m.CarSpeedBoost = 1.35
	m.CarSide = 6
	m.CarHeight = 0
	m.CarForward = 0
	m.CarRotY = 0
	m.CarSmooth = 12
	for i = 1, 8 do
		m["CarHat" .. i] = ""
		m["CarOffX" .. i] = 0
		m["CarOffY" .. i] = 0
		m["CarOffZ" .. i] = 0
		m["CarRotX" .. i] = 0
		m["CarRotY" .. i] = 0
		m["CarRotZ" .. i] = 0
	end
	-- Car wheels (4) + engine
	m.CarWheelSpin = true
	m.CarWheelSpinSpd = 12
	for i = 1, 4 do
		m["CarWheelHat" .. i] = ""
		m["CarWheelOffX" .. i] = ({ -1.8, 1.8, -1.8, 1.8 })[i]
		m["CarWheelOffY" .. i] = -0.6
		m["CarWheelOffZ" .. i] = ({ 1.6, 1.6, -1.6, -1.6 })[i]
		m["CarWheelRotX" .. i] = 0
		m["CarWheelRotY" .. i] = 0
		m["CarWheelRotZ" .. i] = 90
	end
	m.CarEngineHat = ""
	m.CarEngineOffX, m.CarEngineOffY, m.CarEngineOffZ = 0, 0.4, -1.8
	m.CarEngineRotX, m.CarEngineRotY, m.CarEngineRotZ = 0, 0, 0
	m.CarEngineBob = true
	m.CarEngineBobAmt = 0.08
	m.CarEngineBobSpd = 18

	-- Ball system (10 slots: choose hat as ball, yeet, mouse track)
	m.BallEnabled = false
	m.BallActiveSlot = 1
	m.BallTrackMouse = true
	m.BallTrackStrength = 1
	m.BallFloatSide = 2.2
	m.BallFloatHeight = 1.0
	m.BallFloatForward = -0.5
	m.BallYeetForce = 90
	m.BallYeetUp = 35
	m.BallGravity = 40
	m.BallBounce = 0.55
	m.BallLife = 4
	m.BallReturn = true
	m.BallReturnSpeed = 100
	m.BallSize = 1.2
	m.BallSpin = true
	m.BallSpinSpd = 8
	m.BallKey = "Zero" -- yeet active ball (rebindable)
	for i = 1, 10 do
		m["BallHat" .. i] = ""
		m["BallOffX" .. i] = 0
		m["BallOffY" .. i] = (i - 1) * 0.35 - 1.5
		m["BallOffZ" .. i] = 0
		m["BallRotX" .. i] = 0
		m["BallRotY" .. i] = 0
		m["BallRotZ" .. i] = 0
		m["BallKind" .. i] = 1 -- 1 float 2 bounce 3 homing 4 sticky
	end
	m.BallKindNames = { "1 Float", "2 Bounce", "3 Homing", "4 Sticky" }

	-- PLANETS (10 slots, solar-system style orbit around you)
	m.PlanetEnabled = false
	m.PlanetSpin = true
	m.PlanetSpinSpd = 0.6 -- base angular speed
	m.PlanetSelfSpin = true -- each planet spins on own axis
	m.PlanetSelfSpinSpd = 4
	m.PlanetSmooth = 16
	m.PlanetFollow = true -- follow character
	m.PlanetAutoRebuild = true -- put hats back if lost / snapped
	for i = 1, 10 do
		m["PlanetHat" .. i] = ""
		-- solar-system defaults: increasing radius
		m["PlanetRad" .. i] = 3 + i * 1.4
		m["PlanetHeight" .. i] = 0.5 + ((i - 1) % 3) * 0.4
		m["PlanetSpeed" .. i] = 1.0 / (0.6 + i * 0.18) -- outer slower
		m["PlanetPhase" .. i] = (i - 1) * 0.628 -- start angle offset
		m["PlanetOffX" .. i] = 0 -- extra side
		m["PlanetOffY" .. i] = 0 -- extra up
		m["PlanetOffZ" .. i] = 0 -- extra forward
		m["PlanetRotX" .. i] = 0
		m["PlanetRotY" .. i] = 0
		m["PlanetRotZ" .. i] = 0
		m["PlanetIncline" .. i] = ((i % 3) - 1) * 8 -- orbital inclination deg
	end

	-- MOTORCYCLE (hat build + lean + wheel spin + ride)
	m.MotoEnabled = false
	m.MotoRide = false
	m.MotoSpeedBoost = 1.55
	m.MotoSide = 5
	m.MotoHeight = 0
	m.MotoForward = 0
	m.MotoRotY = 0
	m.MotoSmooth = 14
	m.MotoLean = true
	m.MotoLeanAmt = 18 -- max lean degrees when turning
	m.MotoWheelSpin = true
	m.MotoWheelSpinSpd = 16
	m.MotoEnterAnim = true
	m.MotoEnterTime = 0.85
	m.MotoEngineSFX = true
	m.MotoEngineSFXId = "rbxassetid://13114759" -- generic engine-ish (change freely)
	m.MotoIdleSFXId = "rbxassetid://13114759"
	m.MotoVolume = 0.7
	for i = 1, 6 do
		m["MotoHat" .. i] = ""
		m["MotoOffX" .. i] = 0
		m["MotoOffY" .. i] = 0
		m["MotoOffZ" .. i] = 0
		m["MotoRotX" .. i] = 0
		m["MotoRotY" .. i] = 0
		m["MotoRotZ" .. i] = 0
	end
	for i = 1, 2 do
		m["MotoWheelHat" .. i] = ""
		m["MotoWheelOffX" .. i] = 0
		m["MotoWheelOffY" .. i] = -0.5
		m["MotoWheelOffZ" .. i] = (i == 1) and 1.4 or -1.4
		m["MotoWheelRotX" .. i] = 0
		m["MotoWheelRotY" .. i] = 0
		m["MotoWheelRotZ" .. i] = 90
	end
	m.MotoEngineHat = ""
	m.MotoEngineOffX, m.MotoEngineOffY, m.MotoEngineOffZ = 0, 0.3, -0.4
	m.KeyMotoRide = "Equals" -- toggle ride
	m.MotoAutoRebuild = true

	-- HAT TOOLS (sword / random melee from hats)
	m.ToolEnabled = false
	m.ToolActiveSlot = 1
	m.ToolMode = 1 -- 1 sword 2 hammer 3 spear 4 random spin 5 shield-bash
	m.ToolModeNames = { "1 Sword", "2 Hammer", "3 Spear", "4 Spin Tool", "5 Bash" }
	m.ToolFloatSide = 1.2
	m.ToolFloatHeight = 0.4
	m.ToolFloatForward = -0.6
	m.ToolSwingCooldown = 0.35
	m.ToolSwingForce = 40
	m.ToolSwingRange = 7
	m.ToolTrackMouse = true
	m.ToolSFX = true
	m.ToolSwingSFXId = "rbxassetid://131961136"
	m.ToolVolume = 0.9
	m.KeyToolSwing = "V"
	m.KeyToolCycle = "LeftBracket"
	m.ToolAutoRebuild = true
	for i = 1, 6 do
		m["ToolHat" .. i] = ""
		m["ToolOffX" .. i] = 0
		m["ToolOffY" .. i] = (i - 1) * 0.3 - 0.6
		m["ToolOffZ" .. i] = 0
		m["ToolRotX" .. i] = 0
		m["ToolRotY" .. i] = 90
		m["ToolRotZ" .. i] = 0
	end

	-- PLANE (frames + 2 propellers + 2 engines + guns + flight + speedo + cam lock)
	m.PlaneEnabled = false
	m.PlaneRide = false
	m.PlaneFly = false -- free flight mode
	m.PlaneSpeed = 60 -- studs/s base
	m.PlaneMaxSpeed = 180
	m.PlaneAccel = 40
	m.PlaneTurnRate = 1.4
	m.PlanePitchRate = 1.1
	m.PlaneLift = 1.0
	m.PlaneSmooth = 10
	m.PlaneSide = 8
	m.PlaneHeight = 2
	m.PlaneForward = 0
	m.PlaneRotY = 0
	m.PlaneCamLock = false -- lock camera to plane frame
	m.PlaneCamSmooth = 12
	m.PlaneSpeedo = true -- local speedometer GUI
	m.PlaneEnterAnim = true
	m.PlaneEnterTime = 1.0
	m.PlaneEngineSFX = true
	m.PlaneEngineSFXId = "rbxassetid://13114759"
	m.PlanePropSFXId = "rbxassetid://13114759"
	m.PlaneVolume = 0.75
	m.PlaneGunEnabled = false
	m.PlaneGunCooldown = 0.2
	m.PlaneGunSpeed = 220
	m.PlaneGunLife = 2.0
	-- Plane gun aim / fire styles
	m.PlaneGunTrackMouse = true -- aim guns + bullets at mouse / world point
	m.PlaneGunTrackOnlyFire = false -- if true, only orient guns toward mouse while firing
	m.PlaneGunTrackSmooth = 14
	m.PlaneGunFireStyle = 1 -- 1 Beam 2 Gaster (back&forth) 3 AK47 4 Minigun
	m.PlaneGunFireStyleNames = { "1 Beam", "2 Gaster (back & forth)", "3 AK47", "4 Minigun" }
	m.PlaneGunBulletStyle = 1 -- 1 Neon beam 2 Orb 3 Spike 4 Hat bullet
	m.PlaneGunBulletStyleNames = { "1 Neon Beam", "2 Orb", "3 Spike", "4 Hat Bullet" }
	m.PlaneGunBulletHat = "" -- hat used when bullet style = Hat
	m.PlaneGunRealHat = true -- hat bullets use real FE hat (flies out + returns)
	m.PlaneGunSpread = 4 -- degrees spread (AK/minigun)
	m.PlaneGunBurst = 3 -- AK burst size
	m.PlaneGunAKCooldown = 0.12
	m.PlaneGunMiniCooldown = 0.04
	m.PlaneGunBeamLength = 180
	m.PlaneGunBeamThick = 0.9
	m.PlaneGunTrailOsc = true -- Gaster-style: bullet goes out then back & forth fast
	m.PlaneGunTrailOscSpeed = 22
	m.PlaneGunTrailOscDist = 14
	m.PlaneGunTrailOscTime = 1.0
	m.PlaneGunBulletSpin = true
	m.PlaneGunTrail = true
	m.PlaneGunR, m.PlaneGunG, m.PlaneGunB = 255, 220, 80
	m.PlaneGunSFX = true
	-- Plane ordnance: 5 attack toggles (Guns + Bomb + Package + Missile + Bomb2)
	-- Each has its own keybind; optional underground stash until you fire.
	m.PlaneOrdnanceUnderground = true
	-- STAY IN PLACE: after you change place (side / up-down / forward) or rot, the hat stays exactly there on the plane
	-- (kept raised, re-driven live every frame, and returns to the live spot after firing)
	m.PlaneBombStay = true
	m.PlanePackageStay = true
	m.PlaneMissileStay = true -- missile ammo tubes (the missile hats that fly out)
	m.PlaneBomb2Stay = true
	m.PlaneOrdnanceStashDepth = 12
	m.PlaneOrdnanceStashRise = 0.35
	m.PlaneOrdnanceStashHold = 1.2
	-- Attack 2: Bomb (any hat, e.g. Bomb Hat)
	m.PlaneBombEnabled = false
	m.PlaneBombHat = ""
	m.PlaneBombKey = "One"
	m.PlaneBombCooldown = 1.4
	m.PlaneBombCount = 1
	m.PlaneBombSpread = 2.5
	m.PlaneBombFallSpeed = 90
	m.PlaneBombLife = 5
	m.PlaneBombReturn = true
	m.PlaneBombReturnSpeed = 120
	m.PlaneBombBounce = true -- bounce off ground / surfaces
	m.PlaneBombBounceAmt = 0.55 -- restitution 0..1
	m.PlaneBombBounceFriction = 0.82 -- horizontal speed kept on bounce
	m.PlaneBombMinBounce = 6 -- stop bouncing when |Vy| below this
	m.PlaneBombSide, m.PlaneBombHeight, m.PlaneBombForward = 0, -1.5, 0
	m.PlaneBombRotX, m.PlaneBombRotY, m.PlaneBombRotZ = 0, 0, 0
	m.PlaneBombSFX = true
	-- Attack 3: Package / crate / box body (any hat)
	m.PlanePackageEnabled = false
	m.PlanePackageHat = ""
	m.PlanePackageKey = "Two"
	m.PlanePackageCooldown = 1.8
	m.PlanePackageCount = 1
	m.PlanePackageSpread = 2
	m.PlanePackageFallSpeed = 70
	m.PlanePackageLife = 6
	m.PlanePackageReturn = true
	m.PlanePackageReturnSpeed = 100
	m.PlanePackageBounce = true
	m.PlanePackageBounceAmt = 0.4
	m.PlanePackageBounceFriction = 0.75
	m.PlanePackageSide, m.PlanePackageHeight, m.PlanePackageForward = 0, -2, 0
	m.PlanePackageRotX, m.PlanePackageRotY, m.PlanePackageRotZ = 0, 0, 0
	m.PlanePackageSFX = true
	-- Attack 4: Missile launcher (launcher hat + missile hat e.g. AIM-54)
	m.PlaneMissileEnabled = false
	m.PlaneMissileLauncherHat = ""
	m.PlaneMissileHat = "" -- legacy alias for slot 1
	m.PlaneMissileKey = "Three"
	m.PlaneMissileCooldown = 1.1 -- full mag reload when all 4 tubes empty
	m.PlaneMissileShotCooldown = 0.22 -- fast delay between sequential tube shots
	m.PlaneMissileSpeed = 200
	m.PlaneMissileLife = 4
	m.PlaneMissileHoming = 1.2
	m.PlaneMissileTrackMouse = true
	m.PlaneMissileCount = 1 -- projectiles per tube press (usually 1)
	m.PlaneMissileSpread = 3
	m.PlaneMissileTrail = true
	m.PlaneMissileSpin = true
	m.PlaneMissileReturn = true
	m.PlaneMissileReturnSpeed = 140
	m.PlaneMissileSide, m.PlaneMissileHeight, m.PlaneMissileForward = 0, -0.8, 1.5
	m.PlaneMissileRotX, m.PlaneMissileRotY, m.PlaneMissileRotZ = 0, 0, 0
	m.PlaneMissileLauncherSide, m.PlaneMissileLauncherHeight, m.PlaneMissileLauncherForward = 0, -0.5, 0.5
	m.PlaneMissileLauncherRotX, m.PlaneMissileLauncherRotY, m.PlaneMissileLauncherRotZ = 0, 0, 0
	m.PlaneMissileLauncherLock = true -- launcher stays mounted on plane; only missile hat flies out
	m.PlaneMissileLauncherLockForce = true -- re-drive launcher every frame so it cannot snap/fly away
	m.PlaneMissileSFX = true
	-- 4 missile tubes / ammo slots (cycle after each fire for fast reload)
	m.PlaneMissileSlotCount = 5
	m.PlaneMissileActiveSlot = 1
	m.PlaneMissileAutoCycle = true -- after fire, advance to next loaded tube
	m.PlaneMissileCycleKey = "Five" -- optional manual cycle key
	m.PlaneMissileAutoDetect = true -- auto-fill empty tubes from AIM-54 / Phoenix hats on character
	m.PlaneMissileAutoDetectIds = { "104594291421043" } -- Aim-54 Pheonix catalog id
	m.PlaneMissileAutoDetectHints = { "aim-54", "aim54", "aim 54", "pheonix", "phoenix missile", "phoenix" }
	for i = 1, 5 do
		m["PlaneMissileHat" .. i] = ""
		-- per-tube park offset so all tubes sit on the plane at once
		m["PlaneMissileSlotSide" .. i] = ((i % 2 == 0) and -1.2 or 1.2)
		m["PlaneMissileSlotHeight" .. i] = -0.6 + ((i - 1) % 3) * 0.15
		m["PlaneMissileSlotForward" .. i] = 1.2 - (i - 1) * 0.3
		m["PlaneMissileSlotRotX" .. i] = 0
		m["PlaneMissileSlotRotY" .. i] = 0
		m["PlaneMissileSlotRotZ" .. i] = 0
		m["PlaneMissileSlotEnabled" .. i] = true
	end
	-- Attack 5: second bomb bay
	m.PlaneBomb2Enabled = false
	m.PlaneBomb2Hat = ""
	m.PlaneBomb2Key = "Four"
	m.PlaneBomb2Cooldown = 1.6
	m.PlaneBomb2Count = 2
	m.PlaneBomb2Spread = 3.5
	m.PlaneBomb2FallSpeed = 95
	m.PlaneBomb2Life = 5
	m.PlaneBomb2Return = true
	m.PlaneBomb2ReturnSpeed = 120
	m.PlaneBomb2Bounce = true
	m.PlaneBomb2BounceAmt = 0.5
	m.PlaneBomb2BounceFriction = 0.8
	m.PlaneBomb2Side, m.PlaneBomb2Height, m.PlaneBomb2Forward = 0, -1.8, -0.5
	m.PlaneBomb2RotX, m.PlaneBomb2RotY, m.PlaneBomb2RotZ = 0, 0, 0
	m.KeyPlaneRide = "RightBracket"
	m.KeyPlaneFly = "BackSlash"
	m.KeyPlaneGun = "MouseButton1" -- while riding (Attack 1)
	m.PlaneAutoRebuild = true -- continuously re-grab / put hats back in place
	m.PlaneLock = true -- force-drive every frame so hats cannot snap away
	-- FULL PLANE: one hat/accessory is the entire aircraft (e.g. red triplane pack)
	m.PlaneFullMode = false
	m.PlaneFullHat = ""
	m.PlaneFullOffX, m.PlaneFullOffY, m.PlaneFullOffZ = 0, -1.5, 0
	m.PlaneFullRotX, m.PlaneFullRotY, m.PlaneFullRotZ = 0, 0, 0
	m.PlaneFullScale = 1
	-- improved flight controls
	m.PlaneRollRate = 1.6
	m.PlaneYawRate = 1.3
	m.PlaneMouseSteer = true -- mouse aims pitch/yaw while flying
	m.PlaneMouseSens = 0.35
	m.PlaneBank = true -- auto bank into turns
	m.PlaneBankAmt = 25 -- max bank degrees
	m.PlaneThrottle = 0 -- 0..1 runtime
	m.PlaneMinFlySpeed = 8
	m.PlaneGravity = 28 -- how hard you fall when slow / stalling
	m.PlaneSeatOffY = -1.2 -- character offset when riding
	-- 10 frame slots
	for i = 1, 10 do
		m["PlaneFrameHat" .. i] = ""
		m["PlaneFrameOffX" .. i] = 0
		m["PlaneFrameOffY" .. i] = 0
		m["PlaneFrameOffZ" .. i] = (i - 5.5) * 0.8
		m["PlaneFrameRotX" .. i] = 0
		m["PlaneFrameRotY" .. i] = 0
		m["PlaneFrameRotZ" .. i] = 0
	end
	-- 2 propellers
	for i = 1, 2 do
		m["PlanePropHat" .. i] = ""
		m["PlanePropOffX" .. i] = (i == 1) and -2.5 or 2.5
		m["PlanePropOffY" .. i] = 0.2
		m["PlanePropOffZ" .. i] = 2.2
		m["PlanePropRotX" .. i] = 0
		m["PlanePropRotY" .. i] = 0
		m["PlanePropRotZ" .. i] = 0
		m["PlanePropSpinSpd" .. i] = 28
	end
	-- 2 engines
	for i = 1, 2 do
		m["PlaneEngineHat" .. i] = ""
		m["PlaneEngineOffX" .. i] = (i == 1) and -1.8 or 1.8
		m["PlaneEngineOffY" .. i] = -0.2
		m["PlaneEngineOffZ" .. i] = 1.5
		m["PlaneEngineRotX" .. i] = 0
		m["PlaneEngineRotY" .. i] = 0
		m["PlaneEngineRotZ" .. i] = 0
		m["PlaneEngineBob" .. i] = true
	end
	-- 4 gun slots on plane
	for i = 1, 4 do
		m["PlaneGunHat" .. i] = ""
		m["PlaneGunOffX" .. i] = (i <= 2) and -1.2 or 1.2
		m["PlaneGunOffY" .. i] = -0.4
		m["PlaneGunOffZ" .. i] = (i % 2 == 1) and 1.0 or 0.2
		m["PlaneGunRotX" .. i] = 0
		m["PlaneGunRotY" .. i] = 0
		m["PlaneGunRotZ" .. i] = 0
		m["PlaneGunFire" .. i] = true
	end

	-- CAR: GTA-style enter + engine start SFX
	m.CarEnterAnim = true
	m.CarEnterTime = 1.1
	m.CarEngineOn = false -- toggled when you enter / ride
	m.CarEngineSFX = true
	m.CarEngineStartSFXId = "rbxassetid://13114759"
	m.CarEngineLoopSFXId = "rbxassetid://13114759"
	m.CarEngineVolume = 0.8
	m.CarEngineType = 1 -- 1 car 2 truck 3 sport 4 motorcycle-ish
	m.CarEngineTypeNames = { "1 Car", "2 Truck", "3 Sport", "4 Moto-ish" }
	m.KeyCarRide = "Minus" -- toggle ride / enter
	m.CarAutoRebuild = true

	-- Refresh
	m.AutoRefresh = false
	m.AutoRefreshInterval = 1
	m.LastRefreshReport = ""

	--------------------------------------------------------------
	-- CONSTANTS
	--------------------------------------------------------------
	local LIMB_ASSET_IDS = {
		Head = { 107852478332182 },
		Torso = { 118799338103138 },
		LeftArm = { 101379144205559 },
		RightArm = { 132416515427938 },
		LeftLeg = { 121360936156823 },
		RightLeg = { 80628080423002 },
	}
	local LIMB_NAME_HINTS = {
		{ "LeftArm", { "larm", "leftarm", "left arm", "l arm" } },
		{ "RightArm", { "rarm", "rightarm", "right arm", "r arm", "black right" } },
		{ "LeftLeg", { "lleg", "leftleg", "left leg", "l leg" } },
		{ "RightLeg", { "rleg", "rightleg", "right leg", "r leg" } },
		{ "Head", { "head", "bigeye" } },
		{ "Torso", { "torso", "default" } },
	}
	local LIMB_NAMES = { "Head", "Torso", "LeftArm", "RightArm", "LeftLeg", "RightLeg" }
	local LIMB_KEYS = {
		Head = "HatHead", Torso = "HatTorso",
		LeftArm = "HatLeftArm", RightArm = "HatRightArm",
		LeftLeg = "HatLeftLeg", RightLeg = "HatRightLeg",
	}
	local LIMB_BASE_POS = {
		Head = Vector3.new(0, 1.5, 0),
		Torso = Vector3.new(0, 0.4, 0),
		LeftArm = Vector3.new(-1.3, 0.5, 0),
		RightArm = Vector3.new(1.3, 0.5, 0),
		LeftLeg = Vector3.new(-0.5, -1.3, 0),
		RightLeg = Vector3.new(0.5, -1.3, 0),
	}
	local LIMB_ROT_KEYS = {
		Head = { "RotHeadX", "RotHeadY", "RotHeadZ" },
		Torso = { "RotTorsoX", "RotTorsoY", "RotTorsoZ" },
		LeftArm = { "RotLeftArmX", "RotLeftArmY", "RotLeftArmZ" },
		RightArm = { "RotRightArmX", "RotRightArmY", "RotRightArmZ" },
		LeftLeg = { "RotLeftLegX", "RotLeftLegY", "RotLeftLegZ" },
		RightLeg = { "RotRightLegX", "RotRightLegY", "RotRightLegZ" },
	}
	local LIMB_OFF_KEYS = {
		Head = { "OffHeadX", "OffHeadY", "OffHeadZ" },
		Torso = { "OffTorsoX", "OffTorsoY", "OffTorsoZ" },
		LeftArm = { "OffLeftArmX", "OffLeftArmY", "OffLeftArmZ" },
		RightArm = { "OffRightArmX", "OffRightArmY", "OffRightArmZ" },
		LeftLeg = { "OffLeftLegX", "OffLeftLegY", "OffLeftLegZ" },
		RightLeg = { "OffRightLegX", "OffRightLegY", "OffRightLegZ" },
	}
	local ORBIT_HAT_KEYS, PLACE_HAT_KEYS = {}, {}
	for i = 1, 10 do
		ORBIT_HAT_KEYS[i] = "OrbitHat" .. i
		PLACE_HAT_KEYS[i] = "PlaceHat" .. i
	end

	local CONTROLLER_CLASSES = {
		"AlignPosition", "AlignOrientation", "BodyPosition", "BodyGyro",
		"BodyVelocity", "BodyForce", "BodyAngularVelocity",
		"LinearVelocity", "AngularVelocity", "VectorForce", "Torque",
	}
	local DANCE_HINTS = {
		"dance", "emote", "groove", "wave", "cheer", "laugh", "point",
		"sit", "lay", "floss", "disco", "shimmy", "twerk", "macarena",
		"robot", "thriller", "hype", "party", "defaultdance", "breakdance",
		"salsa", "tango", "hiphop", "freestyle", "boogie", "shuffle",
		"orange justice", "take the l", "electro shuffle", "fresh",
		"flapper", "ride the pony", "best mates", "worm", "scenario",
		"renegade", "say so", "sturdy", "toosie", "griddy", "dougie",
		"cabbage", "chicken", "gangnam", "harlem", "nae nae", "whip",
		"animate", "custom", "music", "song", "move", "idle_dance",
	}

	local Players = game:GetService("Players")
	local RunService = game:GetService("RunService")
	local CoreGui = game:GetService("CoreGui")
	local UserInputService = game:GetService("UserInputService")
	local Workspace = game:GetService("Workspace")
	local TweenService = game:GetService("TweenService")
	local Debris = game:GetService("Debris")
	local LocalPlayer = Players.LocalPlayer
	local Mouse = LocalPlayer:GetMouse()

	local StandModel, StandRoot = nil, nil
	local Limbs, Held = {}, {}
	local OrbitAngle, IdleT = 0, 0
	local AnimState, AnimT, AnimToken = "idle", 0, 0
	local FollowBound, HBConn = false, nil
	local KeyConns, CharConns = {}, {}
	local HatCache = {}
	local LimbCache = setmetatable({}, { __mode = "k" })
	local NameLabels = {}
	local LimbPreviewParts = {}
	local RefreshToken, LastHatFingerprint = 0, ""
	local NeedRebuild, LastBuild = false, 0
	local OLD_BIND_NAMES = {
		"Uhhhhhh_HatStand_v6", "Uhhhhhh_HatStand_v7", "Uhhhhhh_HatStand_v8",
		"Uhhhhhh_HatStand_v9", "Uhhhhhh_HatStand_v10", "Uhhhhhh_HatStand_v11",
		"Uhhhhhh_HatStand_v12",
	}

	local LocoT, LocoMode = 0, "idle"
	local DanceT, ForceDance, ForceDanceUntil = 0, false, 0
	local DetectedDanceName = ""
	local PlacePreviewPart, PlacedHats, PlaceT, BuildAnimT = nil, {}, 0, 0
	local PlaceFolder = nil
	local OrbitSlots, OrbitT, NeedOrbitRebuild = {}, 0, false

	-- New systems state
	local GasterHeld, GasterLastFire, GasterCharging = nil, 0, false
	local GasterSlots = {} -- [1..5] = held entries
	local GasterFireIdx = 0
	local BoneHeld, BoneLastFire = nil, 0
	local BoneProjectiles = {}
	local OmegaHeld, OmegaHeld2, OmegaLastFire, OmegaCharging = nil, nil, 0, false
	local WeaponHeld, WeaponBullets, WeaponLastFire = nil, {}, 0
	local ShieldHeld, ShieldPlacedCF = nil, nil
	local CarSlots, CarRootCF = {}, nil
	local CarWheels, CarEngine = {}, nil -- wheel slots + engine
	local BallSlots, BallFlying, BallLastYeet = {}, {}, 0
	local PlanetSlots, PlanetT = {}, 0
	local MotoSlots, MotoWheels, MotoEngine, MotoRootCF = {}, {}, nil, nil
	local MotoEnterT, MotoEngineSound = 0, nil
	local ToolSlots, ToolLastSwing = {}, 0
	local PlaneFrames, PlaneProps, PlaneEngines, PlaneGuns = {}, {}, {}, {}
	local PlaneFull = nil -- single full-plane hat body
	local PlaneRootCF, PlaneVel, PlanePitch, PlaneYaw, PlaneRoll = nil, 0, 0, 0, 0
	local PlaneThrottle = 0
	local PlaneEnterT, PlaneEngineSound, PlaneSpeedoGui = 0, nil, nil
	-- Plane ordnance runtime (bomb / package / missile)
	local CarEnterT, CarEngineSound = 0, nil
	local NeedPlanetRebuild, NeedMotoRebuild, NeedToolRebuild, NeedPlaneRebuild, NeedCarRebuild = false, false, false, false, false
	local LastPlanetCheck, LastMotoCheck, LastToolCheck, LastPlaneCheck, LastCarCheck = 0, 0, 0, 0, 0
	local BToolsCarryCF = nil
	local YeetQueue = {} -- {handle, vel, until}
	local PlaceAnimQueue = {} -- animating place/yeet

	-- v14 state + functions live on one table (Luau local limit)
	local X = {
		Blend = {}, CloneLimbs = {}, CloneModel = nil, CloneCF = nil, CloneLastBuild = 0,
		PlaneBombHeld = nil, PlanePackageHeld = nil, PlaneBomb2Held = nil,
		PlaneMissileLauncher = nil, PlaneMissileAmmo = nil, PlaneMissileAmmoSlots = {}, PlaneMissileTubeLast = {},
		PlaneOrdnanceFlying = {},
		PlaneBombLast = 0, PlanePackageLast = 0, PlaneMissileLast = 0, PlaneBomb2Last = 0,
		CloneCount = -1, NeedCloneRebuild = false,
		Phase = 0, SpeedSm = 0, LeanSm = 0, SideSm = 0, AirT = 0, LandT = 0,
		WasAir = false, Air = false, State = nil, ClimbT = 0, ProcT = 0,
		WeaponSlots = {}, BulletHats = {}, LinkWarned = false, Extras = nil, ExtrasFrame = -1, Frame = 0, DanceSource = "",
		Rest = {}, RestSet = false, CalibT = 0, SnapT = 0, RawFrame = -1, Raw = nil, LastRaw = nil, LastLoco = "idle",
		ClawsLeft = nil, ClawsRight = nil, ClawsHead = nil,
		ClawsLastCombo = 0, ClawsLastPush = 0, ClawsLastSpin = 0,
		ClawsComboStep = 0, ClawsAnimT = 0, ClawsMode = "idle", ClawsSpinUntil = 0,
		ClawsBlood = {}, ClawsLocoT = 0, ClawsLoco = "idle", ClawsOff = {},
	}

	--------------------------------------------------------------
	-- HELPERS
	--------------------------------------------------------------
	X.trim = function(s)
		return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
	end

	-- Lightweight SFX (client-only). Pass asset id string or number.
	X.playSFX = function(id, volume, parent, pitch)
		if not id or id == "" or id == "0" then return end
		local sid = tostring(id)
		if not string.find(sid, "rbxassetid://", 1, true) then
			sid = "rbxassetid://" .. sid:gsub("%D", "")
		end
		pcall(function()
			local s = Instance.new("Sound")
			s.Name = "HS_SFX"
			s.SoundId = sid
			s.Volume = tonumber(volume) or 1
			s.PlaybackSpeed = tonumber(pitch) or 1
			s.RollOffMaxDistance = 80
			s.Parent = parent or workspace.CurrentCamera or workspace
			s:Play()
			Debris:AddItem(s, 6)
		end)
	end

	X.modeAllowsStand = function()
		return m.ActiveMode == 1 or m.ActiveMode == 4
			or (m.ActiveMode == 3 and m.StandInOrbitMode ~= false)
	end
	X.modeAllowsPlace = function()
		if not m.PlaceEnabled then return false end
		if cfg.id == "STAND" then return false end -- the Place module owns BTools
		return m.ActiveMode == 1 or m.ActiveMode == 2 or m.ActiveMode == 4
	end
	X.modeAllowsOrbit = function()
		return m.ActiveMode == 3 or m.ActiveMode == 4
	end

	X.getRoot = function(char)
		if not char then return nil end
		return char:FindFirstChild("HumanoidRootPart")
			or char:FindFirstChild("Torso")
			or char:FindFirstChild("UpperTorso")
			or char.PrimaryPart
	end

	X.getFollowRoot = function()
		local ok, uh = pcall(function()
			return _G.Uhhhhhh and _G.Uhhhhhh.Character
		end)
		if ok and uh and uh.Parent then
			local r = X.getRoot(uh)
			if r and r.Parent then return r, uh, "uhhhhh" end
		end
		local char = LocalPlayer.Character
		if char then
			local r = X.getRoot(char)
			if r and r.Parent then return r, char, "character" end
		end
		return nil, nil, nil
	end

	X.getLiveHumanoid = function()
		local char = LocalPlayer.Character
		return char and char:FindFirstChildOfClass("Humanoid")
	end

	function X.boostNetwork()
		pcall(function() sethiddenproperty(LocalPlayer, "SimulationRadius", 1e9) end)
		pcall(function() sethiddenproperty(LocalPlayer, "MaximumSimulationRadius", 1e9) end)
		pcall(function() LocalPlayer.MaximumSimulationRadius = 1e9 end)
		pcall(function() settings().Physics.AllowSleep = false end)
	end

	X.ensurePlaceFolder = function()
		if PlaceFolder and PlaceFolder.Parent then return PlaceFolder end
		local f = Workspace:FindFirstChild(("UhhhhhhHatStand_Placed" .. SUF))
		if not f then
			f = Instance.new("Folder")
			f.Name = ("UhhhhhhHatStand_Placed" .. SUF)
			f.Parent = Workspace
		end
		PlaceFolder = f
		return f
	end

	function X.getLimbRotCFrame(limb)
		local keys = LIMB_ROT_KEYS[limb]
		if not keys then return CFrame.new() end
		return CFrame.Angles(
			math.rad(tonumber(m[keys[1]]) or 0),
			math.rad(tonumber(m[keys[2]]) or 0),
			math.rad(tonumber(m[keys[3]]) or 0)
		)
	end

	-- Default rotations that correct mesh orientation for most hat/accessory limb sets
	-- (big-head packs, classic R6 limbs, generic accessory handles). Arms get 90° Z so
	-- they hang down like a real figure; works with BigRigFix or the universal FixAnyRigPose.
	local BIGRIG_ROT = {
		Head     = CFrame.Angles(0, 0, 0),
		Torso    = CFrame.Angles(0, 0, 0),
		LeftArm  = CFrame.Angles(0, 0, math.rad(90)),
		RightArm = CFrame.Angles(0, 0, math.rad(-90)),
		LeftLeg  = CFrame.Angles(0, 0, math.rad(5)),
		RightLeg = CFrame.Angles(0, 0, math.rad(-5)),
	}
	function X.bigRigBasePos(limb)
		local h = m.BigRigHeight or 1
		local as = m.BigRigArmSpread or 1.55
		local ls = m.BigRigLegSpread or 0.55
		local map = {
			Head     = Vector3.new(0, 1.55 * h, 0),
			Torso    = Vector3.new(0, 0.45 * h, 0),
			LeftArm  = Vector3.new(-as * h, 0.55 * h, 0),
			RightArm = Vector3.new( as * h, 0.55 * h, 0),
			LeftLeg  = Vector3.new(-ls * h, -1.45 * h, 0),
			RightLeg = Vector3.new( ls * h, -1.45 * h, 0),
		}
		return map[limb] or Vector3.zero
	end

	function X.getLimbOffVector(limb)
		local keys = LIMB_OFF_KEYS[limb]
		if not keys then return Vector3.zero end
		return Vector3.new(
			tonumber(m[keys[1]]) or 0,
			tonumber(m[keys[2]]) or 0,
			tonumber(m[keys[3]]) or 0
		)
	end

	X.makeBaseOffset = function(limb)
		local scale = m.StandScale or 1
		local pos
		local extraRot = CFrame.new()
		-- BigRigFix = classic big-head pack layout; FixAnyRigPose = same corrections for any accessory rig
		if m.BigRigFix or m.FixAnyRigPose then
			pos = X.bigRigBasePos(limb)
			extraRot = BIGRIG_ROT[limb] or CFrame.new()
		else
			pos = LIMB_BASE_POS[limb] or Vector3.zero
		end
		local off = X.getLimbOffVector(limb)
		return CFrame.new(pos.X * scale + off.X, pos.Y * scale + off.Y, pos.Z * scale + off.Z)
			* extraRot
			* X.getLimbRotCFrame(limb)
	end

	X.refreshAllLimbOffsets = function()
		for limb, data in pairs(Limbs) do
			if data then data.BaseOffset = X.makeBaseOffset(limb) end
		end
		-- preview is refreshed from UI / applyStandCF / X.buildStand(after helpers exist)
	end

	X.getPlaceSlotRot = function(slot)
		-- per-slot position offset (side / up / forward) is applied before the rotation
		return CFrame.new(
			tonumber(m["PlaceOff" .. slot .. "X"]) or 0,
			tonumber(m["PlaceOff" .. slot .. "Y"]) or 0,
			tonumber(m["PlaceOff" .. slot .. "Z"]) or 0
		) * CFrame.Angles(
			math.rad(tonumber(m["PlaceRot" .. slot .. "X"]) or 0),
			math.rad(tonumber(m["PlaceRot" .. slot .. "Y"]) or 0),
			math.rad(tonumber(m["PlaceRot" .. slot .. "Z"]) or 0)
		)
	end

	--------------------------------------------------------------
	-- HAT SCAN
	--------------------------------------------------------------
	function X.assetIdInInstance(inst, id)
		if not inst then return false end
		local idStr = tostring(id)
		local ok, desc = pcall(function() return inst:GetDescendants() end)
		if not ok then return false end
		for _, d in ipairs(desc) do
			for _, prop in ipairs({ "MeshId", "TextureID", "TextureId" }) do
				local s, val = pcall(function() return d[prop] end)
				if s and type(val) == "string" and string.find(val, idStr, 1, true) then
					return true
				end
			end
		end
		local s2, sid = pcall(function() return inst:GetAttribute("SourceAssetId") end)
		if s2 and sid and tostring(sid) == idStr then return true end
		return false
	end

	function X.matchLimbForHat(h)
		local acc = h.Accessory
		if acc and LimbCache[acc] ~= nil then return LimbCache[acc] or nil end
		local result = nil
		for limb, ids in pairs(LIMB_ASSET_IDS) do
			for _, id in ipairs(ids) do
				if X.assetIdInInstance(h.Accessory, id) or X.assetIdInInstance(h.Handle, id) then
					result = limb break
				end
			end
			if result then break end
		end
		if not result then
			local lower = string.lower(h.Name)
			for _, pair in ipairs(LIMB_NAME_HINTS) do
				for _, hint in ipairs(pair[2]) do
					if string.find(lower, hint, 1, true) then result = pair[1] break end
				end
				if result then break end
			end
		end
		if acc then LimbCache[acc] = result or false end
		return result
	end

	function X.isDrivenByOther(handle)
		if not handle then return false end
		local lt = 0
		pcall(function() lt = handle.LocalTransparencyModifier end)
		if lt > 0.85 then return true end
		local ok, desc = pcall(function() return handle:GetDescendants() end)
		if ok then
			for _, d in ipairs(desc) do
				if not string.find(d.Name, "^HS_") then
					for _, cls in ipairs(CONTROLLER_CLASSES) do
						if d:IsA(cls) then return true end
					end
				end
			end
		end
		return false
	end

	X.refreshAllHats = function(report)
		local oldNames = {}
		for _, h in ipairs(HatCache) do oldNames[h.Name] = true end

		HatCache = {}
		local seen = {}
		local function addAccessory(acc, source)
			if not acc or seen[acc] then return end
			seen[acc] = true
			local handle = acc:FindFirstChild("Handle")
			local ours = (handle ~= nil) and (Held[handle] ~= nil)
			local used = false
			if handle and not ours then used = X.isDrivenByOther(handle) end
			local entry = {
				Name = acc.Name, Accessory = acc, Handle = handle,
				Used = used, Ours = ours, Source = source,
			}
			entry.LimbGuess = X.matchLimbForHat(entry)
			table.insert(HatCache, entry)
		end
		local function scan(model, source)
			if not model then return end
			for _, child in ipairs(model:GetChildren()) do
				if child:IsA("Accoutrement") then addAccessory(child, source) end
			end
		end
		scan(LocalPlayer.Character, "Character")
		pcall(function()
			scan(_G.Uhhhhhh and _G.Uhhhhhh.Character, "Uhhhhhh")
		end)
		table.sort(HatCache, function(a, b)
			if a.Used ~= b.Used then return not a.Used end
			if a.Name ~= b.Name then return a.Name < b.Name end
			return tostring(a.Source) < tostring(b.Source)
		end)

		local lines = {}
		local newOnes, missing = {}, {}
		local nowNames = {}
		for _, h in ipairs(HatCache) do
			nowNames[h.Name] = true
			local tag = h.Ours and "STAND" or (h.Used and "USED" or "SPARE")
			local limb = h.LimbGuess and (" -> " .. h.LimbGuess) or ""
			table.insert(lines, string.format("[%s] %s%s", tag, h.Name, limb))
			if not oldNames[h.Name] then table.insert(newOnes, h.Name) end
		end
		for n in pairs(oldNames) do
			if not nowNames[n] then table.insert(missing, n) end
		end

		m.PreviewText = (#lines > 0) and table.concat(lines, "\n") or "(no hats on character)"

		local reportParts = {}
		table.insert(reportParts, "Checked avatar + Uhhhhhh character")
		table.insert(reportParts, "Total hats: " .. #HatCache)
		if #newOnes > 0 then
			table.insert(reportParts, "NEW: " .. table.concat(newOnes, ", "))
		end
		if #missing > 0 then
			table.insert(reportParts, "GONE: " .. table.concat(missing, ", "))
		end
		if #newOnes == 0 and #missing == 0 then
			table.insert(reportParts, "No change since last scan")
		end
		m.LastRefreshReport = table.concat(reportParts, " | ")
		if report then
			warn("[HatStand] " .. m.LastRefreshReport)
			warn("[HatStand]\n" .. m.PreviewText)
		end
		return HatCache
	end

	function X.hatFingerprint()
		local parts = {}
		for _, h in ipairs(HatCache) do
			local tag = h.Ours and ":O" or (h.Used and ":U" or ":S")
			table.insert(parts, h.Name .. tag .. ":" .. tostring(h.LimbGuess or "") .. ":" .. tostring(h.Source))
		end
		return table.concat(parts, "|")
	end

	X.dropdownNames = function(includeNone)
		pcall(function()
			if #HatCache == 0 then X.refreshAllHats() end
		end)
		HatCache = HatCache or {}
		local names = {}
		if includeNone then table.insert(names, "(none)") end
		for _, h in ipairs(HatCache) do
			local label = tostring(h.Name or "?")
			if h.LimbGuess then label = label .. " [" .. h.LimbGuess .. "]" end
			if h.Used then label = label .. " USED" end
			label = label .. " · " .. tostring(h.Source or "?")
			table.insert(names, label)
		end
		if #names == 0 or (#names == 1 and includeNone) then table.insert(names, "(no hats)") end
		return names
	end

	X.dropdownNamesStand = function()
		pcall(function()
			if #HatCache == 0 then X.refreshAllHats() end
		end)
		HatCache = HatCache or {}
		local names = { "(auto)" }
		for _, h in ipairs(HatCache) do
			local label = tostring(h.Name or "?")
			if h.LimbGuess then label = label .. " [" .. h.LimbGuess .. "]" end
			if h.Used then label = label .. " USED" end
			label = label .. " · " .. tostring(h.Source or "?")
			table.insert(names, label)
		end
		if #names == 1 then names = { "(no hats)" } end
		return names
	end

	X.cleanLabel = function(label)
		label = X.trim(label)
		if label == "" or label == "(auto)" or label == "(no hats)" or label == "(none)" then return "" end
		label = label:gsub("%s*%[.-%]", ""):gsub("%s*USED", ""):gsub("%s*·.*$", "")
		return X.trim(label)
	end

	X.findHatFromLabel = function(label, claimed)
		label = X.cleanLabel(label)
		if label == "" then return nil end
		local lower = string.lower(label)
		local fallback = nil
		for pass = 1, 2 do
			for _, h in ipairs(HatCache) do
				local srcOk = (pass == 2) or (h.Source == "Character") or not m.FEMode
				if srcOk and string.lower(h.Name) == lower then
					if not (claimed and h.Handle and claimed[h.Handle]) then return h end
					fallback = fallback or h
				end
			end
		end
		if fallback then return fallback end
		for _, h in ipairs(HatCache) do
			if string.find(string.lower(h.Name), lower, 1, true) then
				if not (claimed and h.Handle and claimed[h.Handle]) then return h end
				fallback = fallback or h
			end
		end
		return fallback
	end

	X.orbitReservedName = function(name)
		if not (m.OrbitEnabled and X.modeAllowsOrbit()) then return false end
		local lower = string.lower(name or "")
		for i = 1, 10 do
			local lab = X.cleanLabel(m["OrbitHat" .. i] or "")
			if lab ~= "" and string.lower(lab) == lower then return true end
		end
		return false
	end

	X.autoAllowed = function(h, claimed, kind)
		if not h.Handle or not h.Handle.Parent then return false end
		if claimed[h.Handle] then return false end
		if Claims[h.Handle] and Claims[h.Handle] ~= INSTANCE_ID then return false end
		if kind ~= "orbit" and X.orbitReservedName(h.Name) then return false end
		local hd = Held[h.Handle]
		if hd and hd.Kind and hd.Kind ~= (kind or "stand") then return false end
		if h.Used and not m.AllowUsedHats then return false end
		if m.FEMode and h.Source ~= "Character" then return false end
		return true
	end

	X.findHatForLimb = function(limb, claimed, kind, keys)
		kind = kind or "stand"
		keys = keys or LIMB_KEYS
		local label = m[keys[limb]]
		local manual = X.findHatFromLabel(label, claimed)
		if manual and manual.Handle and manual.Handle.Parent and not claimed[manual.Handle] then
			return manual
		end
		-- Strict: you picked this exact hat -> never swap in a different one
		if m.StrictHats and X.trim(label) ~= "" then return nil end
		local autoLimb = (kind == "clone") and m.CloneAutoHats or (kind ~= "clone" and m.AutoLimbHats)
		if m.SelectFirst then autoLimb = false end
		if autoLimb then
			for _, h in ipairs(HatCache) do
				if h.LimbGuess == limb and X.autoAllowed(h, claimed, kind) then return h end
			end
		end
		return nil
	end

	X.nextSpare = function(claimed, kind)
		for _, h in ipairs(HatCache) do
			if (not h.Used) and (not h.LimbGuess) and X.autoAllowed(h, claimed, kind) then return h end
		end
		return nil
	end

	X.clearLabels = function()
		for _, gui in pairs(NameLabels) do pcall(function() gui:Destroy() end) end
		NameLabels = {}
	end

	function X.makeLabel(part, text)
		if not m.ShowHatNames or not part then return end
		local bg = Instance.new("BillboardGui")
		bg.Name = "HS_HatName"
		bg.Size = UDim2.fromOffset(130, 22)
		bg.StudsOffset = Vector3.new(0, 1.15, 0)
		bg.AlwaysOnTop = true
		bg.Adornee = part
		bg.Parent = part
		local tl = Instance.new("TextLabel")
		tl.Size = UDim2.fromScale(1, 1)
		tl.BackgroundTransparency = 0.3
		tl.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
		tl.TextColor3 = Color3.fromRGB(255, 230, 100)
		tl.TextScaled = true
		tl.Font = Enum.Font.Code
		tl.Text = text
		tl.Parent = bg
		Instance.new("UICorner", tl).CornerRadius = UDim.new(0, 4)
		NameLabels[part] = bg
	end

	X.clearLimbPreview = function()
		for _, p in pairs(LimbPreviewParts) do
			pcall(function() p:Destroy() end)
		end
		LimbPreviewParts = {}
	end

	local PREVIEW_COLORS = {
		Head = Color3.fromRGB(255, 220, 80),
		Torso = Color3.fromRGB(80, 180, 255),
		LeftArm = Color3.fromRGB(100, 255, 140),
		RightArm = Color3.fromRGB(100, 255, 140),
		LeftLeg = Color3.fromRGB(255, 120, 180),
		RightLeg = Color3.fromRGB(255, 120, 180),
	}

	X.updateLimbPreview = function()
		X.clearLimbPreview()
		if not m.ShowLimbPreview then return end
		if not StandRoot or not StandRoot.Parent then return end
		for _, limb in ipairs(LIMB_NAMES) do
			local offset = X.makeBaseOffset(limb)
			local part = Instance.new("Part")
			part.Name = "HS_Preview_" .. limb
			part.Size = Vector3.new(0.55, 0.55, 0.55)
			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Material = Enum.Material.Neon
			part.Color = PREVIEW_COLORS[limb] or Color3.fromRGB(200, 200, 200)
			part.Transparency = 0.45
			part.CFrame = StandRoot.CFrame * offset
			part.Parent = StandModel or workspace
			local bg = Instance.new("BillboardGui")
			bg.Size = UDim2.fromOffset(70, 16)
			bg.StudsOffset = Vector3.new(0, 0.7, 0)
			bg.AlwaysOnTop = true
			bg.Adornee = part
			bg.Parent = part
			local tl = Instance.new("TextLabel")
			tl.Size = UDim2.fromScale(1, 1)
			tl.BackgroundTransparency = 0.4
			tl.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
			tl.TextColor3 = Color3.fromRGB(255, 255, 255)
			tl.TextScaled = true
			tl.Font = Enum.Font.Code
			tl.Text = limb
			tl.Parent = bg
			Instance.new("UICorner", tl).CornerRadius = UDim.new(0, 3)
			LimbPreviewParts[limb] = part
		end
	end

	--------------------------------------------------------------
	-- FE CONTROL
	--------------------------------------------------------------
	X.releaseOne = function(handle, held)
		if handle and Claims[handle] == INSTANCE_ID then Claims[handle] = nil end
		pcall(function() if held.AP then held.AP:Destroy() end end)
		pcall(function() if held.AO then held.AO:Destroy() end end)
		pcall(function() if held.Att then held.Att:Destroy() end end)
		local acc = held.Acc
		if acc and acc.Parent then
			local char = LocalPlayer.Character
			local hum = char and char:FindFirstChildOfClass("Humanoid")
			if hum then pcall(function() hum:AddAccessory(acc) end) end
		end
	end

	X.releaseHeld = function(keepSet)
		for handle, held in pairs(Held) do
			if not (keepSet and keepSet[handle]) then
				X.releaseOne(handle, held)
				Held[handle] = nil
			end
		end
	end

	X.attachFE = function(hat, kind)
		local handle = hat.Handle
		if not handle or not handle.Parent then return nil end
		if Held[handle] then
			Held[handle].Kind = kind or Held[handle].Kind
			return Held[handle]
		end
		if Claims[handle] and Claims[handle] ~= INSTANCE_ID then return nil end -- another Hat module owns it
		Claims[handle] = INSTANCE_ID pcall(X.boostNetwork)
		local held = { Acc = hat.Accessory, Handle = handle, Kind = kind or "stand" }
		for _, d in ipairs(handle:GetChildren()) do
			if d:IsA("JointInstance") or d:IsA("WeldConstraint") then
				pcall(function() d:Destroy() end)
			end
		end
		pcall(function()
			handle.Anchored = false
			handle.CanCollide = false
			handle.CanTouch = false
			handle.Massless = true
			handle.LocalTransparencyModifier = 0
		end)
		pcall(function()
			local att = Instance.new("Attachment")
			att.Name = "HS_Att"
			att.Parent = handle
			held.Att = att
			local ap = Instance.new("AlignPosition")
			ap.Name = "HS_AP"
			ap.Mode = Enum.PositionAlignmentMode.OneAttachment
			ap.Attachment0 = att
			ap.RigidityEnabled = true
			ap.MaxForce = math.huge
			ap.Responsiveness = 200
			ap.Position = handle.Position
			ap.Parent = handle
			held.AP = ap
			local ao = Instance.new("AlignOrientation")
			ao.Name = "HS_AO"
			ao.Mode = Enum.OrientationAlignmentMode.OneAttachment
			ao.Attachment0 = att
			ao.RigidityEnabled = true
			ao.MaxTorque = math.huge
			ao.Responsiveness = 200
			ao.CFrame = handle.CFrame
			ao.Parent = handle
			held.AO = ao
		end)
		Held[handle] = held
		return held
	end

	X.driveHandle = function(held, cf, vel)
		if not held or not held.Handle then return end
		local last = held.LastCF
		held.LastCF = cf
		if m.HatsSolid and not vel then
			-- solid hats need a real velocity or they only overlap things instead of pushing them
			local t = os.clock()
			if last and held.LastT and t > held.LastT then
				local v = (cf.Position - last.Position) / (t - held.LastT) * (m.HatsSolidPush or 1)
				if v.Magnitude > 250 then v = v.Unit * 250 end
				vel = v
			end
			held.LastT = t
		end
		-- low-lag: a hat that has not moved does not need its CFrame/velocity rewritten every frame
		if last and not vel and m.LowLag ~= false then
			local sk = (held.SkipN or 0) + 1
			if sk < 8
				and (last.Position - cf.Position).Magnitude < 0.004
				and last.LookVector:Dot(cf.LookVector) > 0.99999
				and last.UpVector:Dot(cf.UpVector) > 0.99999 then
				held.SkipN = sk
				return
			end
			held.SkipN = 0
		end
		local part = held.Handle
		pcall(function()
			if held.AP then held.AP.Position = cf.Position end
			if held.AO then held.AO.CFrame = cf end
			part.CFrame = cf
			part.AssemblyLinearVelocity = vel or Vector3.zero
			part.AssemblyAngularVelocity = Vector3.zero
		end)
	end

	X.cloneHandle = function(handle, name)
		local ok, clone = pcall(function() return handle:Clone() end)
		if not ok or not clone then return nil end
		clone.Name = "Stand_" .. name
		clone.Anchored = true
		clone.CanCollide = false
		clone.CanQuery = false
		clone.CanTouch = false
		clone.Massless = true
		pcall(function()
			clone.LocalTransparencyModifier = 0
			if clone.Transparency > 0.5 then clone.Transparency = 0 end
		end)
		for _, d in ipairs(clone:GetDescendants()) do
			if d:IsA("Weld") or d:IsA("WeldConstraint") or d:IsA("Motor6D")
				or d:IsA("RigidConstraint") or d:IsA("JointInstance") then
				pcall(function() d:Destroy() end)
			elseif d:IsA("BasePart") then
				pcall(function() d.Anchored = true d.CanCollide = false end)
			end
		end
		return clone
	end

	--------------------------------------------------------------
	-- STAND
	--------------------------------------------------------------
	X.destroyStand = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "stand" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		X.clearLabels()
		X.clearLimbPreview()
		Limbs = {}
		if StandModel then pcall(function() StandModel:Destroy() end) end
		StandModel, StandRoot = nil, nil
		AnimState, AnimT = "idle", 0
	end

	X.buildStand = function()
		if not X.modeAllowsStand() then return false end
		if m.SelectFirst and not X.Applied then return false end
		LastBuild = os.clock()
		X.clearLabels()
		Limbs = {}
		X.refreshAllHats()
		LastHatFingerprint = X.hatFingerprint()
		local followRoot = X.getFollowRoot()
		if not followRoot then
			warn("[HatStand] no follow root yet")
			return false
		end
		if m.FEMode then X.boostNetwork() end
		if not StandModel or not StandModel.Parent then
			local model = Instance.new("Model")
			model.Name = ("UhhhhhhHatStand" .. SUF)
			local root = Instance.new("Part")
			root.Name = "StandRoot"
			root.Size = Vector3.new(0.3, 0.3, 0.3)
			root.Transparency = 1
			root.Anchored = true
			root.CanCollide = false
			root.CanQuery = false
			root.CanTouch = false
			root.CFrame = followRoot.CFrame * CFrame.new(m.SideOffset, m.HeightOffset, m.ForwardOffset)
			root.Parent = model
			model.PrimaryPart = root
			model.Parent = workspace
			StandModel, StandRoot = model, root
		elseif not StandRoot or not StandRoot.Parent then
			StandRoot = StandModel:FindFirstChild("StandRoot")
		end
		if StandModel then
			for _, ch in ipairs(StandModel:GetChildren()) do
				if ch ~= StandRoot and ch.Name:sub(1, 6) == "Stand_" then
					pcall(function() ch:Destroy() end)
				end
			end
		end
		local claimed, assignment = {}, {}
		for handle, held in pairs(Held) do
			if held.Kind == "clone" then claimed[handle] = true end
		end
		for _, limb in ipairs(LIMB_NAMES) do
			local hat = X.findHatForLimb(limb, claimed, "stand", LIMB_KEYS)
			if hat then claimed[hat.Handle] = true assignment[limb] = hat end
		end
		if m.AutoSpareHats and not m.SelectFirst then
			for _, limb in ipairs(LIMB_NAMES) do
				if not assignment[limb] and not (m.StrictHats and X.trim(m[LIMB_KEYS[limb]]) ~= "") then
					local hat = X.nextSpare(claimed, "stand")
					if hat then claimed[hat.Handle] = true assignment[limb] = hat end
				end
			end
		end
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "stand" then keep[handle] = true end
		end
		local assigned = 0
		for _, limb in ipairs(LIMB_NAMES) do
			local hat = assignment[limb]
			if hat then
				local offset = X.makeBaseOffset(limb)
				local part, held = nil, nil
				if m.FEMode then
					held = X.attachFE(hat, "stand")
					if held then keep[hat.Handle] = true part = hat.Handle end
				else
					part = X.cloneHandle(hat.Handle, limb .. "_" .. hat.Name)
					if part then part.CFrame = StandRoot.CFrame * offset part.Parent = StandModel end
				end
				if part then
					Limbs[limb] = { Part = part, BaseOffset = offset, Name = hat.Name, Limb = limb, Held = held }
					X.makeLabel(part, limb .. ": " .. hat.Name)
					assigned = assigned + 1
				end
			end
		end
		X.releaseHeld(keep)
		X.refreshAllHats()
		LastHatFingerprint = X.hatFingerprint()
		X.updateLimbPreview()
		warn("[HatStand] limbs=" .. tostring(assigned) .. " FE=" .. tostring(m.FEMode))
		return assigned > 0
	end

	--------------------------------------------------------------
	-- ANIM (dance detection improved)
	--------------------------------------------------------------
	X.newOffsets = function()
		return {
			Head = CFrame.new(), Torso = CFrame.new(),
			LeftArm = CFrame.new(), RightArm = CFrame.new(),
			LeftLeg = CFrame.new(), RightLeg = CFrame.new(),
		}
	end

	function X.playerIsDancing(hum)
		if ForceDance and os.clock() < ForceDanceUntil then
			DetectedDanceName = "force"
			return true
		end
		if not m.DanceSync or not hum then return false end
		local animator = hum:FindFirstChildOfClass("Animator")
		if not animator then return false end
		local ok, tracks = pcall(function() return animator:GetPlayingAnimationTracks() end)
		if not ok or type(tracks) ~= "table" then return false end
		DetectedDanceName = ""
		local bestWeight, bestName = 0, ""
		for _, track in ipairs(tracks) do
			local playing = false
			pcall(function() playing = track.IsPlaying end)
			if playing then
				local w = 0
				pcall(function() w = track.weightCurrent or 0 end)
				if w >= 0.08 then
					local name = ""
					pcall(function()
						name = string.lower(tostring(track.Name or "") .. " " .. tostring(track.Animation and track.Animation.Name or ""))
					end)
					local isLoco = string.find(name, "walk", 1, true) or string.find(name, "run", 1, true)
						or string.find(name, "jump", 1, true) or string.find(name, "fall", 1, true)
						or string.find(name, "climb", 1, true) or string.find(name, "swim", 1, true)
					local isIdle = false
					if m.PoseFix then
						local hintHit = false
						for _, hint in ipairs(DANCE_HINTS) do
							if string.find(name, hint, 1, true) then hintHit = true break end
						end
						if string.find(name, "idle", 1, true) or string.find(name, "toolnone", 1, true) then isIdle = true end
						pcall(function()
							if track.Priority == Enum.AnimationPriority.Idle and not hintHit then isIdle = true end
						end)
					end
					if not isLoco and not isIdle then
						local matched = false
						for _, hint in ipairs(DANCE_HINTS) do
							if string.find(name, hint, 1, true) then
								matched = true
								break
							end
						end
						local len = 0
						pcall(function() len = track.Length or 0 end)
						if matched or (w > 0.35 and len > 0.8) or (w > 0.55) then
							if w > bestWeight then
								bestWeight, bestName = w, name
							end
						end
					end
				end
			end
		end
		if bestWeight > 0 then
			DetectedDanceName = bestName
			return true
		end
		return false
	end

	local CHAR_LIMB_NAMES = {
		Head = { "Head" },
		Torso = { "Torso", "UpperTorso" },
		LeftArm = { "Left Arm", "LeftUpperArm", "LeftHand" },
		RightArm = { "Right Arm", "RightUpperArm", "RightHand" },
		LeftLeg = { "Left Leg", "LeftUpperLeg", "LeftFoot" },
		RightLeg = { "Right Leg", "RightUpperLeg", "RightFoot" },
	}
	function X.sampleCharacterLimbOffsets()
		if not m.DanceMirrorCharacter then return nil end
		local char = LocalPlayer.Character
		if not char then return nil end
		local root = X.getRoot(char)
		if not root then return nil end
		local inv = root.CFrame:Inverse()
		local out = X.newOffsets()
		local got = 0
		for limb, names in pairs(CHAR_LIMB_NAMES) do
			for _, n in ipairs(names) do
				local part = char:FindFirstChild(n)
				if part and part:IsA("BasePart") then
					local rel = inv * part.CFrame
					local base = X.makeBaseOffset(limb)
					out[limb] = base:Inverse() * rel
					got = got + 1
					break
				end
			end
		end
		if got < 3 then return nil end
		return out
	end

	X.updateLocoMode = function(dt)
		local followRoot = X.getFollowRoot()
		local hum = X.getLiveHumanoid()
		if X.playerIsDancing(hum) then
			LocoMode = "dance"
			DanceT = DanceT + dt
			return
		end
		if not followRoot then LocoMode = "idle" return end
		local vel = followRoot.AssemblyLinearVelocity or Vector3.zero
		local horiz = Vector3.new(vel.X, 0, vel.Z).Magnitude
		local state = hum and hum:GetState() or nil
		if state == Enum.HumanoidStateType.Jumping or state == Enum.HumanoidStateType.Freefall or vel.Y > 8 then
			LocoMode = "jump"
		elseif horiz > (m.RunThreshold or 14) then
			LocoMode = "run"
			LocoT = LocoT + dt
		elseif horiz > 1.5 then
			LocoMode = "walk"
			LocoT = LocoT + dt
		else
			LocoMode = "idle"
		end
	end


	function X.jojoWalkOffsets(t, strength)
		local o, s = X.newOffsets(), strength or 1
		local sw, sw2 = math.sin(t), math.sin(t + math.pi)
		o.LeftLeg = CFrame.Angles(-math.rad(28) * sw * s, 0, math.rad(4) * s)
			* CFrame.new(0, math.max(0, -sw) * 0.12 * s, -0.15 * sw * s)
		o.RightLeg = CFrame.Angles(-math.rad(28) * sw2 * s, 0, -math.rad(4) * s)
			* CFrame.new(0, math.max(0, -sw2) * 0.12 * s, -0.15 * sw2 * s)
		o.LeftArm = CFrame.Angles(-math.rad(35) * sw2 * s, 0, math.rad(18) * s)
			* CFrame.new(0.05 * s, 0, -0.1 * sw2 * s)
		o.RightArm = CFrame.Angles(-math.rad(35) * sw * s, 0, -math.rad(18) * s)
			* CFrame.new(-0.05 * s, 0, -0.1 * sw * s)
		o.Torso = CFrame.Angles(math.rad(6) * s, math.rad(8) * sw * s, 0)
			* CFrame.new(0, math.abs(sw) * 0.04 * s, 0)
		o.Head = CFrame.Angles(math.rad(4) * s, -math.rad(6) * sw * s, 0)
		return o
	end

	function X.jojoRunOffsets(t, strength)
		local o, s = X.newOffsets(), strength or 1
		local sw, sw2 = math.sin(t), math.sin(t + math.pi)
		o.LeftLeg = CFrame.Angles(-math.rad(55) * sw * s, 0, math.rad(8) * s)
			* CFrame.new(0, math.max(0, -sw) * 0.2 * s, -0.35 * sw * s)
		o.RightLeg = CFrame.Angles(-math.rad(55) * sw2 * s, 0, -math.rad(8) * s)
			* CFrame.new(0, math.max(0, -sw2) * 0.2 * s, -0.35 * sw2 * s)
		o.LeftArm = CFrame.Angles(-math.rad(70) * sw2 * s, math.rad(10) * s, math.rad(25) * s)
			* CFrame.new(0.1 * s, 0.1 * s, -0.4 * sw2 * s)
		o.RightArm = CFrame.Angles(-math.rad(70) * sw * s, -math.rad(10) * s, -math.rad(25) * s)
			* CFrame.new(-0.1 * s, 0.1 * s, -0.4 * sw * s)
		o.Torso = CFrame.Angles(math.rad(18) * s, math.rad(12) * sw * s, 0)
			* CFrame.new(0, math.abs(sw) * 0.08 * s, 0)
		o.Head = CFrame.Angles(math.rad(12) * s, -math.rad(8) * sw * s, 0)
		return o
	end

	function X.jojoJumpOffsets(strength)
		local o, s = X.newOffsets(), strength or 1
		o.LeftArm = CFrame.Angles(-math.rad(30) * s, 0, math.rad(50) * s) * CFrame.new(0.15 * s, 0.3 * s, -0.1 * s)
		o.RightArm = CFrame.Angles(-math.rad(30) * s, 0, -math.rad(50) * s) * CFrame.new(-0.15 * s, 0.3 * s, -0.1 * s)
		o.LeftLeg = CFrame.Angles(math.rad(25) * s, 0, math.rad(10) * s) * CFrame.new(0, 0.2 * s, 0.15 * s)
		o.RightLeg = CFrame.Angles(math.rad(15) * s, 0, -math.rad(10) * s) * CFrame.new(0, 0.15 * s, 0.1 * s)
		o.Torso = CFrame.Angles(-math.rad(8) * s, 0, 0) * CFrame.new(0, 0.15 * s, 0)
		o.Head = CFrame.Angles(math.rad(10) * s, 0, 0)
		return o
	end

	X.danceOffsets = function(t, strength)
		local o = X.newOffsets()
		local s = (strength or 1) * (m.DanceStrength or 1)
		local a, b, c = math.sin(t * 6.5), math.sin(t * 4.2), math.cos(t * 5.1)
		-- slightly vary by detected dance name
		local dn = DetectedDanceName or ""
		if string.find(dn, "floss") or string.find(dn, "disco") then
			a, b = math.sin(t * 8), math.sin(t * 3.5)
		elseif string.find(dn, "robot") then
			a = math.sin(t * 4) * 0.6
			b = math.cos(t * 4) * 0.6
		elseif string.find(dn, "wave") or string.find(dn, "cheer") then
			a = math.sin(t * 5)
			b = math.sin(t * 2.2)
		end
		o.Torso = CFrame.Angles(math.rad(5) * a * s, math.rad(20) * b * s, math.rad(8) * c * s)
			* CFrame.new(b * 0.2 * s, math.abs(a) * 0.25 * s, 0)
		o.Head = CFrame.Angles(math.rad(10) * a * s, math.rad(25) * b * s, math.rad(5) * c * s)
		o.LeftArm = CFrame.Angles(-math.rad(80) + math.rad(40) * a * s, 0, math.rad(40) + math.rad(30) * b * s)
			* CFrame.new(0.2 * s, 0.3 * s, -0.2 * s)
		o.RightArm = CFrame.Angles(-math.rad(80) + math.rad(40) * c * s, 0, -math.rad(40) - math.rad(30) * a * s)
			* CFrame.new(-0.2 * s, 0.3 * s, -0.2 * s)
		o.LeftLeg = CFrame.Angles(math.rad(15) * b * s, 0, math.rad(12) * s)
			* CFrame.new(0, math.max(0, a) * 0.15 * s, 0)
		o.RightLeg = CFrame.Angles(math.rad(15) * c * s, 0, -math.rad(12) * s)
			* CFrame.new(0, math.max(0, -a) * 0.15 * s, 0)
		return o
	end

	function X.ballerOffsets(t)
		local o = X.newOffsets()
		local s = 1
		local a = math.sin(t * 2.8)
		local b = math.sin(t * 1.6)
		o.Torso = CFrame.Angles(math.rad(8), math.rad(12) * b, 0) * CFrame.new(0, math.abs(a) * 0.08, 0)
		o.Head = CFrame.Angles(math.rad(6), -math.rad(10) * b, 0)
		o.LeftArm = CFrame.Angles(-math.rad(25) + a * 0.15, 0, math.rad(35))
			* CFrame.new(0.1, 0.15, -0.15)
		o.RightArm = CFrame.Angles(-math.rad(20) - a * 0.1, 0, -math.rad(40))
			* CFrame.new(-0.15, 0.2, -0.25)
		o.LeftLeg = CFrame.Angles(math.rad(5) * a, 0, math.rad(8))
		o.RightLeg = CFrame.Angles(-math.rad(8) * a, 0, -math.rad(6))
		return o
	end

	X.buildAnimOffsets = function(t, speed)
		local o = X.newOffsets()
		local s = speed or 1
		local a = math.sin(t * 8 * s)
		local b = math.sin(t * 5 * s)
		o.RightArm = CFrame.Angles(-math.rad(70) + math.rad(25) * a, math.rad(10), -math.rad(15))
			* CFrame.new(-0.1, 0.2 + 0.1 * a, -0.8 + 0.15 * a)
		o.LeftArm = CFrame.Angles(-math.rad(40), 0, math.rad(25)) * CFrame.new(0.15, 0.1, -0.2)
		o.Torso = CFrame.Angles(math.rad(12) + math.rad(3) * b, -math.rad(15), 0)
		o.Head = CFrame.Angles(math.rad(8), math.rad(10) * b, 0)
		return o
	end

	X.idleOffsets = function()
		local o = X.newOffsets()
		local style, t = m.IdleStyle, IdleT
		if m.BallerMode or style == 7 then
			return X.ballerOffsets(t)
		end
		if style == 6 then return o end
		if style == 1 then
			local b, s = math.sin(t * 1.7) * 0.05, math.sin(t * 0.9) * 0.025
			o.Torso = CFrame.new(0, b, 0) * CFrame.Angles(0, s, 0)
			o.Head = CFrame.Angles(b * 0.6, s * 1.4, 0)
			o.LeftArm = CFrame.Angles(math.sin(t * 1.3) * 0.06, 0, math.rad(5))
			o.RightArm = CFrame.Angles(-math.sin(t * 1.3) * 0.06, 0, -math.rad(5))
		elseif style == 2 then
			local b = math.abs(math.sin(t * 3.2)) * 0.2
			o.Torso = CFrame.new(0, b, 0)
			o.LeftArm = CFrame.Angles(-b * 0.8, 0, math.rad(8))
			o.RightArm = CFrame.Angles(-b * 0.8, 0, -math.rad(8))
		elseif style == 3 then
			o.LeftArm = CFrame.Angles(-math.rad(35), 0, math.rad(25)) * CFrame.new(0.15, 0.1, -0.2)
			o.RightArm = CFrame.Angles(-math.rad(40), 0, -math.rad(20)) * CFrame.new(-0.1, 0.15, -0.35)
			o.Torso = CFrame.Angles(math.rad(5), -math.rad(8), 0)
		elseif style == 4 then
			local sw = math.sin(t * 2.4)
			o.Torso = CFrame.Angles(0, 0, sw * 0.12) * CFrame.new(sw * 0.15, 0, 0)
			o.LeftArm = CFrame.Angles(sw * 0.4, 0, math.rad(20) + sw * 0.3)
			o.RightArm = CFrame.Angles(-sw * 0.4, 0, -math.rad(20) - sw * 0.3)
		elseif style == 5 then
			local f = math.sin(t * 1.2) * 0.35
			o.Torso = CFrame.new(0, 0.8 + f, 0)
			o.LeftArm = CFrame.Angles(0, 0, math.rad(25))
			o.RightArm = CFrame.Angles(0, 0, -math.rad(25))
		end
		return o
	end

	X.combatOffsets = function(state, t)
		local o = X.newOffsets()
		local s = m.AnimSpeed
		local a = math.clamp(t * 9 * s, 0, 1)
		local swing = math.sin(a * math.pi)
		if state == "punch" then
			o.RightArm = CFrame.Angles(-math.rad(100) * swing, math.rad(10) * swing, math.rad(25) * swing)
				* CFrame.new(0.2 * swing, 0.15 * swing, -1.6 * swing)
			o.Torso = CFrame.Angles(math.rad(8) * swing, -math.rad(40) * swing, 0)
			o.LeftArm = CFrame.Angles(math.rad(40) * swing, 0, math.rad(15) * swing)
		elseif state == "punch2" then
			o.LeftArm = CFrame.Angles(-math.rad(100) * swing, -math.rad(10) * swing, -math.rad(25) * swing)
				* CFrame.new(-0.2 * swing, 0.15 * swing, -1.6 * swing)
			o.Torso = CFrame.Angles(math.rad(8) * swing, math.rad(40) * swing, 0)
		elseif state == "uppercut" then
			o.RightArm = CFrame.Angles(-math.rad(140) * swing, 0, 0) * CFrame.new(0, 1.4 * swing, -0.6 * swing)
			o.Torso = CFrame.Angles(-math.rad(20) * swing, 0, 0)
		elseif state == "kick" then
			o.RightLeg = CFrame.Angles(-math.rad(110) * swing, 0, 0) * CFrame.new(0, 0.6 * swing, -1.4 * swing)
			o.Torso = CFrame.Angles(math.rad(18) * swing, 0, 0)
		elseif state == "block" then
			o.LeftArm = CFrame.Angles(-math.rad(80), math.rad(20), math.rad(50)) * CFrame.new(0.4, 0.5, -0.6)
			o.RightArm = CFrame.Angles(-math.rad(80), -math.rad(20), -math.rad(50)) * CFrame.new(-0.4, 0.5, -0.6)
		elseif state == "wave" then
			o.RightArm = CFrame.Angles(math.rad(-20), 0, math.rad(100) + math.rad(45) * math.sin(t * 12 * s))
		end
		return o
	end

	--------------------------------------------------------------
	-- v14: ROOT-SPACE ANIMATION, RIG LINK, LOCO V2, DANCE LIST, CLONE
	-- (all new functions live on the X table to stay under Luau's local limit)
	--------------------------------------------------------------
	X.standUnit = function()
		local h = (m.BigRigFix or m.FixAnyRigPose) and (m.BigRigHeight or 1) or 1
		return (m.StandScale or 1) * h
	end

	-- Rotate a limb about its joint. `joint` = vector from limb centre to its pivot.
	-- Result: CFrame whose position is the centre shift and rotation is R (stand-root space).
	X.pivotExtra = function(R, joint)
		return CFrame.new(joint - R:VectorToWorldSpace(joint)) * R
	end

	-- old limb-local extras (base * X) -> root-space extra with identical result
	function X.legacyToRoot(base, lx)
		local brot = base - base.Position
		local xp = lx.Position
		local xr = lx - xp
		local R = brot * xr * brot:Inverse()
		return CFrame.new(brot:VectorToWorldSpace(xp)) * R
	end

	X.applyRootExtra = function(base, E)
		local bp = base.Position
		local dp = E.Position
		local R = E - dp
		return CFrame.new(bp + dp) * R * (base - bp)
	end

	X.carry = function(Rt, limb, joint)
		local tc = X.makeBaseOffset("Torso").Position
		local d = X.makeBaseOffset(limb).Position + joint - tc
		return Rt:VectorToWorldSpace(d) - d
	end

	-- ---------- air / landing tracking ----------
	X.updateAir = function(dt)
		local hum = X.getLiveHumanoid()
		local air, st = false, nil
		if hum then
			pcall(function() st = hum:GetState() end)
			air = (st == Enum.HumanoidStateType.Freefall or st == Enum.HumanoidStateType.Jumping)
		else
			local r = X.getFollowRoot()
			if r then air = math.abs((r.AssemblyLinearVelocity or Vector3.zero).Y) > 8 end
		end
		X.State = st
		X.Air = air
		if air then
			X.AirT = X.AirT + dt
			X.WasAir = true
		else
			if X.WasAir and X.AirT > 0.18 then X.LandT = 0.24 end
			X.WasAir = false
			X.AirT = 0
		end
		X.LandT = math.max(0, X.LandT - dt)
	end

	-- ---------- rig link: copy the real animated rig onto the stand ----------
	X.getSourceRig = function()
		local src = m.LinkSource or 1
		local function pick(model)
			if not (model and model.Parent) then return nil, nil end
			local root = model:FindFirstChild("HumanoidRootPart")
				or model:FindFirstChild("Torso") or model:FindFirstChild("UpperTorso")
			if root and root:IsA("BasePart") then return model, root end
			return nil, nil
		end
		if src ~= 3 then
			local uh = nil
			pcall(function() uh = _G.Uhhhhhh and _G.Uhhhhhh.Character end)
			local mdl, r = pick(uh)
			if mdl then return mdl, r end
			if src == 2 then return nil, nil end
		end
		return pick(LocalPlayer.Character)
	end

	X.rawSample = function()
		if X.RawFrame == X.Frame then return X.Raw end
		X.RawFrame = X.Frame
		X.Raw = nil
		local model, root = X.getSourceRig()
		if not model then return nil end
		local inv = root.CFrame:Inverse()
		local rot, got = {}, 0
		if X._rawModel ~= model then X._rawModel = model; X._rawParts = {} end
		local pc = X._rawParts
		for limb, names in pairs(CHAR_LIMB_NAMES) do
			for _, n in ipairs(names) do
				local part = pc[n]
				if not (part and part.Parent) then
					part = model:FindFirstChild(n)
					pc[n] = part
				end
				if part and part:IsA("BasePart") then
					local rel = inv * part.CFrame
					rot[limb] = rel - rel.Position
					got = got + 1
					break
				end
			end
		end
		if got < 3 then return nil end
		X.Raw = rot
		return rot
	end

	X.calibrate = function()
		local raw = X.rawSample()
		if not raw then
			warn("[HatStand] calibrate: no source rig found")
			return false
		end
		X.Rest = {}
		for k, v in pairs(raw) do X.Rest[k] = v end
		X.RestSet = true
		X.Blend = {}
		warn("[HatStand] rest pose calibrated")
		return true
	end

	X.autoCalib = function(dt)
		if not (m.PoseFix and m.PoseAutoCalib) or X.RestSet then X.CalibT = 0 return end
		local raw = X.rawSample()
		if not raw then X.CalibT = 0 return end
		local fr = X.getFollowRoot()
		local v = fr and fr.AssemblyLinearVelocity or Vector3.zero
		local still = Vector3.new(v.X, 0, v.Z).Magnitude < 0.6 and math.abs(v.Y) < 2
			and LocoMode ~= "dance" and not (ForceDance and os.clock() < ForceDanceUntil)
		local dev = 1
		if X.LastRaw then
			dev = 0
			for k, c in pairs(raw) do
				local o = X.LastRaw[k]
				if o then dev = dev + (c.LookVector - o.LookVector).Magnitude + (c.UpVector - o.UpVector).Magnitude end
			end
		end
		X.LastRaw = raw
		if still and dev < 0.03 then X.CalibT = X.CalibT + dt else X.CalibT = 0 end
		if X.CalibT > 0.9 then
			X.CalibT = 0
			X.calibrate()
		end
	end

	X.fixArms = function(rot)
		local L, R = rot.LeftArm, rot.RightArm
		if m.PoseSwapArms and L and R then
			local function mir(c)
				local rx, ry, rz = c:ToEulerAnglesXYZ()
				return CFrame.Angles(rx, -ry, -rz)
			end
			L, R = mir(R), mir(L)
		end
		if m.PoseInvertArmPitch or m.PoseInvertArmRoll then
			local function adj(c)
				if not c then return c end
				local rx, ry, rz = c:ToEulerAnglesXYZ()
				if m.PoseInvertArmPitch then rx = -rx end
				if m.PoseInvertArmRoll then rz = -rz end
				return CFrame.Angles(rx, ry, rz)
			end
			L, R = adj(L), adj(R)
		end
		rot.LeftArm, rot.RightArm = L, R
	end

	X.sampleRig = function()
		local raw = X.rawSample()
		if not raw then return nil end
		local rot = {}
		for k, v in pairs(raw) do rot[k] = v end
		if m.PoseFix then
			if X.RestSet then
				for limb, r in pairs(rot) do
					if X.Rest[limb] then rot[limb] = r * X.Rest[limb]:Inverse() end
				end
			end
			X.fixArms(rot)
		end
		local u = X.standUnit()
		local Rt = rot.Torso or CFrame.new()
		local joints = {
			Head = Vector3.new(0, -0.6 * u, 0),
			LeftArm = Vector3.new(0, 0.9 * u, 0), RightArm = Vector3.new(0, 0.9 * u, 0),
			LeftLeg = Vector3.new(0, 0.95 * u, 0), RightLeg = Vector3.new(0, 0.95 * u, 0),
		}
		local out = {}
		local strength = m.LinkStrength or 1
		for _, limb in ipairs(LIMB_NAMES) do
			local E
			if limb == "Torso" then
				E = Rt
			else
				local R = rot[limb] or CFrame.new()
				local j = joints[limb]
				E = CFrame.new(X.carry(Rt, limb, j) + j - R:VectorToWorldSpace(j)) * R
			end
			if strength ~= 1 then E = CFrame.new():Lerp(E, math.clamp(strength, 0, 1.5)) end
			out[limb] = E
		end
		return out
	end

	-- ---------- JoJo locomotion v2 (root space, speed-locked stride) ----------
	X.locoV2 = function(dt, guard)
		local followRoot = X.getFollowRoot()
		if not followRoot then return nil end
		local u = X.standUnit()
		local vel = followRoot.AssemblyLinearVelocity or Vector3.zero
		local cfr = followRoot.CFrame
		local look = Vector3.new(cfr.LookVector.X, 0, cfr.LookVector.Z)
		local right = Vector3.new(cfr.RightVector.X, 0, cfr.RightVector.Z)
		look = look.Magnitude > 0.01 and look.Unit or Vector3.new(0, 0, -1)
		right = right.Magnitude > 0.01 and right.Unit or Vector3.new(1, 0, 0)
		local hv = Vector3.new(vel.X, 0, vel.Z)
		local a = 1 - math.exp(-(m.LocoBlend or 14) * dt)
		X.SpeedSm = X.SpeedSm + (hv.Magnitude - X.SpeedSm) * a
		X.LeanSm = X.LeanSm + (hv:Dot(look) - X.LeanSm) * a
		X.SideSm = X.SideSm + (hv:Dot(right) - X.SideSm) * a
		local sp, st, air = X.SpeedSm, X.State, X.Air
		local land = X.LandT > 0
		local climbing = (st == Enum.HumanoidStateType.Climbing)
		local seated = (st == Enum.HumanoidStateType.Seated)
		if not (sp > 0.6 or air or land or climbing or seated) then return nil end

		local runT = m.RunThreshold or 14
		local running = sp > runT
		local cyc = running and ((m.RunCycleSpeed or 12.5) / 12.5 * 0.42)
			or ((m.WalkCycleSpeed or 8.5) / 8.5 * 0.52)
		if not air then X.Phase = (X.Phase + dt * sp * cyc) % (math.pi * 2) end

		local kWalk = math.clamp(sp / 9, 0, 1)
		local kRun = math.clamp((sp - runT * 0.7) / (runT * 0.8), 0, 1)
		local ws, rs = m.WalkStrength or 1, m.RunStrength or 1.15
		local legAmp = math.rad(30) * ws * kWalk + math.rad(20) * rs * kRun
		local armAmp = math.rad(26) * ws * kWalk + math.rad(36) * rs * kRun
		local dir = (X.LeanSm < -2) and -1 or 1
		local s = math.sin(X.Phase) * dir
		local c = math.cos(X.Phase) * dir
		local bob = (math.cos(2 * X.Phase) * 0.5 + 0.5) * 0.09 * u * kWalk
			* (m.LocoBob or 1) * (1 + kRun * 0.6)
		local lean = math.clamp(X.LeanSm / 16, -0.5, 1.3) * math.rad(11) * (m.LocoLean or 1)
		local side = math.clamp(X.SideSm / 16, -1, 1) * math.rad(6) * (m.LocoLean or 1)
		local armOut = math.rad(7 + 5 * kWalk) * (m.LocoArmOut or 1)
		local armJ = Vector3.new(0, 0.9 * u, 0)
		local legJ = Vector3.new(0, 0.95 * u, 0)

		local function swing(pitch, roll, joint, lift)
			local R = CFrame.Angles(pitch, 0, 0) * CFrame.Angles(0, 0, roll)
			return CFrame.new(0, lift or 0, 0) * X.pivotExtra(R, joint)
		end

		local o = {}
		if climbing then
			X.ClimbT = X.ClimbT + dt * math.clamp(math.abs(vel.Y) / 6, 0, 3)
			local cs = math.sin(X.ClimbT * 5)
			o.LeftArm = swing(math.rad(150) + cs * math.rad(25), -math.rad(8), armJ, 0)
			o.RightArm = swing(math.rad(150) - cs * math.rad(25), math.rad(8), armJ, 0)
			o.LeftLeg = swing(math.rad(20) - cs * math.rad(25), 0, legJ, math.max(0, cs) * 0.15 * u)
			o.RightLeg = swing(math.rad(20) + cs * math.rad(25), 0, legJ, math.max(0, -cs) * 0.15 * u)
			o.Torso = CFrame.new()
			o.Head = CFrame.Angles(-math.rad(15), 0, 0)
			return o
		elseif seated then
			o.LeftArm = swing(math.rad(25), -math.rad(6), armJ, 0)
			o.RightArm = swing(math.rad(25), math.rad(6), armJ, 0)
			o.LeftLeg = swing(math.rad(85), -math.rad(4), legJ, 0)
			o.RightLeg = swing(math.rad(85), math.rad(4), legJ, 0)
			o.Torso = CFrame.new()
			o.Head = CFrame.new()
			return o
		elseif air then
			local vy = vel.Y
			local riseK = math.clamp(vy / 45, 0, 1)
			local fallK = math.clamp(-vy / 45, 0, 1)
			local fs = m.FallSpread or 1
			local js = m.JumpStrength or 1.2
			local fl = math.sin(X.AirT * 9) * math.rad(5) * fallK * fs
			local spread = (math.rad(30) + math.rad(35) * fallK) * fs
			local armUp = math.rad(35 + 25 * riseK) * js * 0.8
			o.LeftArm = swing(armUp + fl, -spread, armJ, 0)
			o.RightArm = swing(armUp - fl, spread, armJ, 0)
			o.LeftLeg = swing(math.rad(30) * riseK * js + math.rad(8) + fl, -math.rad(8), legJ, 0.12 * u * riseK)
			o.RightLeg = swing(-math.rad(14) * riseK - math.rad(10) * fallK - fl, math.rad(8), legJ, 0)
			local Rt = CFrame.Angles(-math.rad(6) * riseK + math.rad(4) * fallK, 0, 0)
			o.Torso = Rt
			o.Head = CFrame.Angles(-math.rad(8) * fallK, 0, 0)
			for _, l in ipairs({ "LeftArm", "RightArm", "LeftLeg", "RightLeg", "Head" }) do
				local j = (l == "Head") and Vector3.new(0, -0.6 * u, 0) or (l:find("Arm") and armJ or legJ)
				o[l] = CFrame.new(X.carry(Rt, l, j)) * o[l]
			end
		else
			o.LeftLeg = swing(legAmp * s, -math.rad(2), legJ, math.max(0, c) * 0.2 * u * kWalk)
			o.RightLeg = swing(-legAmp * s, math.rad(2), legJ, math.max(0, -c) * 0.2 * u * kWalk)
			if guard then
				local g = math.rad(55) * (1 - kWalk * 0.4)
				o.LeftArm = swing(g - armAmp * 0.3 * s, -math.rad(15), armJ, 0)
				o.RightArm = swing(g + armAmp * 0.3 * s, math.rad(15), armJ, 0)
			else
				o.LeftArm = swing(-armAmp * s, -armOut, armJ, 0)
				o.RightArm = swing(armAmp * s, armOut, armJ, 0)
			end
			local Rt = CFrame.Angles(-lean, -math.rad(6) * s * kWalk, -side)
			o.Torso = Rt
			o.Head = CFrame.Angles(lean * 0.7, math.rad(5) * s * kWalk, side * 0.5)
			for _, l in ipairs({ "LeftArm", "RightArm", "LeftLeg", "RightLeg", "Head" }) do
				local j = (l == "Head") and Vector3.new(0, -0.6 * u, 0) or (l:find("Arm") and armJ or legJ)
				o[l] = CFrame.new(X.carry(Rt, l, j)) * o[l]
			end
		end

		if land then
			local k = (X.LandT / 0.24) * (m.LandSquash or 1)
			local dip = CFrame.new(0, -0.28 * u * k, 0)
			o.Torso = dip * CFrame.Angles(-math.rad(14) * k, 0, 0) * o.Torso
			o.Head = dip * CFrame.Angles(math.rad(10) * k, 0, 0) * o.Head
			o.LeftArm = dip * swing(math.rad(28) * k, -math.rad(10) * k, armJ, 0) * o.LeftArm
			o.RightArm = dip * swing(math.rad(28) * k, math.rad(10) * k, armJ, 0) * o.RightArm
			o.LeftLeg = dip * swing(math.rad(12) * k, -math.rad(14) * k, legJ, 0) * o.LeftLeg
			o.RightLeg = dip * swing(-math.rad(12) * k, math.rad(14) * k, legJ, 0) * o.RightLeg
		end

		if bob ~= 0 and not air then
			local b = CFrame.new(0, bob, 0)
			for _, l in ipairs(LIMB_NAMES) do o[l] = b * o[l] end
		end
		return o
	end

	-- ---------- procedural dances (used by "Procedural Dance" moveset) ----------
	X.procDance = function(t, idx)
		local o = {}
		local u = X.standUnit()
		local s = m.DanceStrength or 1
		local armJ = Vector3.new(0, 0.9 * u, 0)
		local legJ = Vector3.new(0, 0.95 * u, 0)
		local function arm(side, pitch, roll)
			return X.pivotExtra(CFrame.Angles(pitch, 0, 0) * CFrame.Angles(0, 0, roll * side), armJ)
		end
		local function armAbs(pitch, rollAbs)
			return X.pivotExtra(CFrame.Angles(pitch, 0, 0) * CFrame.Angles(0, 0, rollAbs), armJ)
		end
		local function leg(side, pitch, roll, lift)
			local R = CFrame.Angles(pitch, 0, 0) * CFrame.Angles(0, 0, roll * side)
			return CFrame.new(0, lift or 0, 0) * X.pivotExtra(R, legJ)
		end
		local function body(pitch, yaw, roll, y, x)
			return CFrame.new((x or 0) * u, (y or 0) * u, 0) * CFrame.Angles(pitch, yaw, roll)
		end
		if idx == 2 then -- floss
			local a = math.sin(t * 8) * s
			o.LeftArm = armAbs(math.rad(45), a * math.rad(55))
			o.RightArm = armAbs(math.rad(45), a * math.rad(55))
			o.Torso = body(0, 0, 0, math.abs(a) * 0.05, -a * 0.25)
			o.Head = body(0, a * 0.2, 0)
			o.LeftLeg = leg(-1, 0, math.rad(6), 0)
			o.RightLeg = leg(1, 0, math.rad(6), 0)
		elseif idx == 3 then -- robot
			local stepA = (math.floor(t * 2.5) % 2 == 0)
			local hy = ({ 0, 1, 0, -1 })[(math.floor(t * 1.25) % 4) + 1] * math.rad(35) * s
			o.LeftArm = arm(-1, stepA and math.rad(85) or 0, math.rad(10))
			o.RightArm = arm(1, stepA and 0 or math.rad(85), math.rad(10))
			o.Torso = body(0, stepA and math.rad(12) or -math.rad(12), 0)
			o.Head = body(0, hy, 0)
			o.LeftLeg = leg(-1, stepA and math.rad(15) or 0, 0, 0)
			o.RightLeg = leg(1, stepA and 0 or math.rad(15), 0, 0)
		elseif idx == 4 then -- disco
			local sgn = math.sin(t * 3) > 0 and 1 or -1
			local hip = math.sin(t * 6) * 0.2
			o.RightArm = sgn > 0 and arm(1, math.rad(150), math.rad(20)) or arm(1, 0, math.rad(25))
			o.LeftArm = sgn > 0 and arm(-1, 0, math.rad(25)) or arm(-1, math.rad(150), math.rad(20))
			o.Torso = body(0, 0, hip * 0.5 * s, 0, hip)
			o.Head = body(0, 0, -hip * 0.4)
			o.LeftLeg = leg(-1, 0, math.rad(8), math.max(0, -hip) * 0.3)
			o.RightLeg = leg(1, 0, math.rad(8), math.max(0, hip) * 0.3)
		elseif idx == 5 then -- hype
			local p = math.sin(t * 10) * s
			o.LeftArm = arm(-1, math.rad(150) + p * math.rad(30), math.rad(15))
			o.RightArm = arm(1, math.rad(150) - p * math.rad(30), math.rad(15))
			o.Torso = body(0, 0, 0, math.abs(math.sin(t * 5)) * 0.3 * s)
			o.Head = body(-math.rad(10), 0, 0, math.abs(math.sin(t * 5)) * 0.3 * s)
			o.LeftLeg = leg(-1, 0, math.rad(6), math.max(0, p) * 0.25)
			o.RightLeg = leg(1, 0, math.rad(6), math.max(0, -p) * 0.25)
		elseif idx == 6 then -- wave
			o.RightArm = armAbs(0, math.rad(150) + math.sin(t * 9) * math.rad(25) * s)
			o.LeftArm = arm(-1, math.sin(t * 2) * math.rad(10), math.rad(8))
			o.Torso = body(0, 0, math.sin(t * 2) * 0.04)
			o.Head = body(0, 0, math.sin(t * 2) * 0.12)
			o.LeftLeg = leg(-1, 0, math.rad(4), 0)
			o.RightLeg = leg(1, 0, math.rad(4), 0)
		else -- sway
			local sw = math.sin(t * 2.4) * s
			o.Torso = body(0, 0, sw * 0.12, 0, sw * 0.15)
			o.Head = body(0, sw * 0.2, -sw * 0.08)
			o.LeftArm = arm(-1, sw * 0.4, math.rad(20) + sw * 0.3)
			o.RightArm = arm(1, -sw * 0.4, math.rad(20) + sw * 0.3)
			o.LeftLeg = leg(-1, 0, math.rad(6), 0)
			o.RightLeg = leg(1, 0, math.rad(6), 0)
		end
		return o
	end

	-- ---------- pick the pose source for this frame ----------
	X.targetExtras = function(dt)
		local ods = X.OwnDance and X.OwnDance.Stand
		if ods then
			local sample = X.ownDanceSample(ods, dt)
			if ods.Finished then
				X.stopOwnDance("Stand")
			elseif sample then
				return sample, true, m.OwnDanceBlend or 30
			end
		end
		if AnimState ~= "idle" then
			local idle = X.idleOffsets()
			local c = X.combatOffsets(AnimState, AnimT)
			return {
				Head = idle.Head * c.Head, Torso = idle.Torso * c.Torso,
				LeftArm = c.LeftArm, RightArm = c.RightArm,
				LeftLeg = c.LeftLeg, RightLeg = c.RightLeg,
			}, false, 40
		end
		if X.modeAllowsPlace() and m.PlaceBuildAnim then
			return X.buildAnimOffsets(BuildAnimT, m.PlaceBuildAnimSpeed), false, 20
		end
		local mode = m.LinkRigs and 1 or (m.StandMoveset or 2)
		if mode == 1 then
			local s = X.sampleRig()
			if s then return s, true, m.LinkSmooth or 26 end
			if not X.LinkWarned then
				X.LinkWarned = true
				warn("[HatStand] Link: no animated source rig found — using JoJo stand moveset instead")
			end
			mode = 2
		end
		if mode == 4 then
			X.ProcT = X.ProcT + dt
			return X.procDance(X.ProcT, m.ProcDance or 1), true, 18
		end
		if LocoMode == "dance" then
			if m.DanceMirrorCharacter then
				local s = X.sampleRig()
				if s then return s, true, 30 end
			end
			return X.danceOffsets(DanceT, 1), false, 16
		end
		if m.WalkWithMe or m.JojoLoco then
			local lo = X.locoV2(dt, mode == 3)
			if lo then return lo, true, m.LocoBlend or 14 end
		end
		if mode == 3 then
			local old = m.IdleStyle
			m.IdleStyle = 3
			local o = X.idleOffsets()
			m.IdleStyle = old
			return o, false, 24
		end
		return X.idleOffsets(), false, 24
	end

	X.applyBlend = function(dt, extras, isRoot, rate)
		local a = (rate and rate > 0) and (1 - math.exp(-rate * dt)) or 1
		local res = {}
		for _, limb in ipairs(LIMB_NAMES) do
			local tgt = extras and extras[limb] or CFrame.new()
			if not isRoot then tgt = X.legacyToRoot(X.makeBaseOffset(limb), tgt) end
			local cur = X.Blend[limb] or CFrame.new()
			local nxt = cur:Lerp(tgt, a)
			local p = nxt.Position
			if p.X ~= p.X or p.Y ~= p.Y or p.Z ~= p.Z then nxt = tgt end
			X.Blend[limb] = nxt
			res[limb] = nxt
		end
		return res
	end

	X.resolve = function(dt)
		X.autoCalib(dt)
		local ex, isRoot, rate = X.targetExtras(dt)
		if m.PoseFix and m.PoseSnapAfterDance then
			if X.LastLoco == "dance" and LocoMode ~= "dance" then X.SnapT = 0.45 end
			X.LastLoco = LocoMode
			if X.SnapT > 0 then
				X.SnapT = X.SnapT - dt
				rate = math.max(rate or 0, 34)
			end
		end
		return X.applyBlend(dt, ex, isRoot, rate)
	end

	-- ---------- dance list (best effort: Uhhhhhh tables, Uhhhhhh UI, then built-in) ----------
	X.scanDances = function()
		local names, seen = {}, {}
		local source = "none"
		local function add(n)
			n = X.trim(n)
			if n == "" or #n > 42 then return end
			local l = string.lower(n)
			if seen[l] then return end
			seen[l] = true
			table.insert(names, n)
		end
		pcall(function()
			local U = _G.Uhhhhhh
			if type(U) ~= "table" then return end
			local function walk(t, depth)
				if depth > 3 or type(t) ~= "table" then return end
				for k, v in pairs(t) do
					local ks = string.lower(tostring(k))
					if type(v) == "table" and (string.find(ks, "dance", 1, true) or string.find(ks, "emote", 1, true)) then
						for k2, v2 in pairs(v) do
							if type(k2) == "string" then add(k2)
							elseif type(v2) == "string" then add(v2)
							elseif type(v2) == "table" and type(v2.Name) == "string" then add(v2.Name) end
						end
					elseif type(v) == "table" then
						walk(v, depth + 1)
					end
				end
			end
			walk(U, 0)
		end)
		if #names > 0 then source = "Uhhhhhh data" end
		if #names == 0 then
			pcall(function()
				for _, lbl in ipairs(CoreGui:GetDescendants()) do
					if (lbl:IsA("TextLabel") or lbl:IsA("TextButton")) and string.find(string.lower(lbl.Text or ""), "dance", 1, true)
						and #(lbl.Text or "") < 30 then
						local anc = lbl.Parent
						for _ = 1, 4 do
							if not anc then break end
							local btns = {}
							for _, d in ipairs(anc:GetDescendants()) do
								if d:IsA("TextButton") and d ~= lbl and X.trim(d.Text) ~= "" then table.insert(btns, d) end
							end
							if #btns >= 3 and #btns <= 150 then
								for _, b in ipairs(btns) do add(b.Text) end
								break
							end
							anc = anc.Parent
						end
						if #names > 0 then break end
					end
				end
			end)
			if #names > 0 then source = "Uhhhhhh UI" end
		end
		table.sort(names)
		for i, n in ipairs(m.ProcDanceNames) do table.insert(names, "[Stand] " .. string.gsub(n, "^%d+ ", "")) end
		if source == "none" then source = "built-in only (Uhhhhhh dances not found)" end
		X.DanceSource = source
		return names
	end

	X.clickLabel = function(name)
		local lower = string.lower(X.trim(name))
		local best, bestScore = nil, 0
		pcall(function()
			for _, d in ipairs(CoreGui:GetDescendants()) do
				if d:IsA("TextButton") or d:IsA("TextLabel") then
					local t = string.lower(X.trim(d.Text or ""))
					if t ~= "" then
						local sc = 0
						if t == lower then sc = d:IsA("TextButton") and 4 or 3
						elseif string.find(t, lower, 1, true) then sc = d:IsA("TextButton") and 2 or 1 end
						if sc > bestScore then best, bestScore = d, sc end
					end
				end
			end
		end)
		if not best then return false end
		local fired = false
		local function fire(inst)
			pcall(function()
				if not getconnections then return end
				for _, sig in ipairs({ "Activated", "MouseButton1Click", "MouseButton1Down" }) do
					local ev = inst[sig]
					if typeof(ev) == "RBXScriptSignal" then
						for _, cn in ipairs(getconnections(ev)) do
							pcall(function() if cn.Function then cn.Function() fired = true end end)
						end
					end
				end
			end)
		end
		fire(best)
		if not fired and best.Parent then fire(best.Parent) end
		return fired
	end

	X.playDance = function(name)
		name = X.trim(name)
		if name == "" then return false end
		m.SelectedDance = name
		local proc = string.match(name, "^%[Stand%] (.+)$")
		if proc then
			for i, n in ipairs(m.ProcDanceNames) do
				if string.gsub(n, "^%d+ ", "") == proc then m.ProcDance = i break end
			end
			m.StandMoveset = 4
			m.LinkRigs = false
			return true
		end
		local ok = X.clickLabel(name)
		if not ok then warn("[HatStand] could not trigger dance '" .. name .. "' from the Uhhhhhh UI — start it from Uhhhhhh itself; the stand will still copy it") end
		return ok
	end

	-- ---------- CLONE (second body from spare hats; same moveset + dances) ----------
	X.CloneKeys = {
		Head = "CloneHatHead", Torso = "CloneHatTorso",
		LeftArm = "CloneHatLeftArm", RightArm = "CloneHatRightArm",
		LeftLeg = "CloneHatLeftLeg", RightLeg = "CloneHatRightLeg",
	}

	X.clearClone = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "clone" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		X.CloneLimbs = {}
		X.CloneSlots = {}
		X.CloneBlend = nil
		X.CloneCF = nil
		if X.CloneModel then pcall(function() X.CloneModel:Destroy() end) X.CloneModel = nil end
	end

	X.buildClone = function()
		if not (m.Enabled and m.CloneEnabled) then return false end
		if m.SelectFirst and not X.Applied then return false end
		X.CloneLastBuild = os.clock()
		X.refreshAllHats()
		local followRoot = X.getFollowRoot()
		if not followRoot then return false end
		if m.FEMode then X.boostNetwork() end
		if not X.CloneModel or not X.CloneModel.Parent then
			local model = Instance.new("Model")
			model.Name = ("UhhhhhhHatStandClone" .. SUF)
			model.Parent = workspace
			X.CloneModel = model
		end
		for _, ch in ipairs(X.CloneModel:GetChildren()) do pcall(function() ch:Destroy() end) end
		X.CloneCF = X.CloneCF or (followRoot.CFrame * CFrame.new(m.CloneSide, m.CloneHeight, m.CloneForward))

		local claimed, assignment = {}, {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "clone" then claimed[handle] = true end
		end
		for _, limb in ipairs(LIMB_NAMES) do
			local hat = X.findHatForLimb(limb, claimed, "clone", X.CloneKeys)
			if hat then claimed[hat.Handle] = true assignment[limb] = hat end
		end
		local slotHats = {}
		for i = 1, 15 do
			local label = X.trim(m["CloneSlotHat" .. i] or "")
			if label ~= "" then
				local sh = X.findHatFromLabel(label, claimed)
				if sh and sh.Handle and not claimed[sh.Handle] then
					claimed[sh.Handle] = true
					slotHats[i] = sh
				end
			end
		end
		if m.CloneAutoHats and not m.SelectFirst then
			for _, limb in ipairs(LIMB_NAMES) do
				if not assignment[limb] and not (m.StrictHats and X.trim(m[X.CloneKeys[limb]]) ~= "") then
					local hat = X.nextSpare(claimed, "clone")
					if hat then claimed[hat.Handle] = true assignment[limb] = hat end
				end
			end
		end
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "clone" then keep[handle] = true end
		end
		X.CloneLimbs = {}
		local n = 0
		for _, limb in ipairs(LIMB_NAMES) do
			local hat = assignment[limb]
			if hat then
				local part, held = nil, nil
				if m.FEMode then
					held = X.attachFE(hat, "clone")
					if held then keep[hat.Handle] = true part = hat.Handle end
				else
					part = X.cloneHandle(hat.Handle, "Clone_" .. limb)
					if part then part.CFrame = X.CloneCF * X.makeBaseOffset(limb) part.Parent = X.CloneModel end
				end
				if part then X.CloneLimbs[limb] = { Part = part, Held = held, Name = hat.Name } n = n + 1 end
			end
		end
		X.CloneSlots = {}
		for i = 1, 15 do
			local hat = slotHats[i]
			if hat then
				local part, held = nil, nil
				if m.FEMode then
					held = X.attachFE(hat, "clone")
					if held then keep[hat.Handle] = true part = hat.Handle end
				else
					part = X.cloneHandle(hat.Handle, "CloneSlot_" .. i)
					if part then part.Parent = X.CloneModel end
				end
				if part then X.CloneSlots[i] = { Part = part, Held = held, Name = hat.Name } n = n + 1 end
			end
		end
		X.releaseHeld(keep)
		if n ~= X.CloneCount then
			X.CloneCount = n
			warn("[HatStand] clone limbs=" .. tostring(n))
		end
		return n > 0
	end

	X.stepClone = function(dt)
		if not (m.Enabled and m.CloneEnabled) then return end
		if m.SelectFirst and not X.Applied then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local now = os.clock()
		local standReady = (not X.modeAllowsStand()) or next(Limbs) ~= nil or not m.AutoBuild
		local total, missing = 0, 0
		for _, d in pairs(X.CloneLimbs) do
			total = total + 1
			if not d.Part or not d.Part.Parent then missing = missing + 1 end
		end
		if (total == 0 or missing > 0 or X.NeedCloneRebuild) and standReady and (now - X.CloneLastBuild) > 0.75 then
			X.NeedCloneRebuild = false
			for handle in pairs(Held) do
				if not handle.Parent then Held[handle] = nil end
			end
			pcall(X.buildClone)
		end
		if next(X.CloneLimbs) == nil then return end

		local base = followRoot.CFrame
		local cf = base * CFrame.new(m.CloneSide or -3.5, m.CloneHeight or 0, m.CloneForward or 0.5)
		local desired = m.CloneFaceSame and cf or CFrame.lookAt(cf.Position, base.Position)
		X.CloneCF = X.CloneCF or desired
		local dist = (X.CloneCF.Position - desired.Position).Magnitude
		local alpha = (dist > (m.AutoCorrectDist or 25)) and 1 or (1 - math.exp(-(m.CloneSmooth or 22) * dt))
		X.CloneCF = X.CloneCF:Lerp(desired, alpha)

		if X.ExtrasFrame ~= X.Frame then
			X.updateLocoMode(dt)
			X.updateAir(dt)
			IdleT = IdleT + dt
			if AnimState ~= "idle" then AnimT = AnimT + dt end
			X.Extras = X.resolve(dt)
			X.ExtrasFrame = X.Frame
		end
		local extras = X.Extras or {}
		local odc = X.OwnDance and X.OwnDance.Clone
		if odc then
			local ex = X.ownDanceSample(odc, dt)
			if odc.Finished then
				X.stopOwnDance("Clone")
			elseif ex then
				local blend = X.CloneBlend or {}
				X.CloneBlend = blend
				local a = 1 - math.exp(-(m.OwnDanceBlend or 30) * dt)
				for _, limb in ipairs(LIMB_NAMES) do
					local tgt = ex[limb] or CFrame.new()
					local cur = blend[limb] or tgt
					blend[limb] = cur:Lerp(tgt, a)
				end
				extras = blend
			end
		end
		local crKeys = X.CloneCRKeys
		if not crKeys then
			crKeys = {}
			for _, limb in ipairs(LIMB_NAMES) do
				crKeys[limb] = {
					"CloneRot" .. limb .. "X", "CloneRot" .. limb .. "Y", "CloneRot" .. limb .. "Z",
					"CloneOff" .. limb .. "X", "CloneOff" .. limb .. "Y", "CloneOff" .. limb .. "Z",
				}
			end
			X.CloneCRKeys = crKeys
		end
		for limb, d in pairs(X.CloneLimbs) do
			if d.Part and d.Part.Parent then
				-- clone can use its own per-limb rot/offset when set
				local base = X.makeBaseOffset(limb)
				local ck = crKeys[limb]
				if ck then
					local ox = tonumber(m[ck[4]]) or 0
					local oy = tonumber(m[ck[5]]) or 0
					local oz = tonumber(m[ck[6]]) or 0
					local rx = math.rad(tonumber(m[ck[1]]) or 0)
					local ry = math.rad(tonumber(m[ck[2]]) or 0)
					local rz = math.rad(tonumber(m[ck[3]]) or 0)
					if ox ~= 0 or oy ~= 0 or oz ~= 0 or rx ~= 0 or ry ~= 0 or rz ~= 0 then
						base = CFrame.new(base.Position + Vector3.new(ox, oy, oz)) * CFrame.Angles(rx, ry, rz) * (base - base.Position)
					end
				end
				local cl = X.CloneCF * X.applyRootExtra(base, extras[limb] or CFrame.new())
				d.LastCF = cl
				if d.Held then X.driveHandle(d.Held, cl) else pcall(function() d.Part.CFrame = cl end) end
			end
		end
		-- clone slots (extra hats): 1 Float, 2 Weapon, 3 Effect, 4 Hand
		local slots = X.CloneSlots
		if slots and next(slots) then
			local clock = os.clock()
			for i, sl in pairs(slots) do
				if sl.Part and sl.Part.Parent then
					local kind = m["CloneSlotKind" .. i] or 1
					local off = CFrame.new(m["CloneSlotOffX" .. i] or 0, m["CloneSlotOffY" .. i] or 0, m["CloneSlotOffZ" .. i] or 0)
					local rot = CFrame.Angles(math.rad(m["CloneSlotRotX" .. i] or 0), math.rad(m["CloneSlotRotY" .. i] or 0), math.rad(m["CloneSlotRotZ" .. i] or 0))
					local ref = X.CloneCF
					local extra = CFrame.new()
					if kind == 4 then
						local ra = X.CloneLimbs.RightArm
						if ra and ra.LastCF then ref = ra.LastCF end
					elseif kind == 1 then
						extra = CFrame.new(0, math.sin(clock * 2 + i) * 0.15, 0)
					elseif kind == 3 then
						extra = CFrame.Angles(0, clock * 3, 0)
					end
					local cf = ref * extra * off * rot
					if sl.Held then X.driveHandle(sl.Held, cf) else pcall(function() sl.Part.CFrame = cf end) end
				end
			end
		end
	end

	function X.locoAnimOffsets()
		if LocoMode == "dance" then
			-- Prefer real character limb poses when available (perfect dance mirror)
			local mirrored = X.sampleCharacterLimbOffsets()
			if mirrored then return mirrored end
			return X.danceOffsets(DanceT, 1)
		end
		if m.WalkWithMe then
			if LocoMode == "jump" then return X.jojoJumpOffsets(m.JumpStrength)
			elseif LocoMode == "run" then return X.jojoRunOffsets(LocoT * m.RunCycleSpeed, m.RunStrength)
			elseif LocoMode == "walk" then return X.jojoWalkOffsets(LocoT * m.WalkCycleSpeed, m.WalkStrength)
			end
		end
		return nil
	end

	X.animOffsets = function(state, t)
		if state ~= "idle" then
			local idle = X.idleOffsets()
			local c = X.combatOffsets(state, t)
			return {
				Head = idle.Head * c.Head, Torso = idle.Torso * c.Torso,
				LeftArm = c.LeftArm, RightArm = c.RightArm,
				LeftLeg = c.LeftLeg, RightLeg = c.RightLeg,
			}
		end
		if X.modeAllowsPlace() and m.PlaceBuildAnim then
			return X.buildAnimOffsets(BuildAnimT, m.PlaceBuildAnimSpeed)
		end
		local loco = X.locoAnimOffsets()
		if loco then return loco end
		return X.idleOffsets()
	end

	X.playAnim = function(name, duration)
		AnimState, AnimT = name, 0
		AnimToken = AnimToken + 1
		local mine = AnimToken
		task.delay(duration or 0.45, function()
			if AnimToken == mine then AnimState, AnimT = "idle", 0 end
		end)
	end

	--------------------------------------------------------------
	-- PLACE / BTOOLS — REAL HAT + YEET / PICKUP
	--------------------------------------------------------------
	X.clearPlacePreview = function()
		if PlacePreviewPart then
			pcall(function() PlacePreviewPart:Destroy() end)
			PlacePreviewPart = nil
		end
	end

	function X.makeGhostClone(handle)
		local ok, clone = pcall(function() return handle:Clone() end)
		if not ok or not clone then return nil end
		clone.Name = "HS_PlacePreview"
		clone.Anchored = true
		clone.CanCollide = false
		clone.CanQuery = false
		clone.CanTouch = false
		clone.Massless = true
		pcall(function()
			clone.Transparency = math.max(clone.Transparency, 0.5)
			clone.LocalTransparencyModifier = 0
		end)
		for _, d in ipairs(clone:GetDescendants()) do
			if d:IsA("BasePart") then
				pcall(function()
					d.Anchored = true
					d.CanCollide = false
					d.Transparency = math.max(d.Transparency, 0.5)
				end)
			elseif d:IsA("JointInstance") or d:IsA("WeldConstraint") or d:IsA("Motor6D") then
				pcall(function() d:Destroy() end)
			end
		end
		clone.Parent = workspace
		return clone
	end

	X.getMouseWorldCF = function()
		local cam = Workspace.CurrentCamera
		if not cam then return nil end
		local unitRay = cam:ScreenPointToRay(Mouse.X, Mouse.Y)
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Exclude
		local exclude = { LocalPlayer.Character }
		if StandModel then table.insert(exclude, StandModel) end
		if PlacePreviewPart then table.insert(exclude, PlacePreviewPart) end
		local folder = X.ensurePlaceFolder()
		if folder then table.insert(exclude, folder) end
		params.FilterDescendantsInstances = exclude
		local result = Workspace:Raycast(unitRay.Origin, unitRay.Direction * 500, params)
		local pos, normal
		if result then
			pos, normal = result.Position, result.Normal
		else
			pos = unitRay.Origin + unitRay.Direction * 30
			normal = Vector3.new(0, 1, 0)
		end
		if m.PlaceSnapGrid and m.PlaceSnapGrid > 0 then
			local g = m.PlaceSnapGrid
			pos = Vector3.new(
				math.floor(pos.X / g + 0.5) * g,
				math.floor(pos.Y / g + 0.5) * g,
				math.floor(pos.Z / g + 0.5) * g
			)
		end
		local look = Vector3.new(cam.CFrame.LookVector.X, 0, cam.CFrame.LookVector.Z)
		if look.Magnitude < 0.01 then look = Vector3.new(0, 0, -1) end
		look = look.Unit
		return CFrame.lookAt(pos + normal * 0.5, pos + normal * 0.5 + look)
	end

	X.getActivePlaceHat = function()
		local slot = math.clamp(math.floor(m.PlaceActiveSlot or 1), 1, 10)
		local label = m["PlaceHat" .. slot]
		return X.findHatFromLabel(label), slot
	end

	function X.updatePlacePreview()
		if not (X.modeAllowsPlace() and m.PlacePreviewOn) then
			X.clearPlacePreview()
			X.clearStructGhosts()
			return
		end
		if m.BToolsClickBuild and (m.BToolsMode or 1) ~= 1 then
			X.clearPlacePreview()
			if m.BToolsPreviewAll then X.updateStructPreview() else X.clearStructGhosts() end
			return
		end
		X.clearStructGhosts()
		local hat, slot = X.getActivePlaceHat()
		if not hat or not hat.Handle or not hat.Handle.Parent then
			X.clearPlacePreview()
			return
		end
		if not PlacePreviewPart or not PlacePreviewPart.Parent then
			X.clearPlacePreview()
			PlacePreviewPart = X.makeGhostClone(hat.Handle)
		end
		if not PlacePreviewPart then return end
		local cf = X.getMouseWorldCF()
		if cf then
			pcall(function() PlacePreviewPart.CFrame = cf * X.getPlaceSlotRot(slot) end)
		end
	end

	X.placeHatAt = function(cf, fromAnim, slotOverride, rawCF)
		if #PlacedHats >= (m.PlaceMax or 80) then
			warn("[HatStand] place limit reached")
			return false
		end
		X.refreshAllHats()
		local hat, slot
		if slotOverride then
			slot = slotOverride
			hat = X.findHatFromLabel(m["PlaceHat" .. slot])
		else
			hat, slot = X.getActivePlaceHat()
		end
		if not hat or not hat.Handle or not hat.Handle.Parent then
			warn("[HatStand] Place Slot " .. tostring(slot) .. " empty — pick a hat in the dropdown")
			return false
		end

		if Held[hat.Handle] then
			local prev = Held[hat.Handle]
			if prev.Kind == "place" then
				if not rawCF then cf = cf * X.getPlaceSlotRot(slot) end
				X.driveHandle(prev, cf)
				for _, e in ipairs(PlacedHats) do
					if e.Handle == hat.Handle then
						e.BaseCF = cf
						e.CarryOff = nil
						e.T = 0
						break
					end
				end
				X.clearPlacePreview()
				warn("[HatStand] moved: " .. hat.Name)
				return true
			end
			pcall(function() if prev.AP then prev.AP:Destroy() end end)
			pcall(function() if prev.AO then prev.AO:Destroy() end end)
			pcall(function() if prev.Att then prev.Att:Destroy() end end)
			Held[hat.Handle] = nil
			for limb, data in pairs(Limbs) do
				if data and data.Part == hat.Handle then Limbs[limb] = nil end
			end
			for i, so in pairs(OrbitSlots) do
				if so and so.Handle == hat.Handle then OrbitSlots[i] = nil end
			end
			warn("[HatStand] reclaimed " .. hat.Name .. " from " .. tostring(prev.Kind))
		end

		if not rawCF then cf = cf * X.getPlaceSlotRot(slot) end

		-- custom place animation (arc down)
		if m.PlaceCustomAnim and not fromAnim then
			local startCF = hat.Handle.CFrame
			local mid = startCF:Lerp(cf, 0.5) * CFrame.new(0, 3, 0)
			table.insert(PlaceAnimQueue, {
				Handle = hat.Handle,
				From = startCF,
				Mid = mid,
				To = cf,
				T = 0,
				Dur = 0.35,
				Kind = "place",
				Slot = slot,
				Hat = hat,
			})
			X.clearPlacePreview()
			return true
		end

		if m.FEMode then
			X.boostNetwork()
			local held = X.attachFE(hat, "place")
			if held then
				X.driveHandle(held, cf)
				table.insert(PlacedHats, {
					Handle = hat.Handle,
					Held = held,
					BaseCF = cf,
					T = 0,
					Name = hat.Name,
					Slot = slot,
					IsClone = false,
					Persist = m.PlacePersist,
					Acc = hat.Accessory,
					Template = X.makeTemplate(hat.Handle),
				})
				X.clearPlacePreview()
				warn("[HatStand] placed REAL: " .. hat.Name .. " (slot " .. slot .. ")")
				return true
			end
			warn("[HatStand] FE attach failed, using clone for " .. hat.Name)
		end

		local clone = X.cloneHandle(hat.Handle, "Placed_S" .. slot .. "_" .. hat.Name)
		if not clone then
			warn("[HatStand] clone failed")
			return false
		end
		clone.CFrame = cf
		clone.Parent = X.ensurePlaceFolder()
		table.insert(PlacedHats, {
			Handle = clone, Held = nil, BaseCF = cf, T = 0,
			Name = hat.Name, Slot = slot, IsClone = true, Persist = true,
		})
		X.clearPlacePreview()
		warn("[HatStand] placed clone: " .. hat.Name)
		return true
	end

	-- BTOOLS BUILD: place EVERY slot that has a chosen hat as one structure
	function X.btoolsAnchor(useMouse)
		local cf
		if useMouse then cf = X.getMouseWorldCF() end
		if cf then return cf end
		local fr = X.getFollowRoot()
		if not fr then return nil end
		local look = Vector3.new(fr.CFrame.LookVector.X, 0, fr.CFrame.LookVector.Z)
		if look.Magnitude < 0.01 then look = Vector3.new(0, 0, -1) end
		look = look.Unit
		local pos = fr.Position + look * (6 + 2 * (m.BToolsScale or 1))
		local ex = { LocalPlayer.Character }
		if StandModel then table.insert(ex, StandModel) end
		local folder = X.ensurePlaceFolder()
		if folder then table.insert(ex, folder) end
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Exclude
		params.FilterDescendantsInstances = ex
		local r = Workspace:Raycast(pos + Vector3.new(0, 10, 0), Vector3.new(0, -80, 0), params)
		if r then pos = r.Position + Vector3.new(0, 0.5, 0) else pos = pos - Vector3.new(0, 3, 0) end
		return CFrame.lookAt(pos, pos + look)
	end

	function X.btoolsPlan(anchor)
		local mode = m.BToolsMode or 1
		local preset = X.btoolsPreset(mode, m.BToolsScale or 1, m.BToolsSpacing or 2.5)
		local plan, claimed, k = {}, {}, 0
		for slot = 1, 10 do
			local label = m["PlaceHat" .. slot]
			if X.trim(label or "") ~= "" then
				local hat = X.findHatFromLabel(label, claimed)
				if hat and hat.Handle and hat.Handle.Parent and not claimed[hat.Handle] then
					claimed[hat.Handle] = true
					k = k + 1
					local p = (mode == 1) and preset[slot] or preset[k]
					if p then
						local lift = 0
						if mode ~= 1 then
							lift = math.max(0, hat.Handle.Size.Y * 0.5 - 0.5)
						end
						local cf = anchor * CFrame.new(p.x, p.y + lift, p.z)
							* CFrame.Angles(math.rad(p.rx or 0), math.rad(p.ry or 0), math.rad(p.rz or 0))
						table.insert(plan, { slot = slot, hat = hat, cf = cf })
					end
				end
			end
		end
		return plan
	end

	function X.buildStructure(useMouse)
		if not m.Enabled then return false end
		X.refreshAllHats()
		local anchor = X.btoolsAnchor(useMouse)
		if not anchor then
			warn("[HatStand] Build: no character root found")
			return false
		end
		local plan = X.btoolsPlan(anchor)
		if #plan == 0 then
			warn("[HatStand] Build: pick hats in the Place Slot dropdowns first (spare hats only)")
			return false
		end
		BToolsCarryCF = nil
		local step = m.PlaceBuildAnim and (0.12 / math.max(m.PlaceBuildAnimSpeed or 1, 0.3)) or 0
		for i, p in ipairs(plan) do
			local function go() pcall(X.placeHatAt, p.cf, false, p.slot, true) end
			if step > 0 and i > 1 then task.delay((i - 1) * step, go) else go() end
		end
		X.clearPlacePreview()
		X.clearStructGhosts()
		warn("[HatStand] BUILD " .. tostring(m.BToolsModeNames[m.BToolsMode or 1]) .. " with " .. #plan .. " hats")
		return true
	end

	function X.clearStructGhosts()
		if X.StructGhosts then
			for _, g in ipairs(X.StructGhosts) do pcall(function() g:Destroy() end) end
		end
		X.StructGhosts, X.StructSig = {}, ""
	end

	function X.updateStructPreview()
		local anchor = X.getMouseWorldCF()
		if not anchor then X.clearStructGhosts() return end
		local plan = X.btoolsPlan(anchor)
		local sig = tostring(m.BToolsMode)
		for _, p in ipairs(plan) do sig = sig .. "|" .. p.slot .. p.hat.Name end
		if sig ~= X.StructSig or not X.StructGhosts then
			X.clearStructGhosts()
			for _, p in ipairs(plan) do
				table.insert(X.StructGhosts, X.makeGhostClone(p.hat.Handle) or Instance.new("Folder"))
			end
			X.StructSig = sig
		end
		for i, p in ipairs(plan) do
			local g = X.StructGhosts[i]
			if g and g:IsA("BasePart") then pcall(function() g.CFrame = p.cf end) end
		end
	end

	function X.yeetNearestPlaced()
		local followRoot = X.getFollowRoot()
		if not followRoot or #PlacedHats == 0 then return end
		local best, bestDist = nil, 999
		for _, e in ipairs(PlacedHats) do
			if e.Handle and e.Handle.Parent then
				local d = (e.Handle.Position - followRoot.Position).Magnitude
				if d < bestDist then best, bestDist = e, d end
			end
		end
		if not best or bestDist > 40 then
			warn("[HatStand] no placed hat nearby to yeet")
			return
		end
		local look = followRoot.CFrame.LookVector
		local vel = look * (m.PlaceYeetForce or 80) + Vector3.new(0, m.PlaceYeetUp or 40, 0)
		if best.Held then
			-- release FE so physics can take over briefly then re-drive
			local held = best.Held
			pcall(function() if held.AP then held.AP:Destroy() end end)
			pcall(function() if held.AO then held.AO:Destroy() end end)
			Held[best.Handle] = nil
			best.Held = nil
			pcall(function()
				best.Handle.Anchored = false
				best.Handle.AssemblyLinearVelocity = vel
			end)
		else
			pcall(function()
				best.Handle.Anchored = false
				best.Handle.AssemblyLinearVelocity = vel
			end)
		end
		table.insert(YeetQueue, {
			Entry = best,
			Until = os.clock() + 1.8,
			Vel = vel,
		})
		warn("[HatStand] YEET: " .. tostring(best.Name))
	end

	function X.placeBackNearest()
		local followRoot = X.getFollowRoot()
		if not followRoot or #PlacedHats == 0 then return end
		local best, bestDist = nil, 999
		for _, e in ipairs(PlacedHats) do
			if e.Handle and e.Handle.Parent then
				local d = (e.Handle.Position - followRoot.Position).Magnitude
				if d < bestDist then best, bestDist = e, d end
			end
		end
		if not best then return end
		local cf = X.getMouseWorldCF() or (followRoot.CFrame * CFrame.new(0, 0, -4))
		cf = cf * X.getPlaceSlotRot(best.Slot or 1)
		if m.PlaceCustomAnim then
			table.insert(PlaceAnimQueue, {
				Handle = best.Handle,
				From = best.Handle.CFrame,
				Mid = best.Handle.CFrame:Lerp(cf, 0.4) * CFrame.new(0, 2.5, 0),
				To = cf,
				T = 0,
				Dur = 0.4,
				Kind = "placeback",
				Entry = best,
			})
		else
			best.BaseCF = cf
			if best.Held then
				X.driveHandle(best.Held, cf)
			else
				pcall(function() best.Handle.CFrame = cf end)
			end
		end
		warn("[HatStand] place-back: " .. tostring(best.Name))
	end

	function X.freezePlacedForRespawn()
		if not (m.PlacePersist or m.PlaceStayAfterRespawn) then return end
		for _, e in ipairs(PlacedHats) do
			-- always snapshot last known CF so loop respawns keep placement
			if e.Handle and e.Handle.Parent then
				e.BaseCF = e.BaseCF or e.Handle.CFrame
				pcall(function() e.LastCF = e.Handle.CFrame end)
			end
			if (not e.IsClone) and e.Handle and e.Handle.Parent then
				local clone = X.cloneHandle(e.Handle, "Persist_" .. (e.Name or "hat"))
				if clone then
					local base = e.BaseCF or e.Handle.CFrame
					clone.CFrame = base
					clone.Parent = X.ensurePlaceFolder()
					if e.Held or Held[e.Handle] then
						local held = e.Held or Held[e.Handle]
						if held then
							pcall(function() if held.AP then held.AP:Destroy() end end)
							pcall(function() if held.AO then held.AO:Destroy() end end)
							pcall(function() if held.Att then held.Att:Destroy() end end)
						end
						Held[e.Handle] = nil
					end
					e.Handle = clone
					e.Held = nil
					e.IsClone = true
					e.Lost = true
					e.Template = e.Template or X.makeTemplate(clone)
					e.BaseCF = base
				end
			elseif e.IsClone and e.Handle and e.Handle.Parent then
				-- already a persist clone — pin CFrame hard
				pcall(function()
					e.Handle.Anchored = true
					e.Handle.CFrame = e.BaseCF or e.LastCF or e.Handle.CFrame
				end)
			end
		end
	end

	X.clearAllPlaced = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "place" then keep[handle] = true end
		end
		for _, entry in ipairs(PlacedHats) do
			if entry.IsClone and entry.Handle then
				pcall(function() entry.Handle:Destroy() end)
			end
		end
		X.releaseHeld(keep)
		PlacedHats = {}
		X.clearPlacePreview()
		local folder = Workspace:FindFirstChild(("UhhhhhhHatStand_Placed" .. SUF))
		if folder then
			for _, ch in ipairs(folder:GetChildren()) do
				pcall(function() ch:Destroy() end)
			end
		end
	end

	function X.stepPlaceAnims(dt)
		for i = #PlaceAnimQueue, 1, -1 do
			local a = PlaceAnimQueue[i]
			a.T = a.T + dt
			local alpha = math.clamp(a.T / a.Dur, 0, 1)
			local cf
			if alpha < 0.5 then
				cf = a.From:Lerp(a.Mid, alpha * 2)
			else
				cf = a.Mid:Lerp(a.To, (alpha - 0.5) * 2)
			end
			if a.Handle and a.Handle.Parent then
				pcall(function() a.Handle.CFrame = cf end)
			end
			if alpha >= 1 then
				if a.Kind == "place" and a.Hat then
					X.placeHatAt(a.To, true, a.Slot or math.clamp(math.floor(m.PlaceActiveSlot or 1), 1, 10), true)
				elseif a.Kind == "placeback" and a.Entry then
					a.Entry.BaseCF = a.To
					if m.FEMode and a.Entry.Handle and not a.Entry.IsClone then
						local hat = { Handle = a.Entry.Handle, Accessory = a.Entry.Acc, Name = a.Entry.Name }
						local held = X.attachFE(hat, "place")
						if held then
							a.Entry.Held = held
							X.driveHandle(held, a.To)
						end
					else
						pcall(function() a.Entry.Handle.CFrame = a.To a.Entry.Handle.Anchored = true end)
					end
				end
				table.remove(PlaceAnimQueue, i)
			end
		end
	end

	function X.stepYeet(dt)
		local now = os.clock()
		for i = #YeetQueue, 1, -1 do
			local y = YeetQueue[i]
			if now > y.Until or not y.Entry or not y.Entry.Handle or not y.Entry.Handle.Parent then
				-- re-attach as placed at current pos
				if y.Entry and y.Entry.Handle and y.Entry.Handle.Parent and not y.Entry.IsClone then
					local hat = { Handle = y.Entry.Handle, Accessory = y.Entry.Acc, Name = y.Entry.Name }
					local held = X.attachFE(hat, "place")
					if held then
						y.Entry.Held = held
						y.Entry.BaseCF = y.Entry.Handle.CFrame
						X.driveHandle(held, y.Entry.BaseCF)
					end
				elseif y.Entry and y.Entry.Handle then
					pcall(function() y.Entry.Handle.Anchored = true end)
					y.Entry.BaseCF = y.Entry.Handle.CFrame
				end
				table.remove(YeetQueue, i)
			end
		end
	end

	X.makeTemplate = function(handle)
		if not handle then return nil end
		local ok, c = pcall(function() return handle:Clone() end)
		if not ok or not c then return nil end
		c.Name = "HS_Template"
		pcall(function()
			c.Anchored = true
			c.CanCollide = false
			c.CanQuery = false
			c.CanTouch = false
			c.Massless = true
			c.LocalTransparencyModifier = 0
			if c.Transparency > 0.5 then c.Transparency = 0 end
		end)
		for _, d in ipairs(c:GetDescendants()) do
			local kill = d:IsA("JointInstance") or d:IsA("WeldConstraint") or string.find(d.Name, "^HS_")
			if not kill then
				for _, cls in ipairs(CONTROLLER_CLASSES) do
					if d:IsA(cls) then kill = true break end
				end
			end
			if kill then
				pcall(function() d:Destroy() end)
			elseif d:IsA("BasePart") then
				pcall(function() d.Anchored = true d.CanCollide = false end)
			end
		end
		c.Parent = nil
		return c
	end

	-- real hat vanished (rig reload / respawn / destroyed): keep a visible copy where it was placed
	X.spawnLocked = function(e)
		if not e.Template then return false end
		local ok, c = pcall(function() return e.Template:Clone() end)
		if not ok or not c then return false end
		c.Name = "Placed_Locked_" .. tostring(e.Name or "hat")
		pcall(function() c.CFrame = e.BaseCF or c.CFrame end)
		c.Parent = X.ensurePlaceFolder()
		e.Handle = c
		e.Held = nil
		e.IsClone = true
		e.Lost = true
		return true
	end

	-- when a hat with the same name is back on the avatar / Uhhhhhh rig, take the REAL one again
	X.reclaim = function(e)
		local now = os.clock()
		if now - (e.ReclaimT or 0) < 1 then return end
		e.ReclaimT = now
		if not e.Name then return end
		X.refreshAllHats()
		for _, h in ipairs(HatCache) do
			if h.Name == e.Name and h.Handle and h.Handle.Parent and not Held[h.Handle] then
				local held = X.attachFE(h, "place")
				if held then
					if e.Handle and e.Handle.Parent and e.IsClone then pcall(function() e.Handle:Destroy() end) end
					e.Handle = h.Handle
					e.Held = held
					e.Acc = h.Accessory
					e.IsClone = false
					e.Lost = false
					X.driveHandle(held, e.BaseCF or h.Handle.CFrame)
					warn("[HatStand] re-grabbed real placed hat: " .. tostring(e.Name))
					return
				end
			end
		end
	end

	-- placed hats are held every frame and repaired if the game / Uhhhhhh fights back
	X.keepPlaced = function(e)
		if e.IsClone or not e.Handle or not e.Handle.Parent then return end
		local h = e.Handle
		local held = e.Held
		if not held then return end
		if Held[h] ~= held then Held[h] = held end
		held.Kind = "place"
		local broken = (not held.AP or not held.AP.Parent) or (not held.AO or not held.AO.Parent)
			or (not held.Att or not held.Att.Parent)
		if broken then
			pcall(function() if held.AP then held.AP:Destroy() end end)
			pcall(function() if held.AO then held.AO:Destroy() end end)
			pcall(function() if held.Att then held.Att:Destroy() end end)
			Held[h] = nil
			local nh = X.attachFE({ Handle = h, Accessory = e.Acc, Name = e.Name }, "place")
			e.Held = nh
			held = nh
			if not held then return end
		end
		for _, d in ipairs(h:GetChildren()) do
			if not string.find(d.Name, "^HS_") then
				if d:IsA("JointInstance") or d:IsA("WeldConstraint") then
					pcall(function() d:Destroy() end)
				else
					for _, cls in ipairs(CONTROLLER_CLASSES) do
						if d:IsA(cls) then pcall(function() d:Destroy() end) break end
					end
				end
			end
		end
		pcall(function()
			h.Anchored = false
			h.CanCollide = X.placedSolid() and true or false
			h.Massless = true
			h.LocalTransparencyModifier = 0
			if e.OrigT == nil then e.OrigT = math.min(h.Transparency, 0.5) end
			if h.Transparency > e.OrigT + 0.2 then h.Transparency = e.OrigT end
		end)
	end

	X.removeNearest = function()
		local followRoot = X.getFollowRoot()
		if not followRoot or #PlacedHats == 0 then return end
		local best, bestI, bestDist = nil, nil, math.huge
		for i, e in ipairs(PlacedHats) do
			if e.Handle and e.Handle.Parent then
				local d = (e.Handle.Position - followRoot.Position).Magnitude
				if d < bestDist then best, bestI, bestDist = e, i, d end
			end
		end
		if not best then return end
		if best.IsClone then
			pcall(function() best.Handle:Destroy() end)
		else
			local held = best.Held or Held[best.Handle]
			if held then X.releaseOne(best.Handle, held) end
			Held[best.Handle] = nil
		end
		for i = #YeetQueue, 1, -1 do
			if YeetQueue[i].Entry == best then table.remove(YeetQueue, i) end
		end
		table.remove(PlacedHats, bestI)
		warn("[HatStand] removed placed hat: " .. tostring(best.Name))
	end

	-- BTools preset offsets: returns table of {x,y,z, rx,ry,rz} for slots 1..n
	X.btoolsPreset = function(mode, scale, spacing)
		local s = scale or 1
		local sp = (spacing or 2.5) * s
		local out = {}
		-- sp already includes the scale, so add() does not scale again
		local function add(x, y, z, rx, ry, rz)
			table.insert(out, { x = x, y = y, z = z, rx = rx or 0, ry = ry or 0, rz = rz or 0 })
		end
		if mode == 2 then -- Wall
			for i = 0, 9 do add((i % 5 - 2) * sp, math.floor(i / 5) * sp, 0) end
		elseif mode == 3 then -- Floor
			for i = 0, 9 do add((i % 5 - 2) * sp, 0, (math.floor(i / 5) - 1) * sp) end
		elseif mode == 4 then -- House (walls + roof)
			add(-sp, 0, -sp); add(sp, 0, -sp); add(-sp, 0, sp); add(sp, 0, sp)
			add(-sp, sp, -sp); add(sp, sp, -sp); add(-sp, sp, sp); add(sp, sp, sp)
			add(0, sp * 1.6, 0); add(0, 0, 0)
		elseif mode == 5 then -- Tower
			for i = 0, 9 do add(0, i * sp * 0.7, 0) end
		elseif mode == 6 then -- Bridge
			for i = 0, 9 do add((i - 4.5) * sp, 0, 0) end
		elseif mode == 7 then -- Platform
			for i = 0, 8 do add((i % 3 - 1) * sp, 0, (math.floor(i / 3) - 1) * sp) end
			add(0, sp * 0.5, 0)
		elseif mode == 8 then -- Stairs
			for i = 0, 9 do add(i * sp * 0.5, i * sp * 0.4, 0) end
		elseif mode == 9 then -- Fence
			for i = 0, 9 do add((i - 4.5) * sp, 0, 0) end
		elseif mode == 10 then -- Gate
			add(-sp * 1.5, 0, 0); add(-sp * 1.5, sp, 0); add(-sp * 1.5, sp * 2, 0)
			add(sp * 1.5, 0, 0); add(sp * 1.5, sp, 0); add(sp * 1.5, sp * 2, 0)
			add(0, sp * 2.2, 0); add(-sp * 0.5, sp * 1.1, 0); add(sp * 0.5, sp * 1.1, 0); add(0, 0, 0)
		elseif mode == 11 then -- Car frame
			add(-sp, 0, sp); add(sp, 0, sp); add(-sp, 0, -sp); add(sp, 0, -sp)
			add(-sp, sp * 0.6, 0); add(sp, sp * 0.6, 0); add(0, sp * 0.8, -sp * 0.5)
			add(0, 0, 0); add(0, sp * 0.4, sp * 0.8); add(0, sp * 0.3, -sp)
		elseif mode == 12 then -- Helicopter
			add(0, 0, 0); add(0, sp, 0); add(0, sp * 1.6, 0)
			add(-sp * 1.2, sp * 1.6, 0); add(sp * 1.2, sp * 1.6, 0)
			add(0, sp * 0.4, -sp); add(0, sp * 0.4, sp * 0.6)
			add(-sp * 0.6, 0, 0); add(sp * 0.6, 0, 0); add(0, -sp * 0.3, 0)
		elseif mode == 13 then -- Boat
			for i = 0, 4 do add((i - 2) * sp * 0.7, 0, 0) end
			add(-sp, sp * 0.5, 0); add(sp, sp * 0.5, 0); add(0, sp * 0.8, -sp * 0.5)
			add(0, sp * 0.3, sp); add(0, 0, -sp)
		elseif mode == 14 then -- Plane
			add(0, 0, 0); add(0, 0, -sp); add(0, 0, sp)
			add(-sp * 1.5, 0, 0); add(sp * 1.5, 0, 0)
			add(-sp * 0.8, 0, -sp * 0.3); add(sp * 0.8, 0, -sp * 0.3)
			add(0, sp * 0.5, -sp * 0.5); add(0, -sp * 0.2, sp * 0.5); add(0, sp * 0.3, sp)
		elseif mode == 15 then -- Throne
			add(0, 0, 0); add(0, sp * 0.5, 0); add(0, sp, 0)
			add(-sp * 0.7, sp * 0.5, -sp * 0.3); add(sp * 0.7, sp * 0.5, -sp * 0.3)
			add(-sp * 0.7, sp, -sp * 0.3); add(sp * 0.7, sp, -sp * 0.3)
			add(0, sp * 1.4, -sp * 0.4); add(-sp * 0.5, 0, sp * 0.4); add(sp * 0.5, 0, sp * 0.4)
		elseif mode == 16 then -- Arch
			add(-sp, 0, 0); add(-sp, sp, 0); add(-sp, sp * 2, 0)
			add(0, sp * 2.2, 0); add(sp, sp * 2, 0); add(sp, sp, 0); add(sp, 0, 0)
			add(-sp * 0.5, sp * 2.1, 0); add(sp * 0.5, sp * 2.1, 0); add(0, 0, 0)
		elseif mode == 17 then -- Pyramid
			add(0, sp * 2, 0)
			add(-sp, sp, -sp); add(sp, sp, -sp); add(-sp, sp, sp); add(sp, sp, sp)
			add(-sp * 1.5, 0, -sp * 1.5); add(sp * 1.5, 0, -sp * 1.5)
			add(-sp * 1.5, 0, sp * 1.5); add(sp * 1.5, 0, sp * 1.5); add(0, 0, 0)
		elseif mode == 18 then -- Dome
			for i = 0, 7 do
				local a = i * (math.pi * 2 / 8)
				add(math.cos(a) * sp, math.sin(i * 0.4) * sp * 0.5 + sp * 0.5, math.sin(a) * sp)
			end
			add(0, sp * 1.2, 0); add(0, 0, 0)
		elseif mode == 19 then -- Ring
			for i = 0, 9 do
				local a = i * (math.pi * 2 / 10)
				add(math.cos(a) * sp * 1.5, 0, math.sin(a) * sp * 1.5)
			end
		elseif mode == 20 then -- Fort
			add(-sp * 1.5, 0, -sp * 1.5); add(sp * 1.5, 0, -sp * 1.5)
			add(-sp * 1.5, 0, sp * 1.5); add(sp * 1.5, 0, sp * 1.5)
			add(-sp * 1.5, sp, -sp * 1.5); add(sp * 1.5, sp, -sp * 1.5)
			add(-sp * 1.5, sp, sp * 1.5); add(sp * 1.5, sp, sp * 1.5)
			add(0, sp * 1.5, 0); add(0, 0, 0)
		elseif mode == 21 then -- Table
			add(-sp, 0, -sp); add(sp, 0, -sp); add(-sp, 0, sp); add(sp, 0, sp)
			add(0, sp * 0.9, 0); add(-sp * 0.5, sp * 0.9, 0); add(sp * 0.5, sp * 0.9, 0)
			add(0, sp * 0.9, -sp * 0.5); add(0, sp * 0.9, sp * 0.5); add(0, sp * 0.5, 0)
		elseif mode == 22 then -- Chair
			add(0, 0, 0); add(0, sp * 0.5, 0); add(0, sp, -sp * 0.3)
			add(-sp * 0.4, 0, -sp * 0.3); add(sp * 0.4, 0, -sp * 0.3)
			add(-sp * 0.4, sp * 0.5, -sp * 0.3); add(sp * 0.4, sp * 0.5, -sp * 0.3)
			add(0, sp * 1.2, -sp * 0.3); add(-sp * 0.3, 0, sp * 0.3); add(sp * 0.3, 0, sp * 0.3)
		elseif mode == 23 then -- Cage
			for i = 0, 3 do
				local a = i * (math.pi / 2)
				add(math.cos(a) * sp, 0, math.sin(a) * sp)
				add(math.cos(a) * sp, sp, math.sin(a) * sp)
			end
			add(0, sp * 1.2, 0); add(0, 0, 0)
		elseif mode == 24 then -- Ramp
			for i = 0, 9 do add(i * sp * 0.4, i * sp * 0.25, 0, 0, 0, -15) end
		elseif mode == 25 then -- Spiral stairs
			for i = 0, 9 do
				local a = i * (math.pi / 4)
				add(math.cos(a) * sp, i * sp * 0.35, math.sin(a) * sp)
			end
		elseif mode and mode >= 26 and X.btoolsExtra(mode, add, sp) then
			-- extra modes 26+ handled
		else
			-- Free / Manual: keep existing offsets
			for i = 1, 10 do
				add(tonumber(m["PlaceOff" .. i .. "X"]) or 0, tonumber(m["PlaceOff" .. i .. "Y"]) or 0, tonumber(m["PlaceOff" .. i .. "Z"]) or 0,
					tonumber(m["PlaceRot" .. i .. "X"]) or 0, tonumber(m["PlaceRot" .. i .. "Y"]) or 0, tonumber(m["PlaceRot" .. i .. "Z"]) or 0)
			end
			return out
		end
		return out
	end

	-- EXTRA BUILD MODES 26-65 (up to 10 parts each; sp = spacing * scale)
	X.btoolsExtra = function(mode, add, sp)
		local pi, pi2 = math.pi, math.pi * 2
		local sin, cos, floor, abs = math.sin, math.cos, math.floor, math.abs
		local B = {}
		B[26] = function() -- Double Wall
			for i = 0, 9 do add((i % 5 - 2) * sp, 0, (i < 5) and -sp or sp) end
		end
		B[27] = function() -- Corridor
			for i = 0, 4 do add(-sp, 0, (i - 2) * sp); add(sp, 0, (i - 2) * sp) end
		end
		B[28] = function() -- Zigzag Wall
			for i = 0, 9 do add((i - 4.5) * sp * 0.8, 0, (i % 2 == 0 and -1 or 1) * sp * 0.5, 0, (i % 2 == 0) and 30 or -30, 0) end
		end
		B[29] = function() -- Descending Stairs
			for i = 0, 9 do add(i * sp * 0.5, -i * sp * 0.4 + sp * 3.6, 0) end
		end
		B[30] = function() -- Pillars
			for i = 0, 4 do add(-sp * 1.5, i * sp * 0.8, 0); add(sp * 1.5, i * sp * 0.8, 0) end
		end
		B[31] = function() -- Cross (flat plus)
			add(0, 0, 0)
			for d = 1, 2 do add(d * sp, 0, 0); add(-d * sp, 0, 0); add(0, 0, d * sp); add(0, 0, -d * sp) end
			add(0, sp * 0.8, 0)
		end
		B[32] = function() -- X Shape
			add(0, 0, 0)
			for d = 1, 2 do add(d * sp, 0, d * sp); add(-d * sp, 0, d * sp); add(d * sp, 0, -d * sp); add(-d * sp, 0, -d * sp) end
			add(0, sp * 0.8, 0)
		end
		B[33] = function() -- Diamond outline
			for i = 0, 9 do
				local a = i / 10 * pi2
				local c, sn = cos(a), sin(a)
				local k = 2.2 * sp / (abs(c) + abs(sn))
				add(c * k, 0, sn * k)
			end
		end
		B[34] = function() -- Star (flat)
			for i = 0, 9 do
				local a = i * pi2 / 10
				local r = (i % 2 == 0) and 2.2 * sp or 1.1 * sp
				add(cos(a) * r, 0, sin(a) * r)
			end
		end
		B[35] = function() -- Heart (flat)
			for i = 0, 9 do
				local t = i * pi2 / 10
				local x = 16 * sin(t) ^ 3
				local z = 13 * cos(t) - 5 * cos(2 * t) - 2 * cos(3 * t) - cos(4 * t)
				add(x * sp / 6, 0, -z * sp / 6)
			end
		end
		B[36] = function() -- Floor Spiral
			for i = 0, 9 do
				local a, r = i * 0.9, sp * (0.4 + i * 0.25)
				add(cos(a) * r, 0, sin(a) * r)
			end
		end
		B[37] = function() -- Double Ring
			for i = 0, 3 do local a = i * pi2 / 4; add(cos(a) * sp, 0, sin(a) * sp) end
			for i = 0, 5 do local a = i * pi2 / 6; add(cos(a) * sp * 2.2, 0, sin(a) * sp * 2.2) end
		end
		B[38] = function() -- Cube Frame
			for _, y in ipairs({ 0, sp * 2 }) do
				for _, x in ipairs({ -sp, sp }) do
					for _, z in ipairs({ -sp, sp }) do add(x, y, z) end
				end
			end
			add(0, 0, 0); add(0, sp * 2, 0)
		end
		B[39] = function() -- Skyscraper
			add(-sp * 0.6, 0, 0); add(sp * 0.6, 0, 0)
			for i = 0, 7 do add(0, i * sp * 0.7, 0) end
		end
		B[40] = function() -- Windmill
			for i = 0, 3 do add(0, i * sp * 0.8, 0) end
			local hy = sp * 2.4
			add(0, hy, -sp * 0.8)
			add(sp * 1.2, hy, -sp * 0.8); add(-sp * 1.2, hy, -sp * 0.8)
			add(0, hy + sp * 1.2, -sp * 0.8); add(0, hy - sp * 1.2, -sp * 0.8)
			add(0, 0, -sp * 0.6)
		end
		B[41] = function() -- Pen / Enclosure (4 x 3 perimeter)
			for i = 0, 3 do add((i - 1.5) * sp, 0, -sp); add((i - 1.5) * sp, 0, sp) end
			add(-sp * 1.5, 0, 0); add(sp * 1.5, 0, 0)
		end
		B[42] = function() -- Ziggurat
			local rows = { 4, 3, 2, 1 }
			for r, n in ipairs(rows) do
				for i = 0, n - 1 do add((i - (n - 1) / 2) * sp, (r - 1) * sp * 0.8, 0) end
			end
		end
		B[43] = function() -- Lighthouse
			for i = 0, 6 do add(0, i * sp * 0.8, 0) end
			add(0, 7 * sp * 0.8, 0); add(0, 8 * sp * 0.8, 0)
			add(sp * 0.8, 0, 0)
		end
		B[44] = function() -- Totem
			for i = 0, 9 do add(0, i * sp * 0.8, 0, 0, (i % 2) * 90, 0) end
		end
		B[45] = function() -- Couch
			for i = -1, 1 do add(i * sp, 0, 0); add(i * sp, sp * 0.7, sp * 0.6) end
			add(-sp * 1.6, sp * 0.4, 0); add(sp * 1.6, sp * 0.4, 0)
			add(-sp * 0.5, sp * 1.3, sp * 0.6); add(sp * 0.5, sp * 1.3, sp * 0.6)
		end
		B[46] = function() -- Bench
			for i = 0, 3 do add((i - 1.5) * sp, sp * 0.7, 0); add((i - 1.5) * sp, sp * 1.4, sp * 0.5) end
			add(-sp * 1.5, 0, 0); add(sp * 1.5, 0, 0)
		end
		B[47] = function() -- Shelf (5 x 2)
			for i = 0, 9 do add((i % 5 - 2) * sp, floor(i / 5) * sp * 1.4, 0) end
		end
		B[48] = function() -- Ladder
			for i = 0, 4 do add(-sp * 0.7, i * sp * 0.8, 0); add(sp * 0.7, i * sp * 0.8, 0) end
		end
		B[49] = function() -- Slide (steep ramp down toward +X)
			for i = 0, 9 do add(i * sp * 0.35, (9 - i) * sp * 0.45, 0, 0, 0, -30) end
		end
		B[50] = function() -- Half-Pipe
			for i = 0, 9 do
				local a = pi * (i / 9)
				add(cos(a) * sp * 2.2, (1 - sin(a)) * sp * 1.5, 0, 0, 0, math.deg(pi / 2 - a) * 0.8)
			end
		end
		B[51] = function() -- Vertical Loop
			for i = 0, 9 do
				local a = i * pi2 / 10
				add(cos(a) * sp * 1.8, sin(a) * sp * 1.8 + sp * 1.8, 0, 0, 0, math.deg(a) + 90)
			end
		end
		B[52] = function() -- Wave Wall
			for i = 0, 9 do add((i - 4.5) * sp * 0.8, (sin(i * 0.8) + 1) * sp * 0.6, 0) end
		end
		B[53] = function() -- Snake Path
			for i = 0, 9 do add((i - 4.5) * sp * 0.8, 0, sin(i * 0.9) * sp * 1.2) end
		end
		B[54] = function() -- Parkour Path (forward & up)
			for i = 0, 9 do add(sin(i * 1.7) * sp * 1.5, i * sp * 0.45, -i * sp * 1.1) end
		end
		B[55] = function() -- Bed
			for i = 0, 5 do add((i % 2 - 0.5) * sp, 0, (floor(i / 2) - 1) * sp) end
			add(-sp * 0.5, sp * 0.8, -sp * 1.6); add(sp * 0.5, sp * 0.8, -sp * 1.6)
			add(-sp * 0.5, sp * 0.5, -sp); add(sp * 0.5, sp * 0.5, -sp)
		end
		B[56] = function() -- Bunker
			for dx = -1, 1 do
				for dz = -1, 1 do
					if not (dx == 0 and dz == 0) then add(dx * sp, 0, dz * sp) end
				end
			end
			add(-sp * 0.5, sp * 0.9, 0); add(sp * 0.5, sp * 0.9, 0)
		end
		B[57] = function() -- Pier
			for i = 0, 5 do add(0, 0, -i * sp) end
			add(-sp * 0.9, sp * 0.7, 0); add(sp * 0.9, sp * 0.7, 0)
			add(-sp * 0.9, sp * 0.7, -sp * 5); add(sp * 0.9, sp * 0.7, -sp * 5)
		end
		B[58] = function() -- Torii Gate
			for j = 0, 2 do add(-sp * 1.5, j * sp * 0.8, 0); add(sp * 1.5, j * sp * 0.8, 0) end
			add(-sp * 0.75, sp * 2.4, 0); add(0, sp * 2.4, 0); add(sp * 0.75, sp * 2.4, 0)
			add(0, sp * 3.1, 0)
		end
		B[59] = function() -- Crown
			for i = 0, 9 do
				local a = i * pi2 / 10
				add(cos(a) * sp * 1.3, (i % 2 == 0) and 0 or sp * 0.9, sin(a) * sp * 1.3)
			end
		end
		B[60] = function() -- Ferris Wheel
			for i = 0, 7 do
				local a = i * pi2 / 8
				add(cos(a) * sp * 2, sin(a) * sp * 2 + sp * 2.4, 0)
			end
			add(-sp * 0.8, 0, 0); add(sp * 0.8, 0, 0)
		end
		B[61] = function() -- Rocket
			for i = 0, 6 do add(0, i * sp * 0.8, 0) end
			add(sp * 0.9, 0, 0); add(-sp * 0.9, 0, 0); add(0, 0, sp * 0.9)
		end
		B[62] = function() -- Hourglass
			add(-sp, 0, 0); add(0, 0, 0); add(sp, 0, 0)
			add(-sp * 0.6, sp * 0.8, 0); add(sp * 0.6, sp * 0.8, 0)
			add(0, sp * 1.6, 0)
			add(-sp * 0.6, sp * 2.4, 0); add(sp * 0.6, sp * 2.4, 0)
			add(-sp, sp * 3.2, 0); add(sp, sp * 3.2, 0)
		end
		B[63] = function() -- DNA Helix
			for i = 0, 4 do
				local a = i * 0.9
				add(cos(a) * sp, i * sp * 0.8, sin(a) * sp)
				add(cos(a + pi) * sp, i * sp * 0.8, sin(a + pi) * sp)
			end
		end
		B[64] = function() -- Tornado
			for i = 0, 9 do
				local a, r = i * 0.8, sp * (0.4 + i * 0.25)
				add(cos(a) * r, i * sp * 0.6, sin(a) * r)
			end
		end
		B[65] = function() -- Podium
			for j = 0, 2 do add(0, j * sp * 0.8, 0) end
			add(-sp * 1.1, 0, 0); add(-sp * 1.1, sp * 0.8, 0)
			add(sp * 1.1, 0, 0)
			add(0, sp * 2.4, 0); add(-sp * 1.1, sp * 1.6, 0); add(sp * 1.1, sp * 0.8, 0)
			add(0, sp * 3.2, 0)
		end
		local fn = B[mode]
		if fn then fn() return true end
		return false
	end

	X.applyBToolsMode = function()
		if (m.BToolsMode or 1) == 1 then
			warn("[HatStand] Build Mode 1 (Free) keeps your own slot offsets - pick another mode to arrange them")
			return
		end
		local preset = X.btoolsPreset(m.BToolsMode or 1, m.BToolsScale or 1, m.BToolsSpacing or 2.5)
		for i, p in ipairs(preset) do
			if i > 10 then break end
			m["PlaceOff" .. i .. "X"] = p.x
			m["PlaceOff" .. i .. "Y"] = p.y
			m["PlaceOff" .. i .. "Z"] = p.z
			m["PlaceRot" .. i .. "X"] = p.rx or 0
			m["PlaceRot" .. i .. "Y"] = p.ry or 0
			m["PlaceRot" .. i .. "Z"] = p.rz or 0
		end
		warn("[HatStand] BTools mode applied: " .. tostring(m.BToolsModeNames[m.BToolsMode or 1]))
	end

	X.saveBToolsBuild = function(name)
		name = X.trim(name)
		if name == "" then name = "Build_" .. tostring(os.time()) end
		local slots = {}
		for i = 1, 10 do
			slots[i] = {
				hat = m["PlaceHat" .. i] or "",
				offX = tonumber(m["PlaceOff" .. i .. "X"]) or 0,
				offY = tonumber(m["PlaceOff" .. i .. "Y"]) or 0,
				offZ = tonumber(m["PlaceOff" .. i .. "Z"]) or 0,
				rotX = tonumber(m["PlaceRot" .. i .. "X"]) or 0,
				rotY = tonumber(m["PlaceRot" .. i .. "Y"]) or 0,
				rotZ = tonumber(m["PlaceRot" .. i .. "Z"]) or 0,
			}
		end
		if type(m.BToolsSavedBuilds) ~= "table" then m.BToolsSavedBuilds = {} end
		m.BToolsSavedBuilds[name] = { slots = slots, mode = m.BToolsMode, scale = m.BToolsScale, spacing = m.BToolsSpacing }
		m.BToolsLastSaved = name
		m.BToolsBuildName = name
		warn("[HatStand] Build saved as: " .. name)
		return name
	end

	X.loadBToolsBuild = function(name)
		name = X.trim(name)
		local data = type(m.BToolsSavedBuilds) == "table" and m.BToolsSavedBuilds[name]
		if not data or not data.slots then
			warn("[HatStand] No saved build named: " .. tostring(name))
			return false
		end
		for i, s in ipairs(data.slots) do
			m["PlaceHat" .. i] = s.hat or ""
			m["PlaceOff" .. i .. "X"] = s.offX or 0
			m["PlaceOff" .. i .. "Y"] = s.offY or 0
			m["PlaceOff" .. i .. "Z"] = s.offZ or 0
			m["PlaceRot" .. i .. "X"] = s.rotX or 0
			m["PlaceRot" .. i .. "Y"] = s.rotY or 0
			m["PlaceRot" .. i .. "Z"] = s.rotZ or 0
		end
		if data.mode then m.BToolsMode = data.mode end
		if data.scale then m.BToolsScale = data.scale end
		if data.spacing then m.BToolsSpacing = data.spacing end
		m.BToolsBuildName = name
		warn("[HatStand] Build loaded: " .. name)
		return true
	end

	function X.stepPlaced(dt)
		PlaceT = PlaceT + dt
		X.NetT = (X.NetT or 0) + dt
		if X.NetT > 2 then
			X.NetT = 0
			if #PlacedHats > 0 then X.boostNetwork() end
		end
		if X.modeAllowsPlace() and m.PlaceBuildAnim then
			BuildAnimT = BuildAnimT + dt
		end
		X.stepPlaceAnims(dt)
		X.stepYeet(dt)
		-- Carry whole build with player
		local carryRoot = nil
		if m.BToolsCarry and #PlacedHats > 0 then
			local fr = X.getFollowRoot()
			if fr then
				local target = fr.CFrame * CFrame.new(0, 1.5, -4)
				if not BToolsCarryCF then
					BToolsCarryCF = target
				else
					local a = 1 - math.exp(-(m.BToolsCarrySmooth or 14) * dt)
					BToolsCarryCF = BToolsCarryCF:Lerp(target, a)
				end
				carryRoot = BToolsCarryCF
			end
		else
			BToolsCarryCF = nil
		end
		for i = #PlacedHats, 1, -1 do
			local e = PlacedHats[i]
			if not e.Handle or not e.Handle.Parent then
				if not (m.PlaceLock and X.spawnLocked(e)) then
					table.remove(PlacedHats, i)
				end
			else
				if m.PlaceLock and e.Lost then pcall(X.reclaim, e) end
				-- skip if currently yeeting
				local yeeting = false
				for _, y in ipairs(YeetQueue) do
					if y.Entry == e then yeeting = true break end
				end
				if not yeeting then
					e.T = (e.T or 0) + dt
					pcall(X.keepPlaced, e)
					local cf = e.BaseCF
					if carryRoot and e.CarryOff then
						cf = carryRoot * e.CarryOff
					elseif carryRoot and e.BaseCF then
						-- first frame of carry: store relative offset
						if not e.CarryOff then
							e.CarryOff = carryRoot:Inverse() * e.BaseCF
						end
						cf = carryRoot * e.CarryOff
					end
					if m.PlaceSpin then
						cf = cf * CFrame.Angles(0, math.rad(m.PlaceSpinSpeed * 60) * e.T, 0)
					end
					if m.PlaceBob then
						cf = cf * CFrame.new(0, math.sin(e.T * m.PlaceBobSpeed * math.pi * 2) * m.PlaceBobHeight, 0)
					end
					if e.Held then
						X.driveHandle(e.Held, cf)
					else
						pcall(function() e.Handle.CFrame = cf end)
					end
				end
			end
		end
	end

	--------------------------------------------------------------
	-- ORBIT (per-slot speed + radius)
	--------------------------------------------------------------
	X.clearOrbit = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "orbit" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		OrbitSlots = {}
	end

	X.rebuildOrbit = function()
		if not X.modeAllowsOrbit() or not m.OrbitEnabled then
			X.clearOrbit()
			return
		end
		X.refreshAllHats()
		local usedHandles = {}
		for handle, held in pairs(Held) do
			if held.Kind == "stand" or held.Kind == "place" or held.Kind == "gaster"
				or held.Kind == "weapon" or held.Kind == "shield" or held.Kind == "car"
				or held.Kind == "clone" then
				usedHandles[handle] = true
			end
		end
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "orbit" then keep[handle] = true end
		end
		local activeCount = 0
		for i = 1, 10 do
			if X.trim(m["OrbitHat" .. i]) ~= "" then activeCount = activeCount + 1 end
		end
		if activeCount == 0 then activeCount = 10 end
		local newSlots, count = {}, 0
		for i, key in ipairs(ORBIT_HAT_KEYS) do
			local hat = X.findHatFromLabel(m[key])
			if hat and hat.Handle and hat.Handle.Parent and not usedHandles[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "orbit") or nil
				if held then
					keep[hat.Handle] = true
					usedHandles[hat.Handle] = true
				end
				local part = (held and hat.Handle) or (not m.FEMode and X.cloneHandle(hat.Handle, "Orbit_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					count = count + 1
					newSlots[i] = {
						Handle = part, Held = held,
						Angle = (i - 1) * (math.pi * 2 / math.max(activeCount, 1)),
						Name = hat.Name, Index = i,
						SpdMult = tonumber(m["OrbitSpdMult" .. i]) or 1,
						RadOff = tonumber(m["OrbitRadOff" .. i]) or 0,
						VertOff = tonumber(m["OrbitVertOff" .. i]) or 0,
						Rot = CFrame.Angles(
							math.rad(tonumber(m["OrbitRotX" .. i]) or 0),
							math.rad(tonumber(m["OrbitRotY" .. i]) or 0),
							math.rad(tonumber(m["OrbitRotZ" .. i]) or 0)
						),
						Seed = (i * 17.13) % 1,
					}
				end
			end
		end
		X.releaseHeld(keep)
		OrbitSlots = newSlots
		NeedOrbitRebuild = false
		warn("[HatStand] orbit=" .. tostring(count) .. " mode=" .. tostring(m.OrbitMode or 1))
	end

	-- EXTRA ORBIT MODES 36-65: returns an offset from the follow root
	function X.orbitExtra(mode, base, slot, t, idx, total, rad, h, vert, ang, spd)
		local pi, pi2 = math.pi, math.pi * 2
		local sin, cos, abs, floor = math.sin, math.cos, math.abs, math.floor
		local V = Vector3.new
		local fr = (idx - 1) / math.max(total - 1, 1)
		local fo = (idx - 1) / math.max(total, 1)
		local seed = slot.Seed or 0.5
		local function polygon(n, a, r, step)
			local u = ((a / pi2) % 1) * n
			local k = floor(u)
			local f = u - k
			local function vtx(i)
				local aa = (i * (step or 1)) * pi2 / n
				return V(cos(aa) * r, 0, sin(aa) * r)
			end
			return vtx(k):Lerp(vtx(k + 1), f)
		end
		local B = {}
		B[36] = function() -- Vertical Figure-8
			return V(sin(ang) * rad, h + sin(ang * 2) * rad * 0.5 + vert, 0)
		end
		B[37] = function() -- Angel Wings (flapping, behind you)
			local side = (idx % 2 == 0) and 1 or -1
			local k = floor((idx - 1) / 2)
			local a = 0.25 + k * 0.32 + sin(t * spd * 2) * 0.25
			return base.RightVector * (side * cos(a) * rad * 0.9) + base.UpVector * (h + sin(a) * rad * 0.9) - base.LookVector * (rad * 0.3)
		end
		B[38] = function() -- Halo
			local r = rad * 0.35
			return V(cos(ang) * r, h + 2.5 + vert * 0.3, sin(ang) * r)
		end
		B[39] = function() -- Saturn Ring (tilted)
			local x, z = cos(ang) * rad, sin(ang) * rad
			return V(x, h + z * 0.4, z * 0.92)
		end
		B[40] = function() -- Atom (3 orbitals)
			local k = idx % 3
			if k == 0 then return V(cos(ang) * rad, h + sin(ang) * rad, 0)
			elseif k == 1 then return V(0, h + sin(ang) * rad, cos(ang) * rad) end
			return V(cos(ang) * rad, h + vert, sin(ang) * rad)
		end
		B[41] = function() -- Gyroscope
			local k = idx % 3
			local rot = CFrame.Angles(t * 0.5 * (k + 1), t * 0.3 * k, k * 1.05)
			local p = rot * V(cos(ang) * rad, 0, sin(ang) * rad)
			return V(p.X, h + p.Y, p.Z)
		end
		B[42] = function() -- Shield Arc (in front of you)
			local a = (fr - 0.5) * 2.1
			return base.LookVector * (cos(a) * rad) + base.RightVector * (sin(a) * rad) + V(0, h + vert * 0.3, 0)
		end
		B[43] = function() -- Cape Arc (behind you)
			local a = (fr - 0.5) * 2.1
			return -base.LookVector * (cos(a) * rad) + base.RightVector * (sin(a) * rad) + V(0, h + vert * 0.3, 0)
		end
		B[44] = function() -- Elevator Ring
			return V(cos(ang) * rad, h - 1 + ((t * spd * 0.8 + idx * 0.4) % 4), sin(ang) * rad)
		end
		B[45] = function() -- Bounce Ring
			return V(cos(ang) * rad, h + abs(sin(t * spd * 2 + idx)) * 2, sin(ang) * rad)
		end
		B[46] = function() -- Square Path
			local p = CFrame.Angles(0, pi / 4, 0) * polygon(4, ang, rad * 1.2)
			return V(p.X, h + vert, p.Z)
		end
		B[47] = function() -- Hexagon Path
			local p = polygon(6, ang, rad)
			return V(p.X, h + vert, p.Z)
		end
		B[48] = function() -- Pentagram Path
			local p = polygon(5, ang, rad * 1.1, 2)
			return V(p.X, h + vert, p.Z)
		end
		B[49] = function() -- Spirograph
			local x = 2 * cos(ang) + 5 * cos(2 * ang / 3)
			local z = 2 * sin(ang) - 5 * sin(2 * ang / 3)
			return V(x * rad / 7, h + vert, z * rad / 7)
		end
		B[50] = function() -- Lissajous
			return V(sin(3 * ang + idx * 0.3) * rad, h + sin(2 * ang) * rad * 0.5 + vert, cos(2 * ang + idx * 0.2) * rad * 0.8)
		end
		B[51] = function() -- Trefoil Knot
			local x = sin(ang) + 2 * sin(2 * ang)
			local y = cos(ang) - 2 * cos(2 * ang)
			local z = -sin(3 * ang)
			local s2 = rad * 0.33
			return V(x * s2, h + y * s2 * 0.8 + vert * 0.3, z * s2)
		end
		B[52] = function() -- Torus Knot
			local r = 2 + cos(3 * ang)
			local s2 = rad / 3
			return V(r * cos(2 * ang) * s2, h + sin(3 * ang) * s2, r * sin(2 * ang) * s2)
		end
		B[53] = function() -- Hourglass Swirl
			local yv = (fr - 0.5) * rad * 1.6
			local r = rad * (0.25 + 0.75 * abs(yv) / (rad * 0.8))
			local a = ang + idx * 1.2
			return V(cos(a) * r, h + yv + vert * 0.3, sin(a) * r)
		end
		B[54] = function() -- Cone
			local r = rad * (1 - fo * 0.85)
			local a = ang + idx * 0.9
			return V(cos(a) * r, h + fo * rad * 1.4, sin(a) * r)
		end
		B[55] = function() -- Funnel
			local r = rad * (0.2 + fo * 0.8)
			local a = ang + idx * 0.9
			return V(cos(a) * r, h + fo * rad * 1.2, sin(a) * r)
		end
		B[56] = function() -- Fountain
			local ph = (t * spd * 0.6 + fo) % 1
			local dir = idx * 2.39996
			local r = rad * ph * 0.9
			return V(cos(dir) * r, h + 4 * ph * (1 - ph) * rad * 0.9, sin(dir) * r)
		end
		B[57] = function() -- Bubbles
			local ph = (t * 0.12 * (spd + 0.5) + seed) % 1
			local sc = 0.3 + 0.7 * seed
			return V(sin(t * 0.7 + seed * 9) * rad * 0.5 * sc * 2, h - 1 + ph * rad * 1.3, cos(t * 0.6 + seed * 7) * rad * 0.5 * sc * 2)
		end
		B[58] = function() -- Conga Line
			local a = t * spd - idx * 0.35
			return V(cos(a) * rad, h + vert * 0.3, sin(a) * rad)
		end
		B[59] = function() -- Snake Weave
			local a = t * spd - idx * 0.4
			return V(cos(a) * rad, h + sin(a * 3) * 1.2, sin(a) * rad)
		end
		B[60] = function() -- Comet Ellipse
			local q = CFrame.Angles(0, t * 0.3, 0.35) * V(cos(ang) * rad * 1.4, 0, sin(ang) * rad * 0.7)
			return V(q.X, h + q.Y + vert * 0.3, q.Z)
		end
		B[61] = function() -- Shockwave
			local r = rad * (((t * spd * 0.5 + fo) % 1) * 1.3 + 0.15)
			local a = fo * pi2 + t * 0.4
			return V(cos(a) * r, h + vert * 0.3, sin(a) * r)
		end
		B[62] = function() -- Counter-Rotate
			if idx % 2 == 1 then return V(cos(ang) * rad, h + vert, sin(ang) * rad) end
			return V(cos(-ang) * rad * 0.7, h - vert, sin(-ang) * rad * 0.7)
		end
		B[63] = function() -- Forward Wheel
			return base.LookVector * (cos(ang) * rad) + V(0, h + sin(ang) * rad, 0)
		end
		B[64] = function() -- Triple Helix
			local a = ang + (idx % 3) * pi2 / 3
			local yv = ((ang * 0.5 + idx * 0.6) % 6) - 1
			return V(cos(a) * rad * 0.8, h + yv, sin(a) * rad * 0.8)
		end
		B[65] = function() -- Fibonacci Sphere
			local y = 1 - ((idx - 0.5) / math.max(total, 1)) * 2
			local rr = math.sqrt(math.max(1 - y * y, 0))
			local th = idx * 2.39996 + ang * 0.6
			return V(cos(th) * rr * rad, h + y * rad * 0.8 + vert * 0.3, sin(th) * rr * rad)
		end
		B[66] = function() -- Möbius Strip
			local u = ang
			local v = (fr - 0.5) * pi
			local x = (1 + 0.5 * cos(v)) * cos(u)
			local y = (1 + 0.5 * cos(v)) * sin(u)
			local z = 0.5 * sin(v)
			return V(x * rad * 0.7, h + z * rad * 0.7 + vert, y * rad * 0.7)
		end
		B[67] = function() -- Dual Ring
			local ring = (idx % 2)
			local a = ang + (ring == 0 and 0 or pi)
			local r = rad * (ring == 0 and 1 or 0.55)
			return V(cos(a) * r, h + (ring == 0 and 0 or 1.2) + vert, sin(a) * r)
		end
		B[68] = function() -- Orbit Ladder
			local step = floor((idx - 1) / 2)
			local side = (idx % 2 == 0) and 1 or -1
			return V(side * rad * 0.4, h + step * 1.1 + vert, cos(ang + step) * rad * 0.3)
		end
		B[69] = function() -- Pulsar
			local pulse = 0.5 + 0.5 * sin(t * spd * 3)
			local r = rad * (0.4 + 0.6 * pulse)
			return V(cos(ang) * r, h + vert * pulse, sin(ang) * r)
		end
		B[70] = function() -- Diamond Path
			local p = polygon(4, ang, rad)
			return V(p.X, h + abs(p.X) * 0.4 + vert, p.Z)
		end
		B[71] = function() -- Crescent Moon
			local a = (fr - 0.5) * pi * 1.4 + ang * 0.15
			return V(cos(a) * rad, h + sin(a * 0.5) * rad * 0.3 + vert, sin(a) * rad * 0.6)
		end
		B[72] = function() -- Vortex Tunnel
			local depth = ((t * spd * 0.4 + fo) % 1)
			local r = rad * (0.2 + depth * 0.9)
			local a = ang + depth * 4
			return V(cos(a) * r, h + (depth - 0.5) * rad + vert * 0.3, sin(a) * r)
		end
		B[73] = function() -- Ribbon Wave
			local x = ((idx - 1) / math.max(total - 1, 1) - 0.5) * rad * 2.2
			return V(x, h + sin(t * spd * 2 + x * 0.4) * 1.5, cos(t * spd + x * 0.3) * rad * 0.4)
		end
		B[74] = function() -- Cage Box
			local edge = floor((idx - 1) / math.max(math.floor(total / 12), 1)) % 12
			local f = ((ang / pi2) + fo) % 1
			local s = rad * 0.8
			local corners = {
				V(-s, -s, -s), V(s, -s, -s), V(s, s, -s), V(-s, s, -s),
				V(-s, -s, s), V(s, -s, s), V(s, s, s), V(-s, s, s),
			}
			local edges = {{1,2},{2,3},{3,4},{4,1},{5,6},{6,7},{7,8},{8,5},{1,5},{2,6},{3,7},{4,8}}
			local e = edges[(edge % 12) + 1]
			local p = corners[e[1]]:Lerp(corners[e[2]], f)
			return V(p.X, h + p.Y + vert * 0.2, p.Z)
		end
		B[75] = function() -- Solar Flare
			local burst = abs(sin(t * spd * 1.5 + idx * 0.7))
			local r = rad * (0.3 + burst * 1.2)
			local a = ang + burst * 0.5
			return V(cos(a) * r, h + burst * rad * 0.5 + vert, sin(a) * r)
		end
		B[76] = function() -- Twin Orbit
			local twin = (idx % 2 == 0) and 1 or -1
			return V(cos(ang) * rad, h + twin * 1.5 + vert * 0.5, sin(ang) * rad)
		end
		B[77] = function() -- Vertical Helix
			local yv = ((ang * 0.8 + idx * 0.5) % 8) - 2
			return V(cos(ang) * rad * 0.7, h + yv, sin(ang) * rad * 0.7)
		end
		B[78] = function() -- Orbit Cascade
			local layer = floor((idx - 1) / 3)
			local a = ang - layer * 0.4
			local r = rad * (1 - layer * 0.15)
			return V(cos(a) * r, h + layer * 1.3 + vert, sin(a) * r)
		end
		B[79] = function() -- Star Cross
			local arm = (idx % 4)
			local d = ((ang / pi2 + fo) % 1) * rad
			local dirs = {V(1,0,0), V(-1,0,0), V(0,0,1), V(0,0,-1)}
			local dir = dirs[arm + 1]
			return V(dir.X * d, h + vert, dir.Z * d)
		end
		B[80] = function() -- Planetary Dance
			local layer = ((idx - 1) % 4) + 1
			local r = rad * (0.35 + layer * 0.22)
			local a = ang * (1.3 - layer * 0.12) + idx * 0.4
			local incl = sin(a * 0.5) * 0.4 * layer
			return V(cos(a) * r, h + incl * rad * 0.3 + vert, sin(a) * r)
		end
		local fn = B[mode]
		if fn then return fn() end
		return V(cos(ang) * rad, h + vert, sin(ang) * rad)
	end

	function X.orbitPos(mode, base, slot, t, idx, total)
		local spd = m.OrbitSpd * (slot.SpdMult or 1)
		local rad = m.OrbitRad + (slot.RadOff or 0)
		local h = m.OrbitH + (slot.VertOff or 0)
		local ang = (slot.Angle or 0) + t * spd
		local vert = 0
		if m.OrbitVertical then
			vert = math.sin(t * (m.OrbitVertSpd or 0.8) + (slot.Angle or 0)) * (m.OrbitVertAmp or 1.5)
		end
		if m.OrbitFinalePulse or mode == 10 then
			local pulse = 1 + math.sin(t * (m.OrbitFinalePulseSpd or 2.5) + idx) * 0.15 * (m.OrbitFinalePulseAmt or 2)
			rad = rad * pulse
		end
		local offset
		if mode == 2 then -- line
			local span = rad * 2
			local x = ((idx - 1) / math.max(total - 1, 1) - 0.5) * span
			offset = base.RightVector * x + base.UpVector * (h + vert) - base.LookVector * (rad * 0.3)
			return base.Position + offset
		elseif mode == 3 then -- solar system layers
			local layer = ((idx - 1) % 3) + 1
			local r = rad * (0.45 + layer * 0.35)
			local a = ang * (1.2 - layer * 0.15)
			offset = Vector3.new(math.cos(a) * r, h + vert + (layer - 2) * 0.6, math.sin(a) * r)
		elseif mode == 4 then -- figure-8
			offset = Vector3.new(math.sin(ang) * rad, h + vert, math.sin(ang * 2) * rad * 0.55)
		elseif mode == 5 then -- helix
			offset = Vector3.new(math.cos(ang) * rad, h + (ang % (math.pi * 4)) * 0.35 + vert, math.sin(ang) * rad)
		elseif mode == 6 then -- wave line
			local x = ((idx - 1) / math.max(total - 1, 1) - 0.5) * rad * 2
			local y = math.sin(t * spd * 2 + x) * (m.OrbitVertAmp or 1.5)
			offset = base.RightVector * x + base.UpVector * (h + y) - base.LookVector * (rad * 0.4)
			return base.Position + offset
		elseif mode == 7 then -- spiral
			local r = rad * (0.35 + 0.65 * (0.5 + 0.5 * math.sin(t * 0.7 + idx)))
			offset = Vector3.new(math.cos(ang) * r, h + vert, math.sin(ang) * r)
		elseif mode == 8 then -- ring stack
			local ring = math.floor((idx - 1) / 3)
			local inRing = ((idx - 1) % 3)
			local a = ang + inRing * (math.pi * 2 / 3)
			offset = Vector3.new(math.cos(a) * rad, h + ring * 1.4 + vert, math.sin(a) * rad)
		elseif mode == 9 then -- random drift
			local s = slot.Seed or 0.5
			offset = Vector3.new(
				math.sin(t * (0.6 + s) + s * 10) * rad,
				h + math.sin(t * (0.9 + s * 0.5)) * (m.OrbitVertAmp or 1.5),
				math.cos(t * (0.55 + s * 0.3) + s * 7) * rad
			)
		elseif mode == 10 then -- Undertale Finale
			local a = ang * 1.35
			local r = rad * (0.85 + 0.2 * math.sin(t * 4 + idx))
			offset = Vector3.new(math.cos(a) * r, h + math.sin(t * 3 + idx) * 1.2, math.sin(a) * r)
		elseif mode == 11 then -- Rose curve (r = cos(kθ))
			local k = 3 + (idx % 3)
			local r = rad * math.abs(math.cos(k * ang))
			offset = Vector3.new(math.cos(ang) * r, h + vert, math.sin(ang) * r)
		elseif mode == 12 then -- Infinity (sideways 8)
			offset = Vector3.new(math.sin(ang) * rad, h + vert, math.sin(ang * 2) * rad * 0.45)
		elseif mode == 13 then -- DNA double helix
			local strand = ((idx - 1) % 2 == 0) and 1 or -1
			local a = ang + (strand > 0 and 0 or math.pi)
			offset = Vector3.new(math.cos(a) * rad * 0.7, h + (ang % (math.pi * 6)) * 0.28 + vert, math.sin(a) * rad * 0.7)
		elseif mode == 14 then -- Cube faces
			local face = ((idx - 1) % 6) + 1
			local u = ((idx - 1) / 6 - math.floor((idx - 1) / 6)) * 2 - 1
			local half = rad * 0.55
			local map = {
				Vector3.new(half, u * half, 0), Vector3.new(-half, u * half, 0),
				Vector3.new(u * half, half, 0), Vector3.new(u * half, -half, 0),
				Vector3.new(0, u * half, half), Vector3.new(0, u * half, -half),
			}
			local p = map[face] or Vector3.zero
			local rotA = ang * 0.4
			offset = Vector3.new(
				p.X * math.cos(rotA) - p.Z * math.sin(rotA),
				h + p.Y + vert,
				p.X * math.sin(rotA) + p.Z * math.cos(rotA)
			)
		elseif mode == 15 then -- Pyramid
			local layer = math.floor((idx - 1) / 3)
			local inL = ((idx - 1) % 3)
			local r = rad * (1 - layer * 0.28)
			local a = ang + inL * (math.pi * 2 / 3)
			offset = Vector3.new(math.cos(a) * r, h + layer * 1.2 + vert, math.sin(a) * r)
		elseif mode == 16 then -- Star path
			local points = 5
			local a = ang
			local r = rad * (0.55 + 0.45 * math.abs(math.cos(points * a / 2)))
			offset = Vector3.new(math.cos(a) * r, h + vert, math.sin(a) * r)
		elseif mode == 17 then -- Tornado
			local rise = (ang % (math.pi * 8)) * 0.22
			local r = rad * (0.25 + 0.75 * (1 - math.clamp(rise / (rad * 3), 0, 1)))
			offset = Vector3.new(math.cos(ang * 1.6) * r, h + rise + vert, math.sin(ang * 1.6) * r)
		elseif mode == 18 then -- Butterfly
			local a = ang
			local rx = math.sin(a) * (math.exp(math.cos(a)) - 2 * math.cos(4 * a) - math.sin(a / 12) ^ 5)
			local rz = math.cos(a) * (math.exp(math.cos(a)) - 2 * math.cos(4 * a) - math.sin(a / 12) ^ 5)
			offset = Vector3.new(rx * rad * 0.12, h + vert + math.sin(a * 2) * 0.4, rz * rad * 0.12)
		elseif mode == 19 then -- Flower bloom
			local petals = 6
			local a = ang
			local r = rad * (0.4 + 0.6 * math.abs(math.sin(petals * a)))
			offset = Vector3.new(math.cos(a) * r, h + vert + math.sin(a * 3) * 0.3, math.sin(a) * r)
		elseif mode == 20 then -- Orbit rings (concentric)
			local ring = ((idx - 1) % 4) + 1
			local r = rad * (0.35 + ring * 0.28)
			local a = ang * (1.1 - ring * 0.08) + ring
			offset = Vector3.new(math.cos(a) * r, h + (ring - 2) * 0.5 + vert, math.sin(a) * r)
		elseif mode == 21 then -- Sine weave
			local x = ((idx - 1) / math.max(total - 1, 1) - 0.5) * rad * 2.2
			local z = math.sin(t * spd * 1.5 + x * 0.4) * rad * 0.6
			local y = math.cos(t * spd + x * 0.3) * (m.OrbitVertAmp or 1.5) * 0.5
			offset = base.RightVector * x + base.UpVector * (h + y) + base.LookVector * z
			return base.Position + offset
		elseif mode == 22 then -- Pendulum
			local swing = math.sin(ang) * rad
			offset = Vector3.new(swing, h - math.abs(swing) * 0.15 + vert, math.cos(ang * 0.5) * rad * 0.2)
		elseif mode == 23 then -- Galaxy spiral
			local r = rad * (0.2 + 0.8 * ((idx - 1) / math.max(total, 1)))
			local a = ang + (idx - 1) * 0.45
			offset = Vector3.new(math.cos(a) * r, h + math.sin(a * 0.5) * 0.8 + vert, math.sin(a) * r)
		elseif mode == 24 then -- Grid lattice
			local cols = 3
			local row = math.floor((idx - 1) / cols)
			local col = ((idx - 1) % cols)
			local spacing = rad * 0.55
			local x = (col - 1) * spacing
			local z = (row - 1) * spacing
			local rotA = ang * 0.3
			offset = Vector3.new(
				x * math.cos(rotA) - z * math.sin(rotA),
				h + vert,
				x * math.sin(rotA) + z * math.cos(rotA)
			)
		elseif mode == 25 then -- Sphere surface
			local phi = ((idx - 1) / math.max(total, 1)) * math.pi
			local theta = ang + idx * 0.7
			offset = Vector3.new(
				math.sin(phi) * math.cos(theta) * rad,
				h + math.cos(phi) * rad * 0.7 + vert,
				math.sin(phi) * math.sin(theta) * rad
			)
		elseif mode == 26 then -- Triangle path
			local seg = (ang / (math.pi * 2 / 3)) % 3
			local f = (ang % (math.pi * 2 / 3)) / (math.pi * 2 / 3)
			local corners = {
				Vector3.new(rad, 0, 0), Vector3.new(-rad * 0.5, 0, rad * 0.866), Vector3.new(-rad * 0.5, 0, -rad * 0.866),
			}
			local i0 = math.floor(seg) % 3 + 1
			local i1 = i0 % 3 + 1
			local p = corners[i0]:Lerp(corners[i1], f)
			offset = Vector3.new(p.X, h + vert, p.Z)
		elseif mode == 27 then -- Heart shape
			local a = ang
			local hx = 16 * math.sin(a) ^ 3
			local hy = 13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a)
			offset = Vector3.new(hx * rad * 0.06, h + hy * rad * 0.06 + vert, math.sin(a * 0.5) * rad * 0.15)
		elseif mode == 28 then -- Cross orbit
			local axis = ((idx - 1) % 2)
			if axis == 0 then
				offset = Vector3.new(math.cos(ang) * rad, h + vert, 0)
			else
				offset = Vector3.new(0, h + vert, math.sin(ang) * rad)
			end
		elseif mode == 29 then -- Chaotic swarm
			local s = slot.Seed or 0.5
			offset = Vector3.new(
				math.sin(t * (1.1 + s * 2) + s * 20) * rad * (0.6 + s * 0.5),
				h + math.sin(t * (1.4 + s) + s * 8) * (m.OrbitVertAmp or 1.5) * 1.2,
				math.cos(t * (0.9 + s * 1.5) + s * 12) * rad * (0.6 + (1 - s) * 0.5)
			)
		elseif mode == 30 then -- Rain fall
			local x = ((idx - 1) / math.max(total - 1, 1) - 0.5) * rad * 2
			local fall = ((t * spd * 2 + idx * 0.7) % 4) - 2
			offset = base.RightVector * x + base.UpVector * (h + 2 - fall) - base.LookVector * (rad * 0.2)
			return base.Position + offset
		elseif mode == 31 then -- Vertical circle
			offset = Vector3.new(math.cos(ang) * rad, h + math.sin(ang) * rad + vert, 0)
		elseif mode == 32 then -- Horizontal figure-8
			offset = Vector3.new(math.sin(ang) * rad, h + vert, math.sin(ang * 2) * rad * 0.5)
		elseif mode == 33 then -- Expanding pulse
			local pulse = 0.5 + 0.5 * math.sin(t * (m.OrbitFinalePulseSpd or 2.5))
			local r = rad * (0.4 + 0.6 * pulse)
			offset = Vector3.new(math.cos(ang) * r, h + vert * pulse, math.sin(ang) * r)
		elseif mode == 34 then -- Zigzag
			local x = ((idx - 1) / math.max(total - 1, 1) - 0.5) * rad * 2
			local z = (((idx - 1) % 2 == 0) and 1 or -1) * rad * 0.4 * math.sin(t * spd)
			offset = base.RightVector * x + base.UpVector * (h + vert) + base.LookVector * z
			return base.Position + offset
		elseif mode == 35 then -- Crown arc
			local a = -math.pi * 0.6 + ((idx - 1) / math.max(total - 1, 1)) * math.pi * 1.2 + ang * 0.15
			offset = Vector3.new(math.sin(a) * rad, h + math.cos(a * 0.5) * rad * 0.35 + vert, -math.cos(a) * rad * 0.3)
		elseif mode >= 36 and mode <= 65 then
			offset = X.orbitExtra(mode, base, slot, t, idx, total, rad, h, vert, ang, spd)
		else -- circle
			offset = Vector3.new(math.cos(ang) * rad, h + vert, math.sin(ang) * rad)
		end
		return base.Position + offset
	end

	function X.stepOrbit(dt)
		if not (X.modeAllowsOrbit() and m.OrbitEnabled) then return end
		if next(OrbitSlots) == nil then
			local any = false
			for i = 1, 10 do if X.trim(m["OrbitHat" .. i]) ~= "" then any = true break end end
			if any and m.OrbitAutoRebuild then NeedOrbitRebuild = true end
			return
		end
		OrbitT = OrbitT + dt
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local base = followRoot.CFrame
		local mode = m.OrbitMode or 1
		local total = 0
		for _ in pairs(OrbitSlots) do total = total + 1 end
		for _, slot in pairs(OrbitSlots) do
			if slot.Handle and slot.Handle.Parent then
				local pos = X.orbitPos(mode, base, slot, OrbitT, slot.Index or 1, math.max(total, 1))
				local cf
				if m.OrbitFaceOut or mode == 10 then
					cf = CFrame.lookAt(pos, base.Position)
				else
					cf = CFrame.new(pos) * (base - base.Position)
				end
				if m.OrbitSpinSelf then
					cf = cf * CFrame.Angles(0, OrbitT * m.OrbitSpinSelfSpd, 0)
				end
				if slot.Rot then cf = cf * slot.Rot end
				if slot.Held then X.driveHandle(slot.Held, cf)
				else pcall(function() slot.Handle.CFrame = cf end) end
			else
				NeedOrbitRebuild = true
			end
		end
	end

	--------------------------------------------------------------
	-- GASTER BLASTER (5 slots) + BONE + OMEGA
	--------------------------------------------------------------
	X.clearGaster = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "gaster" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		GasterHeld = nil
		GasterSlots = {}
	end

	X.rebuildGaster = function()
		X.clearGaster()
		if not m.GasterEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "gaster" then used[handle] = true end
		end
		local count = 0
		for i = 1, 5 do
			local label = m["GasterHat" .. i]
			if X.trim(label) == "" and i == 1 and X.trim(m.GasterHat) ~= "" then
				label = m.GasterHat -- legacy fallback
			end
			local hat = X.findHatFromLabel(label)
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "gaster") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "Gaster_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					if held then
						held.Kind = "gaster"
						X.initSansStash(held)
					end
					GasterSlots[i] = {
						Handle = part, Held = held, Index = i, Name = hat.Name,
					}
					if i == (m.GasterActiveSlot or 1) then
						GasterHeld = held or { Handle = part, Kind = "gaster" }
						X.initSansStash(GasterHeld)
					end
				end
			end
		end
		if count == 0 then
			warn("[HatStand] Gaster: no hats in any of the 5 slots")
		else
			warn("[HatStand] Gaster slots ready: " .. count)
		end
	end

	function X.gasterSlotCF(i, base, track)
		local side = tonumber(m["GasterSide" .. i]) or m.GasterSide or 4.5
		local height = tonumber(m["GasterHeight" .. i]) or m.GasterHeight or 1.2
		local forward = tonumber(m["GasterForward" .. i]) or m.GasterForward or -1
		local cf = base * CFrame.new(side, height, forward)
			* CFrame.Angles(
				math.rad(tonumber(m["GasterRotX" .. i]) or 0),
				math.rad(tonumber(m["GasterRotY" .. i]) or 0),
				math.rad(tonumber(m["GasterRotZ" .. i]) or 0)
			)
		if track and m.GasterTrackMouse then
			local look = Mouse.Hit.Position - cf.Position
			if look.Magnitude > 0.1 then
				cf = CFrame.lookAt(cf.Position, cf.Position + look)
					* CFrame.Angles(
						math.rad(tonumber(m["GasterRotX" .. i]) or 0),
						math.rad(tonumber(m["GasterRotY" .. i]) or 0),
						math.rad(tonumber(m["GasterRotZ" .. i]) or 0)
					)
			end
		end
		return cf
	end

	X.fireOneGasterSlot = function(slot, force)
		local gs = GasterSlots[slot]
		if not gs or not gs.Handle or not gs.Handle.Parent then return end
		local held = gs.Held or { Handle = gs.Handle, Kind = "gaster" }
		if X.sansStashOn(held) and not force then
			local depth, rise, hold = X.stashParams(held)
			held.UpUntil = os.clock() + rise + hold + (m.GasterChargeTime or 0.35)
			if (held.Up or 0) < 0.85 then
				if not held._pending then
					held._pending = true
					task.delay(rise, function()
						held._pending = false
						X.fireOneGasterSlot(slot, true)
					end)
				end
				return
			end
		end
		local handle = gs.Handle
		local origin = handle.Position
		local dir
		if m.GasterTrackMouse then
			local to = Mouse.Hit.Position - origin
			dir = (to.Magnitude > 0.1) and to.Unit or handle.CFrame.LookVector
		else
			dir = handle.CFrame.LookVector
		end
		if m.GasterSFX then
			X.playSFX(m.GasterSFXId, m.GasterVolume or 1, handle, 0.9 + math.random() * 0.2)
		end
		local charge = Instance.new("Part")
		charge.Name = "HS_GasterCharge"
		charge.Anchored = true
		charge.CanCollide = false
		charge.Material = Enum.Material.Neon
		charge.Color = m.GasterColor or Color3.new(1, 1, 1)
		charge.Size = Vector3.new(0.4, 0.4, 0.4) * (m.GasterSize or 1.4)
		charge.CFrame = CFrame.new(origin)
		charge.Parent = workspace
		Debris:AddItem(charge, (m.GasterChargeTime or 0.35) + 0.1)
		GasterCharging = true
		task.delay(m.GasterChargeTime or 0.35, function()
			GasterCharging = false
			if not handle or not handle.Parent then return end
			origin = handle.Position
			if m.GasterTrackMouse then
				local to = Mouse.Hit.Position - origin
				if to.Magnitude > 0.1 then dir = to.Unit end
			end
			local length = m.GasterLaserLength or 80
			local thick = m.GasterLaserThick or 1.2
			local beam = Instance.new("Part")
			beam.Name = "HS_GasterLaser"
			beam.Anchored = true
			beam.CanCollide = false
			beam.Material = Enum.Material.Neon
			beam.Color = m.GasterColor or Color3.new(1, 1, 1)
			beam.Size = Vector3.new(thick, thick, length)
			beam.CFrame = CFrame.lookAt(origin, origin + dir) * CFrame.new(0, 0, -length / 2)
			beam.Parent = workspace
			Debris:AddItem(beam, 0.45)
			local hitPos = origin + dir * length
			local params = RaycastParams.new()
			params.FilterType = Enum.RaycastFilterType.Exclude
			params.FilterDescendantsInstances = { LocalPlayer.Character, StandModel }
			local result = Workspace:Raycast(origin, dir * length, params)
			if result then hitPos = result.Position end
			local boom = Instance.new("Part")
			boom.Name = "HS_GasterBoom"
			boom.Anchored = true
			boom.CanCollide = false
			boom.Material = Enum.Material.Neon
			boom.Color = m.GasterColor or Color3.new(1, 1, 1)
			boom.Shape = Enum.PartType.Ball
			boom.Size = Vector3.new(3, 3, 3) * (m.GasterSize or 1.4)
			boom.CFrame = CFrame.new(hitPos)
			boom.Parent = workspace
			Debris:AddItem(boom, 0.35)
			local push = m.GasterPush or 45
			for _, plr in ipairs(Players:GetPlayers()) do
				if plr ~= LocalPlayer and plr.Character then
					local root = X.getRoot(plr.Character)
					if root and (root.Position - hitPos).Magnitude < 12 then
						pcall(function()
							root.AssemblyLinearVelocity = root.AssemblyLinearVelocity
								+ (root.Position - hitPos).Unit * push
						end)
					end
				end
			end
			if m.GasterSFX then
				X.playSFX(m.GasterFireSFXId, m.GasterVolume or 1, handle, 1)
			end
			if m.GasterUseHatBullet then
				local bhat = X.findHatFromLabel(m.GasterHatBullet ~= "" and m.GasterHatBullet or (m["GasterHat" .. slot] or m.GasterHat))
				if bhat and bhat.Handle then
					local heldB = m.FEMode and X.attachFE(bhat, "gaster") or nil
					local part = heldB and bhat.Handle or (not m.FEMode and X.cloneHandle(bhat.Handle, "GasterBullet"))
					if part then
						if not m.FEMode then part.Parent = workspace end
						local startPos, forward = origin, dir
						local dist = m.GasterTrailOscDist or 12
						local spd = m.GasterTrailOscSpeed or 18
						local life = m.GasterTrailOscTime or 1.2
						local t0 = os.clock()
						local trailOn = m.GasterTrailOsc
						local trail
						if trailOn then
							pcall(function()
								local att0 = Instance.new("Attachment"); att0.Parent = part
								local att1 = Instance.new("Attachment"); att1.Position = Vector3.new(0, 0, -1); att1.Parent = part
								trail = Instance.new("Trail")
								trail.Attachment0, trail.Attachment1 = att0, att1
								trail.Lifetime = 0.35
								trail.FaceCamera = true
								trail.Color = ColorSequence.new(m.GasterColor or Color3.new(1, 1, 1))
								trail.Parent = part
							end)
						end
						task.spawn(function()
							while os.clock() - t0 < life do
								local osc = trailOn and math.sin((os.clock() - t0) * spd) or 1
								local pos = startPos + forward * (dist * (0.5 + 0.5 * osc))
								local cf = CFrame.lookAt(pos, pos + forward)
								if heldB then X.driveHandle(heldB, cf) else pcall(function() part.CFrame = cf end) end
								RunService.Heartbeat:Wait()
							end
							if trail then pcall(function() trail:Destroy() end) end
							if not m.FEMode and part then pcall(function() part:Destroy() end) end
						end)
					end
				end
			end
			warn("[HatStand] GASTER FIRE slot " .. tostring(slot))
		end)
	end

	X.fireGaster = function(force)
		if not m.GasterEnabled then return end
		local now = os.clock()
		if now - GasterLastFire < (m.GasterCooldown or 1.4) then return end
		GasterLastFire = now
		if (m.GasterFireMode or 1) == 2 then
			for i = 1, 5 do
				if m["GasterFire" .. i] and GasterSlots[i] then
					X.fireOneGasterSlot(i, force)
				end
			end
		else
			local slot = m.GasterActiveSlot or 1
			if not GasterSlots[slot] then
				for i = 1, 5 do
					if GasterSlots[i] and m["GasterFire" .. i] then slot = i break end
				end
			end
			X.fireOneGasterSlot(slot, force)
		end
	end

	function X.stepGaster(dt)
		if not m.GasterEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local base = followRoot.CFrame
		local track = m.GasterTrackMouse and (not m.GasterTrackOnlyFire or GasterCharging)
		for i, gs in pairs(GasterSlots) do
			if gs.Handle and gs.Handle.Parent then
				local cf = X.gasterSlotCF(i, base, track)
				if GasterCharging then
					cf = cf * CFrame.Angles(0, 0, math.sin(os.clock() * 30) * 0.08)
				end
				local held = gs.Held or { Handle = gs.Handle, Kind = "gaster" }
				cf = X.stashShift(held, cf, dt)
				if gs.Held and gs.Held.AP then
					X.driveHandle(gs.Held, cf)
				else
					pcall(function() gs.Handle.CFrame = cf end)
				end
			end
		end
		local act = GasterSlots[m.GasterActiveSlot or 1]
		if act then GasterHeld = act.Held or { Handle = act.Handle, Kind = "gaster" } end
	end

	--------------------------------------------------------------
	-- BONE ATTACK (hat-based)
	--------------------------------------------------------------
	X.clearBone = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "bone" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		BoneHeld = nil
		for _, p in ipairs(BoneProjectiles) do
			if p and p.Part and not p.Real then pcall(function() p.Part:Destroy() end) end
		end
		BoneProjectiles = {}
	end

	X.rebuildBone = function()
		X.clearBone()
		if not m.BoneEnabled then return end
		local hat = X.findHatFromLabel(m.BoneHat)
		if not hat or not hat.Handle then
			warn("[HatStand] Bone: no hat selected")
			return
		end
		if m.FEMode then
			BoneHeld = X.attachFE(hat, "bone")
		else
			local clone = X.cloneHandle(hat.Handle, "Bone")
			if clone then
				clone.Parent = workspace
				BoneHeld = { Handle = clone, Kind = "bone" }
			end
		end
		if BoneHeld then
			BoneHeld.Kind = "bone"
			X.initSansStash(BoneHeld)
		end
		warn("[HatStand] Bone ready: " .. hat.Name)
	end

	X.fireBone = function(force)
		if not m.BoneEnabled then return end
		local now = os.clock()
		if now - BoneLastFire < (m.BoneCooldown or 0.9) and not force then return end
		if BoneHeld and X.sansStashOn(BoneHeld) and not force then
			local depth, rise, hold = X.stashParams(BoneHeld)
			BoneHeld.UpUntil = os.clock() + rise + hold + (m.BoneRise or 0.25)
			if (BoneHeld.Up or 0) < 0.85 then
				if not BoneHeld._pending then
					BoneHeld._pending = true
					task.delay(rise, function()
						BoneHeld._pending = false
						X.fireBone(true)
					end)
				end
				return
			end
		end
		BoneLastFire = now
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local base = followRoot.CFrame
		local origin = (base * CFrame.new(m.BoneSide or -3.5, m.BoneHeight or 0.5, m.BoneForward or -1)).Position
		local dir
		if m.BoneTrackMouse then
			local to = Mouse.Hit.Position - origin
			dir = (to.Magnitude > 0.1) and to.Unit or base.LookVector
		else
			dir = base.LookVector
		end
		if m.BoneSFX then
			X.playSFX(m.BoneSFXId, m.BoneVolume or 0.9, followRoot, 1.1)
		end
		local n = math.clamp(math.floor(m.BoneCount or 5), 1, 12)
		local spread = m.BoneSpread or 2.5
		local speed = m.BoneSpeed or 90
		local life = m.BoneLife or 1.8
		local right = base.RightVector
		for k = 1, n do
			local offset = (k - (n + 1) / 2) * spread
			local startPos = origin + right * offset
			local part, real, heldB = nil, false, nil
			if m.BoneUseRealHat and BoneHeld and BoneHeld.Handle and k == 1 then
				part = BoneHeld.Handle
				real = true
				heldB = BoneHeld
			else
				local src = BoneHeld and BoneHeld.Handle
				if src then
					part = X.cloneHandle(src, "BoneProj_" .. k)
				else
					part = Instance.new("Part")
					part.Name = "HS_Bone"
					part.Size = Vector3.new(0.4, 0.4, 3.5)
					part.Material = Enum.Material.Neon
					part.Color = m.BoneColor or Color3.new(1, 1, 1)
					part.Anchored = true
					part.CanCollide = false
				end
				if part then part.Parent = workspace end
			end
			if part then
				table.insert(BoneProjectiles, {
					Part = part, Held = heldB, Real = real,
					Pos = startPos, Dir = dir, Speed = speed,
					Until = now + life, Spin = 0,
				})
			end
		end
		warn("[HatStand] BONE ATTACK x" .. n)
	end

	function X.stepBone(dt)
		if m.BoneEnabled and BoneHeld and BoneHeld.Handle then
			local followRoot = X.getFollowRoot()
			if followRoot then
				local cf = followRoot.CFrame * CFrame.new(m.BoneSide or -3.5, m.BoneHeight or 0.5, m.BoneForward or -1)
				if m.BoneTrackMouse then
					local look = Mouse.Hit.Position - cf.Position
					if look.Magnitude > 0.1 then cf = CFrame.lookAt(cf.Position, cf.Position + look) end
				end
				local flying = false
				for _, b in ipairs(BoneProjectiles) do
					if b.Real and b.Part == BoneHeld.Handle then flying = true break end
				end
				if not flying then
					cf = X.stashShift(BoneHeld, cf, dt)
					if BoneHeld.AP then X.driveHandle(BoneHeld, cf)
					else pcall(function() BoneHeld.Handle.CFrame = cf end) end
				end
			end
		end
		for i = #BoneProjectiles, 1, -1 do
			local b = BoneProjectiles[i]
			if os.clock() > b.Until or not b.Part or not b.Part.Parent then
				if not b.Real and b.Part then pcall(function() b.Part:Destroy() end) end
				table.remove(BoneProjectiles, i)
			else
				b.Pos = b.Pos + b.Dir * b.Speed * dt
				b.Spin = (b.Spin or 0) + dt * 8
				local cf = CFrame.lookAt(b.Pos, b.Pos + b.Dir) * CFrame.Angles(0, 0, b.Spin)
				if b.Held then X.driveHandle(b.Held, cf)
				else pcall(function() b.Part.CFrame = cf end) end
			end
		end
	end

	--------------------------------------------------------------
	-- OMEGA BLASTER (1 or 2 hat blasters)
	--------------------------------------------------------------
	X.OmegaSlots = X.OmegaSlots or {}
	X.OmegaBullets = X.OmegaBullets or {}
	X.OmegaCharges = 0
	X.omegaHatKey = function(i) return (i == 1) and "OmegaHat" or ("OmegaHat" .. i) end
	X.omegaBulletKey = function(i) return (i == 1) and "OmegaBulletHat" or ("OmegaBulletHat" .. i) end

	X.clearOmega = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "omega" then keep[handle] = true end
		end
		for _, b in pairs(X.OmegaBullets or {}) do
			if b and b.Held and b.Held.Handle then
				pcall(function() X.stripTrails(b.Held.Handle) end)
				if b.Clone then pcall(function() b.Held.Handle:Destroy() end) end
			end
		end
		for _, sl in pairs(X.OmegaSlots or {}) do
			if sl and sl.Clone and sl.Handle then pcall(function() sl.Handle:Destroy() end) end
		end
		X.releaseHeld(keep)
		OmegaHeld, OmegaHeld2 = nil, nil
		X.OmegaSlots = {}
		X.OmegaBullets = {}
	end

	X.rebuildOmega = function()
		X.clearOmega()
		if not m.OmegaEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "omega" then used[handle] = true end
		end
		local function take(label, tag)
			if X.trim(X.cleanLabel(label or "")) == "" then return nil end
			local hat = X.findHatFromLabel(label, used)
			if not hat or not hat.Handle or used[hat.Handle] then return nil end
			local held = m.FEMode and X.attachFE(hat, "omega") or nil
			local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, tag))
			if not part then return nil end
			if not m.FEMode then part.Parent = workspace end
			if held then used[hat.Handle] = true end
			local ctl = held or { Handle = part, Kind = "omega" }
			ctl.Kind = "omega"
			return ctl, hat, (held == nil)
		end
		local count = 0
		for i = 1, 5 do
			local ctl, hat, isClone = take(m[X.omegaHatKey(i)], "Omega" .. i)
			if ctl then
				X.initSansStash(ctl)
				X.OmegaSlots[i] = { Handle = ctl.Handle, Ctl = ctl, Index = i, Name = hat.Name, Clone = isClone }
				count = count + 1
			end
		end
		if m.OmegaUseHatBullet then
			for i = 1, 5 do
				if X.OmegaSlots[i] then
					local bctl, _, bclone = take(m[X.omegaBulletKey(i)], "OmegaBullet" .. i)
					if bctl then
						bctl.IsOmegaBullet = true
						if m.OmegaBulletTrail and bctl.Handle then pcall(function() X.addTrail(bctl.Handle, false) end) end
						X.OmegaBullets[i] = { Held = bctl, Fly = nil, Clone = bclone }
					elseif X.trim(X.cleanLabel(m[X.omegaBulletKey(i)] or "")) ~= "" then
						warn("[HatStand] Omega slot " .. i .. " bullet hat unavailable (already used by another slot/feature?)")
					end
				end
			end
		end
		local act = X.OmegaSlots[m.OmegaActiveSlot or 1]
		OmegaHeld = act and act.Ctl or nil
		if count == 0 then
			warn("[HatStand] Omega: no hats in any of the 5 slots")
		else
			warn("[HatStand] Omega slots ready: " .. count)
		end
	end

	-- send the chosen bullet hat down the beam (+ optional back & forth trail), then back to its blaster
	X.launchOmegaBullet = function(idx, origin, dir, hitPos)
		local b = X.OmegaBullets[idx]
		if not b or not b.Held or not b.Held.Handle or not b.Held.Handle.Parent then return end
		b.Fly = { Origin = origin, Dir = dir, Dist = math.max((hitPos - origin).Magnitude, 1), T = 0, Phase = 1, Last = origin }
		if m.OmegaBulletTrail then pcall(function() X.trailEnable(b.Held.Handle, true) end) end
	end
	X.stepOmegaBullets = function(dt, followRoot)
		local speed = math.max(tonumber(m.OmegaBulletSpeed) or 220, 20)
		for i, b in pairs(X.OmegaBullets) do
			local held = b and b.Held
			if held and held.Handle and held.Handle.Parent then
				local slot = X.OmegaSlots[i]
				local ref = slot and slot.Handle
				local parkCF = (ref and ref.Parent) and ref.CFrame or (followRoot.CFrame * CFrame.new(0, 3, 2))
				local cf = parkCF
				local f = b.Fly
				if f then
					if f.Phase == 1 then
						f.T = f.T + dt
						local d = math.min(f.Dist, f.T * speed)
						f.Last = f.Origin + f.Dir * d
						cf = CFrame.lookAt(f.Last, f.Last + f.Dir)
						if d >= f.Dist then
							f.Phase = m.OmegaTrailOsc and 2 or 3
							f.T = 0
						end
					elseif f.Phase == 2 then
						f.T = f.T + dt
						local dist = tonumber(m.OmegaTrailOscDist) or 12
						local spd = tonumber(m.OmegaTrailOscSpeed) or 18
						local osc = 0.5 - 0.5 * math.cos(f.T * spd) -- 0..1, starts at the hit point
						f.Last = f.Origin + f.Dir * math.max(f.Dist - dist * osc, 0)
						cf = CFrame.lookAt(f.Last, f.Last + f.Dir)
						if f.T >= (tonumber(m.OmegaTrailOscTime) or 1.2) then f.Phase = 3 end
					else
						local to = parkCF.Position - f.Last
						local stepLen = speed * 1.5 * dt
						if to.Magnitude <= stepLen then
							b.Fly = nil
							cf = parkCF
							if m.OmegaBulletTrail then pcall(function() X.trailEnable(held.Handle, false) end) end
						else
							f.Last = f.Last + to.Unit * stepLen
							cf = CFrame.lookAt(f.Last, f.Last + to.Unit)
						end
					end
					if b.Fly and m.OmegaBulletSpin then
						cf = cf * CFrame.Angles(0, 0, os.clock() * 20)
					end
				end
				if held.AP then X.driveHandle(held, cf)
				else pcall(function() held.Handle.CFrame = cf end) end
			end
		end
	end

	function X.fireOmegaBeam(origin, dir, sizeMul, bulletIdx)
		local length = m.OmegaLaserLength or 120
		local thick = (m.OmegaLaserThick or 2.4) * (sizeMul or 1)
		local beam = Instance.new("Part")
		beam.Name = "HS_OmegaLaser"
		beam.Anchored = true
		beam.CanCollide = false
		beam.Material = Enum.Material.Neon
		beam.Color = m.OmegaColor or Color3.fromRGB(180, 220, 255)
		beam.Size = Vector3.new(thick, thick, length)
		beam.CFrame = CFrame.lookAt(origin, origin + dir) * CFrame.new(0, 0, -length / 2)
		beam.Parent = workspace
		Debris:AddItem(beam, 0.55)
		local hitPos = origin + dir * length
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Exclude
		params.FilterDescendantsInstances = { LocalPlayer.Character, StandModel }
		local result = Workspace:Raycast(origin, dir * length, params)
		if result then hitPos = result.Position end
		local boom = Instance.new("Part")
		if bulletIdx and m.OmegaUseHatBullet then
			X.launchOmegaBullet(bulletIdx, origin, dir, hitPos)
		end
		boom.Name = "HS_OmegaBoom"
		boom.Anchored = true
		boom.CanCollide = false
		boom.Material = Enum.Material.Neon
		boom.Color = m.OmegaColor or Color3.fromRGB(180, 220, 255)
		boom.Shape = Enum.PartType.Ball
		boom.Size = Vector3.new(5, 5, 5) * (m.OmegaSize or 2.2) * 0.5
		boom.CFrame = CFrame.new(hitPos)
		boom.Parent = workspace
		Debris:AddItem(boom, 0.4)
		local push = m.OmegaPush or 80
		for _, plr in ipairs(Players:GetPlayers()) do
			if plr ~= LocalPlayer and plr.Character then
				local root = X.getRoot(plr.Character)
				if root and (root.Position - hitPos).Magnitude < 16 then
					pcall(function()
						root.AssemblyLinearVelocity = root.AssemblyLinearVelocity
							+ (root.Position - hitPos).Unit * push
					end)
				end
			end
		end
	end

	-- fire ONE omega slot: rise (if underground) -> charge -> beam (+ hat bullet)
	X.fireOneOmegaSlot = function(slot, force)
		local sl = X.OmegaSlots[slot]
		if not sl or not sl.Handle or not sl.Handle.Parent then return end
		local ctl = sl.Ctl
		ctl.Kind = "omega"
		local chargeT = m.OmegaChargeTime or 0.55
		local useStash = X.sansStashOn(ctl)
		local depth, rise, hold = X.stashParams(ctl)
		if useStash and not force then
			ctl.UpUntil = os.clock() + rise + chargeT + hold
			if m.OmegaRiseBeforeFire ~= false and (ctl.Up or 0) < 0.9 then
				if ctl._pending then return end
				ctl._pending = true
				task.spawn(function()
					local t0 = os.clock()
					local timeout = math.max(rise, 0.15) + 1.5
					while (ctl.Up or 0) < 0.9 and (os.clock() - t0) < timeout do
						ctl.UpUntil = os.clock() + chargeT + hold + 0.5 -- don't sink mid-rise
						RunService.Heartbeat:Wait()
					end
					ctl._pending = false
					X.fireOneOmegaSlot(slot, true)
				end)
				return
			end
		end
		local handle = sl.Handle
		X.OmegaCharges = X.OmegaCharges + 1
		OmegaCharging = true
		if useStash then ctl.UpUntil = os.clock() + chargeT + hold + 0.25 end
		if m.OmegaSFX then
			X.playSFX(m.OmegaSFXId, m.OmegaVolume or 1.2, handle, 0.85)
		end
		local charge = Instance.new("Part")
		charge.Name = "HS_OmegaCharge"
		charge.Anchored = true
		charge.CanCollide = false
		charge.Material = Enum.Material.Neon
		charge.Color = m.OmegaColor or Color3.fromRGB(180, 220, 255)
		charge.Size = Vector3.new(0.6, 0.6, 0.6) * (m.OmegaSize or 2.2)
		charge.CFrame = CFrame.new(handle.Position)
		charge.Parent = workspace
		Debris:AddItem(charge, chargeT + 0.1)
		task.spawn(function()
			local t0 = os.clock()
			while charge.Parent and (os.clock() - t0) < chargeT do
				if handle and handle.Parent then charge.CFrame = CFrame.new(handle.Position) end
				RunService.Heartbeat:Wait()
			end
		end)
		task.delay(chargeT, function()
			X.OmegaCharges = math.max(0, X.OmegaCharges - 1)
			if X.OmegaCharges == 0 then OmegaCharging = false end
			if not handle or not handle.Parent then return end
			if useStash then ctl.UpUntil = os.clock() + hold end -- stay up while the beam shows
			local origin = handle.Position
			local dir
			if m.OmegaTrackMouse then
				local to = Mouse.Hit.Position - origin
				dir = (to.Magnitude > 0.1) and to.Unit or handle.CFrame.LookVector
			else
				dir = handle.CFrame.LookVector
			end
			X.fireOmegaBeam(origin, dir, 1, slot)
			if m.OmegaSFX then
				X.playSFX(m.OmegaFireSFXId, m.OmegaVolume or 1.2, handle, 1)
			end
			warn("[HatStand] OMEGA BLAST slot " .. tostring(slot))
		end)
	end

	X.fireOmega = function(force)
		if not m.OmegaEnabled then return end
		local now = os.clock()
		if now - OmegaLastFire < (m.OmegaCooldown or 2.2) and not force then return end
		local any = false
		if (m.OmegaFireMode or 2) == 2 then
			for i = 1, 5 do
				if m["OmegaFire" .. i] ~= false and X.OmegaSlots[i] then
					X.fireOneOmegaSlot(i, force)
					any = true
				end
			end
		else
			local slot = m.OmegaActiveSlot or 1
			if not X.OmegaSlots[slot] then
				for i = 1, 5 do
					if X.OmegaSlots[i] and m["OmegaFire" .. i] ~= false then slot = i break end
				end
			end
			if X.OmegaSlots[slot] then
				X.fireOneOmegaSlot(slot, force)
				any = true
			end
		end
		if any then OmegaLastFire = now end
	end

	function X.stepOmega(dt)
		if not m.OmegaEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local base = followRoot.CFrame
		for i, sl in pairs(X.OmegaSlots) do
			if sl.Handle and sl.Handle.Parent then
				local ctl = sl.Ctl
				ctl.Kind = "omega"
				local cf = base * CFrame.new(
					tonumber(m["OmegaSide" .. i]) or 0,
					tonumber(m["OmegaHeight" .. i]) or 2.5,
					tonumber(m["OmegaForward" .. i]) or -2
				)
				local track = m.OmegaTrackMouse and (not m.OmegaTrackOnlyFire or OmegaCharging or (ctl.Up or 0) > 0.5)
				if track then
					local look = Mouse.Hit.Position - cf.Position
					if look.Magnitude > 0.1 then cf = CFrame.lookAt(cf.Position, cf.Position + look) end
				end
				cf = cf * CFrame.Angles(
					math.rad((m.OmegaRotX or 0) + (tonumber(m["OmegaRotX" .. i]) or 0)),
					math.rad((m.OmegaRotY or 0) + (tonumber(m["OmegaRotY" .. i]) or 0)),
					math.rad((m.OmegaRotZ or 0) + (tonumber(m["OmegaRotZ" .. i]) or 0))
				)
				if OmegaCharging then
					cf = cf * CFrame.Angles(0, 0, math.sin(os.clock() * 25) * 0.1)
				end
				cf = X.stashShift(ctl, cf, dt)
				if ctl.AP then X.driveHandle(ctl, cf)
				else pcall(function() sl.Handle.CFrame = cf end) end
			end
		end
		local act = X.OmegaSlots[m.OmegaActiveSlot or 1]
		OmegaHeld = act and act.Ctl or OmegaHeld
		if m.OmegaUseHatBullet then pcall(X.stepOmegaBullets, dt, followRoot) end
	end

	--------------------------------------------------------------
	-- WEAPONS
	--------------------------------------------------------------
	X.clearWeapon = function()
		local had = (WeaponHeld ~= nil) or (next(X.WeaponSlots) ~= nil) or (next(X.BulletHats) ~= nil)
		for _, ent in pairs(X.BulletHats) do
			if ent and ent.Held and ent.Held.Handle then X.stripTrails(ent.Held.Handle) end
		end
		if had then
			local keep = {}
			for handle, held in pairs(Held) do
				if held.Kind ~= "weapon" then keep[handle] = true end
			end
			X.releaseHeld(keep)
		end
		for _, h in pairs(X.WeaponSlots) do
			if h and not h.AP and h.Handle then pcall(function() h.Handle:Destroy() end) end
		end
		X.WeaponSlots = {}
		X.BulletHats = {}
		WeaponHeld = nil
		for _, b in ipairs(WeaponBullets) do
			-- real (FE) hat bullets are the player's own hats: never destroy them
			if not b.Real then
				pcall(function() if b.Part then b.Part:Destroy() end end)
			end
		end
		WeaponBullets = {}
	end

	X.activeWeapon = function()
		local want = math.clamp(math.floor(m.WeaponActiveSlot or 1), 1, 10)
		if X.WeaponSlots[want] then return X.WeaponSlots[want], want end
		for step = 1, 10 do
			local s = ((want - 1 + step) % 10) + 1
			if X.WeaponSlots[s] then return X.WeaponSlots[s], s end
		end
		return nil, want
	end

	-- where a slot's weapon floats (root space). lift raises it (used as the bullet-hat "home")
	X.weaponBase = function(slot, rootCF, lift, aimDir)
		local stayH = (m.WeaponStayUp and (m.WeaponStayUpHeight or 3.5)) or 0
		local posCF = rootCF * CFrame.new(
			(m.WeaponFloatSide or 1.8) + (tonumber(m["WeaponOffsetX" .. slot]) or 0),
			(m.WeaponFloatHeight or 0.6) + (tonumber(m["WeaponOffsetY" .. slot]) or 0) + (lift or 0) + stayH,
			(m.WeaponFloatForward or -0.4) + (tonumber(m["WeaponOffsetZ" .. slot]) or 0)
		)
		local rotBase = posCF
		if aimDir then
			local p = posCF.Position
			rotBase = CFrame.lookAt(p, p + aimDir)
		end
		return rotBase
			* CFrame.Angles(math.rad(m.WeaponRotX or 0), math.rad(m.WeaponRotY or 90), math.rad(m.WeaponRotZ or 0))
			* CFrame.Angles(
				math.rad(tonumber(m["WeaponRot" .. slot .. "X"]) or 0),
				math.rad(tonumber(m["WeaponRot" .. slot .. "Y"]) or 0),
				math.rad(tonumber(m["WeaponRot" .. slot .. "Z"]) or 0)
			)
	end

	-- ---------- trails ----------
	X.rainbowSeq = function()
		local pts = {}
		for i = 0, 5 do
			table.insert(pts, ColorSequenceKeypoint.new(i / 5, Color3.fromHSV(i / 6, 1, 1)))
		end
		return ColorSequence.new(pts)
	end

	X.applyTrailProps = function(tr)
		pcall(function()
			tr.Lifetime = m.WeaponTrailLife or 0.6
			tr.WidthScale = NumberSequence.new(m.WeaponTrailWidth or 1)
			tr.LightEmission = 1
			tr.FaceCamera = true
			tr.MinLength = 0.05
			tr.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1),
			})
			if m.WeaponRainbow then
				tr.Color = X.rainbowSeq()
			else
				tr.Color = ColorSequence.new(Color3.fromRGB(
					m.WeaponTrailR or 255, m.WeaponTrailG or 180, m.WeaponTrailB or 60))
			end
		end)
	end

	X.addTrail = function(part, enabled)
		if not part then return nil end
		local old = part:FindFirstChild("HS_Trail")
		if old then
			X.applyTrailProps(old)
			old.Enabled = enabled and true or false
			return old
		end
		local half = 0.4
		pcall(function() half = math.clamp(math.max(part.Size.X, part.Size.Y) / 2, 0.2, 2) end)
		local a0 = Instance.new("Attachment")
		a0.Name = "HS_TrA"
		a0.Position = Vector3.new(0, half, 0)
		a0.Parent = part
		local a1 = Instance.new("Attachment")
		a1.Name = "HS_TrB"
		a1.Position = Vector3.new(0, -half, 0)
		a1.Parent = part
		local tr = Instance.new("Trail")
		tr.Name = "HS_Trail"
		tr.Attachment0 = a0
		tr.Attachment1 = a1
		tr.Enabled = enabled and true or false
		X.applyTrailProps(tr)
		tr.Parent = part
		return tr
	end

	X.trailEnable = function(part, on)
		if not part then return end
		local tr = part:FindFirstChild("HS_Trail")
		if tr then
			if on then pcall(function() tr:Clear() end) end
			tr.Enabled = on and true or false
		end
	end

	X.stripTrails = function(handle)
		if not handle then return end
		for _, n in ipairs({ "HS_Trail", "HS_TrA", "HS_TrB" }) do
			local c = handle:FindFirstChild(n)
			if c then pcall(function() c:Destroy() end) end
		end
	end

	X.refreshTrails = function()
		for _, ent in pairs(X.BulletHats) do
			local h = ent and ent.Held and ent.Held.Handle
			local tr = h and h:FindFirstChild("HS_Trail")
			if tr then X.applyTrailProps(tr) end
		end
		for _, b in ipairs(WeaponBullets) do
			local tr = b.Part and b.Part:FindFirstChild("HS_Trail")
			if tr then X.applyTrailProps(tr) end
		end
	end

	X.bulletFolder = function()
		if X.BulletFolder and X.BulletFolder.Parent then return X.BulletFolder end
		local f = Workspace:FindFirstChild(("UhhhhhhHatStand_Bullets" .. SUF))
		if not f then
			f = Instance.new("Folder")
			f.Name = ("UhhhhhhHatStand_Bullets" .. SUF)
			f.Parent = Workspace
		end
		X.BulletFolder = f
		return f
	end

	X.cleanClone = function(c)
		for _, d in ipairs(c:GetDescendants()) do
			local kill = string.find(d.Name, "^HS_") ~= nil
			if not kill then
				for _, cls in ipairs(CONTROLLER_CLASSES) do
					if d:IsA(cls) then kill = true break end
				end
			end
			if kill then pcall(function() d:Destroy() end) end
		end
	end

	X.scaleClone = function(c, k)
		if k == 1 then return end
		pcall(function()
			if c:IsA("BasePart") then c.Size = c.Size * k end
			for _, d in ipairs(c:GetDescendants()) do
				if d:IsA("SpecialMesh") then d.Scale = d.Scale * k
				elseif d:IsA("BasePart") then d.Size = d.Size * k end
			end
		end)
	end

	X.getRP = function()
		if X.RPFrame == X.Frame and X.RP then return X.RP end
		local rp = RaycastParams.new()
		rp.FilterType = Enum.RaycastFilterType.Exclude
		pcall(function() rp.RespectCanCollide = true end)
		local ex = {}
		if LocalPlayer.Character then table.insert(ex, LocalPlayer.Character) end
		pcall(function()
			if _G.Uhhhhhh and _G.Uhhhhhh.Character then table.insert(ex, _G.Uhhhhhh.Character) end
		end)
		if StandModel then table.insert(ex, StandModel) end
		if X.CloneModel then table.insert(ex, X.CloneModel) end
		table.insert(ex, X.ensurePlaceFolder())
		table.insert(ex, X.bulletFolder())
		rp.FilterDescendantsInstances = ex
		X.RP, X.RPFrame = rp, X.Frame
		return rp
	end

	X.hitFX = function(pos)
		if not m.WeaponHitFX then return end
		pcall(function()
			local p = Instance.new("Part")
			p.Name = "HS_HitFX"
			p.Shape = Enum.PartType.Ball
			p.Material = Enum.Material.Neon
			p.Anchored = true
			p.CanCollide = false
			p.CanQuery = false
			p.CanTouch = false
			p.Color = m.WeaponRainbow and Color3.fromHSV((os.clock() * 0.9) % 1, 1, 1)
				or Color3.fromRGB(m.WeaponBulletR or 255, m.WeaponBulletG or 220, m.WeaponBulletB or 80)
			p.Size = Vector3.new(0.6, 0.6, 0.6)
			p.Transparency = 0.2
			p.CFrame = CFrame.new(pos)
			p.Parent = X.bulletFolder()
			local k = (m.WeaponBulletSize or 1) * 5
			TweenService:Create(p, TweenInfo.new(0.3), {
				Size = Vector3.new(k, k, k), Transparency = 1,
			}):Play()
			Debris:AddItem(p, 0.4)
		end)
	end

	-- ---------- laser / gaster blaster effects ----------
	X.bulletColor = function()
		if m.WeaponRainbow then return Color3.fromHSV((os.clock() * 0.9) % 1, 1, 1) end
		return Color3.fromRGB(m.WeaponBulletR or 255, m.WeaponBulletG or 220, m.WeaponBulletB or 80)
	end

	X.castRay = function(origin, dir, len)
		local pos = origin + dir * len
		local ok, res = pcall(function() return Workspace:Raycast(origin, dir * len, X.getRP()) end)
		if ok and res then pos = res.Position end
		return pos
	end

	X.flash = function(pos, size, dur, col)
		pcall(function()
			local f = Instance.new("Part")
			f.Name = "HS_Flash"
			f.Shape = Enum.PartType.Ball
			f.Material = Enum.Material.Neon
			f.Anchored = true
			f.CanCollide = false
			f.CanQuery = false
			f.CanTouch = false
			f.Color = col
			f.Size = Vector3.new(0.4, 0.4, 0.4)
			f.Transparency = 0.1
			f.CFrame = CFrame.new(pos)
			f.Parent = X.bulletFolder()
			TweenService:Create(f, TweenInfo.new(dur), {
				Size = Vector3.new(size, size, size), Transparency = 1,
			}):Play()
			Debris:AddItem(f, dur + 0.1)
		end)
	end

	X.beam = function(origin, hitPos, thick, col, life)
		local len = (hitPos - origin).Magnitude
		if len < 0.2 then return end
		pcall(function()
			local p = Instance.new("Part")
			p.Name = "HS_Beam"
			p.Anchored = true
			p.CanCollide = false
			p.CanQuery = false
			p.CanTouch = false
			p.Material = Enum.Material.Neon
			p.Color = col
			p.Size = Vector3.new(thick, thick, len)
			p.CFrame = CFrame.lookAt(origin, hitPos) * CFrame.new(0, 0, -len / 2)
			p.Parent = X.bulletFolder()
			TweenService:Create(p, TweenInfo.new(life, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Size = Vector3.new(0.05, 0.05, len), Transparency = 1,
			}):Play()
			Debris:AddItem(p, life + 0.1)
		end)
	end

	X.fireLaser = function(origin, dir, size)
		local col = X.bulletColor()
		local t = m.WeaponLaserTime or 0.2
		local pos = X.castRay(origin, dir, m.WeaponLaserLength or 200)
		X.beam(origin, pos, 0.5 * size, col, t)
		X.beam(origin, pos, 0.2 * size, Color3.new(1, 1, 1), t * 0.8)
		X.flash(origin, 2.5 * size, 0.2, col)
		X.hitFX(pos)
	end

	X.fireBlaster = function(origin, dir0, size)
		task.spawn(function()
			local s = size * (m.WeaponBlasterScale or 1)
			local col = X.bulletColor()
			local depth = m.UndergroundStash and (m.StashDepth or 10) or 0
			local rise = math.max(m.StashRise or 0.3, 0.05)
			local charge = math.max(m.WeaponBlasterCharge or 0.5, 0.05)
			local folder = X.bulletFolder()
			local base = origin - dir0 * 3
			local parts = {}
			local function add(sz, rel, color, neon, ball)
				local p = Instance.new("Part")
				p.Name = "HS_Blaster"
				p.Anchored = true
				p.CanCollide = false
				p.CanQuery = false
				p.CanTouch = false
				p.Material = neon and Enum.Material.Neon or Enum.Material.SmoothPlastic
				p.Color = color
				if ball then p.Shape = Enum.PartType.Ball end
				p.Size = sz * s
				p.Parent = folder
				Debris:AddItem(p, 10)
				local e = { P = p, Rel = rel }
				table.insert(parts, e)
				return e
			end
			local white = Color3.fromRGB(240, 240, 240)
			add(Vector3.new(2.2, 1.8, 2.6), CFrame.new(0, 0, 0), white, false, false)
			local jaw = add(Vector3.new(1.8, 0.6, 2.2), CFrame.new(0, -1.15 * s, -0.5 * s), white, false, false)
			add(Vector3.new(0.5, 0.5, 0.5), CFrame.new(-0.6 * s, 0.25 * s, -1.25 * s), col, true, true)
			add(Vector3.new(0.5, 0.5, 0.5), CFrame.new(0.6 * s, 0.25 * s, -1.25 * s), col, true, true)
			local glow = add(Vector3.new(0.4, 0.4, 0.4), CFrame.new(0, -0.45 * s, -1.5 * s), col, true, true)
			local dir = dir0
			local off = depth
			local jitter = Vector3.zero
			local function aim()
				local tgt = Mouse.Hit.Position - base
				if tgt.Magnitude > 0.5 then dir = tgt.Unit end
			end
			local function layout(k)
				local spot = CFrame.new(0, -off, 0) * CFrame.lookAt(base + jitter, base + jitter + dir)
				for _, e in ipairs(parts) do
					local rel = e.Rel
					if e == jaw then rel = rel * CFrame.new(0, -0.5 * s * k, 0) end
					e.P.CFrame = spot * rel
				end
				local g = 0.4 * s * (1 + k * 5)
				glow.P.Size = Vector3.new(g, g, g)
			end
			local function ease(k) return k * k * (3 - 2 * k) end

			local t0 = os.clock()
			if depth > 0 then -- rise out of the ground
				while true do
					local k = math.clamp((os.clock() - t0) / rise, 0, 1)
					off = depth * (1 - ease(k))
					aim()
					layout(0)
					if k >= 1 then break end
					task.wait()
				end
			end
			off = 0
			t0 = os.clock() -- charge
			while true do
				local k = math.clamp((os.clock() - t0) / charge, 0, 1)
				aim()
				layout(k)
				if k >= 1 then break end
				task.wait()
			end
			-- fire
			local muzzle = (CFrame.lookAt(base, base + dir) * CFrame.new(0, -0.45 * s, -1.7 * s)).Position
			local hitPos = X.castRay(muzzle, dir, m.WeaponLaserLength or 200)
			X.beam(muzzle, hitPos, 3 * s, col, 0.55)
			X.beam(muzzle, hitPos, 1.2 * s, Color3.new(1, 1, 1), 0.45)
			X.flash(muzzle, 5 * s, 0.3, col)
			X.flash(hitPos, 8 * s, 0.4, col)
			t0 = os.clock()
			while os.clock() - t0 < 0.4 do
				local k = (os.clock() - t0) / 0.4
				jitter = Vector3.new(math.random() - 0.5, math.random() - 0.5, math.random() - 0.5) * 0.4 * s * (1 - k)
				layout(1)
				task.wait()
			end
			jitter = Vector3.zero
			if depth > 0 then -- sink back underground
				t0 = os.clock()
				while true do
					local k = math.clamp((os.clock() - t0) / rise, 0, 1)
					off = depth * ease(k)
					layout(1 - k)
					if k >= 1 then break end
					task.wait()
				end
			else
				for _, e in ipairs(parts) do
					TweenService:Create(e.P, TweenInfo.new(0.3), { Transparency = 1 }):Play()
				end
				task.wait(0.35)
			end
			for _, e in ipairs(parts) do pcall(function() e.P:Destroy() end) end
		end)
	end

	-- ---------- underground stash: sink until used, rise to fire ----------
	-- Weapons use UndergroundStash; Sans attacks (gaster/bone/omega) use SansUnderground (or UndergroundStash)
	X.sansStashOn = function(held)
		local kind = held and held.Kind
		if kind == "shield" then
			return (m.ShieldUnderground and true) or false
		end
		if kind == "gaster" or kind == "bone" or kind == "omega" then
			return (m.SansUnderground and true) or false -- the SANS toggle alone decides (on = hidden, off = raised)
		end
		if kind == "planebomb" or kind == "planepackage" or kind == "planemissile"
			or kind == "planemissileammo" or kind == "planebomb2" then
			return (m.PlaneOrdnanceUnderground and true) or false
		end
		return (m.UndergroundStash and true) or false
	end
	X.stashParams = function(held)
		local kind = held and held.Kind
		if kind == "shield" then
			return m.ShieldStashDepth or 10, m.ShieldStashRise or 0.3, m.ShieldStashHold or 0
		end
		if kind == "gaster" or kind == "bone" or kind == "omega" then
			-- prefer Sans-specific values when Sans stash is on (or always for these kinds)
			local depth = m.SansStashDepth or m.StashDepth or 12
			local rise = m.SansStashRise or m.StashRise or 0.35
			local hold = m.SansStashHold or m.StashHold or 1.0
			if kind == "omega" then
				if (m.OmegaStashDepth or 0) > 0 then depth = m.OmegaStashDepth end
				if (m.OmegaStashRise or 0) > 0 then rise = m.OmegaStashRise end
				if (m.OmegaStashHold or 0) > 0 then hold = m.OmegaStashHold end
			end
			return depth, rise, hold
		end
		if kind == "planebomb" or kind == "planepackage" or kind == "planemissile"
			or kind == "planemissileammo" or kind == "planebomb2" then
			return m.PlaneOrdnanceStashDepth or 12, m.PlaneOrdnanceStashRise or 0.35, m.PlaneOrdnanceStashHold or 1.2
		end
		return m.StashDepth or 10, m.StashRise or 0.3, m.StashHold or 1.2
	end
	X.stashShift = function(held, cf, dt)
		local now = os.clock()
		local target = 1
		if X.sansStashOn(held) then target = (now < (held.UpUntil or 0)) and 1 or 0 end
		local up = held.Up
		if up == nil then up = (target == 0) and 0 or 1 end
		local depth, riseT = X.stashParams(held)
		riseT = math.max(riseT or 0.3, 0.05)
		if up < target then up = math.min(target, up + dt / riseT)
		elseif up > target then up = math.max(target, up - dt / riseT) end
		held.Up = up
		if up >= 1 then return cf end
		local e = up * up * (3 - 2 * up)
		return CFrame.new(0, -(depth or 10) * (1 - e), 0) * cf
	end
	-- call when selecting/rebuilding a Sans hat so it starts buried
	X.initSansStash = function(held)
		if held and X.sansStashOn(held) then
			held.Up = 0
			held.UpUntil = 0
		end
	end

	-- master SANS toggle: sink / raise Gaster + Bone + Omega (+ omega bullet hats) live, no rebuild
	X.setSansUnderground = function(on)
		m.SansUnderground = on and true or false
		local function touch(held)
			if not held then return end
			if m.SansUnderground then held.UpUntil = 0 end -- stash target becomes "down"; "up" is automatic when stash is off
		end
		for _, gs in pairs(GasterSlots) do touch(gs.Held) end
		touch(BoneHeld)
		for _, sl in pairs(X.OmegaSlots or {}) do touch(sl.Ctl) end
		warn("[HatStand] SANS underground -> " .. (m.SansUnderground and "ON (hidden)" or "OFF (raised)"))
	end

	X.rebuildWeapon = function()
		X.clearWeapon()
		if not m.WeaponEnabled then return end
		X.refreshAllHats()
		local claimed = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "weapon" then claimed[handle] = true end
		end
		local count = 0
		for slot = 1, 10 do
			local label = m["WeaponHat" .. slot]
			if X.trim(X.cleanLabel(label)) ~= "" then
				local hat = X.findHatFromLabel(label, claimed)
				if hat and hat.Handle and hat.Handle.Parent and not claimed[hat.Handle] then
					claimed[hat.Handle] = true
					local held = nil
					if m.FEMode then
						held = X.attachFE(hat, "weapon")
					else
						local clone = X.cloneHandle(hat.Handle, "Weapon" .. slot)
						if clone then
							clone.Parent = workspace
							held = { Handle = clone, Kind = "weapon" }
						end
					end
					if held then
						held.Slot = slot
						X.WeaponSlots[slot] = held
						count = count + 1
					end
				else
					warn("[HatStand] Weapon slot " .. slot .. ": hat '" .. tostring(label) .. "' unavailable (already used elsewhere?)")
				end
			end
		end
		-- real (FE) hat bullets: one hat per slot that has the "Hat" bullet style
		local bulletCount = 0
		if m.WeaponRealHat and m.FEMode then
			for slot = 1, 10 do
				local style = math.clamp(math.floor(tonumber(m["WeaponBullet" .. slot]) or 1), 1, 4)
				local label = m["WeaponBulletHat" .. slot]
				if style == 4 and X.trim(X.cleanLabel(label)) ~= "" then
					local hat = X.findHatFromLabel(label, claimed)
					if hat and hat.Handle and hat.Handle.Parent and not claimed[hat.Handle] then
						claimed[hat.Handle] = true
						local held = X.attachFE(hat, "weapon")
						if held then
							held.Slot = slot
							held.IsBulletHat = true
							X.BulletHats[slot] = { Held = held, Flying = false }
							if m.WeaponTrail then X.addTrail(hat.Handle, false) end
							bulletCount = bulletCount + 1
						end
					else
						warn("[HatStand] Bullet hat for slot " .. slot .. ": '" .. tostring(label) .. "' unavailable (already used elsewhere?)")
					end
				end
			end
		end
		WeaponHeld = X.activeWeapon()
		if count == 0 and bulletCount == 0 then
			warn("[HatStand] no weapon hats chosen — pick a hat in a Weapon Slot dropdown")
		else
			warn("[HatStand] weapons floating: " .. count .. "  real bullet hats: " .. bulletCount)
		end
	end

	X.cycleWeapon = function()
		local cur = math.clamp(math.floor(m.WeaponActiveSlot or 1), 1, 10)
		for step = 1, 10 do
			local s = ((cur - 1 + step) % 10) + 1
			if X.WeaponSlots[s] then
				m.WeaponActiveSlot = s
				WeaponHeld = X.WeaponSlots[s]
				warn("[HatStand] weapon slot -> " .. s)
				return
			end
		end
		warn("[HatStand] no weapons to cycle")
	end

	X.doFire = function(slotOverride)
		if not m.WeaponEnabled then return false end
		local active = slotOverride and X.WeaponSlots[slotOverride] or X.activeWeapon()
		if not active or not active.Handle then return false end
		local now = os.clock()

		local slot = active.Slot or m.WeaponActiveSlot or 1
		local style = math.clamp(math.floor(tonumber(m["WeaponBullet" .. slot]) or 1), 1, 6)
		local handle = active.Handle
		local aimPoint = Mouse.Hit.Position
		local toAim = aimPoint - handle.Position
		local baseDir = (toAim.Magnitude > 0.1) and toAim.Unit or handle.CFrame.LookVector
		if m.WeaponAimMouse == false then
			local fr = X.getFollowRoot()
			if fr then baseDir = fr.CFrame.LookVector end
		end
		local origin = handle.Position + baseDir * 1.5
		local speed = m.WeaponFireSpeed or 120
		local life = m.WeaponBulletLife or 2.5
		local size = m.WeaponBulletSize or 1

		local ent = (style == 4) and X.BulletHats[slot] or nil
		local real = ent and ent.Held and ent.Held.Handle and ent.Held.Handle.Parent and true or false
		if real and ent.Flying then return false end -- the real hat is still out
		WeaponLastFire = now

		if m.WeaponMuzzleFlash and style <= 4 then X.flash(origin, 1.6 * size, 0.15, X.bulletColor()) end
		active.Recoil = 1
		if m.WeaponSFX then
			X.playSFX(m.WeaponFireSFXId, m.WeaponVolume or 0.85, handle, 0.95 + math.random() * 0.15)
		end
		-- per-slot burst (up to WeaponMaxBurst); real hat bullets still 1 at a time unless HatBulletCount > 1
		local perSlot = tonumber(m["WeaponBurst" .. slot]) or m.WeaponBurst or 1
		local maxB = m.WeaponMaxBurst or 12
		local n = real and math.clamp(math.floor(tonumber(m["WeaponHatBulletCount" .. slot]) or 1), 1, 4) or math.clamp(math.floor(perSlot), 1, maxB)
		local spread = m.WeaponSpread or 0
		for k = 1, n do
			local d = baseDir
			if n > 1 then
				local yaw = ((k - 1) / (n - 1) - 0.5) * 2 * spread
				d = (CFrame.lookAt(origin, origin + baseDir) * CFrame.Angles(0, math.rad(yaw), 0)).LookVector
			elseif spread > 0 and not real then
				d = (CFrame.lookAt(origin, origin + baseDir)
					* CFrame.Angles(math.rad((math.random() - 0.5) * 2 * spread), math.rad((math.random() - 0.5) * 2 * spread), 0)).LookVector
			end

			local part, neon = nil, false
			if style == 5 then
				X.fireBlaster(origin, d, size)
			elseif style == 6 then
				X.fireLaser(origin, d, size)
			elseif real then
				part = ent.Held.Handle
				ent.Flying = true
				if m.WeaponTrail then
					X.addTrail(part, true)
					X.trailEnable(part, true)
				end
			elseif style == 4 then
				local label = m["WeaponBulletHat" .. slot]
				local src = handle
				if X.trim(X.cleanLabel(label)) ~= "" then
					local hat = X.findHatFromLabel(label)
					if hat and hat.Handle and hat.Handle.Parent then src = hat.Handle end
				end
				part = X.cloneHandle(src, "Bullet")
				if part then
					X.cleanClone(part)
					X.scaleClone(part, size)
					part.CFrame = CFrame.lookAt(origin, origin + d)
					part.Parent = X.bulletFolder()
				end
			else
				neon = true
				part = Instance.new("Part")
				part.Name = "HS_Bullet"
				part.Anchored = true
				part.CanCollide = false
				part.CanQuery = false
				part.CanTouch = false
				part.Material = Enum.Material.Neon
				part.Color = Color3.fromRGB(m.WeaponBulletR or 255, m.WeaponBulletG or 220, m.WeaponBulletB or 80)
				if style == 1 then -- beam
					part.Size = Vector3.new(0.25, 0.25, 4) * size
				elseif style == 2 then -- orb
					part.Shape = Enum.PartType.Ball
					part.Size = Vector3.new(0.7, 0.7, 0.7) * size
				else -- spike
					part.Size = Vector3.new(0.3, 0.3, 2.2) * size
				end
				part.CFrame = CFrame.lookAt(origin, origin + d)
				part.Parent = X.bulletFolder()
			end
			if part then
				if not real then
					if m.WeaponTrail then X.addTrail(part, true) end
					Debris:AddItem(part, life + 0.5)
				end
				table.insert(WeaponBullets, {
					Part = part, Real = real, Entry = ent, Slot = slot, Neon = neon, Origin = origin, Pos = origin,
					Vel = d * speed, Life = life, T = 0, Roll = 0,
				})
			end
		end
		return true
	end

	-- slots in the fire rotation: toggled on, have a floating weapon hat, MAX 6
	X.fireList = function()
		local list = {}
		for s = 1, 10 do
			if m["WeaponFire" .. s] and X.WeaponSlots[s] then
				table.insert(list, s)
				if #list >= 6 then break end
			end
		end
		return list
	end

	X.fireSeq = function()
		local list = X.fireList()
		if #list == 0 then return end
		if (m.WeaponFireMode or 1) == 2 then
			WeaponLastFire = os.clock()
			for _, s in ipairs(list) do X.doFire(s) end
		else
			for k = 0, #list - 1 do
				local idx = ((X.FireIdx or 0) + k) % #list + 1
				if X.doFire(list[idx]) then
					X.FireIdx = idx
					WeaponLastFire = os.clock()
					break
				end
			end
		end
	end

	X.fireWeapon = function()
		if not m.WeaponEnabled then
			warn("[HatStand] weapon fire: Weapon Enabled is OFF")
			return
		end
		local list = X.fireList()
		if #list == 0 then
			warn("[HatStand] weapon fire: no slot is in the fire rotation (Fire Slot toggles) or no weapon hat is floating")
			return
		end
		X.TrackUntil = os.clock() + (m.WeaponTrackHold or 1.5)
		if os.clock() - WeaponLastFire < (m.WeaponFireCooldown or 0.25) then return end
		if m.UndergroundStash then
			local targets = list
			if (m.WeaponFireMode or 1) == 1 then
				targets = { list[((X.FireIdx or 0) % #list) + 1] }
			end
			local rise = m.StashRise or 0.3
			local upUntil = os.clock() + rise + (m.StashHold or 1.2) + (m.WeaponBlasterCharge or 0.5)
			local needWait = false
			for _, s in ipairs(targets) do
				local wh = X.WeaponSlots[s]
				if wh then
					wh.UpUntil = upUntil
					if (wh.Up or 0) < 0.85 then needWait = true end
				end
				local ent = X.BulletHats[s]
				if ent and ent.Held then ent.Held.UpUntil = upUntil end
			end
			if needWait then
				if not X.FirePending then
					X.FirePending = true
					task.delay(rise, function()
						X.FirePending = false
						pcall(X.fireSeq)
					end)
				end
				return
			end
		end
		X.fireSeq()
	end

	-- returns true when the bullet is finished and must be removed
	X.stepBullet = function(b, dt, rootCF)
		local part = b.Part
		if not part or not part.Parent then
			if b.Real and b.Entry then b.Entry.Flying = false end
			return true
		end
		if b.Real and b.Entry and (not b.Entry.Held or not b.Entry.Held.Handle or not b.Entry.Held.Handle.Parent) then
			return true
		end
		if b.Returning then
			local home = rootCF and X.weaponBase(b.Slot, rootCF, 0.9)
			if not home then
				b.Entry.Flying = false
				X.trailEnable(part, false)
				return true
			end
			local cur = b.Pos or part.Position
			local to = home.Position - cur
			local stepLen = (m.WeaponReturnSpeed or 140) * dt
			if to.Magnitude <= stepLen + 0.4 then
				X.driveHandle(b.Entry.Held, home)
				b.Entry.Flying = false
				b.Entry.Held.UpUntil = os.clock() + (m.StashHold or 1.2)
				X.trailEnable(part, false)
				return true
			end
			b.Pos = cur + to.Unit * stepLen
			X.driveHandle(b.Entry.Held, CFrame.new(b.Pos) * (part.CFrame - part.Position))
			return false
		end

		b.T = b.T + dt
		local vel = b.Vel
		if (m.WeaponHoming or 0) > 0 and vel.Magnitude > 0.1 then
			local tgt = Mouse.Hit.Position - (b.Pos or part.Position)
			if tgt.Magnitude > 0.5 then
				local nd = vel.Unit:Lerp(tgt.Unit, math.clamp(m.WeaponHoming * dt * 4, 0, 1))
				if nd.Magnitude > 0.01 then vel = nd.Unit * vel.Magnitude end
			end
		end
		if (m.WeaponGravity or 0) ~= 0 then
			vel = vel + Vector3.new(0, -(m.WeaponGravity or 0) * dt, 0)
		end
		b.Vel = vel

		local pos = b.Pos or part.Position
		local step = vel * dt
		local hit = nil
		if m.WeaponStopOnHit then
			local ok, res = pcall(function() return Workspace:Raycast(pos, step, X.getRP()) end)
			if ok then hit = res end
		end
		if hit and (b.T < 0.12 or (hit.Position - (b.Origin or hit.Position)).Magnitude < 4) then hit = nil end
		local newPos = hit and hit.Position or (pos + step)
		b.Pos = newPos
		local dirU = (vel.Magnitude > 0.01) and vel.Unit or Vector3.new(0, 0, -1)
		local cf = CFrame.lookAt(newPos, newPos + dirU)
		if (m.WeaponBulletSpin or 0) ~= 0 then
			b.Roll = (b.Roll or 0) + math.rad(m.WeaponBulletSpin) * dt
			cf = cf * CFrame.Angles(0, 0, b.Roll)
		end
		if b.Real then
			X.driveHandle(b.Entry.Held, cf)
		else
			pcall(function() part.CFrame = cf end)
			if b.Neon and m.WeaponRainbow then
				pcall(function() part.Color = Color3.fromHSV((b.T * 0.9) % 1, 1, 1) end)
			end
		end
		if hit then
			X.hitFX(newPos)
			if b.Real then b.Returning = true return false end
			return true
		end
		if b.T > b.Life then
			if b.Real then b.Returning = true return false end
			return true
		end
		return false
	end

	function X.stepWeapon(dt)
		if not m.WeaponEnabled then return end
		local followRoot = X.getFollowRoot()
		local rootCF = followRoot and followRoot.CFrame or nil
		if m.WeaponAutoFire and X.BHeld then pcall(X.fireWeapon) end
		if rootCF then
			for slot, wh in pairs(X.WeaponSlots) do
				if wh and wh.Handle and wh.Handle.Parent then
					local rootLook = rootCF.LookVector
					local dir = rootLook
					local base0 = X.weaponBase(slot, rootCF, 0)
					local track = m.WeaponTrackMouse
						and (((m.WeaponTrackMode or 2) == 1) or os.clock() < (X.TrackUntil or 0))
					wh.TrackK = wh.TrackK or 0
					wh.TrackK = wh.TrackK + ((track and 1 or 0) - wh.TrackK) * math.min(1, dt * (m.WeaponTrackSmooth or 12))
					if wh.TrackK > 0.001 then
						local want = Mouse.Hit.Position - base0.Position
						if not m.WeaponTrackPitch then want = Vector3.new(want.X, 0, want.Z) end
						if want.Magnitude > 0.5 then
							local mixed = rootLook:Lerp(want.Unit, math.clamp(wh.TrackK * (m.WeaponTrackStrength or 1), 0, 1))
							if mixed.Magnitude > 0.01 then dir = mixed.Unit end
						end
					end
					local cf = X.weaponBase(slot, rootCF, 0, (wh.TrackK > 0.001) and dir or nil)
					wh.Recoil = math.max(0, (wh.Recoil or 0) - dt * (m.WeaponRecoilSpeed or 7))
					if wh.Recoil > 0 and (m.WeaponRecoil or 0) > 0 then
						cf = cf + (-dir * (m.WeaponRecoil * wh.Recoil * wh.Recoil))
					end
					if (m.WeaponBobAmt or 0) > 0 then
						cf = cf + Vector3.new(0, math.sin(os.clock() * (m.WeaponBobSpeed or 2) + slot) * m.WeaponBobAmt, 0)
					end
					cf = X.stashShift(wh, cf, dt)
					if wh.AP then
						X.driveHandle(wh, cf)
					else
						pcall(function() wh.Handle.CFrame = cf end)
					end
				else
					X.WeaponSlots[slot] = nil
					for hd in pairs(Held) do
						if not hd.Parent then Held[hd] = nil end
					end
				end
			end
			-- real bullet hats wait at their "home" next to the weapon
			local live = {}
			for _, bb in ipairs(WeaponBullets) do
				if bb.Entry then live[bb.Entry] = true end
			end
			for slot, ent in pairs(X.BulletHats) do
				local h = ent.Held and ent.Held.Handle
				if h and h.Parent then
					if ent.Flying and not live[ent] then ent.Flying = false end
					if not ent.Flying then
						X.driveHandle(ent.Held, X.stashShift(ent.Held, X.weaponBase(slot, rootCF, 0.9), dt))
					end
				else
					X.BulletHats[slot] = nil
				end
			end
		end
		for i = #WeaponBullets, 1, -1 do
			local ok, done = pcall(X.stepBullet, WeaponBullets[i], dt, rootCF)
			if (not ok) or done then
				local b = WeaponBullets[i]
				if b and b.Real and b.Entry then b.Entry.Flying = false end
				if b and not b.Real then
					pcall(function() if b.Part then b.Part:Destroy() end end)
				end
				table.remove(WeaponBullets, i)
			end
		end
	end

	--------------------------------------------------------------
	-- SHIELD
	--------------------------------------------------------------
	X.clearShield = function()
		if ShieldHeld then
			local keep = {}
			for handle, held in pairs(Held) do
				if held.Kind ~= "shield" then keep[handle] = true end
			end
			X.releaseHeld(keep)
		end
		ShieldHeld = nil
		ShieldPlacedCF = nil
	end

	X.rebuildShield = function()
		X.clearShield()
		if not m.ShieldEnabled then return end
		local hat = X.findHatFromLabel(m.ShieldHat)
		if not hat or not hat.Handle then
			warn("[HatStand] Shield: no hat")
			return
		end
		if m.FEMode then
			ShieldHeld = X.attachFE(hat, "shield")
		else
			local clone = X.cloneHandle(hat.Handle, "Shield")
			if clone then
				clone.Parent = workspace
				ShieldHeld = { Handle = clone, Kind = "shield" }
			end
		end
		if ShieldHeld then ShieldHeld.Kind = "shield" X.initSansStash(ShieldHeld) end
		warn("[HatStand] Shield ready: " .. hat.Name)
	end

	function X.placeShieldAtMouse()
		local cf = X.getMouseWorldCF()
		if cf then
			ShieldPlacedCF = cf * CFrame.Angles(
				math.rad(m.ShieldRotX or 0),
				math.rad(m.ShieldRotY or 0),
				math.rad(m.ShieldRotZ or 0)
			)
			m.ShieldMode = 2
			warn("[HatStand] Shield placed free")
		end
	end

	-- raise / lower the shield from underground (key = m.KeyShield)
	X.toggleShieldStash = function()
		if not m.ShieldEnabled or not ShieldHeld then return end
		if not m.ShieldUnderground then return end
		local now = os.clock()
		if (ShieldHeld.UpUntil or 0) > now then
			ShieldHeld.UpUntil = 0 -- sink
			warn("[HatStand] Shield -> underground")
		else
			local hold = tonumber(m.ShieldStashHold) or 0
			ShieldHeld.UpUntil = (hold > 0) and (now + hold) or math.huge
			warn("[HatStand] Shield -> up")
		end
	end

	function X.stepShield(dt)
		if not m.ShieldEnabled or not ShieldHeld or not ShieldHeld.Handle then return end
		local followRoot = X.getFollowRoot()
		local cf
		if m.ShieldMode == 2 and ShieldPlacedCF then
			cf = ShieldPlacedCF
		elseif m.ShieldMode == 3 and followRoot then
			-- grab: closer to hand-ish
			cf = followRoot.CFrame * CFrame.new(1.2, 0.8, -1.5)
				* CFrame.Angles(math.rad(m.ShieldRotX), math.rad(m.ShieldRotY), math.rad(m.ShieldRotZ))
		else
			-- hold front
			if not followRoot then return end
			cf = followRoot.CFrame
				* CFrame.new(m.ShieldSide or 0, m.ShieldHeight or 1, m.ShieldForward or -2.2)
				* CFrame.Angles(
					math.rad(m.ShieldRotX or 0),
					math.rad(m.ShieldRotY or 0),
					math.rad(m.ShieldRotZ or 0)
				)
		end
		if m.ShieldBob then
			cf = cf + Vector3.new(0, math.sin(os.clock() * (m.ShieldBobSpeed or 1.2)) * (m.ShieldBobAmt or 0.25), 0)
		end
		if m.ShieldSpin then
			cf = cf * CFrame.Angles(0, os.clock() * (m.ShieldSpinSpeed or 2), 0)
		end
		if m.ShieldAutoFace and followRoot and m.ShieldMode ~= 2 then
			local look = followRoot.CFrame.LookVector
			cf = CFrame.lookAt(cf.Position, cf.Position + look) * CFrame.Angles(
				math.rad(m.ShieldRotX or 0), math.rad(m.ShieldRotY or 0), math.rad(m.ShieldRotZ or 0)
			)
		end
		if m.ShieldUnderground and X.stashShift then
			cf = X.stashShift(ShieldHeld, cf, dt)
		end
		if ShieldHeld.AP then
			X.driveHandle(ShieldHeld, cf)
		else
			pcall(function() ShieldHeld.Handle.CFrame = cf end)
		end
	end




	--------------------------------------------------------------
	-- RAVENGER CLAWS (on X table — avoids Luau local limit)
	--------------------------------------------------------------
	local clearClaws, rebuildClaws, stepClaws, fireClawsCombo, fireClawsPush, fireClawsSpin
	do
		local function clearClawsBlood()
			for _, p in ipairs(X.ClawsBlood) do
				pcall(function() p:Destroy() end)
			end
			X.ClawsBlood = {}
		end

		clearClaws = function()
			if X.ClawsBullet and X.ClawsBullet.Held and X.ClawsBullet.Held.Handle then
				pcall(function() X.stripTrails(X.ClawsBullet.Held.Handle) end)
			end
			X.ClawsBullet = nil
			local keep = {}
			for handle, held in pairs(Held) do
				if held.Kind ~= "claws" then keep[handle] = true end
			end
			X.releaseHeld(keep)
			X.ClawsLeft, X.ClawsRight, X.ClawsHead = nil, nil, nil
			X.ClawsMode, X.ClawsComboStep, X.ClawsAnimT = "idle", 0, 0
			X.ClawsSpinUntil = 0
			clearClawsBlood()
		end

		rebuildClaws = function()
			clearClaws()
			if not m.ClawsEnabled then return end
			X.refreshAllHats()
			local leftHat = X.findHatFromLabel(m.ClawsLeftHat)
			local rightHat = X.findHatFromLabel(m.ClawsRightHat)
			local headHat = X.findHatFromLabel(m.ClawsHeadHat)
			if not leftHat and not rightHat and not headHat then
				warn("[HatStand] Claws: pick Left/Right (claw or arm) and/or Head hats")
				return
			end
			local function attachOne(hat, side)
				if not hat or not hat.Handle then return nil end
				local held
				if m.FEMode then
					held = X.attachFE(hat, "claws")
				else
					local clone = X.cloneHandle(hat.Handle, "Claw_" .. side)
					if clone then
						clone.Parent = workspace
						held = { Handle = clone, Kind = "claws" }
						Held[clone] = held
					end
				end
				if held then
					held.Kind = "claws"
					held.Side = side
				end
				return held
			end
			X.ClawsLeft = attachOne(leftHat, "L")
			X.ClawsRight = attachOne(rightHat, "R")
			X.ClawsHead = attachOne(headHat, "H")
			if m.ClawsLaserUseHat and X.trim(X.cleanLabel(m.ClawsLaserHat or "")) ~= "" then
				local usedB = {}
				for _, h in ipairs({ leftHat, rightHat, headHat }) do
					if h and h.Handle then usedB[h.Handle] = true end
				end
				local bh = X.findHatFromLabel(m.ClawsLaserHat, usedB)
				if bh and bh.Handle and not usedB[bh.Handle] then
					local bheld = attachOne(bh, "B")
					if bheld then
						if m.ClawsLaserTrail and bheld.Handle then pcall(function() X.addTrail(bheld.Handle, false) end) end
						X.ClawsBullet = { Held = bheld, Fly = nil }
					end
				else
					warn("[HatStand] Claws laser: bullet hat unavailable (pick a hat not used by the claws)")
				end
			end
			warn("[HatStand] Ravenger Claws L=" .. tostring(leftHat and leftHat.Name)
				.. " R=" .. tostring(rightHat and rightHat.Name)
				.. " Head=" .. tostring(headHat and headHat.Name))
		end

		local function clawsBaseCF(side, followRoot)
			local scale = m.ClawsScale or 1.8
			local gSide = m.ClawsSide or 1.6
			local gH = m.ClawsHeight or 0.4
			local gF = m.ClawsForward or -0.8
			local ox, oy, oz, rx, ry, rz = 0, 0, 0, 0, 0, 0
			local sideSign = 0
			if side == "L" then
				sideSign = -1
				ox = tonumber(m.ClawsLeftOffX) or 0
				oy = tonumber(m.ClawsLeftOffY) or 0
				oz = tonumber(m.ClawsLeftOffZ) or 0
				rx = tonumber(m.ClawsLeftRotX) or 0
				ry = tonumber(m.ClawsLeftRotY) or 0
				rz = tonumber(m.ClawsLeftRotZ) or 0
			elseif side == "R" then
				sideSign = 1
				ox = tonumber(m.ClawsRightOffX) or 0
				oy = tonumber(m.ClawsRightOffY) or 0
				oz = tonumber(m.ClawsRightOffZ) or 0
				rx = tonumber(m.ClawsRightRotX) or 0
				ry = tonumber(m.ClawsRightRotY) or 0
				rz = tonumber(m.ClawsRightRotZ) or 0
			else
				ox = tonumber(m.ClawsHeadOffX) or 0
				oy = tonumber(m.ClawsHeadOffY) or 1.4
				oz = tonumber(m.ClawsHeadOffZ) or 0
				rx = tonumber(m.ClawsHeadRotX) or 0
				ry = tonumber(m.ClawsHeadRotY) or 0
				rz = tonumber(m.ClawsHeadRotZ) or 0
			end
			local baseX = (side == "H") and 0 or (sideSign * gSide * scale * 0.55)
			local baseY = (side == "H") and (1.2 * scale * 0.5) or (gH * scale * 0.5)
			local baseZ = gF
			local cf = followRoot.CFrame * CFrame.new(baseX + ox, baseY + oy, baseZ + oz)
			if m.ClawsTrackMouse and side ~= "H" then
				local look = Mouse.Hit.Position - cf.Position
				if look.Magnitude > 0.1 then
					cf = CFrame.lookAt(cf.Position, cf.Position + look)
				end
			end
			local hangZ = (side == "H") and 0 or (sideSign * math.rad(90))
			local hangY = (side == "H") and 0 or (sideSign * math.rad(15))
			cf = cf * CFrame.Angles(
				math.rad(tonumber(m.ClawsRotX) or 0) + math.rad(rx),
				math.rad(tonumber(m.ClawsRotY) or 0) + hangY + math.rad(ry),
				math.rad(tonumber(m.ClawsRotZ) or 0) + hangZ + math.rad(rz)
			)
			return cf
		end

		local function spawnClawsBlood(pos, dir)
			if not m.ClawsBloodTrail then return end
			local part = Instance.new("Part")
			part.Name = "HS_ClawBlood"
			part.Size = Vector3.new(0.25, 0.25, 0.25)
			part.Shape = Enum.PartType.Ball
			part.Material = Enum.Material.Neon
			part.Color = Color3.fromRGB(180, 20, 30)
			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.Transparency = 0.15
			part.CFrame = CFrame.new(pos)
			part.Parent = workspace
			table.insert(X.ClawsBlood, part)
			local life, t0 = 0.45, os.clock()
			task.spawn(function()
				while os.clock() - t0 < life and part.Parent do
					local a = (os.clock() - t0) / life
					part.Transparency = 0.15 + a * 0.85
					part.CFrame = part.CFrame + (dir or Vector3.new(0, 1, 0)) * 0.08
					task.wait()
				end
				pcall(function() part:Destroy() end)
			end)
		end

		local function clawsPushNearby(origin, dir, force, up)
			pcall(function()
				for _, plr in ipairs(Players:GetPlayers()) do
					if plr ~= LocalPlayer and plr.Character then
						local root = X.getRoot(plr.Character)
						if root and (root.Position - origin).Magnitude < (m.ClawsComboRange or 8) + 2 then
							local bv = Instance.new("BodyVelocity")
							bv.Name = "HS_ClawPush"
							bv.MaxForce = Vector3.new(1e5, 1e5, 1e5)
							bv.Velocity = dir * (force or 55) + Vector3.new(0, up or 18, 0)
							bv.Parent = root
							Debris:AddItem(bv, 0.25)
						end
					end
				end
			end)
		end

		fireClawsCombo = function()
			if not m.ClawsEnabled then return end
			local now = os.clock()
			if now - X.ClawsLastCombo < (m.ClawsComboCooldown or 0.28) / X.clawsRage() then return end
			if X.ClawsMode == "spin" and now < X.ClawsSpinUntil then return end
			X.ClawsLastCombo = now
			X.ClawsMode = "combo"
			X.ClawsComboStep = (X.ClawsComboStep % 3) + 1
			X.ClawsAnimT = 0
			local followRoot = select(1, X.getFollowRoot())
			if followRoot and m.ClawsSFX then
				X.playSFX(m.ClawsSlashSFXId, m.ClawsVolume or 0.95, followRoot, 0.95 + X.ClawsComboStep * 0.05)
			end
			if followRoot then
				spawnClawsBlood(followRoot.Position + followRoot.CFrame.LookVector * 2, followRoot.CFrame.LookVector + Vector3.new(0, 0.4, 0))
			end
			warn("[HatStand] Claws COMBO step " .. X.ClawsComboStep)
		end

		fireClawsPush = function()
			if not m.ClawsEnabled then return end
			local now = os.clock()
			if now - X.ClawsLastPush < (m.ClawsPushCooldown or 1.1) / X.clawsRage() then return end
			if X.ClawsMode == "spin" and now < X.ClawsSpinUntil then return end
			X.ClawsLastPush = now
			X.ClawsMode = "push"
			X.ClawsAnimT = 0
			local followRoot = select(1, X.getFollowRoot())
			if not followRoot then return end
			if m.ClawsSFX then X.playSFX(m.ClawsPushSFXId, m.ClawsVolume or 0.95, followRoot, 0.9) end
			local dir = followRoot.CFrame.LookVector
			if m.ClawsTrackMouse then
				local to = Mouse.Hit.Position - followRoot.Position
				if to.Magnitude > 0.1 then dir = Vector3.new(to.X, 0, to.Z).Unit end
			end
			clawsPushNearby(followRoot.Position, dir, m.ClawsPushForce, m.ClawsPushUp)
			spawnClawsBlood(followRoot.Position + dir * 3, dir)
			warn("[HatStand] Claws PUSH")
		end

		fireClawsSpin = function()
			if not m.ClawsEnabled then return end
			local now = os.clock()
			if now - X.ClawsLastSpin < (m.ClawsSpinCooldown or 2.4) / X.clawsRage() then return end
			X.ClawsLastSpin = now
			X.ClawsMode = "spin"
			X.ClawsAnimT = 0
			X.ClawsSpinUntil = now + (m.ClawsSpinDuration or 0.85)
			local followRoot = select(1, X.getFollowRoot())
			if followRoot and m.ClawsSFX then
				X.playSFX(m.ClawsSpinSFXId, m.ClawsVolume or 0.95, followRoot, 1.15)
			end
			local hum = X.getLiveHumanoid()
			if hum then
				pcall(function()
					local old = hum.WalkSpeed
					hum.WalkSpeed = math.max(old, old * 1.45)
					task.delay(m.ClawsSpinDuration or 0.85, function()
						if hum and hum.Parent then hum.WalkSpeed = old end
					end)
				end)
			end
			warn("[HatStand] Claws SPIN")
		end


		-- rage multiplier (cooldowns + anim speed)
		X.clawsRage = function()
			if m.ClawsRage then return math.max(tonumber(m.ClawsRageMul) or 1.6, 0.5) end
			return 1
		end
		X.clawsLaserColor = function()
			return Color3.fromRGB(m.ClawsLaserR or 255, m.ClawsLaserG or 60, m.ClawsLaserB or 60)
		end
		X.clawsRayParams = function()
			local ex = {}
			if LocalPlayer.Character then table.insert(ex, LocalPlayer.Character) end
			if StandModel then table.insert(ex, StandModel) end
			pcall(function() table.insert(ex, X.bulletFolder()) end)
			local params = RaycastParams.new()
			params.FilterType = Enum.RaycastFilterType.Exclude
			params.FilterDescendantsInstances = ex
			return params
		end

		-- LASER: charge orb on each claw -> neon beam toward mouse -> bullet hat flies down it and returns
		X.fireClawsLaser = function()
			if not m.ClawsEnabled then return end
			local now = os.clock()
			if now - (X.ClawsLastLaser or 0) < (m.ClawsLaserCooldown or 1.6) / X.clawsRage() then return end
			local followRoot = select(1, X.getFollowRoot())
			if not followRoot then return end
			X.ClawsLastLaser = now
			X.ClawsMode = "push"
			X.ClawsAnimT = 0
			local list = {}
			if m.ClawsLaserDual then
				if X.ClawsLeft and X.ClawsLeft.Handle then table.insert(list, X.ClawsLeft) end
				if X.ClawsRight and X.ClawsRight.Handle then table.insert(list, X.ClawsRight) end
			else
				X.ClawsLaserFlip = not X.ClawsLaserFlip
				local pick = X.ClawsLaserFlip and (X.ClawsLeft or X.ClawsRight) or (X.ClawsRight or X.ClawsLeft)
				if pick and pick.Handle then table.insert(list, pick) end
			end
			if #list == 0 and X.ClawsHead and X.ClawsHead.Handle then table.insert(list, X.ClawsHead) end
			local col = X.clawsLaserColor()
			local charge = math.max(tonumber(m.ClawsLaserCharge) or 0.25, 0)
			if m.ClawsSFX then X.playSFX(m.ClawsSpinSFXId, m.ClawsVolume or 0.95, followRoot, 1.4) end
			task.spawn(function()
				local function originOf(h)
					if h and h.Handle and h.Handle.Parent then return h.Handle.Position end
					return followRoot.Position + Vector3.new(0, 1.5, 0)
				end
				local orbs = {}
				for i = 1, math.max(#list, 1) do
					local p = Instance.new("Part")
					p.Name = "HS_ClawsCharge"
					p.Anchored = true
					p.CanCollide = false
					p.CanQuery = false
					p.CanTouch = false
					p.Material = Enum.Material.Neon
					p.Shape = Enum.PartType.Ball
					p.Color = col
					p.Size = Vector3.new(0.4, 0.4, 0.4)
					p.Parent = workspace
					orbs[i] = p
				end
				local t0 = os.clock()
				while os.clock() - t0 < charge do
					local a = (os.clock() - t0) / math.max(charge, 0.01)
					for i, p in ipairs(orbs) do
						p.Size = Vector3.new(1, 1, 1) * (0.4 + a * 1.6)
						p.CFrame = CFrame.new(originOf(list[i]))
					end
					task.wait()
				end
				for _, p in ipairs(orbs) do pcall(function() p:Destroy() end) end

				local length = tonumber(m.ClawsLaserLength) or 140
				local thick = tonumber(m.ClawsLaserThick) or 1.2
				local params = X.clawsRayParams()
				local aimPoint
				if m.ClawsLaserAim then
					aimPoint = Mouse.Hit.Position
				else
					aimPoint = followRoot.Position + followRoot.CFrame.LookVector * length
				end
				for i = 1, math.max(#list, 1) do
					local origin = originOf(list[i])
					local dir = aimPoint - origin
					if dir.Magnitude < 0.5 then dir = followRoot.CFrame.LookVector end
					dir = dir.Unit
					local hitPos = origin + dir * length
					local result = Workspace:Raycast(origin, dir * length, params)
					if result then hitPos = result.Position end
					local dist = math.max((hitPos - origin).Magnitude, 1)
					local beam = Instance.new("Part")
					beam.Name = "HS_ClawsLaser"
					beam.Anchored = true
					beam.CanCollide = false
					beam.CanQuery = false
					beam.CanTouch = false
					beam.Material = Enum.Material.Neon
					beam.Color = col
					beam.Size = Vector3.new(thick, thick, dist)
					beam.CFrame = CFrame.lookAt(origin, origin + dir) * CFrame.new(0, 0, -dist / 2)
					beam.Parent = workspace
					local boom = Instance.new("Part")
					boom.Name = "HS_ClawsLaserBoom"
					boom.Anchored = true
					boom.CanCollide = false
					boom.CanQuery = false
					boom.CanTouch = false
					boom.Material = Enum.Material.Neon
					boom.Shape = Enum.PartType.Ball
					boom.Color = col
					boom.Size = Vector3.new(1, 1, 1) * thick * 2.5
					boom.CFrame = CFrame.new(hitPos)
					boom.Parent = workspace
					task.spawn(function()
						local t1 = os.clock()
						while beam.Parent and os.clock() - t1 < 0.5 do
							local a = (os.clock() - t1) / 0.5
							beam.Size = Vector3.new(thick * (1 - a * 0.8), thick * (1 - a * 0.8), dist)
							beam.Transparency = a * 0.8
							boom.Size = Vector3.new(1, 1, 1) * thick * (2.5 + a * 3)
							boom.Transparency = a
							task.wait()
						end
						pcall(function() beam:Destroy() end)
						pcall(function() boom:Destroy() end)
					end)
					if i == 1 and m.ClawsLaserUseHat and X.ClawsBullet and X.ClawsBullet.Held
						and X.ClawsBullet.Held.Handle and X.ClawsBullet.Held.Handle.Parent then
						X.ClawsBullet.Fly = { Origin = origin, Dir = dir, Dist = dist, T = 0, Phase = 1, Last = origin }
						if m.ClawsLaserTrail then pcall(function() X.trailEnable(X.ClawsBullet.Held.Handle, true) end) end
					end
				end
			end)
			warn("[HatStand] Claws LASER")
		end

		-- bullet hat: hover behind you, fly down the beam, optional back & forth trail, return
		X.stepClawsBullet = function(dt, followRoot)
			local b = X.ClawsBullet
			local held = b and b.Held
			if not (held and held.Handle and held.Handle.Parent) then return end
			local speed = math.max(tonumber(m.ClawsLaserBulletSpeed) or 220, 20)
			local parkCF = followRoot.CFrame * CFrame.new(0, 3.6, 1.8) * CFrame.Angles(0, os.clock() * 2, 0)
			local cf = parkCF
			local f = b.Fly
			if f then
				if f.Phase == 1 then
					f.T = f.T + dt
					local d = math.min(f.Dist, f.T * speed)
					f.Last = f.Origin + f.Dir * d
					cf = CFrame.lookAt(f.Last, f.Last + f.Dir)
					if d >= f.Dist then
						f.Phase = m.ClawsLaserTrailOsc and 2 or 3
						f.T = 0
					end
				elseif f.Phase == 2 then
					f.T = f.T + dt
					local dist = tonumber(m.ClawsLaserTrailOscDist) or 12
					local spd = tonumber(m.ClawsLaserTrailOscSpeed) or 18
					local osc = 0.5 - 0.5 * math.cos(f.T * spd)
					f.Last = f.Origin + f.Dir * math.max(f.Dist - dist * osc, 0)
					cf = CFrame.lookAt(f.Last, f.Last + f.Dir)
					if f.T >= (tonumber(m.ClawsLaserTrailOscTime) or 1.0) then f.Phase = 3 end
				else
					local to = parkCF.Position - f.Last
					local stepLen = speed * 1.5 * dt
					if to.Magnitude <= stepLen then
						b.Fly = nil
						cf = parkCF
						if m.ClawsLaserTrail then pcall(function() X.trailEnable(held.Handle, false) end) end
					else
						f.Last = f.Last + to.Unit * stepLen
						cf = CFrame.lookAt(f.Last, f.Last + to.Unit)
					end
				end
				if b.Fly and m.ClawsLaserBulletSpin then
					cf = cf * CFrame.Angles(0, 0, os.clock() * 20)
				end
			end
			if held.AP then X.driveHandle(held, cf)
			else pcall(function() held.Handle.CFrame = cf end) end
		end

		-- SLAM: claws rise then smash down, neon shockwave ring on the ground (visual only)
		X.spawnClawsShockwave = function(followRoot)
			local origin = followRoot.Position
			local res = Workspace:Raycast(origin, Vector3.new(0, -12, 0), X.clawsRayParams())
			local pos = res and res.Position or (origin - Vector3.new(0, 3, 0))
			local maxR = tonumber(m.ClawsSlamRadius) or 14
			local ring = Instance.new("Part")
			ring.Name = "HS_ClawsShock"
			ring.Anchored = true
			ring.CanCollide = false
			ring.CanQuery = false
			ring.CanTouch = false
			ring.Material = Enum.Material.Neon
			ring.Color = X.clawsLaserColor()
			ring.Shape = Enum.PartType.Cylinder
			ring.Size = Vector3.new(0.5, 1, 1)
			ring.CFrame = CFrame.new(pos + Vector3.new(0, 0.3, 0)) * CFrame.Angles(0, 0, math.pi / 2)
			ring.Parent = workspace
			task.spawn(function()
				local t0, life = os.clock(), 0.45
				while ring.Parent and os.clock() - t0 < life do
					local a = (os.clock() - t0) / life
					local d = math.max(maxR * 2 * a, 1)
					ring.Size = Vector3.new(0.5 * (1 - a) + 0.1, d, d)
					ring.Transparency = a
					task.wait()
				end
				pcall(function() ring:Destroy() end)
			end)
			spawnClawsBlood(pos + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0))
		end
		X.fireClawsSlam = function()
			if not m.ClawsEnabled then return end
			local now = os.clock()
			if now - (X.ClawsLastSlam or 0) < (m.ClawsSlamCooldown or 2.0) / X.clawsRage() then return end
			if X.ClawsMode == "spin" and now < X.ClawsSpinUntil then return end
			X.ClawsLastSlam = now
			X.ClawsMode = "slam"
			X.ClawsAnimT = 0
			X.ClawsSlamHit = false
			local followRoot = select(1, X.getFollowRoot())
			if followRoot and m.ClawsSFX then X.playSFX(m.ClawsPushSFXId, m.ClawsVolume or 0.95, followRoot, 0.7) end
			warn("[HatStand] Claws SLAM")
		end

		stepClaws = function(dt)
			if not m.ClawsEnabled then return end
			local followRoot = select(1, X.getFollowRoot())
			if not followRoot then return end

			-- locomotion state for claws: idle / walk / run / jump / fall
			do
				local hum = X.getLiveHumanoid()
				local vel = followRoot.AssemblyLinearVelocity or Vector3.zero
				local horiz = Vector3.new(vel.X, 0, vel.Z).Magnitude
				local st = hum and hum:GetState() or nil
				local loco = "idle"
				if st == Enum.HumanoidStateType.Jumping or (vel.Y > 8 and st ~= Enum.HumanoidStateType.Climbing) then
					loco = "jump"
				elseif st == Enum.HumanoidStateType.Freefall or st == Enum.HumanoidStateType.FallingDown then
					loco = (vel.Y < -2) and "fall" or "jump"
				elseif horiz > (m.RunThreshold or 14) then
					loco = "run"
				elseif horiz > 1.5 then
					loco = "walk"
				end
				X.ClawsLoco = loco
				if loco == "walk" then
					X.ClawsLocoT = X.ClawsLocoT + dt * (m.WalkCycleSpeed or 8.5) * (m.AnimSpeed or 1) * X.clawsRage()
				elseif loco == "run" then
					X.ClawsLocoT = X.ClawsLocoT + dt * (m.RunCycleSpeed or 12.5) * (m.AnimSpeed or 1) * X.clawsRage()
				elseif loco == "idle" then
					X.ClawsLocoT = X.ClawsLocoT + dt * 1.5
				else
					X.ClawsLocoT = X.ClawsLocoT + dt * 14
				end
			end
			X.ClawsAnimT = X.ClawsAnimT + dt
			X.ClawsDt = dt
			local now = os.clock()
			if X.ClawsMode == "combo" and X.ClawsAnimT > 0.32 then X.ClawsMode = "idle" end
			if X.ClawsMode == "push" and X.ClawsAnimT > 0.4 then X.ClawsMode = "idle" end
			if X.ClawsMode == "spin" and now >= X.ClawsSpinUntil then X.ClawsMode = "idle" end
			if X.ClawsMode == "slam" then
				if X.ClawsAnimT > 0.6 then
					X.ClawsMode = "idle"
				elseif X.ClawsAnimT >= 0.34 and not X.ClawsSlamHit then
					X.ClawsSlamHit = true
					pcall(X.spawnClawsShockwave, followRoot)
				end
			end
			pcall(X.stepClawsBullet, dt, followRoot)

			local function poseFor(side, held)
				if not held or not held.Handle then return end
				local cf = clawsBaseCF(side, followRoot)
				local t = X.ClawsAnimT
				local sideSign = (side == "L") and -1 or ((side == "R") and 1 or 0)
				local isHead = (side == "H")
				local mode = X.ClawsMode

				if mode == "idle" then
					if m.ClawsIdleBob then
						local bob = math.sin(os.clock() * (m.ClawsBobSpeed or 2.2) + sideSign) * (m.ClawsBobAmt or 0.12)
						cf = cf * CFrame.new(0, bob * (isHead and 0.6 or 1), 0)
					end
				elseif mode == "combo" and not isHead then
					local stepN = X.ClawsComboStep
					local swing = math.sin(math.clamp(t / 0.28, 0, 1) * math.pi)
					if stepN == 1 then
						cf = cf * CFrame.Angles(0, sideSign * math.rad(70) * swing, math.rad(40) * swing) * CFrame.new(0, 0, -1.8 * swing)
					elseif stepN == 2 then
						cf = cf * CFrame.Angles(math.rad(20) * swing, -sideSign * math.rad(80) * swing, -math.rad(30) * swing) * CFrame.new(0, 0.3 * swing, -2.0 * swing)
					else
						cf = cf * CFrame.Angles(-math.rad(90) * swing, sideSign * math.rad(15), 0) * CFrame.new(0, -0.5 * swing, -1.5 * swing)
					end
				elseif mode == "combo" and isHead then
					local swing = math.sin(math.clamp(t / 0.28, 0, 1) * math.pi)
					cf = cf * CFrame.Angles(math.rad(12) * swing, math.rad(18) * swing * (X.ClawsComboStep % 2 == 0 and 1 or -1), 0)
				elseif mode == "push" and not isHead then
					local thrust = math.sin(math.clamp(t / 0.35, 0, 1) * math.pi)
					cf = cf * CFrame.Angles(-math.rad(25) * thrust, 0, sideSign * math.rad(10)) * CFrame.new(0, 0.2 * thrust, -2.8 * thrust)
				elseif mode == "push" and isHead then
					local thrust = math.sin(math.clamp(t / 0.35, 0, 1) * math.pi)
					cf = cf * CFrame.Angles(-math.rad(15) * thrust, 0, 0) * CFrame.new(0, 0, -0.6 * thrust)
				elseif mode == "slam" then
					local up = math.clamp(t / 0.22, 0, 1)
					local down = math.clamp((t - 0.22) / 0.12, 0, 1)
					down = down * (1 - math.clamp((t - 0.4) / 0.2, 0, 1))
					local hold = up * (1 - math.clamp((t - 0.22) / 0.12, 0, 1))
					local v
					if isHead then
						v = Vector3.new(0, -0.8 * down, -0.5 * down)
					else
						v = Vector3.new(sideSign * 0.3 * hold, 2.4 * hold - 2.8 * down, 0.6 * hold - 1.4 * down)
					end
					cf = CFrame.new(followRoot.CFrame:VectorToWorldSpace(v)) * cf
				elseif mode == "spin" then
					local ang = (now - (X.ClawsSpinUntil - (m.ClawsSpinDuration or 0.85))) * (m.ClawsSpinSpeed or 14)
					local rad = m.ClawsSpinRadius or 4.5
					local base = followRoot.CFrame
					if isHead then
						cf = base * CFrame.new(0, 1.5 + math.sin(ang * 2) * 0.15, 0) * CFrame.Angles(0, ang * 0.5, 0)
							* CFrame.Angles(math.rad(tonumber(m.ClawsHeadRotX) or 0), math.rad(tonumber(m.ClawsHeadRotY) or 0), math.rad(tonumber(m.ClawsHeadRotZ) or 0))
					else
						local offset = CFrame.Angles(0, ang + (side == "L" and 0 or math.pi), 0) * CFrame.new(0, 0.5, -rad)
						cf = base * offset * CFrame.Angles(math.rad(20), 0, sideSign * math.rad(90))
					end
				end

				-- locomotion animation (only while not attacking)
				if m.ClawsAnims and mode == "idle" then
					local k = tonumber(m.ClawsAnimStrength) or 1
					local ph = X.ClawsLocoT
					local loco = X.ClawsLoco
					local sgn = isHead and 0 or sideSign
					local tp, tr = Vector3.zero, Vector3.zero -- target pos (root space) / rot (rad, root space)
					if loco == "idle" then
						local br = math.sin(ph * 1.3 + sideSign)
						tp = Vector3.new(sgn * 0.05 * br, 0.04 * br, 0)
						tr = Vector3.new(0.04 * br, 0, sgn * 0.05 * br)
					elseif loco == "walk" then
						local sw = math.sin(ph + (sideSign > 0 and 0 or math.pi))
						if isHead then sw = math.sin(ph * 2) end
						tp = Vector3.new(0, 0.1 * math.abs(math.cos(ph)), isHead and 0 or (-0.9 * sw))
						tr = Vector3.new(isHead and 0.05 * sw or (0.35 * sw), 0, isHead and 0.06 * sw or 0)
					elseif loco == "run" then
						local sw = math.sin(ph + (sideSign > 0 and 0 or math.pi))
						if isHead then sw = math.sin(ph * 2) end
						tp = Vector3.new(sgn * 0.25, 0.18 * math.abs(math.cos(ph)), isHead and -0.25 or (0.55 - 1.5 * sw))
						tr = Vector3.new(isHead and -0.2 or (-0.5 + 0.55 * sw), 0, isHead and 0 or (sgn * 0.15))
					elseif loco == "jump" then
						tp = Vector3.new(sgn * 0.6, isHead and 0.25 or 1.0, isHead and 0 or -0.2)
						tr = Vector3.new(isHead and 0.2 or -0.4, 0, sgn * 0.5)
					else -- fall
						local fl = math.sin(ph * 1.2 + sideSign * 1.7)
						tp = Vector3.new(sgn * 0.9, isHead and 0.35 or (1.4 + 0.12 * fl), isHead and 0 or 0.1)
						tr = Vector3.new(isHead and 0.3 or (-0.2 + 0.15 * fl), 0, sgn * (0.7 + 0.15 * fl))
					end
					tp, tr = tp * k, tr * k
					local o = X.ClawsOff[side]
					if not o then o = { p = Vector3.zero, r = Vector3.zero }; X.ClawsOff[side] = o end
					local a = 1 - math.exp(-(tonumber(m.ClawsAnimBlend) or 12) * (X.ClawsDt or 0.016))
					o.p = o.p:Lerp(tp, a)
					o.r = o.r:Lerp(tr, a)
					local rootCF = followRoot.CFrame
					local localCF = rootCF:Inverse() * cf
					cf = rootCF * CFrame.new(localCF.Position + o.p) * CFrame.Angles(o.r.X, o.r.Y, o.r.Z) * localCF.Rotation
				elseif X.ClawsOff[side] then
					X.ClawsOff[side] = nil
				end

				if held.AP then
					X.driveHandle(held, cf)
				else
					pcall(function() held.Handle.CFrame = cf end)
				end
			end

			poseFor("L", X.ClawsLeft)
			poseFor("R", X.ClawsRight)
			poseFor("H", X.ClawsHead)

			for i = #X.ClawsBlood, 1, -1 do
				if not X.ClawsBlood[i] or not X.ClawsBlood[i].Parent then
					table.remove(X.ClawsBlood, i)
				end
			end
		end
	end

	--------------------------------------------------------------
	-- CAR
	--------------------------------------------------------------
	X.clearCar = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "car" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		CarSlots = {}
		CarWheels = {}
		CarEngine = nil
		CarRootCF = nil
		if CarEngineSound then pcall(function() CarEngineSound:Stop() CarEngineSound:Destroy() end) CarEngineSound = nil end
		m.CarEngineOn = false
		-- restore walkspeed if we boosted
		local hum = X.getLiveHumanoid()
		if hum and hum:GetAttribute("HS_CarBoost") then
			pcall(function()
				hum.WalkSpeed = hum:GetAttribute("HS_OrigWalk") or 16
				hum:SetAttribute("HS_CarBoost", nil)
			end)
		end
	end

	X.rebuildCar = function()
		X.clearCar()
		if not m.CarEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "car" then used[handle] = true end
		end
		local count = 0
		for i = 1, 8 do
			local hat = X.findHatFromLabel(m["CarHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "car") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "Car_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					CarSlots[i] = {
						Handle = part,
						Held = held,
						Off = Vector3.new(
							tonumber(m["CarOffX" .. i]) or 0,
							tonumber(m["CarOffY" .. i]) or 0,
							tonumber(m["CarOffZ" .. i]) or 0
						),
						Rot = CFrame.Angles(
							math.rad(tonumber(m["CarRotX" .. i]) or 0),
							math.rad(tonumber(m["CarRotY" .. i]) or 0),
							math.rad(tonumber(m["CarRotZ" .. i]) or 0)
						),
					}
				end
			end
		end
		-- wheels
		for i = 1, 4 do
			local hat = X.findHatFromLabel(m["CarWheelHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "car") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "CarWheel_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					CarWheels[i] = {
						Handle = part, Held = held,
						Off = Vector3.new(
							tonumber(m["CarWheelOffX" .. i]) or 0,
							tonumber(m["CarWheelOffY" .. i]) or 0,
							tonumber(m["CarWheelOffZ" .. i]) or 0
						),
						Rot = CFrame.Angles(
							math.rad(tonumber(m["CarWheelRotX" .. i]) or 0),
							math.rad(tonumber(m["CarWheelRotY" .. i]) or 0),
							math.rad(tonumber(m["CarWheelRotZ" .. i]) or 90)
						),
						Spin = 0,
					}
				end
			end
		end
		-- engine
		do
			local hat = X.findHatFromLabel(m.CarEngineHat)
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "car") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "CarEngine"))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					CarEngine = {
						Handle = part, Held = held,
						Off = Vector3.new(m.CarEngineOffX or 0, m.CarEngineOffY or 0.4, m.CarEngineOffZ or -1.8),
						Rot = CFrame.Angles(math.rad(m.CarEngineRotX or 0), math.rad(m.CarEngineRotY or 0), math.rad(m.CarEngineRotZ or 0)),
						T = 0,
					}
				end
			end
		end
		warn("[HatStand] Car parts=" .. count .. " wheels=" .. tostring(#CarWheels > 0 and 4 or 0) .. " engine=" .. tostring(CarEngine ~= nil))
	end

	function X.stepCar(dt)
		if not m.CarEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end

		local target
		if m.CarRide then
			-- GTA-style enter: slide in from the side then settle under the rig
			local enterX = 0
			if m.CarEnterAnim and CarEnterT and CarEnterT > 0 then
				CarEnterT = math.max(0, CarEnterT - dt)
				local t = 1 - (CarEnterT / math.max(m.CarEnterTime or 1.1, 0.05))
				-- ease out cubic
				local e = 1 - (1 - t) * (1 - t) * (1 - t)
				enterX = (1 - e) * 4.5
			end
			target = followRoot.CFrame * CFrame.new(enterX, -2.2, 0) * CFrame.Angles(0, math.rad(m.CarRotY or 0), 0)
			-- speed boost
			local hum = X.getLiveHumanoid()
			if hum and not hum:GetAttribute("HS_CarBoost") then
				pcall(function()
					hum:SetAttribute("HS_OrigWalk", hum.WalkSpeed)
					hum.WalkSpeed = (hum.WalkSpeed or 16) * (m.CarSpeedBoost or 1.35)
					hum:SetAttribute("HS_CarBoost", true)
				end)
			end
			-- client engine SFX (start once, then loop with speed pitch)
			if m.CarEngineSFX and not CarEngineSound then
				pcall(function()
					local s = Instance.new("Sound")
					s.Name = "HS_CarEngine"
					s.SoundId = tostring(m.CarEngineLoopSFXId or m.CarEngineStartSFXId or "rbxassetid://13114759")
					s.Volume = m.CarEngineVolume or 0.8
					s.Looped = true
					s.Parent = followRoot
					s:Play()
					CarEngineSound = s
					m.CarEngineOn = true
					-- one-shot start click
					X.playSFX(m.CarEngineStartSFXId or "rbxassetid://13114759", (m.CarEngineVolume or 0.8) * 1.1, followRoot, 1.05)
				end)
			end
			if CarEngineSound then
				local hv = Vector3.new((followRoot.AssemblyLinearVelocity or Vector3.zero).X, 0, (followRoot.AssemblyLinearVelocity or Vector3.zero).Z).Magnitude
				local basePitch = ({0.85, 0.7, 1.05, 0.95})[m.CarEngineType or 1] or 0.85
				pcall(function() CarEngineSound.PlaybackSpeed = basePitch + math.clamp(hv / 55, 0, 1.3) end)
			end
		else
			target = followRoot.CFrame
				* CFrame.new(m.CarSide or 6, m.CarHeight or 0, m.CarForward or 0)
				* CFrame.Angles(0, math.rad(m.CarRotY or 0), 0)
			local hum = X.getLiveHumanoid()
			if hum and hum:GetAttribute("HS_CarBoost") then
				pcall(function()
					hum.WalkSpeed = hum:GetAttribute("HS_OrigWalk") or 16
					hum:SetAttribute("HS_CarBoost", nil)
				end)
			end
			if CarEngineSound then
				pcall(function() CarEngineSound:Stop() CarEngineSound:Destroy() end)
				CarEngineSound = nil
				m.CarEngineOn = false
			end
		end

		if not CarRootCF then
			CarRootCF = target
		else
			local alpha = 1 - math.exp(-(m.CarSmooth or 12) * dt)
			CarRootCF = CarRootCF:Lerp(target, alpha)
		end

		for _, slot in pairs(CarSlots) do
			if slot.Handle and slot.Handle.Parent then
				local cf = CarRootCF * CFrame.new(slot.Off) * slot.Rot
				if slot.Held then
					X.driveHandle(slot.Held, cf)
				else
					pcall(function() slot.Handle.CFrame = cf end)
				end
			end
		end
		-- wheels spin while moving / riding
		local spd = 0
		if followRoot then
			local v = followRoot.AssemblyLinearVelocity or Vector3.zero
			spd = Vector3.new(v.X, 0, v.Z).Magnitude
		end
		for _, w in pairs(CarWheels) do
			if w.Handle and w.Handle.Parent then
				if m.CarWheelSpin then
					w.Spin = (w.Spin or 0) + dt * (m.CarWheelSpinSpd or 12) * (0.3 + math.clamp(spd / 20, 0, 2))
				end
				local cf = CarRootCF * CFrame.new(w.Off) * w.Rot * CFrame.Angles(w.Spin or 0, 0, 0)
				if w.Held then X.driveHandle(w.Held, cf)
				else pcall(function() w.Handle.CFrame = cf end) end
			end
		end
		-- engine bob
		if CarEngine and CarEngine.Handle and CarEngine.Handle.Parent then
			CarEngine.T = (CarEngine.T or 0) + dt
			local bob = 0
			if m.CarEngineBob then
				bob = math.sin(CarEngine.T * (m.CarEngineBobSpd or 18)) * (m.CarEngineBobAmt or 0.08)
			end
			local cf = CarRootCF * CFrame.new(CarEngine.Off + Vector3.new(0, bob, 0)) * CarEngine.Rot
			if CarEngine.Held then X.driveHandle(CarEngine.Held, cf)
			else pcall(function() CarEngine.Handle.CFrame = cf end) end
		end
	end


	--------------------------------------------------------------
	-- TITAN: limbs + core fire burst (heli-style attach / driveHandle)
	--------------------------------------------------------------
	X.TitanSlots = X.TitanSlots or {}
	X.TitanRootCF = nil
	X.TitanLocoT = 0
	X.TitanMode = "idle"
	X.TitanCoreBurst = nil -- { t, phase, dir, start, end }

	X.clearTitan = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "titan" and held.Kind ~= "titanfire" and held.Kind ~= "titantrail" then
				keep[handle] = true
			end
		end
		X.releaseHeld(keep)
		X.TitanSlots = {}
		X.TitanRootCF = nil
		X.TitanCoreBurst = nil
		X.TitanFireSlot = nil
		X.TitanTrailSlot = nil
		X.TitanCount = 0
	end

	X.titanLayout = function()
		local scale = tonumber(m.TitanScale) or 3.5
		return {
			Torso = Vector3.new(0, 0, 0),
			Head = Vector3.new(0, 1.5 * scale, 0),
			LeftArm = Vector3.new(-1.2 * scale, 0.25 * scale, 0),
			RightArm = Vector3.new(1.2 * scale, 0.25 * scale, 0),
			LeftLeg = Vector3.new(-0.45 * scale, -1.85 * scale, 0),
			RightLeg = Vector3.new(0.45 * scale, -1.85 * scale, 0),
			Core = Vector3.new(0, 1.0 * scale * 0.35, -0.35), -- base; user Off/Rot applied live
			Jetpack = Vector3.new(0, 0.4, 1.4),
			Shield = Vector3.new(0, 1, -2.5),
		}, scale
	end

	X.titanLiveOffRot = function(limb)
		-- live place (side / up / forward) + rot for core / limbs / jetpack / shield
		local off, rot = Vector3.zero, CFrame.new()
		if limb == "Core" then
			off = Vector3.new(tonumber(m.TitanCoreOffX) or 0, tonumber(m.TitanCoreOffY) or 1.0, tonumber(m.TitanCoreOffZ) or -0.35)
			rot = CFrame.Angles(math.rad(tonumber(m.TitanCoreRotX) or 0), math.rad(tonumber(m.TitanCoreRotY) or 0), math.rad(tonumber(m.TitanCoreRotZ) or 0))
		elseif limb == "Jetpack" then
			off = Vector3.new(tonumber(m.TitanJetpackOffX) or 0, tonumber(m.TitanJetpackOffY) or 0.4, tonumber(m.TitanJetpackOffZ) or 1.4)
			rot = CFrame.Angles(math.rad(tonumber(m.TitanJetpackRotX) or 0), math.rad(tonumber(m.TitanJetpackRotY) or 0), math.rad(tonumber(m.TitanJetpackRotZ) or 0))
		elseif limb == "Shield" then
			off = Vector3.new(tonumber(m.TitanShieldOffX) or 0, tonumber(m.TitanShieldOffY) or 1, tonumber(m.TitanShieldOffZ) or -2.5)
		elseif m["TitanOff" .. limb .. "X"] ~= nil then
			off = Vector3.new(tonumber(m["TitanOff" .. limb .. "X"]) or 0, tonumber(m["TitanOff" .. limb .. "Y"]) or 0, tonumber(m["TitanOff" .. limb .. "Z"]) or 0)
			rot = CFrame.Angles(
				math.rad(tonumber(m["TitanRot" .. limb .. "X"]) or 0),
				math.rad(tonumber(m["TitanRot" .. limb .. "Y"]) or 0),
				math.rad(tonumber(m["TitanRot" .. limb .. "Z"]) or 0)
			)
		end
		return off, rot
	end

	X.rebuildTitan = function()
		X.clearTitan()
		if not m.TitanEnabled then
			warn("[HatStand] Titan rebuild skipped (disabled)")
			return
		end
		if not m.Enabled then
			warn("[HatStand] Titan rebuild: enable Hat Stand first")
			return
		end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "titan" and held.Kind ~= "titanfire" and held.Kind ~= "titantrail" then
				used[handle] = true
			end
		end
		local layout = X.titanLayout()
		local function grab(label, limb, kind)
			kind = kind or "titan"
			label = tostring(label or "")
			if X.cleanLabel then label = X.cleanLabel(label) end
			if label == "" or label == "(none)" then return nil end
			local hat = X.findHatFromLabel(label, used)
			if not (hat and hat.Handle and hat.Handle.Parent) then
				warn("[HatStand] Titan: no hat for " .. tostring(limb) .. " = " .. label)
				return nil
			end
			if used[hat.Handle] then
				warn("[HatStand] Titan: already used " .. label)
				return nil
			end
			local held = X.attachFE(hat, kind)
			if not held then
				warn("[HatStand] Titan: attachFE failed " .. label)
				return nil
			end
			held.Kind = kind
			used[hat.Handle] = true
			local base = layout[limb] or Vector3.zero
			-- base layout only; user Off/Rot re-read every frame in stepTitan
			return {
				Handle = hat.Handle,
				Held = held,
				Limb = limb,
				Base = base,
				Off = base,
				Rot = CFrame.new(),
				Name = hat.Name,
			}
		end
		local n = 0
		for _, pair in ipairs({
			{ "TitanHatTorso", "Torso" },
			{ "TitanHatHead", "Head" },
			{ "TitanHatLeftArm", "LeftArm" },
			{ "TitanHatRightArm", "RightArm" },
			{ "TitanHatLeftLeg", "LeftLeg" },
			{ "TitanHatRightLeg", "RightLeg" },
			{ "TitanHatCore", "Core" },
			{ "TitanHatJetpack", "Jetpack" },
		}) do
			local s = grab(m[pair[1]], pair[2], "titan")
			if s then X.TitanSlots[pair[2]] = s; n = n + 1 end
		end
		if m.TitanShieldEnabled then
			local s = grab(m.TitanShieldHat, "Shield", "titan")
			if s then X.TitanSlots.Shield = s; n = n + 1 end
		end
		do
			local s = grab(m.TitanCoreFireHat, "Fire", "titanfire")
			if s then X.TitanFireSlot = s; n = n + 1 end
		end
		do
			local s = grab(m.TitanCoreTrailHat, "Trail", "titantrail")
			if s then X.TitanTrailSlot = s; n = n + 1 end
		end
		X.TitanLastBuild = os.clock()
		X.TitanCount = n
		warn("[HatStand] Titan rebuilt: " .. tostring(n) .. " pieces (scale=" .. tostring(m.TitanScale) .. ")")
	end

	X.titanDetectMode = function()
		if m.TitanFly then return "fly" end
		local fr = X.getFollowRoot()
		local hum = X.getLiveHumanoid()
		if not fr then return "idle" end
		local vel = fr.AssemblyLinearVelocity or Vector3.zero
		local horiz = Vector3.new(vel.X, 0, vel.Z).Magnitude
		local state = hum and hum:GetState() or nil
		-- jump / fall first so air motion is not treated as walk
		if state == Enum.HumanoidStateType.Jumping or (vel.Y > 6 and state ~= Enum.HumanoidStateType.Climbing) then
			return "jump"
		end
		if state == Enum.HumanoidStateType.Freefall or (vel.Y < -4 and horiz < 2) then
			return "fall"
		end
		if state == Enum.HumanoidStateType.Climbing then
			return "climb"
		end
		if horiz > (m.RunThreshold or 14) then return "run" end
		if horiz > 1.2 then return "walk" end
		return "idle"
	end

	-- Dedicated Titan loco (scaled, clear limb swing) — does not depend on stand JoJo helpers
	X.titanAnimOffsets = function(mode, t)
		local o = {
			Head = CFrame.new(), Torso = CFrame.new(), LeftArm = CFrame.new(), RightArm = CFrame.new(),
			LeftLeg = CFrame.new(), RightLeg = CFrame.new(), Core = CFrame.new(), Jetpack = CFrame.new(), Shield = CFrame.new(),
		}
		if m.TitanAnim == false then return o end
		local scale = math.clamp((tonumber(m.TitanScale) or 3.5) / 3.5, 0.6, 2.2)
		local spd = tonumber(m.TitanAnimSpeed) or 1
		t = t * spd

		if mode == "walk" then
			local cycle = t * (m.WalkCycleSpeed or 8.5)
			local sw, sw2 = math.sin(cycle), math.sin(cycle + math.pi)
			local s = 1.15 * scale
			o.LeftLeg = CFrame.Angles(-math.rad(32) * sw * s, 0, math.rad(5) * s)
				* CFrame.new(0, math.max(0, -sw) * 0.18 * s, -0.22 * sw * s)
			o.RightLeg = CFrame.Angles(-math.rad(32) * sw2 * s, 0, -math.rad(5) * s)
				* CFrame.new(0, math.max(0, -sw2) * 0.18 * s, -0.22 * sw2 * s)
			o.LeftArm = CFrame.Angles(-math.rad(40) * sw2 * s, 0, math.rad(22) * s)
				* CFrame.new(0.06 * s, 0, -0.12 * sw2 * s)
			o.RightArm = CFrame.Angles(-math.rad(40) * sw * s, 0, -math.rad(22) * s)
				* CFrame.new(-0.06 * s, 0, -0.12 * sw * s)
			o.Torso = CFrame.Angles(math.rad(7) * s, math.rad(10) * sw * s, 0)
				* CFrame.new(0, math.abs(sw) * 0.06 * s, 0)
			o.Head = CFrame.Angles(math.rad(5) * s, -math.rad(8) * sw * s, 0)
			o.Core = CFrame.new(0, math.abs(sw) * 0.05 * s, 0)
		elseif mode == "run" then
			local cycle = t * (m.RunCycleSpeed or 12.5)
			local sw, sw2 = math.sin(cycle), math.sin(cycle + math.pi)
			local s = 1.35 * scale
			o.LeftLeg = CFrame.Angles(-math.rad(58) * sw * s, 0, math.rad(10) * s)
				* CFrame.new(0, math.max(0, -sw) * 0.28 * s, -0.4 * sw * s)
			o.RightLeg = CFrame.Angles(-math.rad(58) * sw2 * s, 0, -math.rad(10) * s)
				* CFrame.new(0, math.max(0, -sw2) * 0.28 * s, -0.4 * sw2 * s)
			o.LeftArm = CFrame.Angles(-math.rad(75) * sw2 * s, math.rad(12) * s, math.rad(28) * s)
				* CFrame.new(0.12 * s, 0.12 * s, -0.45 * sw2 * s)
			o.RightArm = CFrame.Angles(-math.rad(75) * sw * s, -math.rad(12) * s, -math.rad(28) * s)
				* CFrame.new(-0.12 * s, 0.12 * s, -0.45 * sw * s)
			o.Torso = CFrame.Angles(math.rad(20) * s, math.rad(14) * sw * s, 0)
				* CFrame.new(0, math.abs(sw) * 0.1 * s, 0)
			o.Head = CFrame.Angles(math.rad(14) * s, -math.rad(10) * sw * s, 0)
			o.Core = CFrame.new(0, math.abs(sw) * 0.08 * s, 0)
		elseif mode == "jump" then
			local s = 1.2 * scale
			o.LeftArm = CFrame.Angles(-math.rad(35) * s, 0, math.rad(55) * s) * CFrame.new(0.18 * s, 0.35 * s, -0.12 * s)
			o.RightArm = CFrame.Angles(-math.rad(35) * s, 0, -math.rad(55) * s) * CFrame.new(-0.18 * s, 0.35 * s, -0.12 * s)
			o.LeftLeg = CFrame.Angles(math.rad(28) * s, 0, math.rad(12) * s) * CFrame.new(0, 0.22 * s, 0.18 * s)
			o.RightLeg = CFrame.Angles(math.rad(18) * s, 0, -math.rad(12) * s) * CFrame.new(0, 0.18 * s, 0.12 * s)
			o.Torso = CFrame.Angles(-math.rad(10) * s, 0, 0) * CFrame.new(0, 0.2 * s, 0)
			o.Head = CFrame.Angles(math.rad(12) * s, 0, 0)
			o.Core = CFrame.new(0, 0.12 * s, 0)
		elseif mode == "fall" then
			local s = 1.15 * scale
			local wob = math.sin(t * 6) * 0.15
			o.LeftArm = CFrame.Angles(math.rad(20) * s, 0, math.rad(70) * s) * CFrame.new(0.2 * s, 0.1 * s, 0)
			o.RightArm = CFrame.Angles(math.rad(20) * s, 0, -math.rad(70) * s) * CFrame.new(-0.2 * s, 0.1 * s, 0)
			o.LeftLeg = CFrame.Angles(math.rad(15) * s + wob, 0, math.rad(8) * s)
			o.RightLeg = CFrame.Angles(math.rad(25) * s - wob, 0, -math.rad(8) * s)
			o.Torso = CFrame.Angles(math.rad(12) * s, 0, 0)
			o.Head = CFrame.Angles(-math.rad(8) * s, 0, 0)
		elseif mode == "climb" then
			local cycle = t * 9
			local sw, sw2 = math.sin(cycle), math.sin(cycle + math.pi)
			local s = 1.1 * scale
			o.LeftArm = CFrame.Angles(-math.rad(90) + math.rad(40) * sw * s, 0, math.rad(20) * s)
			o.RightArm = CFrame.Angles(-math.rad(90) + math.rad(40) * sw2 * s, 0, -math.rad(20) * s)
			o.LeftLeg = CFrame.Angles(math.rad(40) * sw2 * s, 0, 0)
			o.RightLeg = CFrame.Angles(math.rad(40) * sw * s, 0, 0)
			o.Torso = CFrame.Angles(math.rad(-5) * s, 0, 0)
		elseif mode == "fly" then
			local s = scale
			local bob = math.sin(t * 10) * 0.1 * s
			o.LeftArm = CFrame.Angles(math.rad(-30) * s, 0, math.rad(-45) * s)
			o.RightArm = CFrame.Angles(math.rad(-30) * s, 0, math.rad(45) * s)
			o.LeftLeg = CFrame.Angles(math.rad(25) * s, 0, math.rad(8) * s)
			o.RightLeg = CFrame.Angles(math.rad(25) * s, 0, -math.rad(8) * s)
			o.Torso = CFrame.Angles(math.rad(-22) * s, 0, 0) * CFrame.new(0, bob, 0)
			o.Head = CFrame.Angles(math.rad(8) * s, 0, 0)
			o.Jetpack = CFrame.new(0, math.sin(t * 16) * 0.12 * s, 0)
			o.Core = CFrame.new(0, bob * 0.6, 0)
		else -- idle
			local bob = math.sin(t * 2.2) * 0.12 * scale
			local breath = math.sin(t * 1.4)
			o.Torso = CFrame.new(0, bob, 0) * CFrame.Angles(math.rad(2) * breath, 0, 0)
			o.Head = CFrame.Angles(math.rad(math.sin(t * 1.3) * 5), math.rad(math.sin(t * 0.7) * 4), 0)
			o.LeftArm = CFrame.Angles(math.rad(math.sin(t * 1.1) * 4), 0, math.rad(-8 + math.sin(t) * 4) * scale)
			o.RightArm = CFrame.Angles(math.rad(math.sin(t * 1.1 + 1) * 4), 0, math.rad(8 + math.sin(t + 1) * 4) * scale)
			o.LeftLeg = CFrame.Angles(0, 0, math.rad(3))
			o.RightLeg = CFrame.Angles(0, 0, math.rad(-3))
			o.Core = CFrame.new(0, math.sin(t * 3.2) * 0.07 * scale, 0)
			o.Jetpack = CFrame.new(0, math.sin(t * 2.5) * 0.04, 0)
		end
		return o
	end

	X.titanCoreFire = function()
		if not m.TitanEnabled or not m.TitanCoreFireEnabled then return end
		if not X.TitanRootCF then return end
		X.TitanLastCoreFire = X.TitanLastCoreFire or 0
		if os.clock() - X.TitanLastCoreFire < (m.TitanCoreFireCooldown or 0.45) then return end
		X.TitanLastCoreFire = os.clock()
		local root = X.TitanRootCF
		local core = X.TitanSlots.Core
		local origin = root.Position
		if core then
			local liveOff = select(1, X.titanLiveOffRot("Core"))
			local base = core.Base or core.Off or Vector3.zero
			origin = (root * CFrame.new(base + liveOff)).Position
		end
		local dir = root.LookVector
		pcall(function()
			local cam = workspace.CurrentCamera
			if cam and Mouse then
				local unit = cam:ScreenPointToRay(Mouse.X, Mouse.Y)
				dir = unit.Direction
			end
		end)
		local dist = m.TitanCoreFireDist or 40
		X.TitanCoreBurst = {
			phase = "out",
			t = 0,
			origin = origin,
			dir = dir.Unit,
			dist = dist,
			outSpeed = m.TitanCoreFireSpeed or 180,
			backSpeed = m.TitanCoreFireReturn or 220,
			pos = origin,
		}
		warn("[HatStand] Titan CORE FIRE")
	end

	X.stepTitan = function(dt)
		if not m.TitanEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local now = os.clock()
		X.TitanLastBuild = X.TitanLastBuild or 0
		X.TitanCount = X.TitanCount or 0

		-- FAST auto-rebuild: rate-limited like Hellcopter
		if m.TitanAutoRebuild ~= false then
			local delay = math.max(tonumber(m.TitanRebuildDelay) or 0.08, 0.02)
			if X.TitanCount == 0 then delay = math.max(delay, 0.35) end
			if (now - X.TitanLastBuild) > delay then
				local need = false
				local anyCfg = (m.TitanHatHead or "") ~= "" or (m.TitanHatTorso or "") ~= "" or (m.TitanHatCore or "") ~= ""
					or (m.TitanHatLeftArm or "") ~= "" or (m.TitanHatRightArm or "") ~= ""
					or (m.TitanHatLeftLeg or "") ~= "" or (m.TitanHatRightLeg or "") ~= ""
					or (m.TitanHatJetpack or "") ~= "" or (m.TitanCoreFireHat or "") ~= ""
				if X.TitanCount == 0 then
					need = anyCfg
				else
					for _, s in pairs(X.TitanSlots or {}) do
						if not (s and s.Handle and s.Handle.Parent) then need = true break end
					end
					if not need and X.TitanFireSlot and not (X.TitanFireSlot.Handle and X.TitanFireSlot.Handle.Parent) then need = true end
					if not need and X.TitanTrailSlot and not (X.TitanTrailSlot.Handle and X.TitanTrailSlot.Handle.Parent) then need = true end
				end
				X.TitanLastBuild = now
				if need then X.rebuildTitan() end
			end
		end

		local mode = X.titanDetectMode()
		X.TitanMode = mode
		X.TitanLocoT = (X.TitanLocoT or 0) + dt * (m.TitanAnimSpeed or 1)
		local offsets = X.titanAnimOffsets(mode, X.TitanLocoT)

		if mode == "fly" then
			pcall(function()
				local look = followRoot.CFrame.LookVector
				local right = followRoot.CFrame.RightVector
				local up = 0
				local fwd, side = 0, 0
				if not UserInputService:GetFocusedTextBox() then
					if UserInputService:IsKeyDown(Enum.KeyCode.W) then fwd = fwd + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.S) then fwd = fwd - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.D) then side = side + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.A) then side = side - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.Space) then up = 40 end
					if UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) or UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) then up = -30 end
				end
				local spd = m.TitanFlySpeed or 70
				local wish = look * (fwd * spd) + right * (side * spd) + Vector3.new(0, up, 0)
				if fwd == 0 and side == 0 and up == 0 then
					wish = look * spd * 0.35 -- gentle forward cruise when no keys
				end
				followRoot.AssemblyLinearVelocity = followRoot.AssemblyLinearVelocity:Lerp(wish, math.clamp(dt * 5, 0, 1))
			end)
		end

		local target = followRoot.CFrame
			* CFrame.new(m.TitanSide or 0, m.TitanHeight or 0, m.TitanForward or 0)
			* CFrame.Angles(math.rad(m.TitanRotX or 0), math.rad(m.TitanRotY or 0), math.rad(m.TitanRotZ or 0))
		if not X.TitanRootCF then X.TitanRootCF = target
		else X.TitanRootCF = X.TitanRootCF:Lerp(target, 1 - math.exp(-(m.TitanSmooth or 22) * dt)) end

		-- body limbs: base layout + LIVE user place/rot + anim
		for limb, s in pairs(X.TitanSlots) do
			if s and s.Handle and s.Handle.Parent then
				local L = s.Limb or limb
				local liveOff, liveRot = X.titanLiveOffRot(L)
				local base = s.Base or Vector3.zero
				-- Core / Jetpack / Shield: layout base is neutral; user offs are absolute extras on top of style base
				local useOff
				if L == "Core" or L == "Jetpack" or L == "Shield" then
					useOff = liveOff -- full user control for core/jetpack/shield position
				else
					useOff = base + liveOff
				end
				s.Off = useOff
				s.Rot = liveRot
				local anim = offsets[L] or offsets[limb] or CFrame.new()
				local cf = X.TitanRootCF * CFrame.new(useOff) * liveRot * anim
				if s.Held then X.driveHandle(s.Held, cf)
				else pcall(function() s.Handle.CFrame = cf end) end
			end
		end

		-- CORE FIRE burst
		local coreCF = X.TitanRootCF
		if X.TitanSlots.Core then
			coreCF = X.TitanRootCF * CFrame.new(X.TitanSlots.Core.Off) * (X.TitanSlots.Core.Rot or CFrame.new())
		end
		local burst = X.TitanCoreBurst
		if burst then
			burst.t = burst.t + dt
			if burst.phase == "out" then
				local step = (burst.outSpeed or 180) * dt
				burst.pos = burst.pos + burst.dir * step
				local traveled = (burst.pos - burst.origin).Magnitude
				if traveled >= (burst.dist or 40) then
					burst.phase = "back"
					burst.pos = burst.origin + burst.dir * (burst.dist or 40)
				end
			elseif burst.phase == "back" then
				local toCore = coreCF.Position - burst.pos
				local dist = toCore.Magnitude
				local step = (burst.backSpeed or 220) * dt
				if dist <= step or dist < 0.5 then
					burst.pos = coreCF.Position
					X.TitanCoreBurst = nil
					burst = nil
				else
					burst.pos = burst.pos + toCore.Unit * step
				end
			end
		end
		local firePos = burst and burst.pos or coreCF.Position
		local fireLook = burst and burst.dir or coreCF.LookVector
		if X.TitanFireSlot and X.TitanFireSlot.Handle and X.TitanFireSlot.Handle.Parent then
			local cf = CFrame.new(firePos, firePos + fireLook)
			if X.TitanFireSlot.Held then X.driveHandle(X.TitanFireSlot.Held, cf)
			else pcall(function() X.TitanFireSlot.Handle.CFrame = cf end) end
		end
		if X.TitanTrailSlot and X.TitanTrailSlot.Handle and X.TitanTrailSlot.Handle.Parent then
			local trailPos = firePos
			if burst then
				trailPos = firePos - fireLook * 2.5
			else
				trailPos = coreCF.Position - coreCF.LookVector * 0.5
			end
			local cf = CFrame.new(trailPos, trailPos + fireLook)
			if X.TitanTrailSlot.Held then X.driveHandle(X.TitanTrailSlot.Held, cf)
			else pcall(function() X.TitanTrailSlot.Handle.CFrame = cf end) end
		end
	end

	X.toggleTitanFly = function()
		m.TitanFly = not m.TitanFly
		warn("[HatStand] Titan FLY " .. (m.TitanFly and "ON" or "OFF"))
	end

	--------------------------------------------------------------
	-- BALL SYSTEM (10 slots)
	--------------------------------------------------------------
	X.clearBall = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "ball" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		BallSlots = {}
		BallFlying = {}
	end

	X.rebuildBall = function()
		X.clearBall()
		if not m.BallEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "ball" then used[handle] = true end
		end
		local count = 0
		for i = 1, 10 do
			local hat = X.findHatFromLabel(m["BallHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "ball") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "Ball_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					BallSlots[i] = {
						Handle = part, Held = held, Index = i, Name = hat.Name,
						Off = Vector3.new(
							tonumber(m["BallOffX" .. i]) or 0,
							tonumber(m["BallOffY" .. i]) or 0,
							tonumber(m["BallOffZ" .. i]) or 0
						),
						Rot = CFrame.Angles(
							math.rad(tonumber(m["BallRotX" .. i]) or 0),
							math.rad(tonumber(m["BallRotY" .. i]) or 0),
							math.rad(tonumber(m["BallRotZ" .. i]) or 0)
						),
						Kind = tonumber(m["BallKind" .. i]) or 1,
						Flying = false,
					}
				end
			end
		end
		warn("[HatStand] Balls=" .. count)
	end

	X.ballBase = function(slot, rootCF)
		local s = BallSlots[slot]
		if not s then return rootCF end
		return rootCF * CFrame.new(
			(m.BallFloatSide or 2.2) + s.Off.X,
			(m.BallFloatHeight or 1) + s.Off.Y,
			(m.BallFloatForward or -0.5) + s.Off.Z
		) * s.Rot
	end

	X.yeetBall = function(slot)
		slot = slot or m.BallActiveSlot or 1
		local s = BallSlots[slot]
		if not s or not s.Handle or s.Flying then return end
		local fr = X.getFollowRoot()
		if not fr then return end
		local dir
		if m.BallTrackMouse and Mouse and Mouse.Hit then
			dir = (Mouse.Hit.Position - s.Handle.Position)
			if dir.Magnitude > 0.1 then dir = dir.Unit else dir = fr.CFrame.LookVector end
		else
			dir = fr.CFrame.LookVector
		end
		local vel = dir * (m.BallYeetForce or 90) + Vector3.new(0, m.BallYeetUp or 35, 0)
		s.Flying = true
		table.insert(BallFlying, {
			Slot = slot, Entry = s, Pos = s.Handle.Position, Vel = vel,
			T = 0, Life = m.BallLife or 4, Spin = 0,
		})
		BallLastYeet = os.clock()
		warn("[HatStand] Ball yeet slot " .. tostring(slot))
	end

	function X.stepBall(dt)
		if not m.BallEnabled then return end
		local fr = X.getFollowRoot()
		if not fr then return end
		local rootCF = fr.CFrame
		-- float non-flying balls
		for i, s in pairs(BallSlots) do
			if s.Handle and s.Handle.Parent and not s.Flying then
				local cf = X.ballBase(i, rootCF)
				if m.BallTrackMouse and Mouse and Mouse.Hit then
					local to = Mouse.Hit.Position - cf.Position
					if to.Magnitude > 0.5 then
						local look = CFrame.lookAt(cf.Position, cf.Position + to.Unit)
						cf = look:Lerp(cf, 1 - math.clamp(m.BallTrackStrength or 1, 0, 1) * 0.85)
						cf = CFrame.new(cf.Position) * (look - look.Position) * s.Rot
					end
				end
				if m.BallSpin then
					s.SpinT = (s.SpinT or 0) + dt * (m.BallSpinSpd or 8)
					cf = cf * CFrame.Angles(s.SpinT, s.SpinT * 0.7, 0)
				end
				if s.Held then X.driveHandle(s.Held, cf)
				else pcall(function() s.Handle.CFrame = cf end) end
			end
		end
		-- flying balls
		for i = #BallFlying, 1, -1 do
			local b = BallFlying[i]
			local s = b.Entry
			if not s or not s.Handle or not s.Handle.Parent then
				if s then s.Flying = false end
				table.remove(BallFlying, i)
			else
				b.T = b.T + dt
				local vel = b.Vel + Vector3.new(0, -(m.BallGravity or 40) * dt, 0)
				if (s.Kind == 3 or (tonumber(m["BallKind" .. b.Slot]) or 1) == 3) and m.BallTrackMouse and Mouse then
					local to = Mouse.Hit.Position - b.Pos
					if to.Magnitude > 1 then
						vel = vel:Lerp(to.Unit * vel.Magnitude, math.clamp(dt * 3, 0, 1))
					end
				end
				b.Vel = vel
				b.Pos = b.Pos + vel * dt
				-- ground bounce
				if b.Pos.Y < (fr.Position.Y - 2) and vel.Y < 0 then
					b.Pos = Vector3.new(b.Pos.X, fr.Position.Y - 2, b.Pos.Z)
					b.Vel = Vector3.new(vel.X * 0.85, -vel.Y * (m.BallBounce or 0.55), vel.Z * 0.85)
				end
				b.Spin = (b.Spin or 0) + dt * (m.BallSpinSpd or 8) * 2
				local cf = CFrame.new(b.Pos) * CFrame.Angles(b.Spin, b.Spin * 0.5, 0)
				if s.Held then X.driveHandle(s.Held, cf)
				else pcall(function() s.Handle.CFrame = cf end) end
				if b.T >= (b.Life or 4) then
					if m.BallReturn then
						-- return home
						local home = X.ballBase(b.Slot, rootCF)
						local to = home.Position - b.Pos
						if to.Magnitude < 1.5 then
							s.Flying = false
							table.remove(BallFlying, i)
						else
							b.Vel = to.Unit * (m.BallReturnSpeed or 100)
							b.Life = b.T + 2
						end
					else
						s.Flying = false
						table.remove(BallFlying, i)
					end
				end
			end
		end
	end

	--------------------------------------------------------------
	-- STAND FOLLOW
	--------------------------------------------------------------
	function X.desiredStandCF(followRoot, dt)
		local base = followRoot.CFrame
		if m.WalkWithMe then
			local cf = base * CFrame.new(m.WalkSideOffset or 2.8, m.WalkHeightOffset or 0, m.WalkForwardOffset or 0.5)
			if m.FaceSameWay then return cf end
			return CFrame.lookAt(cf.Position, base.Position)
		end
		local method = m.MethodIndex
		if method == 5 then
			return StandRoot and StandRoot.CFrame or base * CFrame.new(m.SideOffset, m.HeightOffset, m.ForwardOffset)
		end
		if method == 3 or m.OrbitStand then
			OrbitAngle = OrbitAngle + m.OrbitSpeed * dt
			local pos = base.Position + Vector3.new(
				math.cos(OrbitAngle) * m.OrbitRadius, m.HeightOffset, math.sin(OrbitAngle) * m.OrbitRadius
			)
			if m.FaceSameWay then return CFrame.new(pos) * (base - base.Position) end
			return CFrame.lookAt(pos, base.Position)
		end
		if method == 2 then
			local cf = base * CFrame.new(0, m.HeightOffset, -(math.abs(m.SideOffset) + 2))
			if m.FaceSameWay then return cf end
			return CFrame.lookAt(cf.Position, base.Position)
		end
		if method == 4 then
			local cf = base * CFrame.new(-m.SideOffset, m.HeightOffset, m.ForwardOffset)
			if m.FaceSameWay then
				return CFrame.new(cf.Position) * CFrame.Angles(0, math.pi, 0) * (base - base.Position)
			end
			return cf
		end
		local cf = base * CFrame.new(m.SideOffset, m.HeightOffset, m.ForwardOffset)
		if m.FaceSameWay then return cf end
		return CFrame.lookAt(cf.Position, base.Position)
	end

	X.applyStandCF = function(rootCF, dt)
		if not StandRoot then return end
		StandRoot.CFrame = rootCF
		local extras = X.resolve(dt or 1 / 60)
		X.Extras = extras
		X.ExtrasFrame = X.Frame
		for limb, data in pairs(Limbs) do
			local part = data.Part
			if part and part.Parent then
				data.BaseOffset = X.makeBaseOffset(limb)
				local cf = rootCF * X.applyRootExtra(data.BaseOffset, extras[limb] or CFrame.new())
				if data.Held then X.driveHandle(data.Held, cf)
				else pcall(function() part.CFrame = cf end) end
			end
		end
		-- Keep limb-layout preview markers locked to current offsets
		if m.ShowLimbPreview then
			for limb, p in pairs(LimbPreviewParts) do
				if p and p.Parent then
					pcall(function() p.CFrame = rootCF * X.makeBaseOffset(limb) end)
				end
			end
		end
	end

	function X.stepStand(dt)
		if not X.modeAllowsStand() or not m.Enabled then return end
		X.updateLocoMode(dt)
		X.updateAir(dt)
		local now = os.clock()
		local canRebuild = (now - LastBuild) > 0.5
		if NeedRebuild and canRebuild then
			NeedRebuild = false
			if m.AutoBuild then pcall(X.buildStand) end
		end
		if not StandRoot or not StandModel or not StandModel.Parent then
			if m.AutoBuild and canRebuild then pcall(X.buildStand) end
			if not StandRoot then return end
		end
		local missing, total = 0, 0
		for _, data in pairs(Limbs) do
			total = total + 1
			if not data.Part or not data.Part.Parent then missing = missing + 1 end
		end
		if total > 0 and missing > 0 then
			for handle in pairs(Held) do
				if not handle.Parent then Held[handle] = nil end
			end
			NeedRebuild = true
			if missing == total then return end
		end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		IdleT = IdleT + dt
		if AnimState ~= "idle" then AnimT = AnimT + dt end
		if m.MethodIndex == 5 and not m.WalkWithMe then
			X.applyStandCF(StandRoot.CFrame, dt)
			return
		end
		local desired = X.desiredStandCF(followRoot, dt)
		local dist = (StandRoot.Position - desired.Position).Magnitude
		local smooth = m.WalkWithMe and (m.WalkSmoothness or 18) or m.Smoothness
		if m.AutoCorrect and dist > (m.AutoCorrectDist or 25) then
			X.applyStandCF(desired, dt)
			return
		end
		local alpha = (dist > 20) and 1 or (1 - math.exp(-smooth * dt))
		X.applyStandCF(StandRoot.CFrame:Lerp(desired, alpha), dt)
	end

	--------------------------------------------------------------
	-- INPUT
	--------------------------------------------------------------
	function X.bindKeys()
		for _, c in ipairs(KeyConns) do pcall(function() c:Disconnect() end) end
		KeyConns = {}
		local lastPlace = 0
		local function tryPlaceClick(overGui, legacy)
			if not m.Enabled or not X.modeAllowsPlace() then return end
			local structure = m.BToolsClickBuild and (m.BToolsMode or 1) ~= 1
			-- whole-structure builds only from the real input event (so clicking GUI buttons never builds)
			if structure and (overGui or legacy) then return end
			local now = os.clock()
			if now - lastPlace < 0.15 then return end
			lastPlace = now
			if structure then X.buildStructure(true) return end
			local cf = X.getMouseWorldCF()
			if cf then X.placeHatAt(cf) end
		end
		table.insert(KeyConns, UserInputService.InputBegan:Connect(function(input, gp)
			if not m.Enabled then return end
			if input.UserInputType == Enum.UserInputType.MouseButton1 and X.modeAllowsPlace() then
				tryPlaceClick(gp, false)
			end
			if UserInputService:GetFocusedTextBox() then return end
			if m.Keybinds then
				if X.modeAllowsStand() then
					local kcName = input.KeyCode.Name
					local clawsBusy = m.ClawsEnabled and m.ClawsKeysEnabled and (
						kcName == tostring(m.KeyClawsCombo) or kcName == tostring(m.KeyClawsPush) or kcName == tostring(m.KeyClawsSpin)
						or kcName == tostring(m.KeyClawsLaser) or kcName == tostring(m.KeyClawsSlam)
					)
					if not clawsBusy then
						if input.KeyCode == Enum.KeyCode.Z then X.playAnim("punch", 0.42)
						elseif input.KeyCode == Enum.KeyCode.X then X.playAnim("punch2", 0.42)
						elseif input.KeyCode == Enum.KeyCode.C then X.playAnim("uppercut", 0.5)
						end
					end
					if input.KeyCode == Enum.KeyCode.V then X.playAnim("kick", 0.48)
					elseif input.KeyCode == Enum.KeyCode.F then X.playAnim("block", 0.7)
					elseif input.KeyCode == Enum.KeyCode.G then X.playAnim("wave", 0.9)
					elseif input.KeyCode == Enum.KeyCode.H and m.DanceKey then
						ForceDance = true
						ForceDanceUntil = os.clock() + 4
						DanceT = 0
					end
				end
				if X.modeAllowsPlace() then
					if input.KeyCode == Enum.KeyCode.Y then
						X.buildStructure(true)
					elseif input.KeyCode == Enum.KeyCode.R then
						m.PlaceActiveSlot = (m.PlaceActiveSlot % 10) + 1
						X.clearPlacePreview()
						warn("[HatStand] place slot -> " .. m.PlaceActiveSlot)
					elseif input.KeyCode == Enum.KeyCode.E then
						X.yeetNearestPlaced()
					elseif input.KeyCode == Enum.KeyCode.T then
						X.placeBackNearest()
					elseif input.KeyCode == Enum.KeyCode.Backspace or input.KeyCode == Enum.KeyCode.Delete then
						X.removeNearest()
					end
				end
			end
			do
				local function keyIs(field)
					local want = tostring(m[field])
					if want == "MouseButton2" or want == "MouseButton3" then
						return input.UserInputType.Name == want
					end
					return input.KeyCode ~= Enum.KeyCode.Unknown and input.KeyCode.Name == want
				end
				-- Gaster fire / cycle slot
				if m.GasterEnabled and keyIs("KeyGaster") then
					X.fireGaster()
				end
				if m.GasterEnabled and keyIs("KeyGasterCycle") then
					m.GasterActiveSlot = (m.GasterActiveSlot % 5) + 1
					warn("[HatStand] Gaster active slot -> " .. m.GasterActiveSlot)
				end
				-- Bone attack
				if m.BoneEnabled and keyIs("KeyBone") then
					X.fireBone()
				end
				-- Ravenger Claws
				if m.ClawsEnabled and keyIs("KeyClawsKeysToggle") then
					m.ClawsKeysEnabled = not m.ClawsKeysEnabled
					warn("[HatStand] Claws attack keys " .. (m.ClawsKeysEnabled and "ON" or "OFF"))
				end
				if m.ClawsEnabled and keyIs("KeyClawsTrackToggle") then
					m.ClawsTrackMouse = not m.ClawsTrackMouse
					warn("[HatStand] Claws mouse tracking " .. (m.ClawsTrackMouse and "ON" or "OFF"))
				end
				if m.ClawsEnabled and keyIs("KeyClawsRage") then
					m.ClawsRage = not m.ClawsRage
					warn("[HatStand] Claws RAGE " .. (m.ClawsRage and "ON" or "OFF"))
				end
				if m.ClawsEnabled and m.ClawsKeysEnabled then
					if keyIs("KeyClawsLaser") then X.fireClawsLaser() end
					if keyIs("KeyClawsSlam") then X.fireClawsSlam() end
					if keyIs("KeyClawsCombo") then fireClawsCombo() end
					if keyIs("KeyClawsPush") then fireClawsPush() end
					if keyIs("KeyClawsSpin") then fireClawsSpin() end
				end
				-- Omega Blaster
				if m.OmegaEnabled and keyIs("KeyOmega") then
					X.fireOmega()
				end
				-- Sans: fire every enabled Sans attack
				if keyIs("KeySans") then
					if m.GasterEnabled then pcall(X.fireGaster) end
					if m.BoneEnabled then pcall(X.fireBone) end
					if m.OmegaEnabled then pcall(X.fireOmega) end
				end
				-- Sans: sink / raise every Sans attack
				if keyIs("KeySansToggle") then
					X.setSansUnderground(not m.SansUnderground)
				end
				if m.OmegaEnabled and keyIs("KeyOmegaCycle") then
					m.OmegaActiveSlot = (m.OmegaActiveSlot % 5) + 1
					warn("[HatStand] Omega active slot -> " .. m.OmegaActiveSlot)
				end
				-- Shield raise / lower (underground stash)
				if keyIs("KeyShield") then
					X.toggleShieldStash()
				end
				-- Weapon fire
				if m.WeaponEnabled and input.KeyCode == Enum.KeyCode.B then
					X.BHeld = true
					X.fireWeapon()
				end
				if m.WeaponEnabled and input.KeyCode == Enum.KeyCode.N then
					X.cycleWeapon()
				end
				-- Ball yeet
				if m.BallEnabled and keyIs("BallKey") then
					X.yeetBall(m.BallActiveSlot or 1)
				end
				-- Motorcycle ride toggle
				if m.MotoEnabled and keyIs("KeyMotoRide") then
					X.toggleMotoRide()
				end
				-- Plane ride / fly
				if m.PlaneEnabled and keyIs("KeyPlaneRide") then
					X.togglePlaneRide()
				end
				if m.PlaneEnabled and keyIs("KeyPlaneFly") then
					X.togglePlaneFly()
				end
				-- Hellcopter
				if keyIs("KeyHeliRide") then
					if not m.HeliEnabled then
						m.HeliEnabled = true
						pcall(function() X.rebuildHeli() end)
					end
					X.toggleHeliRide()
				end
				if m.TitanEnabled and keyIs("KeyTitanFly") then X.toggleTitanFly() end
				if m.TitanEnabled and keyIs("KeyTitanCoreFire") then X.titanCoreFire() end
				if m.HeliEnabled and keyIs("KeyHeliEngine") then X.toggleHeliEngine() end
				if m.HeliEnabled and keyIs("KeyHeliOff") then X.toggleHeliFly() end
				if m.HeliEnabled and keyIs("KeyHeliMouse") then X.toggleHeliMouse() end
				if m.HeliEnabled and keyIs("KeyHeliLauncher") then
					m.HeliMissileEnabled = not (m.HeliMissileEnabled ~= false)
					if not m.HeliMissileEnabled then X.msClearLock() end
					warn("[HatStand] missile launcher " .. (m.HeliMissileEnabled and "ON" or "OFF"))
				end
				if m.HeliEnabled and m.HeliRide and keyIs("KeyHeliMissile") then X.fireHeliMissile() end
				if m.HeliEnabled and m.HeliRide and keyIs("KeyHeliFire") then X.fireHeli(true) end
				-- Plane ordnance attacks (only while riding)
				if m.PlaneEnabled and m.PlaneRide then
					if m.PlaneBombEnabled and keyIs("PlaneBombKey") then X.firePlaneBomb() end
					if m.PlanePackageEnabled and keyIs("PlanePackageKey") then X.firePlanePackage() end
					if m.PlaneMissileEnabled and keyIs("PlaneMissileKey") then X.firePlaneMissile() end
					if m.PlaneMissileEnabled and keyIs("PlaneMissileCycleKey") then
						local cur = math.clamp(math.floor(m.PlaneMissileActiveSlot or 1), 1, 5)
						m.PlaneMissileActiveSlot = (cur % 5) + 1
						if X.PlaneMissileAmmoSlots then
							X.PlaneMissileAmmo = X.PlaneMissileAmmoSlots[m.PlaneMissileActiveSlot] or X.PlaneMissileAmmo
						end
					end
					if m.PlaneBomb2Enabled and keyIs("PlaneBomb2Key") then X.firePlaneBomb2() end
				end
				-- Car ride / enter (GTA style)
				if m.CarEnabled and keyIs("KeyCarRide") then
					m.CarRide = not m.CarRide
					if m.CarRide and m.CarEnterAnim then CarEnterT = m.CarEnterTime or 1.1 end
					warn("[HatStand] car ride=" .. tostring(m.CarRide))
				end
				-- Hat tool swing / cycle
				if m.ToolEnabled and keyIs("KeyToolSwing") then
					X.swingTool()
				end
				if m.ToolEnabled and keyIs("KeyToolCycle") then
					m.ToolActiveSlot = (m.ToolActiveSlot % 6) + 1
					warn("[HatStand] tool slot -> " .. m.ToolActiveSlot)
				end
				-- Shield place
				if m.ShieldEnabled and keyIs("KeyShieldPlace") then
					X.placeShieldAtMouse()
				end
			end
		end))
		table.insert(KeyConns, UserInputService.InputEnded:Connect(function(input)
			if input.KeyCode == Enum.KeyCode.B then X.BHeld = false end
		end))
		pcall(function()
			table.insert(KeyConns, Mouse.Button1Down:Connect(function()
				if X.modeAllowsPlace() then tryPlaceClick(false, true) end
				if m.PlaneEnabled and m.PlaneRide and m.PlaneGunEnabled then X.firePlaneGuns() end
				if m.HeliEnabled and m.HeliRide then
					X.HeliFireHeld = true
					X.fireHeli(true)
				end
			end))
			table.insert(KeyConns, Mouse.Button1Up:Connect(function()
				X.HeliFireHeld = false
			end))
		end)
	end

	function X.autoRefreshHatsIfChanged()
		X.refreshAllHats(false)
		local after = X.hatFingerprint()
		if after ~= LastHatFingerprint then
			LastHatFingerprint = after
			NeedRebuild = true
			NeedOrbitRebuild = true
			if m.GasterEnabled then task.defer(X.rebuildGaster) end
			if m.BoneEnabled then task.defer(X.rebuildBone) end
			if m.OmegaEnabled then task.defer(X.rebuildOmega) end
			if m.WeaponEnabled then task.defer(X.rebuildWeapon) end
			if m.ShieldEnabled then task.defer(X.rebuildShield) end
			if m.ClawsEnabled then task.defer(rebuildClaws) end
			if m.CarEnabled then task.defer(X.rebuildCar) end
			if m.PlanetEnabled then task.defer(X.rebuildPlanet) end
			if m.MotoEnabled then task.defer(X.rebuildMoto) end
			if m.ToolEnabled then task.defer(X.rebuildTool) end
			if m.PlaneEnabled then task.defer(X.rebuildPlane) end
			if m.HeliEnabled and not m.HeliRide then task.defer(X.rebuildHeli) end
		end
	end

	function X.startHatAutoRefresh()
		RefreshToken = RefreshToken + 1
		local mine = RefreshToken
		task.spawn(function()
			while RefreshToken == mine do
				local waitTime = m.AutoRefresh and (m.AutoRefreshInterval or 1) or 1
				task.wait(waitTime)
				if RefreshToken ~= mine then break end
				if m.Enabled then
					if m.AutoRefresh then
						pcall(function() X.refreshAllHats(true) end)
						local fp = X.hatFingerprint()
						if fp ~= LastHatFingerprint then
							LastHatFingerprint = fp
							NeedRebuild = true
							NeedOrbitRebuild = true
						end
					else
						pcall(X.autoRefreshHatsIfChanged)
					end
				end
			end
		end)
	end

	function X.stopHatAutoRefresh()
		RefreshToken = RefreshToken + 1
	end

	function X.bindCharacter()
		for _, c in ipairs(CharConns) do pcall(function() c:Disconnect() end) end
		CharConns = {}
		table.insert(CharConns, LocalPlayer.CharacterAdded:Connect(function()
			task.delay(0.5, function()
				if m.Enabled then NeedRebuild = true NeedOrbitRebuild = true X.NeedCloneRebuild = true X.RestSet = false X.Blend = {} end
			end)
			task.delay(1.5, function()
				if m.Enabled then
					NeedRebuild = true
					NeedOrbitRebuild = true
					if m.GasterEnabled then X.rebuildGaster() end
					if m.BoneEnabled then X.rebuildBone() end
					if m.OmegaEnabled then X.rebuildOmega() end
					if m.WeaponEnabled then X.rebuildWeapon() end
					if m.ShieldEnabled then X.rebuildShield() end
					if m.ClawsEnabled then rebuildClaws() end
					if m.CarEnabled then X.rebuildCar() end
					if m.PlanetEnabled then X.rebuildPlanet() end
					if m.MotoEnabled then X.rebuildMoto() end
					if m.ToolEnabled then X.rebuildTool() end
					if m.PlaneEnabled then X.rebuildPlane() end
					if m.HeliEnabled then X.rebuildHeli() end
					NeedPlaneRebuild = true
					NeedMotoRebuild = true
					NeedPlanetRebuild = true
					NeedToolRebuild = true
					NeedCarRebuild = true
				end
			end)
		end))
		table.insert(CharConns, LocalPlayer.CharacterRemoving:Connect(function()
			pcall(X.freezePlacedForRespawn)
			Held = {}
			Limbs = {}
			OrbitSlots = {}
			GasterHeld = nil
			GasterSlots = {}
			BoneHeld = nil
			BoneProjectiles = {}
			OmegaHeld, OmegaHeld2 = nil, nil
			X.ClawsLeft, X.ClawsRight, X.ClawsHead = nil, nil, nil
			X.OmegaSlots = {}
			X.OmegaBullets = {}
			WeaponHeld = nil
			X.WeaponSlots = {}
			X.BulletHats = {}
			ShieldHeld = nil
			CarSlots = {}
			PlanetSlots = {}
			MotoSlots, MotoWheels, MotoEngine = {}, {}, nil
			ToolSlots = {}
			PlaneFrames, PlaneProps, PlaneEngines, PlaneGuns = {}, {}, {}, {}
			PlaneFull = nil
			X.CloneLimbs = {}
			X.NeedCloneRebuild = true
			if not m.PlacePersist then PlacedHats = {} end
			X.clearPlacePreview()
			NeedRebuild = true
			NeedOrbitRebuild = true
		end))
	end

	function X.scanWorkspaceMovesets()
		local found, seen = {}, {}
		local function add(n)
			if not n or n == "" then return end
			local l = string.lower(n)
			if l == "hat stand" or seen[l] then return end
			seen[l] = true
			table.insert(found, n)
		end
		if listfiles then
			for _, folder in ipairs({ "UhhhhhhReanim/Modules", "UhhhhhhReanim/BuiltinModules" }) do
				local ok, files = pcall(listfiles, folder)
				if ok and type(files) == "table" then
					for _, path in ipairs(files) do
						if type(path) == "string" and string.find(path, "%.lua") then
							local ok2, data = pcall(readfile, path)
							if ok2 and data and string.find(data, 'ModuleType%s*=%s*"MOVESET"') then
								add(string.match(data, 'm%.Name%s*=%s*"([^"]+)"') or path)
							end
						end
					end
				end
			end
		end
		if #found == 0 then
			for _, n in ipairs({ "Nothing", "Steve", "2007 Roblox", "Sans Undertale" }) do add(n) end
		end
		table.sort(found)
		return found
	end

	function X.findAndClickMoveset(name)
		name = X.trim(name)
		if name == "" then return false end
		local lower = string.lower(name)
		local labels = {}
		local function collect(root, depth)
			if depth > 16 or not root then return end
			for _, child in ipairs(root:GetChildren()) do
				if child:IsA("TextLabel") or child:IsA("TextButton") or child:IsA("ImageButton") then
					local t = X.trim(child.Text or "")
					if t ~= "" then table.insert(labels, { text = t, inst = child }) end
				end
				collect(child, depth + 1)
			end
		end
		pcall(function() collect(CoreGui, 0) end)
		for _, entry in ipairs(labels) do
			local t = string.lower(X.trim(entry.text))
			if t == lower or string.find(t, lower, 1, true) then
				pcall(function()
					if getconnections then
						for _, sig in ipairs({ "Activated", "MouseButton1Click" }) do
							local ev = entry.inst[sig]
							if typeof(ev) == "RBXScriptSignal" then
								for _, c in ipairs(getconnections(ev)) do
									pcall(function() if c.Function then c.Function() end end)
								end
							end
						end
					end
				end)
				return true
			end
		end
		return false
	end

	-- ---------- anti-snap: stop Uhhhhhh dragging weapon / bullet hats back to the rig ----------
	X.lateApply = function(clean)
		if not (m.Enabled and m.WeaponAntiSnap) then return end
		for handle, held in pairs(Held) do
			local k = held.Kind
			if (k == "weapon" or k == "gaster") and held.LastCF and handle.Parent then
				if clean then
					for _, d in ipairs(handle:GetChildren()) do
						if not string.find(d.Name, "^HS_") then
							if d:IsA("JointInstance") or d:IsA("WeldConstraint") then
								pcall(function() d:Destroy() end)
							else
								for _, cls in ipairs(CONTROLLER_CLASSES) do
									if d:IsA(cls) then pcall(function() d:Destroy() end) break end
								end
							end
						end
					end
					if (not held.AP or not held.AP.Parent) and handle.Parent then
						pcall(function()
							local att = handle:FindFirstChild("HS_Att") or Instance.new("Attachment")
							att.Name = "HS_Att"
							att.Parent = handle
							held.Att = att
							local ap = Instance.new("AlignPosition")
							ap.Name = "HS_AP"
							ap.Mode = Enum.PositionAlignmentMode.OneAttachment
							ap.Attachment0 = att
							ap.RigidityEnabled = true
							ap.MaxForce = math.huge
							ap.Responsiveness = 200
							ap.Parent = handle
							held.AP = ap
							local ao = Instance.new("AlignOrientation")
							ao.Name = "HS_AO"
							ao.Mode = Enum.OrientationAlignmentMode.OneAttachment
							ao.Attachment0 = att
							ao.RigidityEnabled = true
							ao.MaxTorque = math.huge
							ao.Responsiveness = 200
							ao.Parent = handle
							held.AO = ao
						end)
					end
					pcall(function()
						handle.Anchored = false
						handle.CanCollide = false
						handle.Massless = true
					end)
				end
				pcall(function()
					if held.AP then held.AP.Position = held.LastCF.Position end
					if held.AO then held.AO.CFrame = held.LastCF end
					handle.CFrame = held.LastCF
					handle.AssemblyLinearVelocity = Vector3.zero
					handle.AssemblyAngularVelocity = Vector3.zero
				end)
			end
		end
	end

	-- placed hats solid: set before every physics step (Stepped), because Roblox / Uhhhhhh reset hat collision
	function X.placedSolid()
		return m.PlaceSolid and not (m.BToolsCarry and BToolsCarryCF)
	end

	function X.solidStep()
		if not m.Enabled or #PlacedHats == 0 then return end
		local solid = X.placedSolid() and true or false
		local yeeting = {}
		for _, y in ipairs(YeetQueue) do
			if y.Entry then yeeting[y.Entry] = true end
		end
		for _, e in ipairs(PlacedHats) do
			local h = e.Handle
			if h and h.Parent and not yeeting[e] then
				pcall(function()
					if h.CanCollide ~= solid then h.CanCollide = solid end
					if solid and not h.CanQuery then h.CanQuery = true end
				end)
			end
		end
	end

	-- ===== ALL HATS SOLID (FE): every worn hat collides with NPCs / dummies / unanchored parts =====
	-- The hats are my own client-owned parts, so their collisions replicate. Anything they hit only moves
	-- for other players if this client simulates it (the huge simulation radius asks for that); server-owned
	-- or anchored things just block the hat.
	local HatNC = setmetatable({}, { __mode = "k" }) -- handle -> { [otherPart] = constraint }
	local HatNCT = setmetatable({}, { __mode = "k" })

	X.hatsSolidHandles = function()
		local list, seen = {}, {}
		local function add(h)
			if h and h:IsA("BasePart") and h.Parent and not seen[h] then seen[h] = true list[#list + 1] = h end
		end
		local function scan(char)
			if not (char and char.Parent) then return end
			for _, d in ipairs(char:GetChildren()) do
				if d:IsA("Accessory") then add(d:FindFirstChild("Handle")) end
			end
		end
		scan(LocalPlayer.Character)
		pcall(function() scan(_G.Uhhhhhh and _G.Uhhhhhh.Character) end)
		for handle in pairs(Held) do add(handle) end
		return list
	end

	function X.hatsSolidRestore()
		for h, set in pairs(HatNC) do
			for _, c in pairs(set) do pcall(function() c:Destroy() end) end
			HatNC[h] = nil
			if h and h.Parent then pcall(function() h.CanCollide = false end) end
		end
	end

	function X.hatsSolidStep()
		if not (m.Enabled and m.HatsSolid) then
			if X.HatsSolidWas then X.HatsSolidWas = false X.hatsSolidRestore() end
			return
		end
		X.HatsSolidWas = true
		local now = os.clock()
		if m.HatsSolidBoost ~= false and now - (X.HatsSolidBoostT or 0) > 1 then
			X.HatsSolidBoostT = now
			pcall(X.boostNetwork)
		end
		local handles = X.hatsSolidHandles()
		-- parts every hat must pass through: my body, the rig, the stand, the clone, (other players)
		local ghost = {}
		local function addModel(model)
			if not (model and model.Parent) then return end
			for _, d in ipairs(model:GetDescendants()) do
				if d:IsA("BasePart") then ghost[#ghost + 1] = d end
			end
		end
		local budget = 80 -- constraints created per step, keeps the frame smooth
		local needScan = false
		for _, h in ipairs(handles) do
			if now - (HatNCT[h] or 0) > 1.5 then needScan = true break end
		end
		if needScan then
			addModel(LocalPlayer.Character)
			pcall(function() addModel(_G.Uhhhhhh and _G.Uhhhhhh.Character) end)
			addModel(X.CloneModel)
			pcall(function() addModel(StandModel) end)
			if m.HatsSolidIgnorePlayers ~= false then
				for _, pl in ipairs(Players:GetPlayers()) do
					if pl ~= LocalPlayer then addModel(pl.Character) end
				end
			end
		end
		for _, h in ipairs(handles) do
			pcall(function()
				if not h.CanCollide then h.CanCollide = true end
				if not h.CanTouch then h.CanTouch = true end
				if not h.CanQuery then h.CanQuery = true end
			end)
			if needScan and now - (HatNCT[h] or 0) > 1.5 and budget > 0 then
				HatNCT[h] = now
				local set = HatNC[h]
				if not set then set = {} HatNC[h] = set end
				for _, part in ipairs(ghost) do
					if part ~= h and not set[part] and budget > 0 then
						budget = budget - 1
						local c = Instance.new("NoCollisionConstraint")
						c.Name = "HS_HatNC"
						c.Part0, c.Part1 = h, part
						c.Parent = h
						set[part] = c
					end
				end
				if budget <= 0 then HatNCT[h] = 0 end -- unfinished: come back next step
				for part, c in pairs(set) do
					if not part.Parent then pcall(function() c:Destroy() end) set[part] = nil end
				end
			end
		end
	end

	X.startLate = function()
		X.stopLate()
		X.LateConns = {
			RunService.Stepped:Connect(function() pcall(X.solidStep) end),
			RunService.Stepped:Connect(function() pcall(X.hatsSolidStep) end),
			RunService.Stepped:Connect(function()
				if m.LowLag ~= false then
					X.LateN = ((X.LateN or 0) + 1) % 4
					if X.LateN ~= 0 then return end
				end
				pcall(X.lateApply, true)
			end),
			RunService.RenderStepped:Connect(function() pcall(X.lateApply, false) end),
		}
	end

	X.stopLate = function()
		for _, c in ipairs(X.LateConns or {}) do pcall(function() c:Disconnect() end) end
		X.LateConns = {}
		if X.HatsSolidWas then X.HatsSolidWas = false pcall(X.hatsSolidRestore) end
	end


	--------------------------------------------------------------
	-- PLANETS (solar-system style 10-slot hat orbits)
	--------------------------------------------------------------
	X.clearPlanet = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "planet" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		PlanetSlots = {}
	end

	X.rebuildPlanet = function()
		X.clearPlanet()
		if not m.PlanetEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "planet" then used[handle] = true end
		end
		local count = 0
		for i = 1, 10 do
			local hat = X.findHatFromLabel(m["PlanetHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "planet") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "Planet_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					PlanetSlots[i] = {
						Handle = part, Held = held, Idx = i,
						Rad = tonumber(m["PlanetRad" .. i]) or (3 + i * 1.4),
						Height = tonumber(m["PlanetHeight" .. i]) or 0.5,
						Speed = tonumber(m["PlanetSpeed" .. i]) or 1,
						Phase = tonumber(m["PlanetPhase" .. i]) or 0,
						Off = Vector3.new(
							tonumber(m["PlanetOffX" .. i]) or 0,
							tonumber(m["PlanetOffY" .. i]) or 0,
							tonumber(m["PlanetOffZ" .. i]) or 0
						),
						Rot = CFrame.Angles(
							math.rad(tonumber(m["PlanetRotX" .. i]) or 0),
							math.rad(tonumber(m["PlanetRotY" .. i]) or 0),
							math.rad(tonumber(m["PlanetRotZ" .. i]) or 0)
						),
						Incline = math.rad(tonumber(m["PlanetIncline" .. i]) or 0),
						SelfSpin = 0,
					}
				end
			end
		end
		warn("[HatStand] planets=" .. count)
	end

	function X.stepPlanet(dt)
		if not m.PlanetEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		PlanetT = PlanetT + dt
		local base = followRoot.CFrame
		for _, slot in pairs(PlanetSlots) do
			if slot.Handle and slot.Handle.Parent then
				local ang = slot.Phase + PlanetT * (m.PlanetSpinSpd or 0.6) * (slot.Speed or 1)
				if not m.PlanetSpin then ang = slot.Phase end
				local r = slot.Rad
				local incl = slot.Incline or 0
				local localPos = Vector3.new(
					math.cos(ang) * r,
					(slot.Height or 0) + math.sin(ang) * math.sin(incl) * r * 0.35,
					math.sin(ang) * math.cos(incl) * r
				) + slot.Off
				local world = base:PointToWorldSpace(localPos)
				if m.PlanetSelfSpin then
					slot.SelfSpin = (slot.SelfSpin or 0) + dt * (m.PlanetSelfSpinSpd or 4)
				end
				local cf = CFrame.new(world)
					* CFrame.Angles(0, ang, 0)
					* CFrame.Angles(0, slot.SelfSpin or 0, 0)
					* slot.Rot
				if slot.Held then X.driveHandle(slot.Held, cf)
				else pcall(function() slot.Handle.CFrame = cf end) end
			end
		end
	end

	--------------------------------------------------------------
	-- MOTORCYCLE
	--------------------------------------------------------------
	X.clearMoto = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "moto" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		MotoSlots, MotoWheels, MotoEngine, MotoRootCF = {}, {}, nil, nil
		if MotoEngineSound then pcall(function() MotoEngineSound:Stop() MotoEngineSound:Destroy() end) MotoEngineSound = nil end
		local hum = X.getLiveHumanoid()
		if hum and hum:GetAttribute("HS_MotoBoost") then
			pcall(function()
				hum.WalkSpeed = hum:GetAttribute("HS_OrigWalk") or 16
				hum:SetAttribute("HS_MotoBoost", nil)
			end)
		end
	end

	X.rebuildMoto = function()
		X.clearMoto()
		if not m.MotoEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "moto" then used[handle] = true end
		end
		local count = 0
		for i = 1, 6 do
			local hat = X.findHatFromLabel(m["MotoHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "moto") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "Moto_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					MotoSlots[i] = {
						Handle = part, Held = held,
						Off = Vector3.new(tonumber(m["MotoOffX" .. i]) or 0, tonumber(m["MotoOffY" .. i]) or 0, tonumber(m["MotoOffZ" .. i]) or 0),
						Rot = CFrame.Angles(math.rad(tonumber(m["MotoRotX" .. i]) or 0), math.rad(tonumber(m["MotoRotY" .. i]) or 0), math.rad(tonumber(m["MotoRotZ" .. i]) or 0)),
					}
				end
			end
		end
		for i = 1, 2 do
			local hat = X.findHatFromLabel(m["MotoWheelHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "moto") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "MotoWheel_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					MotoWheels[i] = {
						Handle = part, Held = held, Spin = 0,
						Off = Vector3.new(tonumber(m["MotoWheelOffX" .. i]) or 0, tonumber(m["MotoWheelOffY" .. i]) or -0.5, tonumber(m["MotoWheelOffZ" .. i]) or 0),
						Rot = CFrame.Angles(math.rad(tonumber(m["MotoWheelRotX" .. i]) or 0), math.rad(tonumber(m["MotoWheelRotY" .. i]) or 0), math.rad(tonumber(m["MotoWheelRotZ" .. i]) or 90)),
					}
				end
			end
		end
		do
			local hat = X.findHatFromLabel(m.MotoEngineHat)
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "moto") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "MotoEngine"))
				if part then
					if not m.FEMode then part.Parent = workspace end
					MotoEngine = {
						Handle = part, Held = held, T = 0,
						Off = Vector3.new(m.MotoEngineOffX or 0, m.MotoEngineOffY or 0.3, m.MotoEngineOffZ or -0.4),
						Rot = CFrame.new(),
					}
					count = count + 1
				end
			end
		end
		warn("[HatStand] moto parts=" .. count)
	end

	function X.stepMoto(dt)
		if not m.MotoEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local vel = followRoot.AssemblyLinearVelocity or Vector3.zero
		local horiz = Vector3.new(vel.X, 0, vel.Z).Magnitude
		local lean = 0
		if m.MotoLean and m.MotoRide then
			local right = Vector3.new(followRoot.CFrame.RightVector.X, 0, followRoot.CFrame.RightVector.Z)
			if right.Magnitude > 0.01 then
				right = right.Unit
				lean = math.clamp(vel:Dot(right) / 40, -1, 1) * math.rad(m.MotoLeanAmt or 18)
			end
		end
		-- enter anim offset
		local enterOff = 0
		if m.MotoEnterAnim and MotoEnterT > 0 then
			MotoEnterT = math.max(0, MotoEnterT - dt)
			local t = 1 - (MotoEnterT / math.max(m.MotoEnterTime or 0.85, 0.05))
			enterOff = (1 - t) * 3 -- approach from side
		end
		local target
		if m.MotoRide then
			target = followRoot.CFrame * CFrame.new(enterOff, -1.6, 0) * CFrame.Angles(0, math.rad(m.MotoRotY or 0), lean)
			local hum = X.getLiveHumanoid()
			if hum and not hum:GetAttribute("HS_MotoBoost") then
				pcall(function()
					hum:SetAttribute("HS_OrigWalk", hum.WalkSpeed)
					hum.WalkSpeed = (hum.WalkSpeed or 16) * (m.MotoSpeedBoost or 1.55)
					hum:SetAttribute("HS_MotoBoost", true)
				end)
			end
			-- engine SFX
			if m.MotoEngineSFX and not MotoEngineSound then
				pcall(function()
					local s = Instance.new("Sound")
					s.Name = "HS_MotoEngine"
					s.SoundId = tostring(m.MotoEngineSFXId or "rbxassetid://13114759")
					s.Volume = m.MotoVolume or 0.7
					s.Looped = true
					s.Parent = followRoot
					s:Play()
					MotoEngineSound = s
				end)
			end
			if MotoEngineSound then
				pcall(function() MotoEngineSound.PlaybackSpeed = 0.85 + math.clamp(horiz / 50, 0, 1.2) end)
			end
		else
			target = followRoot.CFrame * CFrame.new((m.MotoSide or 5) + enterOff, m.MotoHeight or 0, m.MotoForward or 0) * CFrame.Angles(0, math.rad(m.MotoRotY or 0), 0)
			local hum = X.getLiveHumanoid()
			if hum and hum:GetAttribute("HS_MotoBoost") then
				pcall(function()
					hum.WalkSpeed = hum:GetAttribute("HS_OrigWalk") or 16
					hum:SetAttribute("HS_MotoBoost", nil)
				end)
			end
			if MotoEngineSound then pcall(function() MotoEngineSound:Stop() MotoEngineSound:Destroy() end) MotoEngineSound = nil end
		end
		if not MotoRootCF then MotoRootCF = target
		else MotoRootCF = MotoRootCF:Lerp(target, 1 - math.exp(-(m.MotoSmooth or 14) * dt)) end
		for _, slot in pairs(MotoSlots) do
			if slot.Handle and slot.Handle.Parent then
				local cf = MotoRootCF * CFrame.new(slot.Off) * slot.Rot
				if slot.Held then X.driveHandle(slot.Held, cf) else pcall(function() slot.Handle.CFrame = cf end) end
			end
		end
		for _, w in pairs(MotoWheels) do
			if w.Handle and w.Handle.Parent then
				if m.MotoWheelSpin then w.Spin = (w.Spin or 0) + dt * (m.MotoWheelSpinSpd or 16) * (0.3 + horiz / 20) end
				local cf = MotoRootCF * CFrame.new(w.Off) * w.Rot * CFrame.Angles(w.Spin or 0, 0, 0)
				if w.Held then X.driveHandle(w.Held, cf) else pcall(function() w.Handle.CFrame = cf end) end
			end
		end
		if MotoEngine and MotoEngine.Handle and MotoEngine.Handle.Parent then
			MotoEngine.T = (MotoEngine.T or 0) + dt
			local bob = math.sin(MotoEngine.T * 20) * 0.04
			local cf = MotoRootCF * CFrame.new(MotoEngine.Off + Vector3.new(0, bob, 0)) * (MotoEngine.Rot or CFrame.new())
			if MotoEngine.Held then X.driveHandle(MotoEngine.Held, cf) else pcall(function() MotoEngine.Handle.CFrame = cf end) end
		end
	end

	function X.toggleMotoRide()
		m.MotoRide = not m.MotoRide
		if m.MotoRide and m.MotoEnterAnim then MotoEnterT = m.MotoEnterTime or 0.85 end
		warn("[HatStand] moto ride=" .. tostring(m.MotoRide))
	end


	--------------------------------------------------------------
	-- HAT TOOLS (sword / melee)
	--------------------------------------------------------------
	X.clearTool = function()
		local keep = {}
		for handle, held in pairs(Held) do
			if held.Kind ~= "tool" then keep[handle] = true end
		end
		X.releaseHeld(keep)
		ToolSlots = {}
	end

	X.rebuildTool = function()
		X.clearTool()
		if not m.ToolEnabled then return end
		X.refreshAllHats()
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and held.Kind ~= "tool" then used[handle] = true end
		end
		local count = 0
		for i = 1, 6 do
			local hat = X.findHatFromLabel(m["ToolHat" .. i])
			if hat and hat.Handle and not used[hat.Handle] then
				local held = m.FEMode and X.attachFE(hat, "tool") or nil
				local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, "Tool_" .. i))
				if part then
					if not m.FEMode then part.Parent = workspace end
					if held then used[hat.Handle] = true end
					count = count + 1
					ToolSlots[i] = {
						Handle = part, Held = held, Idx = i,
						Off = Vector3.new(tonumber(m["ToolOffX" .. i]) or 0, tonumber(m["ToolOffY" .. i]) or 0, tonumber(m["ToolOffZ" .. i]) or 0),
						Rot = CFrame.Angles(math.rad(tonumber(m["ToolRotX" .. i]) or 0), math.rad(tonumber(m["ToolRotY" .. i]) or 90), math.rad(tonumber(m["ToolRotZ" .. i]) or 0)),
						SwingT = 0,
					}
				end
			end
		end
		warn("[HatStand] tools=" .. count)
	end

	function X.stepTool(dt)
		if not m.ToolEnabled then return end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end
		local active = m.ToolActiveSlot or 1
		local mode = m.ToolMode or 1
		local mouseCF = nil
		if m.ToolTrackMouse then
			pcall(function()
				local hit = Mouse.Hit
				if hit then mouseCF = CFrame.new(followRoot.Position, hit.Position) end
			end)
		end
		for i, slot in pairs(ToolSlots) do
			if slot.Handle and slot.Handle.Parent then
				slot.SwingT = math.max(0, (slot.SwingT or 0) - dt)
				local swing = 0
				if slot.SwingT > 0 then
					local a = 1 - (slot.SwingT / 0.35)
					swing = math.sin(a * math.pi) * ((mode == 2) and 1.4 or 1)
				end
				local base = mouseCF or followRoot.CFrame
				local side = (i == active) and (m.ToolFloatSide or 1.2) or ((i - active) * 0.4)
				local hold = base
					* CFrame.new(side + slot.Off.X, (m.ToolFloatHeight or 0.4) + slot.Off.Y, (m.ToolFloatForward or -0.6) + slot.Off.Z)
					* CFrame.Angles(-math.rad(70) * swing, 0, math.rad(25) * swing)
					* slot.Rot
				if mode == 4 then -- spin
					hold = hold * CFrame.Angles(0, os.clock() * 8, 0)
				elseif mode == 3 then -- spear forward
					hold = hold * CFrame.Angles(-math.rad(20), 0, 0) * CFrame.new(0, 0, -0.8 * swing)
				end
				if slot.Held then X.driveHandle(slot.Held, hold) else pcall(function() slot.Handle.CFrame = hold end) end
			end
		end
	end

	function X.swingTool()
		if not m.ToolEnabled then return end
		if os.clock() - (ToolLastSwing or 0) < (m.ToolSwingCooldown or 0.35) then return end
		ToolLastSwing = os.clock()
		local slot = ToolSlots[m.ToolActiveSlot or 1]
		if slot then slot.SwingT = 0.35 end
		if m.ToolSFX then X.playSFX(m.ToolSwingSFXId, m.ToolVolume or 0.9) end
		-- light push on nearby humanoids (client-side feel)
		local followRoot = X.getFollowRoot()
		if followRoot then
			local range = m.ToolSwingRange or 7
			for _, plr in ipairs(Players:GetPlayers()) do
				if plr ~= LocalPlayer and plr.Character then
					local hrp = plr.Character:FindFirstChild("HumanoidRootPart")
					if hrp and (hrp.Position - followRoot.Position).Magnitude < range then
						local dir = (hrp.Position - followRoot.Position).Unit
						pcall(function()
							hrp.AssemblyLinearVelocity = dir * (m.ToolSwingForce or 40) + Vector3.new(0, 12, 0)
						end)
					end
				end
			end
		end
	end

	--------------------------------------------------------------
	-- PLANE
	--------------------------------------------------------------
	X.clearPlane = function()
		local planeKinds = {
			plane = true, planebomb = true, planepackage = true,
			planemissile = true, planemissileammo = true, planebomb2 = true,
		}
		local keep = {}
		for handle, held in pairs(Held) do
			if not planeKinds[held.Kind] then keep[handle] = true end
		end
		X.releaseHeld(keep)
		PlaneFrames, PlaneProps, PlaneEngines, PlaneGuns = {}, {}, {}, {}
		PlaneFull = nil
		X.PlaneBombHeld, X.PlanePackageHeld, X.PlaneBomb2Held = nil, nil, nil
		X.PlaneMissileLauncher, X.PlaneMissileAmmo = nil, nil
		X.PlaneMissileAmmoSlots = {}
		X.PlaneMissileTubeLast = {}
		X.PlaneOrdnanceFlying = {}
		PlaneRootCF, PlaneVel, PlanePitch, PlaneYaw, PlaneRoll = nil, 0, 0, 0, 0
		PlaneThrottle = 0
		if PlaneEngineSound then pcall(function() PlaneEngineSound:Stop() PlaneEngineSound:Destroy() end) PlaneEngineSound = nil end
		if PlaneSpeedoGui then pcall(function() PlaneSpeedoGui:Destroy() end) PlaneSpeedoGui = nil end
		local hum = X.getLiveHumanoid()
		if hum and hum:GetAttribute("HS_PlaneFly") then
			pcall(function()
				hum.WalkSpeed = hum:GetAttribute("HS_OrigWalk") or 16
				hum:SetAttribute("HS_PlaneFly", nil)
			end)
		end
	end

	
	-- Auto-detect AIM-54 / Phoenix missile hats into empty tubes
	function X.autoDetectMissileHats()
		if m.PlaneMissileAutoDetect == false then return end
		X.refreshAllHats()
		local ids = m.PlaneMissileAutoDetectIds or { "104594291421043" }
		local hints = m.PlaneMissileAutoDetectHints or { "aim-54", "aim54", "pheonix", "phoenix" }
		local matches = {}
		for _, h in ipairs(HatCache or {}) do
			if h.Handle then
				local hit = false
				for _, id in ipairs(ids) do
					if X.assetIdInInstance(h.Accessory, id) or X.assetIdInInstance(h.Handle, id) then
						hit = true break
					end
				end
				if not hit then
					local lower = string.lower(h.Name or "")
					for _, hint in ipairs(hints) do
						if string.find(lower, hint, 1, true) then hit = true break end
					end
				end
				if hit then table.insert(matches, h.Name) end
			end
		end
		if #matches == 0 then return end
		-- fill empty tubes; prefer slot 5 for first AIM-54 if empty
		local order = { 5, 1, 2, 3, 4 }
		local mi = 1
		for _, slot in ipairs(order) do
			if mi > #matches then break end
			if X.trim(m["PlaneMissileHat" .. slot] or "") == "" then
				m["PlaneMissileHat" .. slot] = matches[mi]
				mi = mi + 1
				warn("[HatStand] auto missile tube " .. slot .. " = " .. tostring(m["PlaneMissileHat" .. slot]))
			end
		end
		-- also keep legacy
		if X.trim(m.PlaneMissileHat or "") == "" and X.trim(m.PlaneMissileHat1 or "") ~= "" then
			m.PlaneMissileHat = m.PlaneMissileHat1
		end
	end

	X.rebuildPlane = function()
		X.clearPlane()
		if not m.PlaneEnabled then return end
		X.refreshAllHats()
		local planeKinds = {
			plane = true, planebomb = true, planepackage = true,
			planemissile = true, planemissileammo = true, planebomb2 = true,
		}
		local used = {}
		for handle, held in pairs(Held) do
			if held.Kind and not planeKinds[held.Kind] then used[handle] = true end
		end
		local count = 0
		local function grab(label, name, offx, offy, offz, rx, ry, rz, feKind)
			local hat = X.findHatFromLabel(label)
			if not (hat and hat.Handle and not used[hat.Handle]) then return nil end
			local held = m.FEMode and X.attachFE(hat, feKind or "plane") or nil
			local part = held and hat.Handle or (not m.FEMode and X.cloneHandle(hat.Handle, name))
			if not part then return nil end
			if not m.FEMode then part.Parent = workspace end
			if held then used[hat.Handle] = true end
			count = count + 1
			local entry = {
				Handle = part, Held = held,
				Off = Vector3.new(offx or 0, offy or 0, offz or 0),
				Rot = CFrame.Angles(math.rad(rx or 0), math.rad(ry or 0), math.rad(rz or 0)),
				Spin = 0, T = 0, Kind = feKind or "plane",
			}
			if held then
				held.Kind = feKind or "plane"
				X.initSansStash(held)
			end
			return entry
		end
		-- FULL PLANE single body (triplane / biplane accessory pack etc.)
		if m.PlaneFullMode and X.trim(m.PlaneFullHat or "") ~= "" then
			PlaneFull = grab(m.PlaneFullHat, "PlaneFull",
				m.PlaneFullOffX, m.PlaneFullOffY, m.PlaneFullOffZ,
				m.PlaneFullRotX, m.PlaneFullRotY, m.PlaneFullRotZ, "plane")
			if PlaneFull then
				PlaneFull.IsFull = true
			end
		end
		-- multi-part frames still allowed alongside full body
		for i = 1, 10 do
			PlaneFrames[i] = grab(m["PlaneFrameHat" .. i], "PlaneFrame_" .. i,
				m["PlaneFrameOffX" .. i], m["PlaneFrameOffY" .. i], m["PlaneFrameOffZ" .. i],
				m["PlaneFrameRotX" .. i], m["PlaneFrameRotY" .. i], m["PlaneFrameRotZ" .. i], "plane")
		end
		for i = 1, 2 do
			PlaneProps[i] = grab(m["PlanePropHat" .. i], "PlaneProp_" .. i,
				m["PlanePropOffX" .. i], m["PlanePropOffY" .. i], m["PlanePropOffZ" .. i],
				m["PlanePropRotX" .. i], m["PlanePropRotY" .. i], m["PlanePropRotZ" .. i], "plane")
			if PlaneProps[i] then PlaneProps[i].SpinSpd = tonumber(m["PlanePropSpinSpd" .. i]) or 28 end
		end
		for i = 1, 2 do
			PlaneEngines[i] = grab(m["PlaneEngineHat" .. i], "PlaneEngine_" .. i,
				m["PlaneEngineOffX" .. i], m["PlaneEngineOffY" .. i], m["PlaneEngineOffZ" .. i],
				m["PlaneEngineRotX" .. i], m["PlaneEngineRotY" .. i], m["PlaneEngineRotZ" .. i], "plane")
		end
		for i = 1, 4 do
			PlaneGuns[i] = grab(m["PlaneGunHat" .. i], "PlaneGun_" .. i,
				m["PlaneGunOffX" .. i], m["PlaneGunOffY" .. i], m["PlaneGunOffZ" .. i],
				m["PlaneGunRotX" .. i], m["PlaneGunRotY" .. i], m["PlaneGunRotZ" .. i], "plane")
			if PlaneGuns[i] then PlaneGuns[i].Fire = m["PlaneGunFire" .. i] end
		end
		-- Ordnance: bomb / package / missile / bomb2
		if m.PlaneBombEnabled then
			X.PlaneBombHeld = grab(m.PlaneBombHat, "PlaneBomb",
				m.PlaneBombSide, m.PlaneBombHeight, m.PlaneBombForward,
				m.PlaneBombRotX, m.PlaneBombRotY, m.PlaneBombRotZ, "planebomb")
		end
		if m.PlanePackageEnabled then
			X.PlanePackageHeld = grab(m.PlanePackageHat, "PlanePackage",
				m.PlanePackageSide, m.PlanePackageHeight, m.PlanePackageForward,
				m.PlanePackageRotX, m.PlanePackageRotY, m.PlanePackageRotZ, "planepackage")
		end
		if m.PlaneMissileEnabled then
			X.PlaneMissileLauncher = grab(m.PlaneMissileLauncherHat, "PlaneMissileLauncher",
				m.PlaneMissileLauncherSide, m.PlaneMissileLauncherHeight, m.PlaneMissileLauncherForward,
				m.PlaneMissileLauncherRotX, m.PlaneMissileLauncherRotY, m.PlaneMissileLauncherRotZ, "planemissile")
			X.PlaneMissileAmmoSlots = {}
			pcall(X.autoDetectMissileHats)
			-- migrate legacy single hat into slot 1 if slot 1 empty
			if X.trim(m.PlaneMissileHat1 or "") == "" and X.trim(m.PlaneMissileHat or "") ~= "" then
				m.PlaneMissileHat1 = m.PlaneMissileHat
			end
			for i = 1, 5 do
				local label = m["PlaneMissileHat" .. i]
				if X.trim(label or "") == "" and i == 1 then label = m.PlaneMissileHat end
				local side = m["PlaneMissileSlotSide" .. i]
				local height = m["PlaneMissileSlotHeight" .. i]
				local forward = m["PlaneMissileSlotForward" .. i]
				-- fallback to shared missile offset if per-slot unset
				if side == nil then side = m.PlaneMissileSide end
				if height == nil then height = m.PlaneMissileHeight end
				if forward == nil then forward = m.PlaneMissileForward end
				local slot = grab(label, "PlaneMissileAmmo_" .. i,
					side or 0, height or -0.8, forward or 1.5,
					m["PlaneMissileSlotRotX" .. i] or m.PlaneMissileRotX or 0,
					m["PlaneMissileSlotRotY" .. i] or m.PlaneMissileRotY or 0,
					m["PlaneMissileSlotRotZ" .. i] or m.PlaneMissileRotZ or 0,
					"planemissileammo")
				if slot then
					slot.TubeIndex = i
					X.PlaneMissileAmmoSlots[i] = slot
				end
			end
			-- legacy pointer = active or first filled
			local active = math.clamp(math.floor(m.PlaneMissileActiveSlot or 1), 1, 5)
			X.PlaneMissileAmmo = X.PlaneMissileAmmoSlots[active]
				or X.PlaneMissileAmmoSlots[1]
				or X.PlaneMissileAmmoSlots[2]
				or X.PlaneMissileAmmoSlots[3]
				or X.PlaneMissileAmmoSlots[4]
				or X.PlaneMissileAmmoSlots[5]
		end
		if m.PlaneBomb2Enabled then
			X.PlaneBomb2Held = grab(m.PlaneBomb2Hat, "PlaneBomb2",
				m.PlaneBomb2Side, m.PlaneBomb2Height, m.PlaneBomb2Forward,
				m.PlaneBomb2RotX, m.PlaneBomb2RotY, m.PlaneBomb2RotZ, "planebomb2")
		end
		warn("[HatStand] plane parts=" .. count .. " full=" .. tostring(PlaneFull ~= nil)
			.. " bomb=" .. tostring(X.PlaneBombHeld ~= nil)
			.. " pkg=" .. tostring(X.PlanePackageHeld ~= nil)
			.. " msl=" .. tostring(X.PlaneMissileLauncher ~= nil))
	end

	X.ensurePlaneSpeedo = function()
		if not m.PlaneSpeedo then
			if PlaneSpeedoGui then pcall(function() PlaneSpeedoGui:Destroy() end) PlaneSpeedoGui = nil end
			return
		end
		if PlaneSpeedoGui and PlaneSpeedoGui.Parent then return end
		pcall(function()
			local g = Instance.new("ScreenGui")
			g.Name = "HS_PlaneSpeedo"
			g.ResetOnSpawn = false
			g.Parent = CoreGui
			local f = Instance.new("Frame")
			f.Size = UDim2.fromOffset(160, 48)
			f.Position = UDim2.new(0.5, -80, 1, -70)
			f.BackgroundColor3 = Color3.fromRGB(10, 14, 22)
			f.BackgroundTransparency = 0.25
			f.BorderSizePixel = 0
			f.Parent = g
			Instance.new("UICorner", f).CornerRadius = UDim.new(0, 8)
			local tl = Instance.new("TextLabel")
			tl.Name = "Speed"
			tl.Size = UDim2.fromScale(1, 1)
			tl.BackgroundTransparency = 1
			tl.Font = Enum.Font.Code
			tl.TextScaled = true
			tl.TextColor3 = Color3.fromRGB(120, 255, 160)
			tl.Text = "0 kn"
			tl.Parent = f
			PlaneSpeedoGui = g
		end)
	end

	function X.stepPlane(dt)
		if not m.PlaneEnabled then return end
		-- empty slots but hats assigned -> auto rebuild
		if m.PlaneAutoRebuild then
			local hasBody = PlaneFull ~= nil or next(PlaneFrames) ~= nil or next(PlaneProps) ~= nil or next(PlaneEngines) ~= nil
			if not hasBody then
				local configured = (m.PlaneFullMode and X.trim(m.PlaneFullHat or "") ~= "")
				if not configured then
					for i = 1, 10 do if X.trim(m["PlaneFrameHat" .. i] or "") ~= "" then configured = true break end end
				end
				for i = 1, 2 do if X.trim(m["PlanePropHat" .. i] or "") ~= "" then configured = true break end end
				for i = 1, 2 do if X.trim(m["PlaneEngineHat" .. i] or "") ~= "" then configured = true break end end
				if configured then NeedPlaneRebuild = true end
			end
		end
		local followRoot = X.getFollowRoot()
		if not followRoot then return end

		local flying = m.PlaneRide and m.PlaneFly
		local target

		if m.PlaneRide then
			if PlaneEnterT and PlaneEnterT > 0 then
				PlaneEnterT = math.max(0, PlaneEnterT - dt)
			end

			if flying then
				-- ========== FIXED FLIGHT SYSTEM ==========
				-- Throttle: W/S  Turn: A/D  Pitch: Q/E or mouse  Roll auto-banks
				local cam = workspace.CurrentCamera
				local look = (cam and cam.CFrame.LookVector) or followRoot.CFrame.LookVector
				local flatLook = Vector3.new(look.X, 0, look.Z)
				if flatLook.Magnitude > 0.01 then flatLook = flatLook.Unit else flatLook = followRoot.CFrame.LookVector end
				local rightFlat = Vector3.new(flatLook.Z, 0, -flatLook.X)

				local yawInput, pitchInput, thrInput = 0, 0, 0
				pcall(function()
					if UserInputService:IsKeyDown(Enum.KeyCode.W) then thrInput = thrInput + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.S) then thrInput = thrInput - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.A) then yawInput = yawInput + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.D) then yawInput = yawInput - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.E) then pitchInput = pitchInput + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.Q) then pitchInput = pitchInput - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.Space) then pitchInput = pitchInput + 0.6 end
					if UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) or UserInputService:IsKeyDown(Enum.KeyCode.C) then
						pitchInput = pitchInput - 0.6
					end
				end)

				-- mouse steer (aim relative to screen center)
				if m.PlaneMouseSteer then
					pcall(function()
						local mp = UserInputService:GetMouseLocation()
						local vs = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1920, 1080)
						local nx = (mp.X / vs.X) * 2 - 1
						local ny = (mp.Y / vs.Y) * 2 - 1
						local sens = m.PlaneMouseSens or 0.35
						yawInput = yawInput - nx * sens
						pitchInput = pitchInput - ny * sens
					end)
				end

				-- throttle ramp
				local thrTarget = math.clamp(0.35 + thrInput * 0.65, 0, 1)
				if thrInput < 0 then thrTarget = math.clamp(0.15 + thrInput * 0.15, 0, 1) end
				PlaneThrottle = (PlaneThrottle or 0) + (thrTarget - (PlaneThrottle or 0)) * math.clamp(3 * dt, 0, 1)
				m.PlaneThrottle = PlaneThrottle

				local maxSpd = m.PlaneMaxSpeed or 180
				local baseSpd = m.PlaneSpeed or 60
				local wantSpd = baseSpd + (maxSpd - baseSpd) * (PlaneThrottle or 0)
				local accel = m.PlaneAccel or 40
				PlaneVel = (PlaneVel or 0) + (wantSpd - (PlaneVel or 0)) * math.clamp((accel / 40) * dt, 0, 1)

				-- orientation integrate
				local yawRate = m.PlaneYawRate or 1.3
				local pitchRate = m.PlanePitchRate or 1.1
				local rollRate = m.PlaneRollRate or 1.6
				PlaneYaw = (PlaneYaw or 0) + yawInput * yawRate * dt
				PlanePitch = math.clamp((PlanePitch or 0) + pitchInput * pitchRate * dt, -1.15, 1.15)

				-- auto bank into turn
				local bankTarget = 0
				if m.PlaneBank then
					bankTarget = -yawInput * math.rad(m.PlaneBankAmt or 25)
				end
				PlaneRoll = (PlaneRoll or 0) + (bankTarget - (PlaneRoll or 0)) * math.clamp(rollRate * dt, 0, 1)

				-- build flight CFrame from yaw/pitch/roll
				local pos = followRoot.Position
				local orient = CFrame.Angles(0, PlaneYaw, 0)
					* CFrame.Angles(PlanePitch, 0, 0)
					* CFrame.Angles(0, 0, PlaneRoll)
				local fwd = orient.LookVector

				-- stall / gravity when slow
				local minFly = m.PlaneMinFlySpeed or 8
				local liftFactor = math.clamp((PlaneVel or 0) / math.max(minFly * 2, 1), 0, 1)
				local grav = (m.PlaneGravity or 28) * (1 - liftFactor * 0.85)
				local velVec = fwd * (PlaneVel or 0) + Vector3.new(0, -grav * (1 - math.max(PlanePitch, 0) * 0.5), 0) * (1 - liftFactor)

				-- drive character
				pcall(function()
					followRoot.AssemblyLinearVelocity = velVec
					-- lightly face flight direction so walk anims don't fight
					local flatFwd = Vector3.new(fwd.X, 0, fwd.Z)
					if flatFwd.Magnitude > 0.05 then
						local hum = X.getLiveHumanoid()
						if hum then
							hum.AutoRotate = false
						end
						followRoot.CFrame = CFrame.new(followRoot.Position, followRoot.Position + flatFwd)
					end
				end)

				local seatY = m.PlaneSeatOffY or -1.2
				target = CFrame.new(pos) * orient * CFrame.new(0, seatY, 0)
			else
				-- ride but grounded / taxi: follow character
				target = followRoot.CFrame * CFrame.new(0, m.PlaneSeatOffY or -1.2, 0) * CFrame.Angles(0, math.rad(m.PlaneRotY or 0), 0)
				local v = followRoot.AssemblyLinearVelocity or Vector3.zero
				PlaneVel = Vector3.new(v.X, 0, v.Z).Magnitude
				-- restore autorotate
				pcall(function()
					local hum = X.getLiveHumanoid()
					if hum then hum.AutoRotate = true end
				end)
			end

			if m.PlaneEngineSFX and not PlaneEngineSound then
				pcall(function()
					local s = Instance.new("Sound")
					s.Name = "HS_PlaneEngine"
					s.SoundId = tostring(m.PlaneEngineSFXId or "rbxassetid://13114759")
					s.Volume = m.PlaneVolume or 0.75
					s.Looped = true
					s.Parent = followRoot
					s:Play()
					PlaneEngineSound = s
				end)
			end
			if PlaneEngineSound then
				pcall(function()
					PlaneEngineSound.PlaybackSpeed = 0.65 + math.clamp((PlaneVel or 0) / 100, 0, 1.6) + (PlaneThrottle or 0) * 0.25
				end)
			end
		else
			target = followRoot.CFrame
				* CFrame.new(m.PlaneSide or 8, m.PlaneHeight or 2, m.PlaneForward or 0)
				* CFrame.Angles(0, math.rad(m.PlaneRotY or 0), 0)
			PlaneVel = 0
			PlaneThrottle = 0
			if PlaneEngineSound then
				pcall(function() PlaneEngineSound:Stop() PlaneEngineSound:Destroy() end)
				PlaneEngineSound = nil
			end
			pcall(function()
				local hum = X.getLiveHumanoid()
				if hum then hum.AutoRotate = true end
			end)
		end

		if not PlaneRootCF then
			PlaneRootCF = target
		else
			local sm = (flying and (m.PlaneSmooth or 10) * 1.4) or (m.PlaneSmooth or 10)
			PlaneRootCF = PlaneRootCF:Lerp(target, 1 - math.exp(-sm * dt))
		end

		local function driveSlot(slot, cf)
			if not (slot and slot.Handle and slot.Handle.Parent) then
				if slot and m.PlaneAutoRebuild then NeedPlaneRebuild = true end
				return
			end
			if m.PlaneLock and slot.Held then
				X.driveHandle(slot.Held, cf)
				pcall(function()
					slot.Handle.CFrame = cf
					slot.Handle.AssemblyLinearVelocity = Vector3.zero
					slot.Handle.AssemblyAngularVelocity = Vector3.zero
				end)
			elseif slot.Held then
				X.driveHandle(slot.Held, cf)
			else
				pcall(function() slot.Handle.CFrame = cf end)
			end
		end

		-- FULL PLANE body
		if PlaneFull and PlaneFull.Handle and PlaneFull.Handle.Parent then
			local off = PlaneFull.Off or Vector3.zero
			local rot = PlaneFull.Rot or CFrame.new()
			-- live-update offsets from config so UI sliders work immediately
			off = Vector3.new(m.PlaneFullOffX or 0, m.PlaneFullOffY or -1.5, m.PlaneFullOffZ or 0)
			rot = CFrame.Angles(
				math.rad(m.PlaneFullRotX or 0),
				math.rad(m.PlaneFullRotY or 0),
				math.rad(m.PlaneFullRotZ or 0)
			)
			PlaneFull.Off, PlaneFull.Rot = off, rot
			local cf = PlaneRootCF * CFrame.new(off) * rot
			driveSlot(PlaneFull, cf)
		elseif m.PlaneFullMode and m.PlaneAutoRebuild and X.trim(m.PlaneFullHat or "") ~= "" then
			NeedPlaneRebuild = true
		end

		for _, slot in pairs(PlaneFrames) do
			if slot then
				driveSlot(slot, PlaneRootCF * CFrame.new(slot.Off) * slot.Rot)
			end
		end
		for _, prop in pairs(PlaneProps) do
			if prop and prop.Handle and prop.Handle.Parent then
				local spd = prop.SpinSpd or 28
				if m.PlaneRide then
					prop.Spin = (prop.Spin or 0) + dt * spd * (0.35 + (PlaneThrottle or 0) * 0.9 + (PlaneVel or 0) / 120)
				end
				driveSlot(prop, PlaneRootCF * CFrame.new(prop.Off) * prop.Rot * CFrame.Angles(0, 0, prop.Spin or 0))
			elseif prop then
				if m.PlaneAutoRebuild then NeedPlaneRebuild = true end
			end
		end
		for _, eng in pairs(PlaneEngines) do
			if eng and eng.Handle and eng.Handle.Parent then
				eng.T = (eng.T or 0) + dt
				local bob = math.sin(eng.T * 22) * 0.05 * (0.5 + (PlaneThrottle or 0))
				driveSlot(eng, PlaneRootCF * CFrame.new(eng.Off + Vector3.new(0, bob, 0)) * eng.Rot)
			elseif eng then
				if m.PlaneAutoRebuild then NeedPlaneRebuild = true end
			end
		end
		-- plane guns: optional mouse tracking (aim at world under cursor)
		local gunAimActive = m.PlaneGunTrackMouse and (
			not m.PlaneGunTrackOnlyFire
			or (X._planeGunLast and (os.clock() - (X._planeGunLast or 0)) < 0.35)
		)
		local gunAimPos = nil
		if gunAimActive then
			pcall(function()
				if Mouse and Mouse.Hit then gunAimPos = Mouse.Hit.Position end
			end)
		end
		for _, gun in pairs(PlaneGuns) do
			if gun then
				local base = PlaneRootCF * CFrame.new(gun.Off) * gun.Rot
				if gunAimPos then
					local look = CFrame.lookAt(base.Position, gunAimPos)
					local smooth = math.clamp((m.PlaneGunTrackSmooth or 14) * dt, 0, 1)
					base = base:Lerp(look * gun.Rot, smooth)
				end
				driveSlot(gun, base)
			end
		end
		-- bomb / package / missile (underground rise + in-flight)
		pcall(function() X.stepPlaneOrdnance(dt) end)

		-- camera lock behind plane
		if m.PlaneCamLock and m.PlaneRide and PlaneRootCF then
			pcall(function()
				local cam = workspace.CurrentCamera
				if cam then
					local back = PlaneRootCF * CFrame.new(0, 4, 14)
					local lookAt = PlaneRootCF.Position + PlaneRootCF.LookVector * 8
					cam.CFrame = cam.CFrame:Lerp(CFrame.new(back.Position, lookAt), 1 - math.exp(-(m.PlaneCamSmooth or 12) * dt))
				end
			end)
		end

		-- speedometer
		if m.PlaneSpeedo and m.PlaneRide then
			X.ensurePlaneSpeedo()
			pcall(function()
				local tl = PlaneSpeedoGui and PlaneSpeedoGui:FindFirstChild("Speed", true)
				if tl then
					local kn = math.floor((PlaneVel or 0) * 1.94384 + 0.5)
					local thr = math.floor((PlaneThrottle or 0) * 100 + 0.5)
					tl.Text = string.format("%d kn  |  thr %d%%", kn, thr)
				end
			end)
		elseif PlaneSpeedoGui then
			pcall(function() PlaneSpeedoGui:Destroy() end)
			PlaneSpeedoGui = nil
		end
	end

	function X.togglePlaneRide()
		m.PlaneRide = not m.PlaneRide
		if m.PlaneRide and m.PlaneEnterAnim then PlaneEnterT = m.PlaneEnterTime or 1.0 end
		if not m.PlaneRide then m.PlaneFly = false end
		warn("[HatStand] plane ride=" .. tostring(m.PlaneRide))
	end

	function X.togglePlaneFly()
		if not m.PlaneRide then m.PlaneRide = true end
		m.PlaneFly = not m.PlaneFly
		warn("[HatStand] plane fly=" .. tostring(m.PlaneFly))
	end

	-- Plane gun helpers: aim dir, local neon bullet, hat bullet with Gaster-style back&forth
	function X.planeGunAimDir(origin)
		if m.PlaneGunTrackMouse and Mouse and Mouse.Hit then
			local to = Mouse.Hit.Position - origin
			if to.Magnitude > 0.5 then return to.Unit end
		end
		if PlaneRootCF then return PlaneRootCF.LookVector end
		return Vector3.new(0, 0, -1)
	end

	function X.planeGunColor()
		return Color3.fromRGB(
			math.clamp(tonumber(m.PlaneGunR) or 255, 0, 255),
			math.clamp(tonumber(m.PlaneGunG) or 220, 0, 255),
			math.clamp(tonumber(m.PlaneGunB) or 80, 0, 255)
		)
	end

	function X.spawnPlaneNeonBullet(origin, dir, style)
		style = style or (m.PlaneGunBulletStyle or 1)
		local col = X.planeGunColor()
		local size = Vector3.new(0.25, 0.25, 2)
		if style == 2 then size = Vector3.new(0.7, 0.7, 0.7)
		elseif style == 3 then size = Vector3.new(0.2, 0.2, 2.4) end
		local p = Instance.new("Part")
		p.Name = "HS_PlaneBullet"
		p.Size = size
		p.Anchored = true
		p.CanCollide = false
		p.Material = Enum.Material.Neon
		p.Color = col
		if style == 2 then p.Shape = Enum.PartType.Ball end
		p.CFrame = CFrame.lookAt(origin, origin + dir)
		p.Parent = workspace
		local speed = m.PlaneGunSpeed or 220
		local life = m.PlaneGunLife or 2
		local spin = m.PlaneGunBulletSpin
		local trailOn = m.PlaneGunTrail
		local osc = (m.PlaneGunFireStyle == 2) and m.PlaneGunTrailOsc
		local oscDist = m.PlaneGunTrailOscDist or 14
		local oscSpd = m.PlaneGunTrailOscSpeed or 22
		local oscTime = m.PlaneGunTrailOscTime or 1.0
		if trailOn then
			pcall(function()
				local a0 = Instance.new("Attachment"); a0.Parent = p
				local a1 = Instance.new("Attachment"); a1.Position = Vector3.new(0, 0, -1); a1.Parent = p
				local tr = Instance.new("Trail")
				tr.Attachment0, tr.Attachment1 = a0, a1
				tr.Lifetime = 0.35
				tr.FaceCamera = true
				tr.Color = ColorSequence.new(col)
				tr.Parent = p
			end)
		end
		task.spawn(function()
			local t0 = os.clock()
			local traveled = 0
			local phase = 1 -- 1 go out, 2 osc, 3 done
			local last = origin
			while p.Parent do
				local dt2 = task.wait()
				if phase == 1 then
					traveled = traveled + speed * dt2
					last = origin + dir * traveled
					local cf = CFrame.lookAt(last, last + dir)
					if spin then cf = cf * CFrame.Angles(0, 0, os.clock() * 18) end
					p.CFrame = cf
					if osc then
						if traveled >= (m.PlaneGunBeamLength or 180) * 0.6 then
							phase = 2
							t0 = os.clock()
						end
					elseif os.clock() - t0 >= life then
						break
					end
				elseif phase == 2 then
					local t = os.clock() - t0
					local o = 0.5 - 0.5 * math.cos(t * oscSpd)
					last = origin + dir * math.max(traveled - oscDist * o, 0)
					local cf = CFrame.lookAt(last, last + dir)
					if spin then cf = cf * CFrame.Angles(0, 0, os.clock() * 22) end
					p.CFrame = cf
					if t >= oscTime then break end
				else
					break
				end
			end
			pcall(function() p:Destroy() end)
		end)
		Debris:AddItem(p, (life or 2) + (osc and oscTime or 0) + 0.5)
	end

	function X.spawnPlaneHatBullet(origin, dir)
		local label = m.PlaneGunBulletHat
		if label == "" then return false end
		local bhat = X.findHatFromLabel(label)
		if not (bhat and bhat.Handle) then return false end
		local heldB = (m.FEMode and m.PlaneGunRealHat) and X.attachFE(bhat, "plane") or nil
		local part = heldB and bhat.Handle or X.cloneHandle(bhat.Handle, "PlaneGunBullet")
		if not part then return false end
		if not heldB then part.Parent = workspace end
		local speed = m.PlaneGunSpeed or 220
		local osc = m.PlaneGunTrailOsc
		local oscDist = m.PlaneGunTrailOscDist or 14
		local oscSpd = m.PlaneGunTrailOscSpeed or 22
		local oscTime = m.PlaneGunTrailOscTime or 1.0
		local maxDist = m.PlaneGunBeamLength or 180
		local col = X.planeGunColor()
		if m.PlaneGunTrail then
			pcall(function()
				local a0 = Instance.new("Attachment"); a0.Parent = part
				local a1 = Instance.new("Attachment"); a1.Position = Vector3.new(0, 0, -1); a1.Parent = part
				local tr = Instance.new("Trail")
				tr.Attachment0, tr.Attachment1 = a0, a1
				tr.Lifetime = 0.4
				tr.FaceCamera = true
				tr.Color = ColorSequence.new(col)
				tr.Parent = part
			end)
		end
		local parkCF = part.CFrame
		task.spawn(function()
			local traveled = 0
			local phase = 1
			local tOsc = 0
			local last = origin
			while part and part.Parent do
				local dt2 = task.wait()
				if phase == 1 then
					traveled = traveled + speed * dt2
					last = origin + dir * math.min(traveled, maxDist)
					local cf = CFrame.lookAt(last, last + dir)
					if m.PlaneGunBulletSpin then cf = cf * CFrame.Angles(0, 0, os.clock() * 20) end
					if heldB then X.driveHandle(heldB, cf) else pcall(function() part.CFrame = cf end) end
					if traveled >= maxDist * 0.85 then
						if osc then phase = 2; tOsc = 0 else phase = 3 end
					end
				elseif phase == 2 then
					tOsc = tOsc + dt2
					local o = 0.5 - 0.5 * math.cos(tOsc * oscSpd)
					last = origin + dir * math.max(maxDist * 0.85 - oscDist * o, 0)
					local cf = CFrame.lookAt(last, last + dir)
					if m.PlaneGunBulletSpin then cf = cf * CFrame.Angles(0, 0, os.clock() * 24) end
					if heldB then X.driveHandle(heldB, cf) else pcall(function() part.CFrame = cf end) end
					if tOsc >= oscTime then phase = 3 end
				else
					-- return toward gun / park
					local to = parkCF.Position - last
					local step = speed * 1.4 * dt2
					if to.Magnitude <= step then
						if heldB then X.driveHandle(heldB, parkCF) else pcall(function() part.CFrame = parkCF end) end
						if not heldB then pcall(function() part:Destroy() end) end
						break
					end
					last = last + to.Unit * step
					local cf = CFrame.lookAt(last, last + to.Unit)
					if heldB then X.driveHandle(heldB, cf) else pcall(function() part.CFrame = cf end) end
				end
			end
		end)
		return true
	end

	function X.firePlaneGunBeam(origin, dir)
		-- Gaster-style laser flash along aim
		pcall(function()
			local length = m.PlaneGunBeamLength or 180
			local thick = m.PlaneGunBeamThick or 0.9
			local col = X.planeGunColor()
			local hitPos = origin + dir * length
			local params = RaycastParams.new()
			params.FilterType = Enum.RaycastFilterType.Exclude
			params.FilterDescendantsInstances = { LocalPlayer.Character, StandModel }
			local result = Workspace:Raycast(origin, dir * length, params)
			if result then hitPos = result.Position end
			local dist = (hitPos - origin).Magnitude
			local beam = Instance.new("Part")
			beam.Name = "HS_PlaneGunBeam"
			beam.Anchored = true
			beam.CanCollide = false
			beam.Material = Enum.Material.Neon
			beam.Color = col
			beam.Size = Vector3.new(thick, thick, math.max(dist, 1))
			beam.CFrame = CFrame.lookAt(origin, hitPos) * CFrame.new(0, 0, -dist / 2)
			beam.Parent = workspace
			Debris:AddItem(beam, 0.18)
		end)
	end

	function X.firePlaneGuns()
		if not (m.PlaneEnabled and m.PlaneGunEnabled and m.PlaneRide) then return end
		if not PlaneRootCF then return end
		local style = m.PlaneGunFireStyle or 1
		local cd = m.PlaneGunCooldown or 0.2
		if style == 3 then cd = m.PlaneGunAKCooldown or 0.12
		elseif style == 4 then cd = m.PlaneGunMiniCooldown or 0.04
		elseif style == 2 then cd = math.max(cd, 0.35) end
		X._planeGunLast = X._planeGunLast or 0
		if os.clock() - X._planeGunLast < cd then return end
		X._planeGunLast = os.clock()

		local shots = 1
		if style == 3 then shots = math.max(1, math.floor(m.PlaneGunBurst or 3))
		elseif style == 4 then shots = 1 end -- minigun: one per tick, very fast cd

		local spreadDeg = (style == 3 or style == 4) and (m.PlaneGunSpread or 4) or 0
		local bulletStyle = m.PlaneGunBulletStyle or 1

		for _, gun in pairs(PlaneGuns) do
			if gun and gun.Fire ~= false and gun.Handle then
				local origin = (PlaneRootCF * CFrame.new(gun.Off) * gun.Rot).Position
				for s = 1, shots do
					local dir = X.planeGunAimDir(origin)
					if spreadDeg > 0 then
						local rad = math.rad(spreadDeg)
						dir = (CFrame.lookAt(Vector3.zero, dir)
							* CFrame.Angles(
								(math.random() - 0.5) * 2 * rad,
								(math.random() - 0.5) * 2 * rad,
								0
							)).LookVector
					end
					if style == 2 then
						X.firePlaneGunBeam(origin, dir)
					end
					if bulletStyle == 4 then
						if not X.spawnPlaneHatBullet(origin, dir) then
							X.spawnPlaneNeonBullet(origin, dir, 1)
						end
					else
						X.spawnPlaneNeonBullet(origin, dir, bulletStyle)
					end
					if style == 3 and s < shots then
						task.wait(0.04)
					end
				end
			end
		end
		if m.PlaneGunSFX ~= false then
			X.playSFX(m.WeaponFireSFXId or "rbxassetid://131961136", m.PlaneVolume or 0.75)
		end
	end

	-- ---------- Plane ordnance: rise from underground, drop bomb/package, fire missile ----------
	function X.raisePlaneOrdnance(held)
		if not held then return end
		local _, _, hold = X.stashParams(held)
		held.UpUntil = os.clock() + math.max(hold or 1.2, 0.4)
		held.Up = held.Up or 0
	end

	-- Live-sync ordnance Off/Rot from module settings so launcher/bomb place+rot update in real time
	function X.syncPlaneOrdnanceFromSettings(slot, sideK, heightK, forwardK, rxK, ryK, rzK)
		if not slot then return end
		slot.Off = Vector3.new(
			tonumber(m[sideK]) or 0,
			tonumber(m[heightK]) or 0,
			tonumber(m[forwardK]) or 0
		)
		slot.Rot = CFrame.Angles(
			math.rad(tonumber(m[rxK]) or 0),
			math.rad(tonumber(m[ryK]) or 0),
			math.rad(tonumber(m[rzK]) or 0)
		)
	end

	function X.drivePlaneOrdnanceSlot(slot, dt)
		if not (slot and PlaneRootCF) then return end
		if not (slot.Handle and slot.Handle.Parent) then return end
		-- skip driving the real hat while it is in flight
		if slot._flying then return end
		local base = PlaneRootCF * CFrame.new(slot.Off or Vector3.zero) * (slot.Rot or CFrame.new())
		local held = slot.Held
		if held then
			base = X.stashShift(held, base, dt)
			if held.AP then
				X.driveHandle(held, base)
			else
				pcall(function() slot.Handle.CFrame = base end)
			end
		else
			pcall(function()
				slot.Handle.CFrame = base
				slot.Handle.AssemblyLinearVelocity = Vector3.zero
				slot.Handle.AssemblyAngularVelocity = Vector3.zero
			end)
		end
		slot._parkCF = base
	end

	-- drive one ordnance slot; when its STAY toggle is on it is locked at the live place/rot
	function X.stepPlaneOrdnanceSlot(slot, stayKey, dt)
		if not slot then return end
		slot.StayKey = stayKey
		local stay = m[stayKey] ~= false
		local held = slot.Held
		if held and not slot._flying then
			if stay then
				held.UpUntil = math.huge -- never sink away while STAY is on
			elseif held.UpUntil == math.huge then
				held.UpUntil = 0
			end
		end
		X.drivePlaneOrdnanceSlot(slot, dt)
		if stay and not slot._flying and PlaneRootCF and slot.Handle and slot.Handle.Parent then
			-- hard lock so physics / stash cannot drag it off the spot you set
			local lockCF = PlaneRootCF * CFrame.new(slot.Off or Vector3.zero) * (slot.Rot or CFrame.new())
			if held and held.AP then
				X.driveHandle(held, lockCF)
			else
				pcall(function()
					slot.Handle.CFrame = lockCF
					slot.Handle.AssemblyLinearVelocity = Vector3.zero
					slot.Handle.AssemblyAngularVelocity = Vector3.zero
				end)
			end
			slot._parkCF = lockCF
		end
	end

	-- UI toggle handler (Bomb / Package / Missile tubes / Bomb2)
	function X.setPlaneStay(key, on)
		m[key] = on and true or false
		local list = {}
		if key == "PlaneBombStay" then list = { X.PlaneBombHeld }
		elseif key == "PlanePackageStay" then list = { X.PlanePackageHeld }
		elseif key == "PlaneBomb2Stay" then list = { X.PlaneBomb2Held }
		elseif key == "PlaneMissileStay" then
			for i = 1, 5 do list[#list + 1] = X.PlaneMissileAmmoSlots and X.PlaneMissileAmmoSlots[i] or nil end
		end
		for _, sl in pairs(list) do
			if sl and sl.Held and not sl._flying then
				sl.Held.UpUntil = on and math.huge or 0
			end
		end
	end

	function X.stepPlaneOrdnance(dt)
		if not PlaneRootCF then return end
		-- real-time place / rot for every ordnance slot (launcher, bombs, package, ammo)
		if m.PlaneBombEnabled and X.PlaneBombHeld then
			X.syncPlaneOrdnanceFromSettings(X.PlaneBombHeld,
				"PlaneBombSide", "PlaneBombHeight", "PlaneBombForward",
				"PlaneBombRotX", "PlaneBombRotY", "PlaneBombRotZ")
			X.stepPlaneOrdnanceSlot(X.PlaneBombHeld, "PlaneBombStay", dt)
		end
		if m.PlanePackageEnabled and X.PlanePackageHeld then
			X.syncPlaneOrdnanceFromSettings(X.PlanePackageHeld,
				"PlanePackageSide", "PlanePackageHeight", "PlanePackageForward",
				"PlanePackageRotX", "PlanePackageRotY", "PlanePackageRotZ")
			X.stepPlaneOrdnanceSlot(X.PlanePackageHeld, "PlanePackageStay", dt)
		end
		if m.PlaneBomb2Enabled and X.PlaneBomb2Held then
			X.syncPlaneOrdnanceFromSettings(X.PlaneBomb2Held,
				"PlaneBomb2Side", "PlaneBomb2Height", "PlaneBomb2Forward",
				"PlaneBomb2RotX", "PlaneBomb2RotY", "PlaneBomb2RotZ")
			X.stepPlaneOrdnanceSlot(X.PlaneBomb2Held, "PlaneBomb2Stay", dt)
		end
		if m.PlaneMissileEnabled then
			local launcher = X.PlaneMissileLauncher
			if launcher then
				-- always live-sync place/rot from UI
				X.syncPlaneOrdnanceFromSettings(launcher,
					"PlaneMissileLauncherSide", "PlaneMissileLauncherHeight", "PlaneMissileLauncherForward",
					"PlaneMissileLauncherRotX", "PlaneMissileLauncherRotY", "PlaneMissileLauncherRotZ")
				-- LOCK: launcher never flies / never stays marked flying
				if m.PlaneMissileLauncherLock ~= false then
					launcher._flying = false
					if launcher.Held then
						-- keep above ground / visible while locked
						launcher.Held.Up = 1
						if m.PlaneMissileLauncherLockForce then
							launcher.Held.UpUntil = math.huge
						end
					end
				end
				X.drivePlaneOrdnanceSlot(launcher, dt)
				-- extra hard lock: re-apply CFrame after drive so physics cannot drag it
				if m.PlaneMissileLauncherLockForce and PlaneRootCF and launcher.Handle and launcher.Handle.Parent then
					local lockCF = PlaneRootCF * CFrame.new(launcher.Off or Vector3.zero) * (launcher.Rot or CFrame.new())
					if launcher.Held and launcher.Held.AP then
						X.driveHandle(launcher.Held, lockCF)
					else
						pcall(function()
							launcher.Handle.CFrame = lockCF
							launcher.Handle.AssemblyLinearVelocity = Vector3.zero
							launcher.Handle.AssemblyAngularVelocity = Vector3.zero
						end)
					end
					launcher._parkCF = lockCF
				end
			end
			-- park every missile tube that is not currently in flight (live per-slot place/rot)
			for i = 1, 5 do
				local ammo = (X.PlaneMissileAmmoSlots and X.PlaneMissileAmmoSlots[i]) or (i == 1 and X.PlaneMissileAmmo)
				if ammo then
					-- prefer per-tube offsets; fall back to shared missile offsets
					local sideK = "PlaneMissileSlotSide" .. i
					local heightK = "PlaneMissileSlotHeight" .. i
					local forwardK = "PlaneMissileSlotForward" .. i
					if m[sideK] == nil then sideK = "PlaneMissileSide" end
					if m[heightK] == nil then heightK = "PlaneMissileHeight" end
					if m[forwardK] == nil then forwardK = "PlaneMissileForward" end
					local rxK = "PlaneMissileSlotRotX" .. i
					local ryK = "PlaneMissileSlotRotY" .. i
					local rzK = "PlaneMissileSlotRotZ" .. i
					if m[rxK] == nil then rxK = "PlaneMissileRotX" end
					if m[ryK] == nil then ryK = "PlaneMissileRotY" end
					if m[rzK] == nil then rzK = "PlaneMissileRotZ" end
					X.syncPlaneOrdnanceFromSettings(ammo, sideK, heightK, forwardK, rxK, ryK, rzK)
					X.stepPlaneOrdnanceSlot(ammo, "PlaneMissileStay", dt)
				end
			end
		end
		-- step active falling / flying ordnance
		for i = #X.PlaneOrdnanceFlying, 1, -1 do
			local f = X.PlaneOrdnanceFlying[i]
			if not f or not f.Handle or not f.Handle.Parent then
				table.remove(X.PlaneOrdnanceFlying, i)
			else
				f.T = (f.T or 0) + dt
				local done = false
				if f.Mode == "fall" then
					local grav = f.Gravity or 40
					f.Vel = (f.Vel or Vector3.new(0, -(f.FallSpeed or 90), 0)) + Vector3.new(0, -grav, 0) * dt
					local step = f.Vel * dt
					local from = f.Pos or f.Origin
					-- ground / surface bounce via short ray along motion
					if f.Bounce ~= false then
						local hit = nil
						local rayDir = step
						if rayDir.Magnitude < 0.05 then
							rayDir = Vector3.new(0, -1.5, 0)
						end
						-- also probe downward so slow rolls still rest on ground
						local okR, res = pcall(function()
							return Workspace:Raycast(from + Vector3.new(0, 0.35, 0), rayDir + Vector3.new(0, -0.8, 0), X.getRP())
						end)
						if okR then hit = res end
						if hit and f.Vel.Y <= 0 then
							local n = hit.Normal
							local rest = tonumber(f.BounceAmt) or 0.55
							local fric = tonumber(f.BounceFriction) or 0.82
							local minB = tonumber(f.MinBounce) or 6
							-- reflect velocity off surface normal
							local vn = f.Vel:Dot(n)
							if vn < 0 then
								local reflected = f.Vel - n * (vn * (1 + rest))
								-- horizontal friction along plane
								local tangent = reflected - n * reflected:Dot(n)
								local normalPart = n * reflected:Dot(n)
								f.Vel = normalPart + tangent * fric
								if math.abs(f.Vel.Y) < minB and n.Y > 0.5 then
									-- settle: stay on ground, damp horizontal
									f.Vel = Vector3.new(f.Vel.X * 0.9, 0, f.Vel.Z * 0.9)
									if f.Vel.Magnitude < 1.5 then
										f.Vel = Vector3.zero
									end
								end
							end
							f.Pos = hit.Position + n * 0.55
							step = Vector3.zero
						else
							f.Pos = from + step
						end
					else
						f.Pos = from + step
					end
					local spinCF = f.Spin and CFrame.Angles(f.T * 4, f.T * 2, f.T * 1.5) or CFrame.new()
					-- tilt with velocity when moving
					local look = f.Vel.Magnitude > 2 and f.Vel.Unit or Vector3.new(0, -1, 0)
					local cf
					if look.Magnitude > 0.01 and math.abs(look.Y) < 0.98 then
						cf = CFrame.lookAt(f.Pos, f.Pos + look) * spinCF
					else
						cf = CFrame.new(f.Pos) * spinCF
					end
					if f.Held and f.Held.AP then X.driveHandle(f.Held, cf)
					else pcall(function() f.Handle.CFrame = cf end) end
					if f.T >= (f.Life or 5) then done = true end
				elseif f.Mode == "missile" then
					local dir = f.Dir
					if f.Homing and f.Homing > 0 and Mouse and Mouse.Hit then
						local want = (Mouse.Hit.Position - f.Pos).Unit
						dir = (dir + want * (f.Homing * dt * 3)).Unit
						f.Dir = dir
					end
					f.Pos = f.Pos + dir * (f.Speed or 200) * dt
					local cf = CFrame.lookAt(f.Pos, f.Pos + dir)
					if f.Spin then cf = cf * CFrame.Angles(0, 0, f.T * 18) end
					if f.Held and f.Held.AP then X.driveHandle(f.Held, cf)
					else pcall(function() f.Handle.CFrame = cf end) end
					if f.T >= (f.Life or 4) then done = true end
				end
				if done then
					if f.Return and f.ParkCF and f.Held then
						-- fly back toward park
						f.Mode = "return"
						f.T = 0
					elseif f.Return and f.ParkCF then
						pcall(function() f.Handle.CFrame = f.ParkCF end)
						table.remove(X.PlaneOrdnanceFlying, i)
						if f.Slot then f.Slot._flying = false end
					else
						if not f.Held then pcall(function() f.Handle:Destroy() end) end
						table.remove(X.PlaneOrdnanceFlying, i)
						if f.Slot then f.Slot._flying = false end
					end
				elseif f.Mode == "return" then
					local sl = f.Slot
					local keepStay = sl and sl.StayKey and m[sl.StayKey] ~= false
					if keepStay and PlaneRootCF then
						-- fly back to the LIVE place/rot (follows the plane + any slider change)
						f.ParkCF = PlaneRootCF * CFrame.new(sl.Off or Vector3.zero) * (sl.Rot or CFrame.new())
					end
					local to = f.ParkCF.Position - f.Pos
					local step = (f.ReturnSpeed or 120) * dt
					if to.Magnitude <= step then
						if f.Held and f.Held.AP then X.driveHandle(f.Held, f.ParkCF)
						else pcall(function() f.Handle.CFrame = f.ParkCF end) end
						table.remove(X.PlaneOrdnanceFlying, i)
						if f.Slot then f.Slot._flying = false end
						if f.Held then f.Held.UpUntil = keepStay and math.huge or 0 end -- STAY keeps it up; otherwise sink again if underground on
					else
						f.Pos = f.Pos + to.Unit * step
						local cf = CFrame.lookAt(f.Pos, f.Pos + to.Unit)
						if f.Held and f.Held.AP then X.driveHandle(f.Held, cf)
						else pcall(function() f.Handle.CFrame = cf end) end
					end
				end
			end
		end
	end

	function X.launchPlaneDrop(slot, opts)
		if not (slot and slot.Handle and PlaneRootCF) then return false end
		if slot._flying then return false end
		opts = opts or {}
		local held = slot.Held
		if held then
			X.raisePlaneOrdnance(held)
			held.Up = 1 -- snap visible for the drop
		end
		-- always spawn from plane body position (not underground)
		local surfaceCF = PlaneRootCF * CFrame.new(slot.Off) * slot.Rot
		local origin = surfaceCF.Position
		local count = math.max(1, math.floor(opts.Count or 1))
		local spread = opts.Spread or 0
		local fall = opts.FallSpeed or 90
		local life = opts.Life or 5
		local doReturn = opts.Return ~= false
		local retSpd = opts.ReturnSpeed or 120
		local doBounce = opts.Bounce ~= false
		local bounceAmt = opts.BounceAmt or 0.55
		local bounceFric = opts.BounceFriction or 0.82
		local minBounce = opts.MinBounce or 6
		-- primary uses the real hat; extras are local clones
		for i = 1, count do
			local part, useHeld = slot.Handle, held
			if i > 1 then
				part = X.cloneHandle(slot.Handle, "PlaneDrop_" .. i)
				if part then part.Parent = workspace end
				useHeld = nil
			end
			if part then
				slot._flying = (i == 1)
				local side = (i - (count + 1) / 2) * spread
				local pos = origin + (PlaneRootCF.RightVector * side)
				-- inherit a bit of plane velocity so bombs don't fall straight under
				local planeVel = (PlaneRootCF.LookVector * (PlaneVel or 0) * 0.35)
				table.insert(X.PlaneOrdnanceFlying, {
					Handle = part, Held = useHeld, Slot = (i == 1) and slot or nil,
					Mode = "fall", Origin = pos, Pos = pos,
					Vel = Vector3.new(0, -fall * 0.35, 0) + (PlaneRootCF.LookVector * -8) + planeVel,
					FallSpeed = fall, Life = life, T = 0, Spin = true,
					Return = doReturn and (i == 1), ReturnSpeed = retSpd,
					ParkCF = surfaceCF,
					Bounce = doBounce, BounceAmt = bounceAmt,
					BounceFriction = bounceFric, MinBounce = minBounce,
					Gravity = 40,
				})
			end
		end
		return true
	end

	function X.firePlaneBomb()
		if not (m.PlaneEnabled and m.PlaneBombEnabled and m.PlaneRide) then return end
		if os.clock() - (X.PlaneBombLast or 0) < (m.PlaneBombCooldown or 1.4) then return end
		if not X.PlaneBombHeld then
			warn("[HatStand] Bomb: no hat assigned — pick a bomb hat and Rebuild Plane")
			return
		end
		X.PlaneBombLast = os.clock()
		X.launchPlaneDrop(X.PlaneBombHeld, {
			Count = m.PlaneBombCount, Spread = m.PlaneBombSpread,
			FallSpeed = m.PlaneBombFallSpeed, Life = m.PlaneBombLife,
			Return = m.PlaneBombReturn, ReturnSpeed = m.PlaneBombReturnSpeed,
			Bounce = m.PlaneBombBounce, BounceAmt = m.PlaneBombBounceAmt,
			BounceFriction = m.PlaneBombBounceFriction, MinBounce = m.PlaneBombMinBounce,
		})
		if m.PlaneBombSFX then X.playSFX(m.WeaponFireSFXId or "rbxassetid://131961136", m.PlaneVolume or 0.75) end
		warn("[HatStand] BOMB dropped")
	end

	function X.firePlanePackage()
		if not (m.PlaneEnabled and m.PlanePackageEnabled and m.PlaneRide) then return end
		if os.clock() - (X.PlanePackageLast or 0) < (m.PlanePackageCooldown or 1.8) then return end
		if not X.PlanePackageHeld then
			warn("[HatStand] Package: no hat assigned")
			return
		end
		X.PlanePackageLast = os.clock()
		X.launchPlaneDrop(X.PlanePackageHeld, {
			Count = m.PlanePackageCount, Spread = m.PlanePackageSpread,
			FallSpeed = m.PlanePackageFallSpeed, Life = m.PlanePackageLife,
			Return = m.PlanePackageReturn, ReturnSpeed = m.PlanePackageReturnSpeed,
			Bounce = m.PlanePackageBounce, BounceAmt = m.PlanePackageBounceAmt,
			BounceFriction = m.PlanePackageBounceFriction, MinBounce = m.PlaneBombMinBounce or 6,
		})
		if m.PlanePackageSFX then X.playSFX(m.WeaponFireSFXId or "rbxassetid://131961136", m.PlaneVolume or 0.75) end
		warn("[HatStand] PACKAGE dropped")
	end

	function X.firePlaneBomb2()
		if not (m.PlaneEnabled and m.PlaneBomb2Enabled and m.PlaneRide) then return end
		if os.clock() - (X.PlaneBomb2Last or 0) < (m.PlaneBomb2Cooldown or 1.6) then return end
		if not X.PlaneBomb2Held then
			warn("[HatStand] Bomb2: no hat assigned")
			return
		end
		X.PlaneBomb2Last = os.clock()
		X.launchPlaneDrop(X.PlaneBomb2Held, {
			Count = m.PlaneBomb2Count, Spread = m.PlaneBomb2Spread,
			FallSpeed = m.PlaneBomb2FallSpeed, Life = m.PlaneBomb2Life,
			Return = m.PlaneBomb2Return, ReturnSpeed = m.PlaneBomb2ReturnSpeed or m.PlaneBombReturnSpeed or 120,
			Bounce = m.PlaneBomb2Bounce, BounceAmt = m.PlaneBomb2BounceAmt,
			BounceFriction = m.PlaneBomb2BounceFriction, MinBounce = m.PlaneBombMinBounce or 6,
		})
		if m.PlaneBombSFX then X.playSFX(m.WeaponFireSFXId or "rbxassetid://131961136", m.PlaneVolume or 0.75) end
		warn("[HatStand] BOMB2 dropped")
	end

	function X.pickMissileTube()
		-- return next ready ammo slot index + slot, cycling from active
		local slots = X.PlaneMissileAmmoSlots or {}
		local start = math.clamp(math.floor(m.PlaneMissileActiveSlot or 1), 1, 5)
		local now = os.clock()
		local shotCd = m.PlaneMissileShotCooldown or 0.22
		local fullCd = m.PlaneMissileCooldown or 1.1
		-- if every tube is empty/flying and last full volley still cooling, block
		local anyReady = false
		for i = 1, 5 do
			local s = slots[i]
			if s and s.Handle and s.Handle.Parent and not s._flying and (m["PlaneMissileSlotEnabled" .. i] ~= false) then
				anyReady = true
				break
			end
		end
		if not anyReady then
			-- wait for full reload once all tubes spent
			if now - (X.PlaneMissileMagEmptyAt or 0) < fullCd then
				return nil, nil
			end
			-- tubes may have returned; allow scan again
		end
		for offset = 0, 4 do
			local i = ((start - 1 + offset) % 5) + 1
			if m["PlaneMissileSlotEnabled" .. i] ~= false then
				local s = slots[i]
				if s and s.Handle and s.Handle.Parent and not s._flying then
					local last = (X.PlaneMissileTubeLast and X.PlaneMissileTubeLast[i]) or 0
					-- per-tube small cooldown so the same tube can't double-tap instantly on return
					if now - last >= shotCd * 0.5 then
						return i, s
					end
				end
			end
		end
		return nil, nil
	end

	function X.firePlaneMissile()
		if not (m.PlaneEnabled and m.PlaneMissileEnabled and m.PlaneRide) then return end
		local now = os.clock()
		local shotCd = m.PlaneMissileShotCooldown or 0.22
		if now - (X.PlaneMissileLast or 0) < shotCd then return end

		-- ensure slot table exists (legacy single ammo)
		if not X.PlaneMissileAmmoSlots or not next(X.PlaneMissileAmmoSlots) then
			if X.PlaneMissileAmmo then
				X.PlaneMissileAmmoSlots = { [1] = X.PlaneMissileAmmo }
			end
		end

		local tubeIdx, ammo = X.pickMissileTube()
		if not ammo then
			-- nothing loaded
			if not X.PlaneMissileMagEmptyAt then X.PlaneMissileMagEmptyAt = now end
			return
		end
		X.PlaneMissileMagEmptyAt = nil

		local launcher = X.PlaneMissileLauncher
		X.PlaneMissileLast = now
		X.PlaneMissileTubeLast = X.PlaneMissileTubeLast or {}
		X.PlaneMissileTubeLast[tubeIdx] = now
		m.PlaneMissileActiveSlot = tubeIdx
		X.PlaneMissileAmmo = ammo

		local lockLauncher = m.PlaneMissileLauncherLock ~= false
		if launcher and launcher.Held and not lockLauncher then
			X.raisePlaneOrdnance(launcher.Held)
			launcher.Held.Up = 1
		end
		local sameHandle = launcher and launcher.Handle and ammo.Handle == launcher.Handle
		if ammo.Held and not sameHandle then
			X.raisePlaneOrdnance(ammo.Held)
			ammo.Held.Up = 1
		end

		-- muzzle origin = launcher tip, else this tube's park
		local surfaceCF
		if launcher then
			X.syncPlaneOrdnanceFromSettings(launcher,
				"PlaneMissileLauncherSide", "PlaneMissileLauncherHeight", "PlaneMissileLauncherForward",
				"PlaneMissileLauncherRotX", "PlaneMissileLauncherRotY", "PlaneMissileLauncherRotZ")
			surfaceCF = PlaneRootCF * CFrame.new(launcher.Off) * launcher.Rot
			if lockLauncher then
				launcher._flying = false
				if launcher.Held then
					launcher.Held.Up = 1
					launcher.Held.UpUntil = math.huge
					X.driveHandle(launcher.Held, surfaceCF)
				else
					pcall(function() launcher.Handle.CFrame = surfaceCF end)
				end
				launcher._parkCF = surfaceCF
			end
			surfaceCF = surfaceCF * CFrame.new(0, 0, -1.2)
		else
			local side = m["PlaneMissileSlotSide" .. tubeIdx]
			if side == nil then side = m.PlaneMissileSide or 0 end
			local height = m["PlaneMissileSlotHeight" .. tubeIdx]
			if height == nil then height = m.PlaneMissileHeight or -0.8 end
			local forward = m["PlaneMissileSlotForward" .. tubeIdx]
			if forward == nil then forward = m.PlaneMissileForward or 1.5 end
			surfaceCF = PlaneRootCF * CFrame.new(side, height, forward) * CFrame.Angles(
				math.rad(m["PlaneMissileSlotRotX" .. tubeIdx] or m.PlaneMissileRotX or 0),
				math.rad(m["PlaneMissileSlotRotY" .. tubeIdx] or m.PlaneMissileRotY or 0),
				math.rad(m["PlaneMissileSlotRotZ" .. tubeIdx] or m.PlaneMissileRotZ or 0)
			) * CFrame.new(0, 0, -1.2)
		end

		local origin = surfaceCF.Position
		local dir = PlaneRootCF.LookVector
		if m.PlaneMissileTrackMouse and Mouse and Mouse.Hit then
			local to = Mouse.Hit.Position - origin
			if to.Magnitude > 1 then dir = to.Unit end
		end

		local count = math.max(1, math.floor(m.PlaneMissileCount or 1))
		local spread = m.PlaneMissileSpread or 3
		for i = 1, count do
			local part, useHeld = ammo.Handle, ammo.Held
			local mustClone = (i > 1) or sameHandle or (lockLauncher and launcher and ammo.Handle == launcher.Handle)
			if mustClone then
				part = X.cloneHandle(ammo.Handle, "PlaneMissile_T" .. tubeIdx .. "_" .. i)
				if part then part.Parent = workspace end
				useHeld = nil
				if sameHandle then ammo._flying = false end
			else
				ammo._flying = true
			end
			if part then
				local yaw = math.rad((i - (count + 1) / 2) * spread)
				local d = (CFrame.lookAt(Vector3.zero, dir) * CFrame.Angles(0, yaw, 0)).LookVector
				if m.PlaneMissileTrail then
					pcall(function()
						local a0 = Instance.new("Attachment"); a0.Parent = part
						local a1 = Instance.new("Attachment"); a1.Position = Vector3.new(0, 0, -1.2); a1.Parent = part
						local tr = Instance.new("Trail")
						tr.Attachment0, tr.Attachment1 = a0, a1
						tr.Lifetime = 0.5
						tr.FaceCamera = true
						tr.Color = ColorSequence.new(Color3.fromRGB(255, 180, 60))
						tr.Parent = part
					end)
				end
				table.insert(X.PlaneOrdnanceFlying, {
					Handle = part, Held = useHeld, Slot = (i == 1) and ammo or nil,
					Mode = "missile", Pos = origin, Dir = d,
					Speed = m.PlaneMissileSpeed or 200, Life = m.PlaneMissileLife or 4,
					Homing = m.PlaneMissileHoming or 0, T = 0,
					Spin = m.PlaneMissileSpin, Return = m.PlaneMissileReturn and (i == 1),
					ReturnSpeed = m.PlaneMissileReturnSpeed or 140,
					ParkCF = ammo._parkCF or CFrame.new(origin),
					TubeIndex = tubeIdx,
				})
			end
		end

		-- auto-cycle to next tube for fast follow-up shot
		if m.PlaneMissileAutoCycle ~= false then
			local nextSlot = (tubeIdx % 5) + 1
			for _ = 1, 5 do
				if m["PlaneMissileSlotEnabled" .. nextSlot] == false then
					nextSlot = (nextSlot % 5) + 1
				else
					break
				end
			end
			m.PlaneMissileActiveSlot = nextSlot
		end

		-- if no tubes left ready, start full mag reload timer
		local left = 0
		for i = 1, 5 do
			local s = X.PlaneMissileAmmoSlots and X.PlaneMissileAmmoSlots[i]
			if s and s.Handle and not s._flying and m["PlaneMissileSlotEnabled" .. i] ~= false then
				left = left + 1
			end
		end
		if left == 0 then
			X.PlaneMissileMagEmptyAt = now
		end

		if m.PlaneMissileSFX then X.playSFX(m.WeaponFireSFXId or "rbxassetid://131961136", m.PlaneVolume or 0.75, nil, 0.85) end
		warn("[HatStand] MISSILE tube " .. tostring(tubeIdx) .. " launched")
	end


	-- Auto-rebuild helpers: if configured hats are missing from slots, rebuild
	X.slotsAlive = function(slots)
		if not slots then return false end
		local any, dead = false, false
		for _, s in pairs(slots) do
			if s then
				any = true
				if not (s.Handle and s.Handle.Parent) then dead = true end
			end
		end
		return any, dead
	end

	X.anyHatConfigured = function(prefix, n)
		for i = 1, n do
			if X.trim(m[prefix .. i] or "") ~= "" then return true end
		end
		return false
	end

	function X.checkVehicleRebuilds(now)
		now = now or os.clock()
		-- Plane
		if m.PlaneEnabled and m.PlaneAutoRebuild then
			if now - (LastPlaneCheck or 0) > 0.6 then
				LastPlaneCheck = now
				local hasFrames = PlaneFull ~= nil or next(PlaneFrames) ~= nil or next(PlaneProps) ~= nil or next(PlaneEngines) ~= nil
				local configured = (m.PlaneFullMode and X.trim(m.PlaneFullHat or "") ~= "")
					or X.anyHatConfigured("PlaneFrameHat", 10)
					or X.anyHatConfigured("PlanePropHat", 2)
					or X.anyHatConfigured("PlaneEngineHat", 2)
					or X.anyHatConfigured("PlaneGunHat", 4)
				if configured then
					local alive = PlaneFull and PlaneFull.Handle and PlaneFull.Handle.Parent
					local dead = PlaneFull and not (PlaneFull.Handle and PlaneFull.Handle.Parent)
					for _, group in ipairs({ PlaneFrames, PlaneProps, PlaneEngines, PlaneGuns }) do
						local a, d = X.slotsAlive(group)
						if a then alive = true end
						if d then dead = true end
					end
					if (not alive) or dead then
						NeedPlaneRebuild = true
					end
				end
			end
		end
		-- Moto
		if m.MotoEnabled and m.MotoAutoRebuild then
			if now - (LastMotoCheck or 0) > 0.6 then
				LastMotoCheck = now
				local configured = X.anyHatConfigured("MotoHat", 6) or X.anyHatConfigured("MotoWheelHat", 2) or X.trim(m.MotoEngineHat or "") ~= ""
				if configured then
					local a1, d1 = X.slotsAlive(MotoSlots)
					local a2, d2 = X.slotsAlive(MotoWheels)
					local engDead = MotoEngine and not (MotoEngine.Handle and MotoEngine.Handle.Parent)
					if (not a1 and not a2 and not MotoEngine) or d1 or d2 or engDead then
						NeedMotoRebuild = true
					end
				end
			end
		end
		-- Planet
		if m.PlanetEnabled and m.PlanetAutoRebuild then
			if now - (LastPlanetCheck or 0) > 0.6 then
				LastPlanetCheck = now
				if X.anyHatConfigured("PlanetHat", 10) then
					local a, d = X.slotsAlive(PlanetSlots)
					if (not a) or d then NeedPlanetRebuild = true end
				end
			end
		end
		-- Tool
		

		if m.ToolEnabled and m.ToolAutoRebuild then
			if now - (LastToolCheck or 0) > 0.6 then
				LastToolCheck = now
				if X.anyHatConfigured("ToolHat", 6) then
					local a, d = X.slotsAlive(ToolSlots)
					if (not a) or d then NeedToolRebuild = true end
				end
			end
		end
		-- Car
		if m.CarEnabled and m.CarAutoRebuild then
			if now - (LastCarCheck or 0) > 0.6 then
				LastCarCheck = now
				local configured = X.anyHatConfigured("CarHat", 8) or X.anyHatConfigured("CarWheelHat", 4) or X.trim(m.CarEngineHat or "") ~= ""
				if configured then
					local a1, d1 = X.slotsAlive(CarSlots)
					local a2, d2 = X.slotsAlive(CarWheels)
					local engDead = CarEngine and not (CarEngine.Handle and CarEngine.Handle.Parent)
					if (not a1 and not a2 and not CarEngine) or d1 or d2 or engDead then
						NeedCarRebuild = true
					end
				end
			end
		end
	end

	--------------------------------------------------------------
	-- OWN DANCE: record Steve's Uhhhhhh dance (pose + sounds), replay on stand / clone on their own
	--------------------------------------------------------------
	;(function()
		local HttpService = game:GetService("HttpService")
		local SoundService = game:GetService("SoundService")
		local DANCE_FILE = "HatStand_Dances" .. SUF .. ".json"
		local SKIP_SOUND = {
			Running = true, Jumping = true, Landing = true, Climbing = true,
			GettingUp = true, FreeFalling = true, Splash = true, Swimming = true,
		}

		X.DanceRecs = X.DanceRecs or {}
		X.OwnDance = X.OwnDance or {}
		X.DanceRec = nil
		X.OwnPick = X.OwnPick or ""

		function X.danceRecNames()
			local n = {}
			for k in pairs(X.DanceRecs) do n[#n + 1] = k end
			table.sort(n)
			return n
		end

		local function r4(v) return math.floor(v * 10000 + 0.5) / 10000 end

		function X.saveDanceRecs()
			if type(writefile) ~= "function" then return false end
			local out = {}
			for name, rec in pairs(X.DanceRecs) do
				local fr = {}
				for i, f in ipairs(rec.frames) do
					local e = { r4(f.t) }
					for _, limb in ipairs(LIMB_NAMES) do
						local c = f[limb]
						if c then
							local comps = { c:GetComponents() }
							for j = 1, #comps do comps[j] = r4(comps[j]) end
							e[#e + 1] = comps
						else
							e[#e + 1] = false
						end
					end
					fr[i] = e
				end
				out[name] = { len = rec.len, frames = fr, sounds = rec.sounds }
			end
			local ok = pcall(function() writefile(DANCE_FILE, HttpService:JSONEncode(out)) end)
			return ok
		end

		function X.loadDanceRecs()
			if type(readfile) ~= "function" or type(isfile) ~= "function" then return end
			local ok, data = pcall(function()
				if isfile(DANCE_FILE) then return HttpService:JSONDecode(readfile(DANCE_FILE)) end
			end)
			if not (ok and type(data) == "table") then return end
			for name, rec in pairs(data) do
				if type(rec) == "table" and type(rec.frames) == "table" and not X.DanceRecs[name] then
					local frames = {}
					for i, e in ipairs(rec.frames) do
						local f = { t = e[1] }
						for li, limb in ipairs(LIMB_NAMES) do
							local c = e[li + 1]
							if type(c) == "table" and #c == 12 then f[limb] = CFrame.new(table.unpack(c)) end
						end
						frames[i] = f
					end
					if #frames >= 2 then
						X.DanceRecs[name] = { frames = frames, sounds = rec.sounds or {}, len = tonumber(rec.len) or frames[#frames].t }
						if X.OwnPick == "" then X.OwnPick = name end
					end
				end
			end
		end

		function X.deleteDanceRec(name)
			name = X.trim(name or X.OwnPick or "")
			if X.DanceRecs[name] then
				X.DanceRecs[name] = nil
				if X.OwnPick == name then X.OwnPick = (X.danceRecNames()[1]) or "" end
				pcall(X.saveDanceRecs)
				warn("[HatStand] deleted recording '" .. name .. "'")
			end
		end

		function X.cycleDanceRec()
			local names = X.danceRecNames()
			if #names == 0 then warn("[HatStand] no recordings yet") return "" end
			local at = 0
			for i, n in ipairs(names) do if n == X.OwnPick then at = i break end end
			X.OwnPick = names[(at % #names) + 1]
			warn("[HatStand] selected recording: " .. X.OwnPick)
			return X.OwnPick
		end

		function X.startDanceRec(name, secs, playName)
			if X.DanceRec then X.finishDanceRec() end
			name = X.trim(name or "")
			if name == "" then name = "Dance " .. tostring(#X.danceRecNames() + 1) end
			X.DanceRec = {
				name = name, frames = {}, sounds = {}, seen = {},
				t = 0, acc = 0, sacc = 0, maxT = math.clamp(tonumber(secs) or 12, 1, 120),
			}
			warn("[HatStand] recording '" .. name .. "' ... (Stop to finish early)")
			if X.trim(playName or "") ~= "" then pcall(X.playDance, playName) end
		end

		function X.finishDanceRec()
			local r = X.DanceRec
			if not r then return end
			X.DanceRec = nil
			local f = r.frames
			if #f < 8 then
				warn("[HatStand] recording too short or no source rig found - nothing saved")
				return
			end
			-- trim the idle lead-in (time between pressing record and the dance actually starting)
			local first = f[1]
			local startI = 1
			for i = 2, #f do
				local dev = 0
				for _, limb in ipairs(LIMB_NAMES) do
					local a, b = first[limb], f[i][limb]
					if a and b then
						dev = dev + (a.LookVector - b.LookVector).Magnitude + (a.UpVector - b.UpVector).Magnitude + (a.Position - b.Position).Magnitude
					end
				end
				if dev > 0.25 then startI = math.max(1, i - 3) break end
			end
			local off = f[startI].t
			local frames = {}
			for i = startI, #f do
				local fr = f[i]
				fr.t = fr.t - off
				frames[#frames + 1] = fr
			end
			for _, s in ipairs(r.sounds) do
				local nt = s.t - off
				if nt < 0 then s.pos = (s.pos or 0) - nt nt = 0 end
				s.t = nt
			end
			table.sort(r.sounds, function(a, b) return a.t < b.t end)
			X.DanceRecs[r.name] = { frames = frames, sounds = r.sounds, len = frames[#frames].t }
			X.OwnPick = r.name
			warn("[HatStand] saved recording '" .. r.name .. "' (" .. #frames .. " frames, " .. #r.sounds .. " sounds, "
				.. string.format("%.1f", frames[#frames].t) .. "s)")
			pcall(X.saveDanceRecs)
			return r.name
		end

		local function checkSound(r, s)
			if not s:IsA("Sound") or r.seen[s] or SKIP_SOUND[s.Name] then return end
			local playing = false
			pcall(function() playing = s.IsPlaying end)
			if not playing then return end
			r.seen[s] = true
			local pos = 0
			pcall(function() pos = s.TimePosition end)
			r.sounds[#r.sounds + 1] = {
				t = math.max(0, r.t - pos), pos = math.max(0, pos - r.t),
				id = s.SoundId, vol = s.Volume, speed = s.PlaybackSpeed, looped = s.Looped,
			}
		end

		local function scanSounds(r, root)
			if not root then return end
			local list = root:GetDescendants()
			for i = 1, #list do checkSound(r, list[i]) end
		end

		function X.stepDanceRec(dt)
			local r = X.DanceRec
			if not r then return end
			r.t = r.t + dt
			r.acc = r.acc + dt
			if r.acc >= 1 / 30 then
				r.acc = r.acc % (1 / 30)
				local s = X.sampleRig()
				if s then
					local fr = { t = r.t }
					for _, limb in ipairs(LIMB_NAMES) do fr[limb] = s[limb] end
					r.frames[#r.frames + 1] = fr
				end
			end
			r.sacc = r.sacc + dt
			if r.sacc >= 0.15 then
				r.sacc = 0
				local model = X.getSourceRig()
				scanSounds(r, model)
				if LocalPlayer.Character ~= model then scanSounds(r, LocalPlayer.Character) end
				scanSounds(r, SoundService)
				for _, c in ipairs(Workspace:GetChildren()) do checkSound(r, c) end
			end
			if r.t >= r.maxT then X.finishDanceRec() end
		end

		local function stopSounds(od)
			if od and od.snds then
				for _, s in ipairs(od.snds) do pcall(function() s:Stop() s:Destroy() end) end
				od.snds = {}
			end
		end

		function X.stopOwnDance(tg)
			if tg == "Both" then X.stopOwnDance("Stand") X.stopOwnDance("Clone") return end
			local od = X.OwnDance[tg]
			if od then stopSounds(od) end
			X.OwnDance[tg] = nil
			if tg == "Clone" then X.CloneBlend = nil end
		end

		function X.playOwnDance(tg, name)
			name = X.trim(name or X.OwnPick or "")
			local rec = X.DanceRecs[name]
			if not rec then warn("[HatStand] no recording selected - record one first") return false end
			if tg == "Both" then X.playOwnDance("Stand", name) X.playOwnDance("Clone", name) return true end
			X.stopOwnDance(tg)
			X.OwnDance[tg] = { rec = rec, name = name, t = 0, idx = 1, sIdx = 1, snds = {}, out = {}, tg = tg }
			return true
		end

		local function playSnd(od, s)
			local parent = X.getFollowRoot()
			if od.tg == "Clone" then
				for _, d in pairs(X.CloneLimbs) do
					if d.Part and d.Part.Parent then parent = d.Part break end
				end
			end
			if not parent then return end
			pcall(function()
				local snd = Instance.new("Sound")
				snd.Name = "HS_OwnDanceSound"
				snd.SoundId = s.id
				snd.Volume = s.vol or 0.5
				snd.PlaybackSpeed = (s.speed or 1) * (m.OwnDanceSpeed or 1)
				snd.Looped = s.looped or false
				snd.Parent = parent
				snd.TimePosition = s.pos or 0
				snd:Play()
				od.snds[#od.snds + 1] = snd
				if not snd.Looped then
					snd.Ended:Connect(function() pcall(function() snd:Destroy() end) end)
				end
			end)
		end

		function X.ownDanceSample(od, dt)
			local rec = od.rec
			local fr = rec.frames
			local n = #fr
			if n < 2 then od.Finished = true return nil end
			od.t = od.t + dt * (m.OwnDanceSpeed or 1)
			if od.t >= rec.len then
				if m.OwnDanceLoop ~= false then
					od.t = od.t % math.max(rec.len, 0.05)
					od.idx, od.sIdx = 1, 1
					stopSounds(od)
				else
					od.Finished = true
					return nil
				end
			end
			if m.OwnDanceSounds ~= false then
				local snd = rec.sounds
				while od.sIdx <= #snd and snd[od.sIdx].t <= od.t do
					playSnd(od, snd[od.sIdx])
					od.sIdx = od.sIdx + 1
				end
			end
			local i = od.idx
			if i >= n then i = 1 end
			while i > 1 and fr[i].t > od.t do i = i - 1 end
			while i < n - 1 and fr[i + 1].t <= od.t do i = i + 1 end
			od.idx = i
			local a, b = fr[i], fr[i + 1]
			local span = b.t - a.t
			local k = span > 1e-4 and math.clamp((od.t - a.t) / span, 0, 1) or 0
			local out = od.out
			for _, limb in ipairs(LIMB_NAMES) do
				local ca, cb = a[limb], b[limb]
				if ca and cb then out[limb] = ca:Lerp(cb, k) else out[limb] = ca or cb end
			end
			return out
		end
	end)()

	--------------------------------------------------------------
	-- HELLCOPTER: hat frames + propellers + weapons (hat bullets), physics ride
	--------------------------------------------------------------
	;(function()
		X.HeliFrames, X.HeliProps, X.HeliWpns = {}, {}, {}
		X.HeliPool = {}
		X.HeliMissiles = {}
		X.HeliLaunchers = {}
		X.HeliMissileFlight = {}
		X.HeliBullets = {}
		X.HeliCount = 0
		X.HeliRootCF = nil
		X.HeliYaw, X.HeliPitch, X.HeliRoll, X.HeliRPM = 0, 0, 0, 0
		X.HeliLastBuild = 0
		X.HeliLastShot = 0
		X.HeliFireHeld = false
		X.HeliWasRiding = false


		-- engine sound: synthesised rotor "wop-wop" WAV written to the executor workspace (no Roblox audio id needed)
		local function buildHeliWav()
			local sr, len, thumps = 22050, 22050, 12
			local twoPi = math.pi * 2
			local seed = 12345
			local function rnd()
				seed = (seed * 1103515245 + 12345) % 2147483648
				return seed / 1073741824 - 1
			end
			local raw, n1, n2 = {}, {}, {}
			for i = 1, len do raw[i] = rnd() end
			-- circular low-pass (two passes so the loop seam is smooth)
			local a1, a2 = 0, 0
			for pass = 1, 2 do
				for i = 1, len do
					a1 = a1 + (raw[i] - a1) * 0.22
					a2 = a2 + (raw[i] - a2) * 0.035
					if pass == 2 then n1[i] = a1 n2[i] = a2 end
				end
			end
			local buf, peak = {}, 0
			for i = 0, len - 1 do
				local t = i / sr
				local ph = (t * thumps) % 1
				local ph2 = (ph + 0.5) % 1
				local ts = ph / thumps
				local ts2 = ph2 / thumps
				local e1 = (1 - math.exp(-ph * 600)) * math.exp(-ph * 10)
				local e2 = (1 - math.exp(-ph2 * 600)) * math.exp(-ph2 * 14)
				local v = 0.80 * e1 * math.sin(twoPi * 66 * ts)
					+ 0.45 * e1 * n1[i + 1]
					+ 0.28 * e2 * math.sin(twoPi * 92 * ts2)
					+ 0.16 * e2 * n1[i + 1]
					+ 0.10 * math.sin(twoPi * 138 * t)
					+ 0.05 * math.sin(twoPi * 276 * t)
					+ 0.22 * n2[i + 1]
				buf[i + 1] = v
				if math.abs(v) > peak then peak = math.abs(v) end
			end
			local k = peak > 0 and (0.85 * 32767 / peak) or 1
			local parts = {}
			for i = 1, len do
				parts[i] = string.pack("<i2", math.floor(buf[i] * k + 0.5))
			end
			local data = table.concat(parts)
			local hdr = "RIFF" .. string.pack("<I4", 36 + #data) .. "WAVEfmt "
				.. string.pack("<I4I2I2I4I4I2I2", 16, 1, 1, sr, sr * 2, 2, 16)
				.. "data" .. string.pack("<I4", #data)
			return hdr .. data
		end

		function X.heliEngineUrl()
			if X.HeliAssetTried then return X.HeliAssetUrl end
			X.HeliAssetTried = true
			local gca = getcustomasset or getsynasset
			if type(writefile) ~= "function" or type(gca) ~= "function" then return nil end
			local ok, url = pcall(function()
				writefile("HatStand_HeliEngine.wav", buildHeliWav())
				return gca("HatStand_HeliEngine.wav")
			end)
			if ok and type(url) == "string" and url ~= "" then
				X.HeliAssetUrl = url
				return url
			end
			warn("[HatStand] could not create the generated engine sound, using the Roblox asset id instead")
			return nil
		end

		local function killSnd(snd)
			if snd then pcall(function() snd:Stop() snd:Destroy() end) end
		end

		function X.resetHeliEngine()
			local E = X.HeliEng
			if E then killSnd(E.start) killSnd(E.idle) killSnd(E.gen) end
			X.HeliEng = nil
		end

		function X.resetHeliMini()
			local M = X.HeliMini
			if M then killSnd(M.loop) killSnd(M.stop) end
			X.HeliMini = nil
		end

		function X.resetHeliSound()
			X.resetHeliEngine()
			X.resetHeliMini()
		end

		local function newSnd(parent, name, id, looped)
			local snd = Instance.new("Sound")
			snd.Name = name
			snd.SoundId = id
			snd.Looped = looped or false
			snd.Volume = 0
			snd.RollOffMinDistance = 25
			snd.RollOffMaxDistance = 500
			snd.Parent = parent
			return snd
		end

		-- a sound that is still not loaded a few seconds after creation is treated as failed
		local function soundBad(snd, born)
			if not snd then return true end
			local ok, loaded = pcall(function() return snd.IsLoaded end)
			if ok and loaded then return false end
			return (os.clock() - born) > 5
		end

		function X.stepHeliAudio(dt, followRoot, rpm, riding)
			local sfx = m.HeliSFX ~= false
			local engineOn = sfx and m.HeliEngine == true
			local mode = X.HeliForceGen and 2 or (m.HeliEngineMode or 1)
			local E = X.HeliEng
			if E and (E.parent ~= followRoot or not followRoot.Parent or E.mode ~= mode) then
				X.resetHeliEngine()
				E = nil
			end
			local vol0 = m.HeliVolume or 1
			local pitchM = m.HeliPitch or 1
			local speedF = 0
			if riding then
				speedF = math.clamp(followRoot.AssemblyLinearVelocity.Magnitude / math.max(m.HeliMaxSpeed or 120, 1), 0, 1)
			end

			-- ===== engine: turn-on clip, then idle loop =====
			if sfx and (engineOn or rpm > 0.03) then
				if not E then
					E = { parent = followRoot, mode = mode, born = os.clock(), fade = 0, wasOn = false, startT = 0 }
					if mode == 2 then
						local url = X.heliEngineUrl()
						E.gen = newSnd(followRoot, "HS_HeliEngine",
							url or tostring(m.HeliSFXId or m.PlaneEngineSFXId or "rbxassetid://13114759"), true)
						E.gen:Play()
					else
						E.start = newSnd(followRoot, "HS_HeliStart", tostring(m.HeliStartSFXId), false)
						E.idle = newSnd(followRoot, "HS_HeliIdle", tostring(m.HeliIdleSFXId), true)
					end
					X.HeliEng = E
				end
				if E.mode == 2 then
					local snd = E.gen
					local sp = (0.22 + rpm * 0.78) * pitchM * (1 + speedF * 0.12)
					if math.abs(snd.PlaybackSpeed - sp) > 0.005 then snd.PlaybackSpeed = sp end
					local vol = vol0 * math.clamp(rpm * 1.4, 0, 1)
					if math.abs(snd.Volume - vol) > 0.01 then snd.Volume = vol end
					if not snd.IsPlaying then snd:Play() end
				else
					if soundBad(E.idle, E.born) and soundBad(E.start, E.born) then
						warn("[HatStand] the helicopter engine sound ids did not load - using the generated engine sound")
						X.HeliForceGen = true
						return
					end
					if engineOn and not E.wasOn then
						E.wasOn = true
						E.startT = os.clock()
						E.fade = 0
						pcall(function() E.start.TimePosition = 0 E.start:Play() end)
					elseif not engineOn and E.wasOn then
						E.wasOn = false
						pcall(function() E.start:Stop() end)
					end
					E.start.Volume = vol0
					local startPlaying = E.start.IsPlaying
					local nearEnd = startPlaying and E.start.TimeLength > 0
						and (E.start.TimeLength - E.start.TimePosition) < 0.8
					local startDone = E.wasOn and not startPlaying and (os.clock() - E.startT) > 0.3
					local startFailed = E.wasOn and soundBad(E.start, E.born)
					local idleOn = (E.wasOn and (nearEnd or startDone or startFailed)) or (not E.wasOn and rpm > 0.03)
					if idleOn then
						if not E.idle.IsPlaying then E.idle:Play() end
						E.fade = math.min(1, E.fade + dt * 1.2)
					else
						E.fade = math.max(0, E.fade - dt * 2)
					end
					E.idle.Volume = vol0 * E.fade * math.clamp(rpm * 1.4 + (E.wasOn and 0.15 or 0), 0, 1)
					E.idle.PlaybackSpeed = (0.75 + 0.25 * rpm + speedF * 0.2) * pitchM
				end
			elseif E then
				X.resetHeliEngine()
			end

			-- ===== weapons: minigun loop while firing, stop clip on release =====
			if m.HeliMiniSFX ~= false and m.HeliFireSFX ~= false and not X.HeliMiniBad then
				local firing = riding and os.clock() < (X.HeliFireUntil or 0)
				local M = X.HeliMini
				if M and (M.parent ~= followRoot or not followRoot.Parent) then
					X.resetHeliMini()
					M = nil
				end
				local mv = m.HeliMiniVolume or 1
				if firing then
					if not M then
						M = {
							parent = followRoot, born = os.clock(), on = false,
							loop = newSnd(followRoot, "HS_HeliMiniLoop", tostring(m.HeliMiniLoopId), true),
							stop = newSnd(followRoot, "HS_HeliMiniStop", tostring(m.HeliMiniStopId), false),
						}
						X.HeliMini = M
					end
					M.loop.Volume = mv
					if not M.on then
						M.on = true
						pcall(function() M.stop:Stop() end)
						M.loop.TimePosition = 0
						M.loop:Play()
					elseif not M.loop.IsPlaying then
						M.loop:Play()
					end
					if soundBad(M.loop, M.born) then
						warn("[HatStand] the minigun sound ids did not load - using the normal gun sound")
						X.HeliMiniBad = true
						X.resetHeliMini()
					end
				elseif M and M.on then
					M.on = false
					M.loop:Stop()
					M.stop.Volume = mv
					M.stop.TimePosition = 0
					M.stop:Play()
				end
			end
		end

		local function keysFor(prefix, i)
			return {
				ox = prefix .. "OffX" .. i, oy = prefix .. "OffY" .. i, oz = prefix .. "OffZ" .. i,
				rx = prefix .. "RotX" .. i, ry = prefix .. "RotY" .. i, rz = prefix .. "RotZ" .. i,
			}
		end

		local function slotCF(K)
			return CFrame.new(m[K.ox] or 0, m[K.oy] or 0, m[K.oz] or 0)
				* CFrame.Angles(math.rad(m[K.rx] or 0), math.rad(m[K.ry] or 0), math.rad(m[K.rz] or 0))
		end

		function X.heliGroupCF(prefix)
			return CFrame.new(m[prefix .. "X"] or 0, m[prefix .. "Y"] or 0, m[prefix .. "Z"] or 0)
		end

		local function setRoot(root, v, cf)
			root.AssemblyLinearVelocity = v
			root.CFrame = cf
		end

		local function lockHum()
			local hum = X.getLiveHumanoid()
			if not hum then return end
			if not hum:GetAttribute("HS_HeliOn") then
				pcall(function()
					hum:SetAttribute("HS_HeliWalk", hum.WalkSpeed)
					hum:SetAttribute("HS_HeliJumpP", hum.JumpPower)
					hum:SetAttribute("HS_HeliJumpH", hum.JumpHeight)
					hum:SetAttribute("HS_HeliOn", true)
				end)
			end
			pcall(function()
				if hum.WalkSpeed ~= 0 then hum.WalkSpeed = 0 end
				if hum.JumpPower ~= 0 then hum.JumpPower = 0 end
				if hum.JumpHeight ~= 0 then hum.JumpHeight = 0 end
				if hum.AutoRotate then hum.AutoRotate = false end
			end)
		end

		local function restoreHum()
			local hum = X.getLiveHumanoid()
			if hum and hum:GetAttribute("HS_HeliOn") then
				pcall(function()
					hum.WalkSpeed = hum:GetAttribute("HS_HeliWalk") or 16
					hum.JumpPower = hum:GetAttribute("HS_HeliJumpP") or 50
					hum.JumpHeight = hum:GetAttribute("HS_HeliJumpH") or 7.2
					hum.AutoRotate = true
					hum:SetAttribute("HS_HeliOn", nil)
				end)
			end
		end

		function X.heliTrailColorSeq()
			local idx = m.HeliTrailColor or 1
			if idx == 7 then
				return ColorSequence.new({
					ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 70, 70)),
					ColorSequenceKeypoint.new(0.33, Color3.fromRGB(255, 220, 60)),
					ColorSequenceKeypoint.new(0.66, Color3.fromRGB(70, 255, 150)),
					ColorSequenceKeypoint.new(1, Color3.fromRGB(80, 120, 255)),
				})
			end
			local cols = {
				Color3.fromRGB(255, 170, 60), Color3.fromRGB(110, 190, 255), Color3.fromRGB(90, 255, 90),
				Color3.fromRGB(190, 90, 255), Color3.fromRGB(255, 50, 50), Color3.fromRGB(255, 255, 255),
			}
			return ColorSequence.new(cols[idx] or cols[1])
		end

		function X.heliAddTrail(a)
			pcall(function()
				local a0 = Instance.new("Attachment")
				a0.Parent = a.Handle
				local a1 = Instance.new("Attachment")
				a1.Position = Vector3.new(0, 0, -(m.HeliTrailWidth or 1.2))
				a1.Parent = a.Handle
				local tr = Instance.new("Trail")
				tr.Attachment0, tr.Attachment1 = a0, a1
				tr.Lifetime = m.HeliTrailLife or 0.35
				tr.FaceCamera = true
				tr.LightEmission = 1
				tr.MinLength = 0.05
				tr.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) })
				tr.Color = X.heliTrailColorSeq()
				tr.Enabled = false
				tr.Parent = a.Handle
				a.A0, a.A1, a.Trail = a0, a1, tr
			end)
		end

		function X.heliStyleTrail(a)
			pcall(function()
				if not a.Trail then return end
				a.Trail.Color = X.heliTrailColorSeq()
				a.Trail.Lifetime = m.HeliTrailLife or 0.35
				if a.A1 then a.A1.Position = Vector3.new(0, 0, -(m.HeliTrailWidth or 1.2)) end
			end)
		end

		local function killTrails(w)
			if w and w.Ammo then
				for _, a in ipairs(w.Ammo) do
					pcall(function() if a.Trail then a.Trail:Destroy() end end)
					pcall(function() if a.A0 then a.A0:Destroy() end end)
					pcall(function() if a.A1 then a.A1:Destroy() end end)
				end
			end
		end

		X.clearHeli = function(keepFlight)
			for _, w in pairs(X.HeliWpns) do killTrails(w) end
			killTrails({ Ammo = X.HeliPool or {} })
			killTrails({ Ammo = X.HeliMissiles or {} })
			if X.msCleanup then X.msCleanup() end
			local keep = {}
			for handle, held in pairs(Held) do
				if held.Kind ~= "heli" then keep[handle] = true end
			end
			X.releaseHeld(keep)
			for _, b in ipairs(X.HeliBullets) do
				if b.Neon then pcall(function() b.Neon:Destroy() end) end
			end
			X.HeliFrames, X.HeliProps, X.HeliWpns = {}, {}, {}
			X.HeliPool = {}
			X.HeliMissiles = {}
			X.HeliLaunchers = {}
			X.HeliBullets = {}
			X.HeliCount = 0
			-- a rebuild (hats refreshed / put back) must never reset the flight, only a real clear does
			if not keepFlight then
				X.HeliRootCF = nil
				X.HeliRPM = 0
				X.HeliPitch, X.HeliRoll = 0, 0
				X.resetHeliSound()
				restoreHum()
				X.HeliWasRiding = false
			end
		end

		X.rebuildHeli = function()
			if not (m.Enabled and m.HeliEnabled) then X.clearHeli() return end
			X.clearHeli(true)
			X.HeliLastBuild = os.clock()
			X.refreshAllHats()
			local used = {}
			for handle, held in pairs(Held) do
				if held.Kind and held.Kind ~= "heli" then used[handle] = true end
			end
			local count = 0
			local function grab(label, name)
				label = X.trim(label or "")
				if label == "" then return nil end
				local hat = X.findHatFromLabel(label, used)
				if not (hat and hat.Handle and hat.Handle.Parent) or used[hat.Handle] then return nil end
				local held, part
				if m.FEMode then
					held = X.attachFE(hat, "heli")
					if held then part = hat.Handle end
				else
					part = X.cloneHandle(hat.Handle, name)
					if part then part.Parent = workspace end
				end
				if not part then return nil end
				used[hat.Handle] = true
				if held then held.Kind = "heli" end
				count = count + 1
				return { Handle = part, Held = held, Name = hat.Name }
			end
			for i = 1, 12 do
				local s = grab(m["HeliFrameHat" .. i], "HeliFrame_" .. i)
				if s then s.K = keysFor("HeliFrame", i) X.HeliFrames[i] = s end
			end
			for i = 1, 4 do
				local s = grab(m["HeliPropHat" .. i], "HeliProp_" .. i)
				if s then s.K = keysFor("HeliProp", i) s.I = i s.Spin = 0 X.HeliProps[i] = s end
			end
			for i = 1, 4 do
				local w = grab(m["HeliWpnHat" .. i], "HeliWpn_" .. i)
				if w then
					w.K = keysFor("HeliWpn", i)
					w.I = i
					w.Ammo = {}
					for _, key in ipairs({ "HeliWpnBullet" .. i, "HeliWpnBullet2" .. i }) do
						local a = grab(m[key], "HeliAmmo_" .. i)
						if a then
							a.Busy = false
							X.heliAddTrail(a)
							w.Ammo[#w.Ammo + 1] = a
						end
					end
					X.HeliWpns[i] = w
				end
			end
			X.HeliPool = {}
			for i = 1, 8 do
				local a = grab(m["HeliAmmoHat" .. i], "HeliPool_" .. i)
				if a then
					a.Busy = false
					X.heliAddTrail(a)
					X.HeliPool[#X.HeliPool + 1] = a
				end
			end
			X.HeliLaunchers = {}
			for i = 1, 2 do
				local l = grab(m["HeliLaunchHat" .. i], "HeliLaunch_" .. i)
				if l then l.K = keysFor("HeliLaunch", i) l.I = i X.HeliLaunchers[i] = l end
			end
			X.HeliMissiles = {}
			for i = 1, 4 do
				local a = grab(m["HeliMissileHat" .. i], "HeliMissile_" .. i)
				if a then
					a.Busy = false
					a.K = keysFor("HeliMissile", i)
					X.heliAddTrail(a)
					X.HeliMissiles[#X.HeliMissiles + 1] = a
				end
			end
			X.HeliCount = count
			warn("[HatStand] hellcopter parts=" .. count)
		end

		function X.heliConfigured()
			for i = 1, 12 do if X.trim(m["HeliFrameHat" .. i] or "") ~= "" then return true end end
			for i = 1, 8 do if X.trim(m["HeliAmmoHat" .. i] or "") ~= "" then return true end end
			for i = 1, 4 do if X.trim(m["HeliMissileHat" .. i] or "") ~= "" then return true end end
			for i = 1, 2 do if X.trim(m["HeliLaunchHat" .. i] or "") ~= "" then return true end end
			for i = 1, 4 do
				if X.trim(m["HeliPropHat" .. i] or "") ~= "" or X.trim(m["HeliWpnHat" .. i] or "") ~= "" then return true end
			end
			return false
		end

		function X.setHeliFly(on)
			m.HeliFly = on and true or false
			if not m.HeliFly then
				m.HeliRide = false -- stepHeli dismounts you and gives your walk/jump back
				m.HeliEngine = false
				X.HeliFireHeld = false
			end
			warn("[HatStand] hellcopter fly=" .. tostring(m.HeliFly))
		end

		function X.toggleHeliMouse()
			m.HeliMouseCtl = not m.HeliMouseCtl
			warn("[HatStand] hellcopter mouse control=" .. tostring(m.HeliMouseCtl))
		end

		function X.toggleHeliFly()
			X.setHeliFly(m.HeliFly == false)
		end

		function X.toggleHeliRide()
			if not m.HeliEnabled then return end
			if m.HeliFly == false and not m.HeliRide then
				warn("[HatStand] hellcopter fly is OFF - turn it on first")
				return
			end
			m.HeliRide = not m.HeliRide
			if m.HeliRide then
				local fr = X.getFollowRoot()
				if fr then
					local lv = fr.CFrame.LookVector
					X.HeliYaw = math.atan2(-lv.X, -lv.Z)
				end
				X.HeliPitch, X.HeliRoll = 0, 0
				if m.HeliAutoStart ~= false then m.HeliEngine = true end
			else
				X.HeliFireHeld = false
			end
			warn("[HatStand] hellcopter ride=" .. tostring(m.HeliRide) .. " engine=" .. tostring(m.HeliEngine))
		end

		function X.toggleHeliEngine()
			if not m.HeliEnabled then return end
			m.HeliEngine = not m.HeliEngine
			warn("[HatStand] hellcopter engine=" .. tostring(m.HeliEngine))
		end

		local aimImpl -- smart aim (set below, after bulletParams): snaps to players / missiles near the cursor
		local function aimPoint(noMissiles)
			if aimImpl then
				local ok, pt, tg = pcall(aimImpl, noMissiles)
				if ok and pt then return pt, tg end
			end
			if m.HeliAimMouse ~= false then
				local p
				pcall(function() if Mouse and Mouse.Hit then p = Mouse.Hit.Position end end)
				if p then return p end
			end
			local root = X.HeliRootCF
			if root then return root.Position + root.LookVector * 200 end
			return Vector3.new(0, 0, -200)
		end

		function X.spawnHeliBullet(w, pos, dir, tgt)
			local ammo
			for _, a in ipairs(w.Ammo or {}) do
				if not a.Busy and a.Handle and a.Handle.Parent then ammo = a break end
			end
			if not ammo then
				for _, a in ipairs(X.HeliPool or {}) do
					if not a.Busy and a.Handle and a.Handle.Parent then ammo = a break end
				end
			end
			local speed = math.max(m.HeliBulletSpeed or 260, 1)
			local b = { Pos = pos, Dir = dir, Speed = speed, Life = (m.HeliBulletRange or 260) / speed, T = 0, Ammo = ammo, Home = m.HeliHoming ~= false }
			if b.Home then b.Tgt = tgt end -- locked on a player / missile: keeps chasing it instead of the ground behind it
			if ammo then
				ammo.Busy = true
				-- put the hat at the muzzle first so the trail doesn't streak from its parked spot
				local startCF = CFrame.lookAt(pos, pos + dir)
				if ammo.Held then X.driveHandle(ammo.Held, startCF) else pcall(function() ammo.Handle.CFrame = startCF end) end
				X.heliStyleTrail(ammo)
				pcall(function() if ammo.Trail then ammo.Trail.Enabled = m.HeliTrail ~= false end end)
			elseif m.HeliBulletFallback ~= false and #X.HeliBullets < 60 then
				local folder = X.HeliFolder
				if not (folder and folder.Parent) then
					folder = Instance.new("Folder")
					folder.Name = "HS_HeliBullets"
					folder.Parent = Workspace
					X.HeliFolder = folder
				end
				local p = Instance.new("Part")
				p.Name = "HS_HeliBullet"
				p.Anchored = true
				p.CanCollide = false
				p.CanQuery = false
				p.CanTouch = false
				p.Material = Enum.Material.Neon
				p.Color = Color3.fromRGB(255, 170, 60)
				p.Size = Vector3.new(0.3, 0.3, 3)
				p.CFrame = CFrame.lookAt(pos, pos + dir)
				p.Parent = folder
				b.Neon = p
			else
				return
			end
			X.HeliBullets[#X.HeliBullets + 1] = b
		end

		function X.fireHeli(fromClick)
			if not (m.HeliEnabled and m.HeliRide) then return end
			if X.HeliRPM < 0.3 then return end
			local style = m.HeliFireStyle or 2
			local cd = m.HeliCooldown or 0.14
			if style == 3 then cd = cd * 0.35 elseif style == 4 then cd = cd * 3 end
			local now = os.clock()
			if now - X.HeliLastShot < cd then return end
			if style == 1 and not fromClick then return end
			X.HeliLastShot = now
			local shots = (style == 4) and 3 or 1
			local spread = math.rad(m.HeliSpread or 1.5) * ((style == 3) and 2 or 1)
			local aim, aimTgt = aimPoint()
			local fired = false
			for _, w in pairs(X.HeliWpns) do
				if w and w.Fire ~= false and w.Handle and w.Handle.Parent and w.CF then
					local origin = w.CF.Position
					local dir = aim - origin
					dir = dir.Magnitude > 0.1 and dir.Unit or w.CF.LookVector
					for _ = 1, shots do
						local d = dir
						if spread > 0 then
							d = (CFrame.lookAt(Vector3.zero, dir)
								* CFrame.Angles((math.random() - 0.5) * 2 * spread, (math.random() - 0.5) * 2 * spread, 0)).LookVector
						end
						X.spawnHeliBullet(w, origin + d * 1.5, d, aimTgt)
						fired = true
					end
				end
			end
			if fired and m.HeliFireSFX ~= false then
				if m.HeliMiniSFX ~= false and not X.HeliMiniBad then
					-- keeps the minigun loop alive for as long as shots keep coming
					X.HeliFireUntil = now + cd * 1.6 + 0.1
				else
					X.playSFX(m.WeaponFireSFXId or "rbxassetid://131961136", 0.6)
				end
			end
		end

		local function bulletParams()
			local now = os.clock()
			if X.HeliRayParams and (now - (X.HeliRayT or 0)) < 1 then return X.HeliRayParams end
			local p = RaycastParams.new()
			p.FilterType = Enum.RaycastFilterType.Exclude
			local ex = {}
			if LocalPlayer.Character then ex[#ex + 1] = LocalPlayer.Character end
			pcall(function()
				local u = _G.Uhhhhhh and _G.Uhhhhhh.Character
				if u then ex[#ex + 1] = u end
			end)
			if X.CloneModel then ex[#ex + 1] = X.CloneModel end
			if X.HeliFolder then ex[#ex + 1] = X.HeliFolder end
			pcall(function() if StandModel then ex[#ex + 1] = StandModel end end)
			p.FilterDescendantsInstances = ex
			X.HeliRayParams, X.HeliRayT = p, now
			return p
		end

		-- ===== smart aim: the cursor ray is cast ignoring my own stuff; a player / NPC / missile near the cursor is aimed at directly =====
		local function aimRootOf(model)
			return model:FindFirstChild("HumanoidRootPart") or model:FindFirstChild("Torso")
				or model:FindFirstChild("UpperTorso") or model:FindFirstChild("Head")
		end

		local function heliTgtPos(t)
			if typeof(t) == "Instance" then
				if t.Parent then return t.Position end
				return nil
			end
			if type(t) == "table" and not t.Done and t.Pos then return t.Pos end
			return nil
		end

		aimImpl = function(noMissiles)
			if m.HeliAimMouse == false then return nil end
			local cam = Workspace.CurrentCamera
			if not cam then return nil end
			local now = os.clock()
			local ck = noMissiles and "HeliAimCacheN" or "HeliAimCacheY"
			local c = X[ck]
			if c and now - c.T < 0.008 then return c.P, c.Tgt end
			local mp = UserInputService:GetMouseLocation()
			local ray = cam:ViewportPointToRay(mp.X, mp.Y)
			local ro, rd = ray.Origin, ray.Direction.Unit
			local hit = Workspace:Raycast(ro, rd * 2000, bulletParams())
			local point = hit and hit.Position or (ro + rd * 1000)
			local tgt
			if m.HeliAimAssist ~= false then
				local radius = m.HeliAimAssistRadius or 90
				local bestObj, bestPos, bestD
				local function consider(pos, obj)
					local v, on = cam:WorldToViewportPoint(pos)
					if not on then return end
					local d = (Vector2.new(v.X, v.Y) - mp).Magnitude
					if d <= radius and (not bestD or d < bestD) then bestObj, bestPos, bestD = obj, pos, d end
				end
				local ok, cands = pcall(X.msCandidates)
				if ok and cands then
					for _, ch in ipairs(cands) do
						local r = ch.Parent and aimRootOf(ch)
						local hum = ch:FindFirstChildOfClass("Humanoid")
						if r and (not hum or hum.Health > 0) then
							if hit and hit.Instance:IsDescendantOf(ch) then
								bestObj, bestPos, bestD = r, r.Position, -1 -- cursor is right on the body
								break
							end
							consider(r.Position, r)
						end
					end
				end
				if not noMissiles and bestD ~= -1 then
					for _, q in ipairs(X.HeliMissileFlight or {}) do
						if not q.Done and q.T > 0.25 then consider(q.Pos, q) end
					end
				end
				if bestObj then tgt, point = bestObj, bestPos end
			end
			X[ck] = { T = now, P = point, Tgt = tgt }
			return point, tgt
		end

		function X.stepHeliBullets(dt)
			local list = X.HeliBullets
			if #list == 0 then return end
			local params = bulletParams()
			local spin = m.HeliBulletSpin ~= false
			local rot = CFrame.Angles(math.rad(m.HeliBulletRotX or 0), math.rad(m.HeliBulletRotY or 0), math.rad(m.HeliBulletRotZ or 0))
			local clock = os.clock()
			local homing = m.HeliHoming ~= false
			local track = m.HeliHomingStrength or 4
			local homePt = homing and aimPoint() or nil
			local i = 1
			while i <= #list do
				local b = list[i]
				local want, tr
				if b.Tgt then
					local tp = heliTgtPos(b.Tgt)
					if tp then want, tr = tp - b.Pos, track * 3 else b.Tgt = nil end
				end
				if not want and homePt and b.Home then want, tr = homePt - b.Pos, track end
				if want and want.Magnitude > 4 then
					local nd = b.Dir:Lerp(want.Unit, 1 - math.exp(-tr * dt))
					if nd.Magnitude > 0.01 then b.Dir = nd.Unit end
				end
				local step = b.Speed * dt
				local done = false
				local hit = Workspace:Raycast(b.Pos, b.Dir * step, params)
				if hit then
					b.Pos = hit.Position
					done = true
				else
					b.Pos = b.Pos + b.Dir * step
				end
				b.T = b.T + dt
				if b.T >= b.Life then done = true end
				local cf = CFrame.lookAt(b.Pos, b.Pos + b.Dir)
				if b.Ammo then
					cf = cf * rot
					if spin then cf = cf * CFrame.Angles(0, 0, clock * 20 + i) end
					if b.Ammo.Held then
						X.driveHandle(b.Ammo.Held, cf)
					else
						pcall(function() b.Ammo.Handle.CFrame = cf end)
					end
				elseif b.Neon then
					pcall(function() b.Neon.CFrame = cf end)
				end
				if done then
					if b.Ammo then
						b.Ammo.Busy = false
						pcall(function() if b.Ammo.Trail then b.Ammo.Trail.Enabled = false end end)
					end
					if b.Neon then pcall(function() b.Neon:Destroy() end) end
					table.remove(list, i)
				else
					i = i + 1
				end
			end
		end

		local function drive(slot, cf)
			if not (slot and slot.Handle and slot.Handle.Parent) then return end
			if slot.Held then
				local vel
				if m.HeliSolid and slot.HSolid then
					local t = os.clock()
					if slot.HPrevP and slot.HPrevT and t > slot.HPrevT then
						vel = (cf.Position - slot.HPrevP) / (t - slot.HPrevT) * (m.HeliSolidPush or 1)
						if vel.Magnitude > 250 then vel = vel.Unit * 250 end
					end
					slot.HPrevP, slot.HPrevT = cf.Position, t
				end
				X.driveHandle(slot.Held, cf, vel)
			else
				pcall(function() slot.Handle.CFrame = cf end)
			end
		end

		-- ===================== HAT RIG COLLISION (NPCs / dummies) =====================
		-- Hats are real client-owned parts, so when they are solid and moving they push any NPC part that
		-- this client simulates. Roblox only gives me ownership of nearby unanchored NPC parts (the huge
		-- simulation radius below asks for that); a server-owned or anchored NPC will not react.
		local function heliSolidSlots()
			local out = {}
			if m.HeliSolidFrames ~= false then for _, sl in pairs(X.HeliFrames or {}) do out[#out + 1] = sl end end
			if m.HeliSolidProps ~= false then for _, sl in pairs(X.HeliProps or {}) do out[#out + 1] = sl end end
			if m.HeliSolidWpns ~= false then
				for _, sl in pairs(X.HeliWpns or {}) do out[#out + 1] = sl end
				for _, sl in pairs(X.HeliLaunchers or {}) do out[#out + 1] = sl end
			end
			return out
		end

		local function heliNoCollide(slot, now)
			if now - (slot.HNccT or 0) < 1.5 then return end
			slot.HNccT = now
			local h = slot.Handle
			slot.HNcc = slot.HNcc or {}
			local function addAll(model)
				if not (model and model.Parent) then return end
				for _, d in ipairs(model:GetDescendants()) do
					if d:IsA("BasePart") and d ~= h and not slot.HNcc[d] then
						local c = Instance.new("NoCollisionConstraint")
						c.Name = "HS_HeliNC"
						c.Part0, c.Part1 = h, d
						c.Parent = h
						slot.HNcc[d] = c
					end
				end
			end
			addAll(LocalPlayer.Character)
			pcall(function() addAll(_G.Uhhhhhh and _G.Uhhhhhh.Character) end)
			addAll(X.CloneModel)
			pcall(function() addAll(StandModel) end)
			if m.HeliSolidIgnorePlayers ~= false then
				for _, pl in ipairs(Players:GetPlayers()) do
					if pl ~= LocalPlayer then addAll(pl.Character) end
				end
			end
			-- drop constraints whose other part is gone
			for part, c in pairs(slot.HNcc) do
				if not part.Parent then pcall(function() c:Destroy() end) slot.HNcc[part] = nil end
			end
		end

		function X.stepHeliSolid()
			local on = m.Enabled and m.HeliEnabled and m.HeliSolid and true or false
			if not on then
				if X.HeliSolidWas then
					X.HeliSolidWas = false
					for _, set in ipairs({ X.HeliFrames or {}, X.HeliProps or {}, X.HeliWpns or {}, X.HeliLaunchers or {} }) do
						for _, sl in pairs(set) do
							sl.HSolid = nil
							if sl.Handle and sl.Handle.Parent and not m.HatsSolid then pcall(function() sl.Handle.CanCollide = false end) end
							for part, c in pairs(sl.HNcc or {}) do pcall(function() c:Destroy() end) end
							sl.HNcc = nil
						end
					end
				end
				return
			end
			X.HeliSolidWas = true
			local now = os.clock()
			if m.HeliSolidBoost ~= false and now - (X.HeliSolidBoostT or 0) > 1 then
				X.HeliSolidBoostT = now
				pcall(X.boostNetwork)
			end
			local wanted = {}
			for _, sl in ipairs(heliSolidSlots()) do
				wanted[sl] = true
				local h = sl.Handle
				if h and h.Parent then
					sl.HSolid = true
					heliNoCollide(sl, now)
					pcall(function()
						if not h.CanCollide then h.CanCollide = true end
						if not h.CanQuery then h.CanQuery = true end
						if not h.CanTouch then h.CanTouch = true end
					end)
				end
			end
			-- a category that was switched off goes back to ghost
			for _, set in ipairs({ X.HeliFrames or {}, X.HeliProps or {}, X.HeliWpns or {}, X.HeliLaunchers or {} }) do
				for _, sl in pairs(set) do
					if not wanted[sl] and sl.HSolid then
						sl.HSolid = nil
						if sl.Handle and sl.Handle.Parent and not m.HatsSolid then pcall(function() sl.Handle.CanCollide = false end) end
					end
				end
			end
		end

		if X.HeliSolidConn then pcall(function() X.HeliSolidConn:Disconnect() end) end
		-- before every physics step, because Roblox / Uhhhhhh reset hat collision
		X.HeliSolidConn = RunService.Stepped:Connect(function() pcall(X.stepHeliSolid) end)

		-- ===================== MISSILE LAUNCHER =====================
		local function msRoot(model)
			return model and (model:FindFirstChild("HumanoidRootPart") or model:FindFirstChild("Torso"))
		end

		local function msFolder()
			local folder = X.HeliFolder
			if not (folder and folder.Parent) then
				folder = Instance.new("Folder")
				folder.Name = "HS_HeliBullets"
				folder.Parent = Workspace
				X.HeliFolder = folder
			end
			return folder
		end

		local function msSound(parent, id, vol, looped)
			local snd
			pcall(function()
				snd = Instance.new("Sound")
				snd.Name = "HS_Missile"
				snd.SoundId = tostring(id)
				snd.Looped = looped or false
				snd.Volume = vol
				snd.RollOffMinDistance = 30
				snd.RollOffMaxDistance = 600
				snd.Parent = parent
			end)
			return snd
		end

		function X.msCandidates()
			local out = {}
			local mine = LocalPlayer.Character
			for _, pl in ipairs(Players:GetPlayers()) do
				if pl ~= LocalPlayer and pl.Character then out[#out + 1] = pl.Character end
			end
			if m.HeliMissileNPC then
				local now = os.clock()
				if now - (X.MsNpcT or 0) > 2 then
					X.MsNpcT, X.MsNpc = now, {}
					for _, d in ipairs(Workspace:GetDescendants()) do
						if d:IsA("Humanoid") then
							local mdl = d.Parent
							if mdl and mdl:IsA("Model") and mdl ~= mine and mdl ~= X.CloneModel and mdl ~= StandModel
								and not Players:GetPlayerFromCharacter(mdl) then
								X.MsNpc[#X.MsNpc + 1] = mdl
							end
						end
					end
				end
				for _, c in ipairs(X.MsNpc or {}) do if c.Parent then out[#out + 1] = c end end
			end
			return out
		end

		local function msScreenDist(cam, mp, r)
			local v, on = cam:WorldToViewportPoint(r.Position)
			if not on then return nil end
			return (Vector2.new(v.X, v.Y) - mp).Magnitude
		end

		function X.msPick()
			local cam = Workspace.CurrentCamera
			if not cam then return nil end
			local mp = UserInputService:GetMouseLocation()
			local origin = cam.CFrame.Position
			local rad = m.HeliMissileLockRadius or 140
			local best, bestD
			for _, c in ipairs(X.msCandidates()) do
				local r, hum = msRoot(c), c:FindFirstChildOfClass("Humanoid")
				if r and hum and hum.Health > 0 and (r.Position - origin).Magnitude <= (m.HeliMissileRange or 600) then
					local d = msScreenDist(cam, mp, r)
					if d and d <= rad and (not bestD or d < bestD) then best, bestD = c, d end
				end
			end
			return best
		end

		function X.msClearLock()
			if X.MsLoop then pcall(function() X.MsLoop:Destroy() end) end
			if X.MsMarker then pcall(function() X.MsMarker:Destroy() end) end
			X.MsLoop, X.MsMarker = nil, nil
			X.MsTarget, X.MsT, X.MsLocked = nil, 0, false
		end

		local function msSetMarker(text, color)
			local g = X.MsMarker
			if not (g and g.Parent) then return end
			local l = g:FindFirstChild("L")
			if l then l.Text, l.TextColor3 = text, color end
		end

		function X.stepHeliMissileLock(dt, riding)
			if not (riding and m.HeliMissileEnabled ~= false and X.HeliRPM >= 0.3) then
				if X.MsTarget or X.MsLoop then X.msClearLock() end
				return
			end
			local cam = Workspace.CurrentCamera
			if not cam then return end
			local cur = X.MsTarget
			local keep = false
			if cur and cur.Parent then
				local r, hum = msRoot(cur), cur:FindFirstChildOfClass("Humanoid")
				if r and hum and hum.Health > 0 then
					local d = msScreenDist(cam, UserInputService:GetMouseLocation(), r)
					local far = (r.Position - cam.CFrame.Position).Magnitude
					if d and d <= (m.HeliMissileLockRadius or 140) * 1.8 and far <= (m.HeliMissileRange or 600) then keep = true end
				end
			end
			if not keep then
				X.msClearLock()
				local cand = X.msPick()
				if not cand then return end
				X.MsTarget, X.MsT, X.MsLocked = cand, 0, false
				pcall(function()
					local g = Instance.new("BillboardGui")
					g.Name = "HS_MissileMarker"
					g.AlwaysOnTop = true
					g.Size = UDim2.fromOffset(120, 30)
					g.StudsOffset = Vector3.new(0, 3, 0)
					g.Adornee = msRoot(cand)
					local l = Instance.new("TextLabel")
					l.Name = "L"
					l.Size = UDim2.fromScale(1, 1)
					l.BackgroundTransparency = 1
					l.Font = Enum.Font.GothamBold
					l.TextSize = 16
					l.Text = "[ LOCKING ]"
					l.TextColor3 = Color3.fromRGB(255, 220, 60)
					l.Parent = g
					g.Parent = msFolder()
					X.MsMarker = g
				end)
				if m.HeliMissileSFX ~= false then
					X.MsLoop = msSound(cam, m.HeliMissileLockSFXId, (m.HeliMissileVolume or 1) * (m.HeliMissileLockVol or 0.8), true)
					if X.MsLoop then pcall(function() X.MsLoop:Play() end) end
				end
			end
			if not X.MsLocked then
				X.MsT = X.MsT + dt
				local lt = math.max(m.HeliMissileLockTime or 1, 0.05)
				if X.MsLoop then pcall(function() X.MsLoop.PlaybackSpeed = m.HeliMissileLockSpeed or 1 end) end
				if X.MsT >= lt then
					X.MsLocked = true
					if X.MsLoop then
						if m.HeliMissileLockKeep ~= false then
							pcall(function() X.MsLoop.PlaybackSpeed = m.HeliMissileLockSpeed or 1 end)
						else
							pcall(function() X.MsLoop:Destroy() end)
							X.MsLoop = nil
						end
					end
					msSetMarker("[ LOCKED ]", Color3.fromRGB(255, 60, 60))
				end
			end
		end

		function X.msExplode(pos)
			if m.HeliMissileExplosion ~= false then
				pcall(function()
					local e = Instance.new("Explosion")
					e.Position = pos
					e.BlastRadius = m.HeliMissileExplosionSize or 12
					e.BlastPressure = 0
					e.DestroyJointRadiusPercent = 0
					e.ExplosionType = Enum.ExplosionType.NoCraters
					e.Parent = Workspace
				end)
			end
			if m.HeliMissileSFX ~= false then
				pcall(function()
					local part = Instance.new("Part")
					part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch = true, false, false, false
					part.Transparency = 1
					part.Size = Vector3.new(1, 1, 1)
					part.Position = pos
					part.Parent = msFolder()
					local snd = msSound(part, m.HeliMissileExplodeSFXId, (m.HeliMissileVolume or 1) * (m.HeliMissileExplodeVol or 1), false)
					if snd then snd:Play() end
					Debris:AddItem(part, 8)
				end)
			end
		end

		function X.msCleanup()
			for _, q in ipairs(X.HeliMissileFlight or {}) do
				if q.Neon then pcall(function() q.Neon:Destroy() end) end
				if q.Snd then pcall(function() q.Snd:Destroy() end) end
			end
			X.HeliMissileFlight = {}
			X.msClearLock()
		end

		function X.fireHeliMissile()
			if not (m.HeliEnabled and m.HeliRide and m.HeliMissileEnabled ~= false) then return end
			if X.HeliRPM < 0.3 then return end
			local now = os.clock()
			if now - (X.MsLast or 0) < (m.HeliMissileCooldown or 1.5) then return end
			-- launch from the weapon mounts in turn, or from under the helicopter if there are none
			local launchCF
			for t = 0, 1 do
				local idx = ((X.MsLIdx or 0) + t) % 2 + 1
				local l = X.HeliLaunchers and X.HeliLaunchers[idx]
				if l and l.CF then
					launchCF = l.CF
					X.MsLIdx = idx % 2
					break
				end
			end
			if not launchCF then
				for t = 0, 3 do
					local idx = ((X.MsIdx or 0) + t) % 4 + 1
					local w = X.HeliWpns[idx]
					if w and w.CF then
						launchCF = w.CF
						X.MsIdx = idx % 4
						break
					end
				end
			end
			local root = X.HeliRootCF
			if not launchCF then
				if not root then return end
				launchCF = root * CFrame.new(0, -2, -4)
			end
			X.MsLast = now
			local pos = launchCF.Position
			local target = (X.MsLocked and X.MsTarget and X.MsTarget.Parent) and X.MsTarget or nil
			local dir
			if target and msRoot(target) then
				dir = msRoot(target).Position - pos
			else
				dir = aimPoint(true) - pos
			end
			dir = dir.Magnitude > 0.1 and dir.Unit or launchCF.LookVector
			pos = pos + dir * 2
			local maxSp = math.max(m.HeliMissileSpeed or 150, 10)
			local q = { Pos = pos, Dir = dir, Max = maxSp, Cur = maxSp * 0.35, T = 0, Life = m.HeliMissileLife or 8, Target = target }
			local ammo
			for _, a in ipairs(X.HeliMissiles or {}) do
				if not a.Busy and a.Handle and a.Handle.Parent then ammo = a break end
			end
			local holder
			if ammo then
				ammo.Busy = true
				q.Ammo = ammo
				holder = ammo.Handle
				local startCF = CFrame.lookAt(pos, pos + dir) * (ammo.K and slotCF(ammo.K) or CFrame.new())
				if ammo.Held then X.driveHandle(ammo.Held, startCF) else pcall(function() ammo.Handle.CFrame = startCF end) end
				X.heliStyleTrail(ammo)
				pcall(function() if ammo.Trail then ammo.Trail.Enabled = m.HeliTrail ~= false end end)
			else
				-- no missile hat picked / free: a simple glowing missile so it is always visible
				local p = Instance.new("Part")
				p.Name = "HS_HeliMissile"
				p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
				p.Material = Enum.Material.Neon
				p.Color = Color3.fromRGB(255, 80, 40)
				p.Size = Vector3.new(0.7, 0.7, 4)
				p.CFrame = CFrame.lookAt(pos, pos + dir)
				p.Parent = msFolder()
				q.Neon = p
				holder = p
			end
			if m.HeliMissileSFX ~= false and holder then
				q.Snd = msSound(holder, m.HeliMissileLoopSFXId, (m.HeliMissileVolume or 1) * (m.HeliMissileLoopVol or 1), true)
				if q.Snd then pcall(function() q.Snd:Play() end) end
			end
			X.HeliMissileFlight[#X.HeliMissileFlight + 1] = q
			-- a fired lock is used up: lock on again for the next one
			if target then X.msClearLock() end
		end

		function X.stepHeliMissiles(dt)
			local list = X.HeliMissileFlight
			if not list or #list == 0 then return end
			local params = bulletParams()
			local rot = CFrame.Angles(math.rad(m.HeliMissileRotX or 0), math.rad(m.HeliMissileRotY or 0), math.rad(m.HeliMissileRotZ or 0))
			local turn = m.HeliMissileTurn or 3.5
			local i = 1
			while i <= #list do
				local q = list[i]
				q.T = q.T + dt
				q.Cur = math.min(q.Cur + q.Max * 1.2 * dt, q.Max)
				-- steering: locked missiles chase their target, free missiles chase the mouse point
				local tp
				if q.Target then
					local r = q.Target.Parent and msRoot(q.Target)
					if r then tp = r.Position else q.Target = nil end
				end
				if not tp and not q.Target and m.HeliHoming ~= false then tp = aimPoint(true) end
				if tp and q.T > 0.15 then
					local want = tp - q.Pos
					if want.Magnitude > 0.5 then
						local nd = q.Dir:Lerp(want.Unit, 1 - math.exp(-turn * dt))
						if nd.Magnitude > 0.01 then q.Dir = nd.Unit end
					end
				end
				local step = q.Cur * dt
				local done = false
				local hit = Workspace:Raycast(q.Pos, q.Dir * step, params)
				if hit then
					q.Pos = hit.Position
					done = true
				else
					q.Pos = q.Pos + q.Dir * step
				end
				if not done and q.Target then
					local r = msRoot(q.Target)
					if r and (r.Position - q.Pos).Magnitude < 5 then done = true end
				end
				if q.T >= q.Life then done = true end
				local cf = CFrame.lookAt(q.Pos, q.Pos + q.Dir)
				if q.Ammo then
					cf = cf * (q.Ammo.K and slotCF(q.Ammo.K) or CFrame.new()) * rot
					if q.Ammo.Held then X.driveHandle(q.Ammo.Held, cf) else pcall(function() q.Ammo.Handle.CFrame = cf end) end
				elseif q.Neon then
					pcall(function() q.Neon.CFrame = cf end)
				end
				if done then
					q.Done = true
					X.msExplode(q.Pos)
					if q.Snd then pcall(function() q.Snd:Destroy() end) end
					if q.Ammo then
						q.Ammo.Busy = false
						pcall(function() if q.Ammo.Trail then q.Ammo.Trail.Enabled = false end end)
					end
					if q.Neon then pcall(function() q.Neon:Destroy() end) end
					table.remove(list, i)
				else
					i = i + 1
				end
			end
		end

		function X.stepHeli(dt)
			if not m.HeliEnabled then return end
			local followRoot = X.getFollowRoot()
			if not followRoot then return end
			local now = os.clock()

			-- put hats back if they vanished (rate limited)
			if m.HeliAutoRebuild ~= false and (now - X.HeliLastBuild) > (X.HeliCount == 0 and math.max(m.HeliRebuildDelay or 0.1, 0.5) or math.max(m.HeliRebuildDelay or 0.1, 0.02)) then
				local need = false
				if X.HeliCount == 0 then
					need = X.heliConfigured()
				else
					for _, set in ipairs({ X.HeliFrames, X.HeliProps, X.HeliWpns, X.HeliPool or {}, X.HeliMissiles or {}, X.HeliLaunchers or {} }) do
						for _, s in pairs(set) do
							if not (s.Handle and s.Handle.Parent) then need = true end
							if s.Ammo then
								for _, a in ipairs(s.Ammo) do
									if not (a.Handle and a.Handle.Parent) then need = true end
								end
							end
						end
					end
				end
				X.HeliLastBuild = now
				if need then X.rebuildHeli() end
			end

			local riding = m.HeliRide
			-- rotor spool
			local rpmTarget = m.HeliEngine and 1 or 0
			local rate = (rpmTarget > X.HeliRPM) and (1 / math.max(m.HeliSpoolUp or 2.5, 0.2)) or (1 / math.max(m.HeliSpoolDown or 6, 0.2))
			X.HeliRPM = X.HeliRPM + math.clamp(rpmTarget - X.HeliRPM, -rate * dt, rate * dt)
			local rpm = X.HeliRPM

			local target
			if riding then
				X.HeliWasRiding = true
				lockHum()
				local fwd, side, yawIn, climb = 0, 0, 0, 0
				if not UserInputService:GetFocusedTextBox() then
					if UserInputService:IsKeyDown(Enum.KeyCode.W) then fwd = fwd + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.S) then fwd = fwd - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.D) then side = side + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.A) then side = side - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.Q) then yawIn = yawIn + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.E) then yawIn = yawIn - 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.Space) then climb = climb + 1 end
					if UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) or UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
						climb = climb - 1
					end
				end
				-- mouse control (turn with the cursor / face the mouse point, optional climb)
				if m.HeliMouseCtl and not UserInputService:GetFocusedTextBox() then
					local cam = Workspace.CurrentCamera
					local mp = UserInputService:GetMouseLocation()
					if cam and mp then
						local vs = cam.ViewportSize
						local nx = math.clamp((mp.X - vs.X * 0.5) / (vs.X * 0.5), -1, 1)
						local ny = math.clamp((mp.Y - vs.Y * 0.5) / (vs.Y * 0.5), -1, 1)
						local dz = math.clamp(m.HeliMouseDead or 0.12, 0, 0.9)
						local function dead(v)
							local a = math.abs(v)
							if a <= dz then return 0 end
							return (a - dz) / (1 - dz) * (v < 0 and -1 or 1)
						end
						local sens = m.HeliMouseSens or 1.5
						if (m.HeliMouseMode or 1) == 2 then
							local pt
							pcall(function() if Mouse and Mouse.Hit then pt = Mouse.Hit.Position end end)
							if pt then
								local d = pt - followRoot.Position
								if Vector3.new(d.X, 0, d.Z).Magnitude > 5 then
									local wantYaw = math.atan2(-d.X, -d.Z)
									local diff = (wantYaw - X.HeliYaw + math.pi) % (math.pi * 2) - math.pi
									yawIn = yawIn + math.clamp(diff * 2 * sens, -1, 1)
								end
							end
						else
							yawIn = yawIn - dead(nx) * sens
						end
						if m.HeliMouseClimb == true then climb = climb - dead(ny) end
					end
					yawIn = math.clamp(yawIn, -2.5, 2.5)
					climb = math.clamp(climb, -1, 1)
				end
				X.HeliYaw = X.HeliYaw + yawIn * (m.HeliYawRate or 1.8) * dt * math.clamp(rpm * 1.5, 0, 1)
				local yawCF = CFrame.Angles(0, X.HeliYaw, 0)
				local look, right = yawCF.LookVector, yawCF.RightVector
				local maxSp = m.HeliMaxSpeed or 120
				local vel = followRoot.AssemblyLinearVelocity
				local hv = Vector3.new(vel.X, 0, vel.Z)
				local vy = vel.Y
				local g = Workspace.Gravity
				local want = look * fwd + right * side
				if want.Magnitude > 1 then want = want.Unit end
				want = want * maxSp * rpm
				local ctrl = math.clamp((rpm - 0.3) / 0.7, 0, 1)
				hv = hv:Lerp(want, 1 - math.exp(-(m.HeliAccel or 2.5) * dt * (0.2 + 0.8 * ctrl)))
				if m.HeliPhysics ~= false then
					local auth = math.clamp((rpm - 0.55) / 0.45, 0, 1)
					if m.HeliHoverAssist ~= false then
						vy = vy + g * dt * auth -- cancel gravity while the rotor has power
						local vyWant = climb * (m.HeliClimb or 45)
						vy = vy + (vyWant - vy) * (1 - math.exp(-3 * dt)) * auth
					else
						-- manual collective: lift = rotor power, Space adds, Shift removes
						local thrust = rpm * (1 + climb * 0.45)
						vy = vy + thrust * g * dt
						vy = vy * (1 - math.min(0.9 * dt, 1))
					end
					if auth < 1 then
						vy = vy - ((m.HeliGravity or 1) - 1) * g * dt * (1 - auth)
					end
				else
					vy = climb * (m.HeliClimb or 45) * math.clamp(rpm * 1.5, 0, 1)
				end
				vy = math.clamp(vy, -300, 300)
				local fv = maxSp > 0 and hv:Dot(look) / maxSp or 0
				local sv = maxSp > 0 and hv:Dot(right) / maxSp or 0
				local tilt = math.rad(m.HeliTilt or 22)
				local k = 1 - math.exp(-6 * dt)
				X.HeliPitch = X.HeliPitch + (-fv * tilt - X.HeliPitch) * k
				X.HeliRoll = X.HeliRoll + (-sv * tilt - X.HeliRoll) * k
				pcall(setRoot, followRoot, Vector3.new(hv.X, vy, hv.Z), CFrame.new(followRoot.Position) * yawCF)
				target = CFrame.new(followRoot.Position) * yawCF
					* CFrame.Angles(X.HeliPitch, 0, X.HeliRoll)
					* CFrame.new(0, m.HeliSeatOffY or -1, 0)
			else
				if X.HeliWasRiding then
					X.HeliWasRiding = false
					restoreHum()
				end
				X.HeliPitch, X.HeliRoll = X.HeliPitch * 0.9, X.HeliRoll * 0.9
				target = followRoot.CFrame
					* CFrame.new(m.HeliSide or 8, m.HeliHeight or 2, m.HeliForward or 0)
					* CFrame.Angles(0, math.rad(m.HeliRotY or 0), 0)
			end

			if not X.HeliRootCF then
				X.HeliRootCF = target
			else
				local sm = (m.HeliSmooth or 14) * (riding and 1.4 or 1)
				X.HeliRootCF = X.HeliRootCF:Lerp(target, 1 - math.exp(-sm * dt))
			end
			local root = X.HeliRootCF

			-- frames
			for _, s in pairs(X.HeliFrames) do
				drive(s, root * X.heliGroupCF("HeliFramesAll") * slotCF(s.K))
			end
			-- propellers (spin about the chosen axis, speed follows rotor power)
			for i, s in pairs(X.HeliProps) do
				local spd = m["HeliPropSpd" .. s.I] or 40
				local rpmEase = rpm * rpm * (3 - 2 * rpm) -- slow at first, then up to full speed
				s.Spin = (s.Spin + dt * spd * rpmEase) % (math.pi * 200)
				local axis = m["HeliPropAxis" .. s.I] or 2
				local spinCF
				if axis == 1 then spinCF = CFrame.Angles(s.Spin, 0, 0)
				elseif axis == 3 then spinCF = CFrame.Angles(0, 0, s.Spin)
				else spinCF = CFrame.Angles(0, s.Spin, 0) end
				drive(s, root * X.heliGroupCF("HeliPropsAll") * slotCF(s.K) * spinCF)
			end
			-- weapons (aim at mouse while riding) + idle ammo parked at the gun
			local aim = (riding and m.HeliAimMouse ~= false) and aimPoint() or nil
			for _, w in pairs(X.HeliWpns) do
				local base = root * X.heliGroupCF("HeliWpnsAll") * slotCF(w.K)
				if aim then
					local rotCF = CFrame.Angles(math.rad(m[w.K.rx] or 0), math.rad(m[w.K.ry] or 0), math.rad(m[w.K.rz] or 0))
					local desired = CFrame.lookAt(base.Position, aim) * rotCF
					base = w.CF and w.CF:Lerp(desired, math.clamp(14 * dt, 0, 1)) or desired
				end
				w.CF = base
				drive(w, base)
				for k, a in ipairs(w.Ammo or {}) do
					if not a.Busy then drive(a, base * CFrame.new(0.4 * k, 0.5, 0)) end
				end
			end

			-- idle shared bullet hats parked beside the helicopter
			for k, a in ipairs(X.HeliPool or {}) do
				if not a.Busy then drive(a, root * CFrame.new(-0.6 * k, 0.8, 1.5)) end
			end

			-- missile launcher hats: stay exactly where the sliders put them (swing toward lock / mouse if enabled)
			local launchAim
			if riding and m.HeliLaunchAim ~= false then
				local tr = (X.MsLocked and X.MsTarget and X.MsTarget.Parent) and msRoot(X.MsTarget)
				launchAim = tr and tr.Position or aimPoint(true)
			end
			local firstLauncher
			for _, l in pairs(X.HeliLaunchers or {}) do
				local base = root * slotCF(l.K)
				local desired = base
				if launchAim then
					local rotCF = CFrame.Angles(math.rad(m[l.K.rx] or 0), math.rad(m[l.K.ry] or 0), math.rad(m[l.K.rz] or 0))
					desired = CFrame.lookAt(base.Position, launchAim) * rotCF
				end
				if m.HeliLaunchSmooth == true then
					-- smooth follow: the launcher trails the helicopter a little
					local k = 1 - math.exp(-(m.HeliLaunchSmoothSpeed or 6) * dt)
					base = l.CF and l.CF:Lerp(desired, k) or desired
				else
					-- stay in place: position locked to the helicopter, only the aim swing is eased
					local cur = desired
					if launchAim and l.CF then cur = l.CF:Lerp(desired, math.clamp(10 * dt, 0, 1)) end
					base = CFrame.new(desired.Position) * cur.Rotation
				end
				l.CF = base
				drive(l, base)
				firstLauncher = firstLauncher or l
			end
			-- idle missile hats: loaded on the first launcher, or under the helicopter without one
			for k, a in ipairs(X.HeliMissiles or {}) do
				if not a.Busy then
					if firstLauncher and firstLauncher.CF then
						drive(a, firstLauncher.CF * CFrame.new(0, 0.5 + 0.4 * k, 0) * (a.K and slotCF(a.K) or CFrame.new()))
					else
						drive(a, root * CFrame.new(0.7 * k - 1.8, -1.2, 1.5) * (a.K and slotCF(a.K) or CFrame.new()))
					end
				end
			end
			X.stepHeliMissileLock(dt, riding)

			-- held fire
			if riding and X.HeliFireHeld and (m.HeliFireStyle or 2) ~= 1 then X.fireHeli(false) end

			-- engine + minigun audio
			pcall(X.stepHeliAudio, dt, followRoot, rpm, riding)

			-- optional chase camera
			if m.HeliCamLock and riding then
				pcall(function()
					local cam = workspace.CurrentCamera
					if cam then
						local back = root * CFrame.new(0, 5, 16)
						cam.CFrame = cam.CFrame:Lerp(CFrame.new(back.Position, root.Position + root.LookVector * 8), 1 - math.exp(-(m.HeliCamSmooth or 10) * dt))
					end
				end)
			end
		end
	end)()


	function X.stepAll(dt)
		if not m.Enabled or X.Dead then return end
		X.Frame = X.Frame + 1 if X.Frame % 120 == 1 and next(Held) ~= nil then pcall(X.boostNetwork) end
		-- full rate: stand, clone, hellcopter, dance recorder
		pcall(X.stepDanceRec, dt)
		pcall(X.stepStand, dt)
		pcall(X.stepClone, dt)
		pcall(X.stepHeli, dt)
		pcall(X.stepHeliBullets, dt)
		pcall(X.stepHeliMissiles, dt)
		if m.TitanEnabled then pcall(X.stepTitan, dt) end

		local skip = m.LowLag and math.clamp(math.floor(m.LowLagSkip or 2), 1, 6) or 1
		X.SlowAcc = (X.SlowAcc or 0) + dt
		-- vehicles you are riding stay at full rate
		local rideP = m.PlaneEnabled and m.PlaneRide
		local rideM = m.MotoEnabled and m.MotoRide
		local rideC = m.CarEnabled and m.CarRide
		if rideP then pcall(X.stepPlane, dt) end
		if rideM then pcall(X.stepMoto, dt) end
		if rideC then pcall(X.stepCar, dt) end
		if skip > 1 and (X.Frame % skip) ~= 0 then return end
		local sdt = X.SlowAcc
		X.SlowAcc = 0

		pcall(X.updatePlacePreview)
		pcall(X.stepPlaced, sdt)
		if NeedOrbitRebuild then
			NeedOrbitRebuild = false
			pcall(X.rebuildOrbit)
		end
		pcall(X.checkVehicleRebuilds, os.clock())
		if NeedPlaneRebuild then
			NeedPlaneRebuild = false
			pcall(X.rebuildPlane)
		end
		if NeedMotoRebuild then
			NeedMotoRebuild = false
			pcall(X.rebuildMoto)
		end
		if NeedPlanetRebuild then
			NeedPlanetRebuild = false
			pcall(X.rebuildPlanet)
		end
		if NeedToolRebuild then
			NeedToolRebuild = false
			pcall(X.rebuildTool)
		end
		if NeedCarRebuild then
			NeedCarRebuild = false
			pcall(X.rebuildCar)
		end
		pcall(X.stepOrbit, sdt)
		pcall(X.stepGaster, sdt)
		pcall(X.stepBone, sdt)
		pcall(X.stepOmega, sdt)
		pcall(X.stepWeapon, sdt)
		pcall(X.stepShield, sdt)
		pcall(stepClaws, sdt)
		if not rideC then pcall(X.stepCar, sdt) end
		pcall(X.stepBall, sdt)
		pcall(X.stepPlanet, sdt)
		if not rideM then pcall(X.stepMoto, sdt) end
		pcall(X.stepTool, sdt)
		if not rideP then pcall(X.stepPlane, sdt) end
	end

	function X.startLoop()
		if FollowBound or X.Dead then return end
		for _, n in ipairs(OLD_BIND_NAMES) do
			pcall(function() RunService:UnbindFromRenderStep(n) end)
		end
		pcall(function()
			local g = getgenv()
			if g and g.Uhhhhhh_HatStandHB then
				g.Uhhhhhh_HatStandHB:Disconnect()
				g.Uhhhhhh_HatStandHB = nil
			end
		end)
		HBConn = RunService.Heartbeat:Connect(function(dt)
			pcall(X.stepAll, math.clamp(dt, 0, 0.1))
		end)
		pcall(function()
			local g = getgenv()
			if g then g.Uhhhhhh_HatStandHB = HBConn end
		end)
		X.bindKeys()
		X.bindCharacter()
		X.startLate()
		X.startHatAutoRefresh()
		X.ensurePlaceFolder()
		FollowBound = true
	end

	function X.stopLoop()
		if HBConn then pcall(function() HBConn:Disconnect() end) HBConn = nil end
		pcall(function()
			local g = getgenv()
			if g then g.Uhhhhhh_HatStandHB = nil end
		end)
		for _, c in ipairs(KeyConns) do pcall(function() c:Disconnect() end) end
		for _, c in ipairs(CharConns) do pcall(function() c:Disconnect() end) end
		KeyConns, CharConns = {}, {}
		X.stopLate()
		if X.HeliSolidConn then pcall(function() X.HeliSolidConn:Disconnect() end) X.HeliSolidConn = nil end
		X.stopHatAutoRefresh()
		X.clearPlacePreview()
		FollowBound = false
	end

	function X.refreshState()
		if m.Enabled then
			X.startLoop()
			if X.modeAllowsStand() and m.AutoBuild and (not StandModel or not StandModel.Parent) then
				NeedRebuild = true
			end
			if not X.modeAllowsStand() and StandModel then pcall(X.destroyStand) end
			if X.modeAllowsOrbit() and m.OrbitEnabled then NeedOrbitRebuild = true end
			if not X.modeAllowsPlace() then X.clearPlacePreview() end
			if not X.modeAllowsOrbit() then X.clearOrbit() end
			if m.GasterEnabled then task.defer(X.rebuildGaster) else X.clearGaster() end
			if m.BoneEnabled then task.defer(X.rebuildBone) else X.clearBone() end
			if m.OmegaEnabled then task.defer(X.rebuildOmega) else X.clearOmega() end
			if m.WeaponEnabled then task.defer(X.rebuildWeapon) else X.clearWeapon() end
			if m.ShieldEnabled then task.defer(X.rebuildShield) else X.clearShield() end
			if m.ClawsEnabled then task.defer(rebuildClaws) else clearClaws() end
			if m.CarEnabled then task.defer(X.rebuildCar) else X.clearCar() end
			if m.BallEnabled then task.defer(X.rebuildBall) else X.clearBall() end
			if m.PlanetEnabled then task.defer(X.rebuildPlanet) else X.clearPlanet() end
			if m.MotoEnabled then task.defer(X.rebuildMoto) else X.clearMoto() end
			if m.ToolEnabled then task.defer(X.rebuildTool) else X.clearTool() end
			if m.PlaneEnabled then task.defer(X.rebuildPlane) else X.clearPlane() end
			if m.HeliEnabled then task.defer(X.rebuildHeli) else X.clearHeli() end
			if m.CloneEnabled then X.NeedCloneRebuild = true else X.clearClone() end
		else
			X.stopLoop()
			X.releaseHeld(nil)
			Limbs = {}
			OrbitSlots = {}
			X.clearAllPlaced()
			X.clearGaster()
			X.clearBone()
			X.clearOmega()
			X.clearWeapon()
			X.clearShield()
			clearClaws()
			X.clearCar()
			X.clearHeli()
			X.clearClone()
			X.clearLabels()
			X.clearLimbPreview()
		end
	end

	function X.resetLimbRots()
		for _, limb in ipairs(LIMB_NAMES) do
			local keys = LIMB_ROT_KEYS[limb]
			if keys then m[keys[1]] = 0 m[keys[2]] = 0 m[keys[3]] = 0 end
		end
		X.refreshAllLimbOffsets()
		X.updateLimbPreview()
	end

	function X.resetLimbOffsets()
		for _, limb in ipairs(LIMB_NAMES) do
			local keys = LIMB_OFF_KEYS[limb]
			if keys then m[keys[1]] = 0 m[keys[2]] = 0 m[keys[3]] = 0 end
		end
		X.refreshAllLimbOffsets()
		X.updateLimbPreview()
	end

	--------------------------------------------------------------
	-- CONFIG UI
	--------------------------------------------------------------
	m.Config = function(parent)
		if not parent then
			warn("[HatStand] Config called with nil parent")
			return
		end

		-- Host Util_* can return nil; never chain .Changed/.Activated blindly
		local function onChanged(ctrl, fn)
			if ctrl ~= nil and ctrl.Changed then
				pcall(function() ctrl.Changed:Connect(fn) end)
			end
			return ctrl
		end
		local function onActivated(ctrl, fn)
			if ctrl ~= nil and ctrl.Activated then
				pcall(function() ctrl.Activated:Connect(fn) end)
			end
			return ctrl
		end

		-- per-module GUI: only the sections this module owns are created (cfg.sections = set of keys)
		local H_Text, H_Switch, H_Slider, H_Drop, H_Button, H_Sep =
			Util_CreateText, Util_CreateSwitch, Util_CreateSlider, Util_CreateDropdown, Util_CreateButton, Util_CreateSeparator
		local SEC = "core"
		local DUMMY
		DUMMY = setmetatable({}, {
			__index = function() return DUMMY end,
			__call = function() return DUMMY end,
			__newindex = function() end,
		})
		local SEC_MAP = {
			{ "HAT COLLISION", "core" }, { "PERFORMANCE", "core" },
			{ "LINK / MOVESET", "stand" }, { "POSE FIX", "stand" }, { "CLONE", "stand" },
			{ "OWN DANCE", "stand" }, { "WALK / DANCE", "stand" }, { "── STAND ──", "stand" },
			{ "PLACE / BTOOLS", "place" }, { "BTOOLS BUILD", "place" },
			{ "HAT ORBIT", "orbit" },
			{ "SANS MODE", "sans" }, { "GASTER", "sans" }, { "BONE ATTACK", "sans" }, { "OMEGA BLASTER", "sans" },
			{ "WEAPONS", "weapons" }, { "SHIELD", "shield" }, { "RAVENGER", "claws" },
			{ "CAR", "car" }, { "BALL SYSTEM", "ball" }, { "PLANETS", "planet" },
			{ "MOTORCYCLE", "moto" }, { "PLANE", "plane" }, { "HELLCOPTER", "heli" }, { "TITAN", "titan" },
		}
		local function showing()
			if SEC == "core" or cfg.sections == nil then return true end
			return cfg.sections[SEC] == true
		end
		local Util_CreateText = function(p, text, ...)
			if type(text) == "string" then
				if string.sub(text, 1, 4) == "── " then
					for _, pair in ipairs(SEC_MAP) do
						if string.find(text, pair[1], 1, true) then SEC = pair[2] break end
					end
				elseif text == "HAT STAND  v16" and cfg.title then
					text = cfg.title
				elseif string.sub(text, 1, 7) == "Link • " and cfg.subtitle then
					text = cfg.subtitle
				end
			end
			if not showing() then return DUMMY end
			return H_Text(p, text, ...)
		end
		local Util_CreateSwitch = function(...) if not showing() then return DUMMY end return H_Switch(...) end
		local Util_CreateSlider = function(...) if not showing() then return DUMMY end return H_Slider(...) end
		local Util_CreateDropdown = function(...) if not showing() then return DUMMY end return H_Drop(...) end
		local Util_CreateButton = function(...) if not showing() then return DUMMY end return H_Button(...) end
		local Util_CreateSeparator = function(...) if not showing() then return DUMMY end return H_Sep(...) end

		local function keyDropdown(label, field)
			local start = 1
			for i, n in ipairs(m.KeyNames) do
				if n == m[field] then start = i break end
			end
			local dd = Util_CreateDropdown(parent, label, m.KeyNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					local name = (type(val) == "number") and m.KeyNames[val] or tostring(val)
					if name and name ~= "" then m[field] = name end
				end)
			end
			return dd
		end

		local okUI, errUI = pcall(function()
		Util_CreateText(parent, "HAT STAND  v16", 18, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "Link • Clone • Dances • JoJo Loco • Gaster • Weapons • Shield • Car • Claws", 12, Enum.TextXAlignment.Left)
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── HAT COLLISION (FE) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "All My Hats Solid (hit NPCs / dummies / unanchored parts)", m.HatsSolid == true), function(v) m.HatsSolid = v end)
		onChanged(Util_CreateSlider(parent, "Hat Push Strength", m.HatsSolidPush or 1, 0, 3, 0.1), function(v) m.HatsSolidPush = v end)
		onChanged(Util_CreateSwitch(parent, "Ignore other players (no collision with them)", m.HatsSolidIgnorePlayers ~= false), function(v) m.HatsSolidIgnorePlayers = v end)
		onChanged(Util_CreateSwitch(parent, "Boost simulation radius (own nearby unanchored parts)", m.HatsSolidBoost ~= false), function(v) m.HatsSolidBoost = v end)
		Util_CreateText(parent, "Hats are your own parts, so their collisions are FE. What they hit only moves for everyone if your client simulates it; anchored or server-owned things just block the hat.", 11, Enum.TextXAlignment.Left)
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── PERFORMANCE ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Low-Lag Mode (extras update less often)", m.LowLag), function(v) m.LowLag = v end)
		onChanged(Util_CreateSwitch(parent, "Full stop when I exit the moveset", m.StopOnExit ~= false), function(v) m.StopOnExit = v end)
		onChanged(Util_CreateSlider(parent, "Low-Lag Skip (1 = off, 2 = half rate)", m.LowLagSkip, 1, 6, 1), function(v) m.LowLagSkip = math.floor(v + 0.5) end)
		Util_CreateText(parent, "Stand, clone, hellcopter and anything you are riding stay at full rate. Orbit, weapons, Sans attacks, placed hats etc. run every Nth frame. Also on: duplicate hat writes are skipped and auto-refresh only rebuilds when your hats actually changed.", 11, Enum.TextXAlignment.Left)
		Util_CreateSeparator(parent)


		if cfg.mode == 4 then
			local modeDD = Util_CreateDropdown(parent, "Active Mode", m.ActiveModeNames, m.ActiveMode)
			if modeDD and modeDD.Changed then
				modeDD.Changed:Connect(function(val)
					if type(val) == "number" then m.ActiveMode = val
					elseif type(val) == "string" then
						for i, n in ipairs(m.ActiveModeNames) do
							if n == val then m.ActiveMode = i break end
						end
					end
					NeedRebuild = true
					NeedOrbitRebuild = true
					X.NeedCloneRebuild = true
					X.refreshState()
				end)
			end
			onChanged(Util_CreateSwitch(parent, "Stand + Clone also run in Hat Orbit mode", m.StandInOrbitMode ~= false), function(v)
				m.StandInOrbitMode = v
				NeedRebuild = true NeedOrbitRebuild = true X.NeedCloneRebuild = true
				X.refreshState()
			end)
		else
			Util_CreateText(parent, "Mode: " .. tostring(m.ActiveModeNames[m.ActiveMode] or m.ActiveMode) .. "  (this module is locked to that mode - run the other Hat modules next to it)", 11, Enum.TextXAlignment.Left)
		end
		onChanged(Util_CreateSwitch(parent, "Enabled", m.Enabled), function(v)
			m.Enabled = v X.refreshState()
		end)
		onChanged(Util_CreateSwitch(parent, "Use With Other Movesets", m.UseWithOtherMovesets), function(v)
			m.UseWithOtherMovesets = v X.refreshState()
		end)
		onChanged(Util_CreateSwitch(parent, "FE Real Hats", m.FEMode), function(v)
			m.FEMode = v
			X.releaseHeld(nil)
			NeedRebuild = true
			NeedOrbitRebuild = true
			X.refreshState()
		end)
		onActivated(Util_CreateButton(parent, "Refresh Hat List (check avatar)", 14), function()
			X.refreshAllHats(true)
			LastHatFingerprint = X.hatFingerprint()
		end)
		onChanged(Util_CreateSwitch(parent, "Auto Refresh every 1s", m.AutoRefresh), function(v)
			m.AutoRefresh = v
		end)
		Util_CreateText(parent, (m.LastRefreshReport ~= "" and m.LastRefreshReport) or "Last report: (press Refresh)", 11, Enum.TextXAlignment.Left)

		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── LINK / MOVESET / DANCES ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "LINK RIGS (stand copies my moveset + dances)", m.LinkRigs), function(v)
			m.LinkRigs = v
			X.LinkWarned = false
		end)
		onChanged(Util_CreateSlider(parent, "Link Strength", m.LinkStrength, 0, 1.5, 0.05), function(v) m.LinkStrength = v end)
		onChanged(Util_CreateSlider(parent, "Link Smooth (higher = tighter)", m.LinkSmooth, 6, 60, 1), function(v) m.LinkSmooth = v end)
		local linkDD = Util_CreateDropdown(parent, "Link Source", m.LinkSourceNames, m.LinkSource)
		if linkDD and linkDD.Changed then
			linkDD.Changed:Connect(function(val)
				if type(val) == "number" then m.LinkSource = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.LinkSourceNames) do
						if n == val then m.LinkSource = i break end
					end
				end
				X.LinkWarned = false
				X.RestSet = false
			end)
		end
		local msDD = Util_CreateDropdown(parent, "Stand Moveset (Link OFF)", m.StandMovesetNames, m.StandMoveset)
		if msDD and msDD.Changed then
			msDD.Changed:Connect(function(val)
				if type(val) == "number" then m.StandMoveset = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.StandMovesetNames) do
						if n == val then m.StandMoveset = i break end
					end
				end
			end)
		end
		local pdDD = Util_CreateDropdown(parent, "Procedural Dance (Moveset 4)", m.ProcDanceNames, m.ProcDance)
		if pdDD and pdDD.Changed then
			pdDD.Changed:Connect(function(val)
				if type(val) == "number" then m.ProcDance = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.ProcDanceNames) do
						if n == val then m.ProcDance = i break end
					end
				end
			end)
		end
		local danceNames = X.scanDances()
		Util_CreateText(parent, "Dance list source: " .. tostring(X.DanceSource) .. " (" .. #danceNames .. ")", 11, Enum.TextXAlignment.Left)
		local danceDD = Util_CreateDropdown(parent, "Dance (pick = play)", danceNames, 1)
		if danceDD and danceDD.Changed then
			danceDD.Changed:Connect(function(val)
				local name = (type(val) == "number") and danceNames[val] or tostring(val)
				X.playDance(name)
			end)
		end
		onActivated(Util_CreateButton(parent, "Print Dance List (console)", 12), function()
			warn("[HatStand] dances: " .. table.concat(X.scanDances(), ", "))
		end)
		onChanged(Util_CreateSwitch(parent, "SELECT FIRST (take no hats until I pick + Apply)", m.SelectFirst), function(v)
			m.SelectFirst = v
			X.Applied = false
			if v then
				X.destroyStand()
				X.clearClone()
			else
				NeedRebuild = true
				X.NeedCloneRebuild = true
			end
		end)
		Util_CreateText(parent, "Select First ON: pick Head/Torso/Arms/Legs (and Clone hats) below, then press Apply. Nothing is grabbed from Uhhhhhh before that, and no hat is auto-filled.", 11, Enum.TextXAlignment.Left)
		onActivated(Util_CreateButton(parent, "Apply Selected Hats (stand + clone)", 14), function()
			X.Applied = true
			NeedRebuild = true
			X.NeedCloneRebuild = true
			X.CloneLastBuild = 0
			X.refreshAllHats()
			local picked = 0
			for _, k in pairs(LIMB_KEYS) do if X.trim(m[k]) ~= "" then picked = picked + 1 end end
			for _, k in pairs(X.CloneKeys) do if X.trim(m[k]) ~= "" then picked = picked + 1 end end
			if picked == 0 and m.SelectFirst then
				warn("[HatStand] Select First is ON and no hats are picked — nothing was taken. Pick hats in the dropdowns, then Apply.")
			end
			pcall(X.buildStand)
		end)
		onActivated(Util_CreateButton(parent, "Release All Stand + Clone Hats", 12), function()
			X.Applied = false
			X.destroyStand()
			X.clearClone()
		end)
		onChanged(Util_CreateSwitch(parent, "Strict Hats (keep the hats I picked)", m.StrictHats), function(v)
			m.StrictHats = v NeedRebuild = true X.NeedCloneRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "JoJo Loco (walk / run / jump / fall / land)", m.JojoLoco), function(v) m.JojoLoco = v end)
		onChanged(Util_CreateSlider(parent, "Loco Blend Speed", m.LocoBlend, 4, 40, 1), function(v) m.LocoBlend = v end)
		onChanged(Util_CreateSlider(parent, "Loco Lean", m.LocoLean, 0, 2, 0.05), function(v) m.LocoLean = v end)
		onChanged(Util_CreateSlider(parent, "Loco Bob", m.LocoBob, 0, 2, 0.05), function(v) m.LocoBob = v end)
		onChanged(Util_CreateSlider(parent, "Loco Arm Out", m.LocoArmOut, 0, 3, 0.05), function(v) m.LocoArmOut = v end)
		onChanged(Util_CreateSlider(parent, "Fall Spread", m.FallSpread, 0, 2, 0.05), function(v) m.FallSpread = v end)
		onChanged(Util_CreateSlider(parent, "Land Squash", m.LandSquash, 0, 2, 0.05), function(v) m.LandSquash = v end)

		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── POSE FIX (always on: buttons only) ──", 14, Enum.TextXAlignment.Center)
		onActivated(Util_CreateButton(parent, "Calibrate Rest Pose NOW (stand still, arms down)", 13), function()
			X.calibrate()
		end)
		onActivated(Util_CreateButton(parent, "Clear Rest Calibration", 12), function()
			X.RestSet = false
			X.Rest = {}
			X.CalibT = 0
			X.Blend = {}
		end)
		onActivated(Util_CreateButton(parent, "Reset Pose (stop dance + clear blend)", 12), function()
			ForceDance = false
			ForceDanceUntil = 0
			DanceT = 0
			AnimState, AnimT = "idle", 0
			X.Blend = {}
			X.SnapT = 0.45
		end)
		onActivated(Util_CreateButton(parent, "FIX EVERYTHING (pose + rig + rest)", 14), function()
			m.PoseFix = true
			m.BigRigFix = true
			m.FixAnyRigPose = true
			ForceDance = false
			ForceDanceUntil = 0
			AnimState, AnimT = "idle", 0
			X.resetLimbRots()
			X.resetLimbOffsets()
			X.refreshAllLimbOffsets()
			X.Blend = {}
			X.RestSet = false
			X.calibrate()
			NeedRebuild = true
			pcall(X.buildStand)
			warn("[HatStand] FIX EVERYTHING applied")
		end)

		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── CLONE (spare hats, copies stand pose) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Clone Enabled", m.CloneEnabled), function(v)
			m.CloneEnabled = v
			if v then X.NeedCloneRebuild = true else X.clearClone() end
		end)
		onChanged(Util_CreateSwitch(parent, "Clone Auto Hats (use spare hats)", m.CloneAutoHats), function(v)
			m.CloneAutoHats = v X.NeedCloneRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Clone Face Same Way", m.CloneFaceSame), function(v) m.CloneFaceSame = v end)
		onChanged(Util_CreateSlider(parent, "Clone Side", m.CloneSide, -15, 15, 0.25), function(v) m.CloneSide = v end)
		onChanged(Util_CreateSlider(parent, "Clone Forward", m.CloneForward, -15, 15, 0.25), function(v) m.CloneForward = v end)
		onChanged(Util_CreateSlider(parent, "Clone Height", m.CloneHeight, -10, 10, 0.25), function(v) m.CloneHeight = v end)
		onChanged(Util_CreateSlider(parent, "Clone Follow Smooth", m.CloneSmooth, 5, 60, 1), function(v) m.CloneSmooth = v end)
		local cloneNames = X.dropdownNamesStand()
		local function cloneDD(label, key)
			local start = 1
			for i, n in ipairs(cloneNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					start = i break
				end
			end
			local dd = Util_CreateDropdown(parent, label, cloneNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and cloneNames[val] or tostring(val))
					X.NeedCloneRebuild = true
				end)
			end
		end
		cloneDD("Clone Head", "CloneHatHead")
		cloneDD("Clone Torso", "CloneHatTorso")
		cloneDD("Clone Left Arm", "CloneHatLeftArm")
		cloneDD("Clone Right Arm", "CloneHatRightArm")
		cloneDD("Clone Left Leg", "CloneHatLeftLeg")
		cloneDD("Clone Right Leg", "CloneHatRightLeg")
		onActivated(Util_CreateButton(parent, "Build / Rebuild Clone", 14), function()
			X.NeedCloneRebuild = true
			X.CloneLastBuild = 0
		end)
		onActivated(Util_CreateButton(parent, "Destroy Clone", 12), function() X.clearClone() end)

		-- CLONE limb rotation + position (live, no rebuild needed)
		local CLONE_LIMBS = {
			{ "Head", "Head" }, { "Torso", "Torso" },
			{ "Left Arm", "LeftArm" }, { "Right Arm", "RightArm" },
			{ "Left Leg", "LeftLeg" }, { "Right Leg", "RightLeg" },
		}
		Util_CreateText(parent, "CLONE LIMB ROTATION (saved)", 13, Enum.TextXAlignment.Left)
		for _, L in ipairs(CLONE_LIMBS) do
			local label, limb = L[1], L[2]
			Util_CreateText(parent, "Clone " .. label, 12, Enum.TextXAlignment.Left)
			for _, ax in ipairs({ "X", "Y", "Z" }) do
				local key = "CloneRot" .. limb .. ax
				onChanged(Util_CreateSlider(parent, "Clone " .. label .. " Rot " .. ax, m[key] or 0, -180, 180, 1), function(v)
					m[key] = v
				end)
			end
		end
		Util_CreateText(parent, "CLONE LIMB POSITION (side / up / forward)", 13, Enum.TextXAlignment.Left)
		Util_CreateText(parent, "Move each clone limb up, down, or to the side independently", 11, Enum.TextXAlignment.Left)
		for _, L in ipairs(CLONE_LIMBS) do
			local label, limb = L[1], L[2]
			Util_CreateText(parent, "Clone " .. label .. " Offset", 12, Enum.TextXAlignment.Left)
			onChanged(Util_CreateSlider(parent, "Clone " .. label .. " Side (X)", m["CloneOff" .. limb .. "X"] or 0, -5, 5, 0.05), function(v)
				m["CloneOff" .. limb .. "X"] = v
			end)
			onChanged(Util_CreateSlider(parent, "Clone " .. label .. " Up (Y)", m["CloneOff" .. limb .. "Y"] or 0, -5, 5, 0.05), function(v)
				m["CloneOff" .. limb .. "Y"] = v
			end)
			onChanged(Util_CreateSlider(parent, "Clone " .. label .. " Forward (Z)", m["CloneOff" .. limb .. "Z"] or 0, -5, 5, 0.05), function(v)
				m["CloneOff" .. limb .. "Z"] = v
			end)
		end
		onActivated(Util_CreateButton(parent, "Reset Clone Limb Rot/Offsets", 12), function()
			for _, L in ipairs(CLONE_LIMBS) do
				for _, ax in ipairs({ "X", "Y", "Z" }) do
					m["CloneRot" .. L[2] .. ax] = 0
					m["CloneOff" .. L[2] .. ax] = 0
				end
			end
		end)

		-- CLONE SLOTS (15): extra hats on the clone
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "CLONE SLOTS (15) - extra hats on the clone (Float / Weapon / Effect / Hand)", 13, Enum.TextXAlignment.Left)
		Util_CreateText(parent, "Pick a hat, press Build / Rebuild Clone. Offsets and rotation are live. Hand follows the clone's right arm.", 11, Enum.TextXAlignment.Left)
		for i = 1, 15 do
			local key = "CloneSlotHat" .. i
			local start = 1
			for j, n in ipairs(cloneNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
			end
			local dd = Util_CreateDropdown(parent, "Clone Slot " .. i .. " Hat", cloneNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and cloneNames[val] or tostring(val))
					X.NeedCloneRebuild = true
				end)
			end
			local kdd = Util_CreateDropdown(parent, "Slot " .. i .. " Kind", m.CloneSlotKindNames, m["CloneSlotKind" .. i] or 1)
			if kdd and kdd.Changed then
				kdd.Changed:Connect(function(val)
					local idx = (type(val) == "number") and val or nil
					if not idx then
						for j, n in ipairs(m.CloneSlotKindNames) do if n == val then idx = j break end end
					end
					if idx then m["CloneSlotKind" .. i] = idx end
				end)
			end
			for _, ax in ipairs({ "X", "Y", "Z" }) do
				onChanged(Util_CreateSlider(parent, "Slot " .. i .. " Off " .. ax, m["CloneSlotOff" .. ax .. i] or 0, -8, 8, 0.1), function(v)
					m["CloneSlotOff" .. ax .. i] = v
				end)
			end
			for _, ax in ipairs({ "X", "Y", "Z" }) do
				onChanged(Util_CreateSlider(parent, "Slot " .. i .. " Rot " .. ax, m["CloneSlotRot" .. ax .. i] or 0, -180, 180, 1), function(v)
					m["CloneSlotRot" .. ax .. i] = v
				end)
			end
		end

		-- OWN DANCE
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── OWN DANCE (stand / clone dance by themselves) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "1) Pick a Steve (Uhhhhhh) dance and press Record: it plays on Steve and captures his animation + the sounds. 2) Press Play on Stand / Clone / Both. They keep dancing even when you do something else.", 11, Enum.TextXAlignment.Left)
		do
			local all = X.scanDances()
			local danceNames = {}
			for _, n in ipairs(all) do
				if not string.find(n, "^%[Stand%]") then danceNames[#danceNames + 1] = n end
			end
			if #danceNames == 0 then danceNames[1] = "(none found - use Record Manual)" end
			X.RecDanceName = X.RecDanceName or danceNames[1]
			local dd = Util_CreateDropdown(parent, "Steve Dance To Record", danceNames, 1)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					X.RecDanceName = X.cleanLabel(type(val) == "number" and danceNames[val] or tostring(val))
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Record Length (sec)", m.OwnDanceRecSecs, 2, 60, 1), function(v) m.OwnDanceRecSecs = v end)
		onActivated(Util_CreateButton(parent, "RECORD selected Steve dance (anim + sounds)", 14), function()
			local nm = X.RecDanceName
			if not nm or string.find(nm, "^%(none") then warn("[HatStand] no dance selected") return end
			X.startDanceRec(nm, m.OwnDanceRecSecs, nm)
		end)
		onActivated(Util_CreateButton(parent, "RECORD manual (start any dance yourself, then Stop)", 12), function()
			X.startDanceRec("", 60, nil)
		end)
		onActivated(Util_CreateButton(parent, "STOP + SAVE recording", 12), function() X.finishDanceRec() end)
		onActivated(Util_CreateButton(parent, "Next recording (prints name in console)", 12), function() X.cycleDanceRec() end)
		onActivated(Util_CreateButton(parent, "PLAY on Stand", 14), function() X.playOwnDance("Stand") end)
		onActivated(Util_CreateButton(parent, "PLAY on Clone", 14), function() X.playOwnDance("Clone") end)
		onActivated(Util_CreateButton(parent, "PLAY on Stand + Clone", 14), function() X.playOwnDance("Both") end)
		onActivated(Util_CreateButton(parent, "STOP own dance (Stand + Clone)", 12), function() X.stopOwnDance("Both") end)
		onChanged(Util_CreateSwitch(parent, "Own Dance Loop", m.OwnDanceLoop), function(v) m.OwnDanceLoop = v end)
		onChanged(Util_CreateSwitch(parent, "Own Dance Play Sounds", m.OwnDanceSounds), function(v) m.OwnDanceSounds = v end)
		onChanged(Util_CreateSlider(parent, "Own Dance Speed", m.OwnDanceSpeed, 0.25, 3, 0.05), function(v) m.OwnDanceSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Own Dance Blend", m.OwnDanceBlend, 8, 60, 1), function(v) m.OwnDanceBlend = v end)
		onActivated(Util_CreateButton(parent, "Delete selected recording", 12), function() X.deleteDanceRec() end)
		onActivated(Util_CreateButton(parent, "Print recordings (console)", 12), function()
			warn("[HatStand] recordings: " .. table.concat(X.danceRecNames(), ", ") .. "  | selected: " .. tostring(X.OwnPick))
		end)


		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── WALK / DANCE / BALLER ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Walk With Me", m.WalkWithMe), function(v) m.WalkWithMe = v end)
		onChanged(Util_CreateSwitch(parent, "Dance Sync (detect emote)", m.DanceSync), function(v) m.DanceSync = v end)
		onChanged(Util_CreateSwitch(parent, "H Key = Force Dance", m.DanceKey), function(v) m.DanceKey = v end)
		onChanged(Util_CreateSwitch(parent, "Baller Mode", m.BallerMode), function(v) m.BallerMode = v end)
		onChanged(Util_CreateSwitch(parent, "Big Rig Fix (correct limb pose)", m.BigRigFix), function(v)
			m.BigRigFix = v
			X.refreshAllLimbOffsets()
			NeedRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Fix Rig Stand Rot & Pose (Any Rigs)", m.FixAnyRigPose), function(v)
			m.FixAnyRigPose = v
			X.refreshAllLimbOffsets()
			NeedRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Dance Mirror Character", m.DanceMirrorCharacter), function(v)
			m.DanceMirrorCharacter = v
		end)
		onChanged(Util_CreateSlider(parent, "BigRig Arm Spread", m.BigRigArmSpread, 0.8, 3, 0.05), function(v)
			m.BigRigArmSpread = v X.refreshAllLimbOffsets()
		end)
		onChanged(Util_CreateSlider(parent, "BigRig Leg Spread", m.BigRigLegSpread, 0.2, 1.5, 0.05), function(v)
			m.BigRigLegSpread = v X.refreshAllLimbOffsets()
		end)
		onChanged(Util_CreateSlider(parent, "BigRig Height Scale", m.BigRigHeight, 0.5, 2, 0.05), function(v)
			m.BigRigHeight = v X.refreshAllLimbOffsets()
		end)
		onChanged(Util_CreateSlider(parent, "Walk Side Offset", m.WalkSideOffset, -8, 8, 0.25), function(v) m.WalkSideOffset = v end)
		onChanged(Util_CreateSlider(parent, "Walk Forward Offset", m.WalkForwardOffset, -8, 8, 0.25), function(v) m.WalkForwardOffset = v end)
		onChanged(Util_CreateSlider(parent, "Walk Height Offset", m.WalkHeightOffset, -5, 8, 0.25), function(v) m.WalkHeightOffset = v end)
		onChanged(Util_CreateSlider(parent, "Walk Follow Smooth", m.WalkSmoothness, 5, 40, 1), function(v) m.WalkSmoothness = v end)
		onChanged(Util_CreateSlider(parent, "Walk Strength", m.WalkStrength, 0, 2, 0.05), function(v) m.WalkStrength = v end)
		onChanged(Util_CreateSlider(parent, "Run Strength", m.RunStrength, 0, 2, 0.05), function(v) m.RunStrength = v end)
		onChanged(Util_CreateSlider(parent, "Jump Strength", m.JumpStrength, 0, 2, 0.05), function(v) m.JumpStrength = v end)
		onChanged(Util_CreateSlider(parent, "Walk Cycle Speed", m.WalkCycleSpeed, 2, 16, 0.25), function(v) m.WalkCycleSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Run Cycle Speed", m.RunCycleSpeed, 4, 20, 0.25), function(v) m.RunCycleSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Run Speed Threshold", m.RunThreshold, 6, 30, 1), function(v) m.RunThreshold = v end)
		onChanged(Util_CreateSlider(parent, "Dance Strength", m.DanceStrength, 0, 2, 0.05), function(v) m.DanceStrength = v end)

		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── STAND ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Auto Limb Catalog Hats", m.AutoLimbHats), function(v)
			m.AutoLimbHats = v NeedRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Auto Spare Hats (fill empty limbs)", m.AutoSpareHats), function(v)
			m.AutoSpareHats = v NeedRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Allow Used Hats (risky)", m.AllowUsedHats), function(v)
			m.AllowUsedHats = v NeedRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Auto Build", m.AutoBuild), function(v) m.AutoBuild = v end)
		onChanged(Util_CreateSwitch(parent, "Keybinds (see bottom)", m.Keybinds), function(v) m.Keybinds = v end)
		onChanged(Util_CreateSwitch(parent, "Show Hat Names", m.ShowHatNames), function(v)
			m.ShowHatNames = v NeedRebuild = true
		end)
		onChanged(Util_CreateSwitch(parent, "Auto Correct Place", m.AutoCorrect), function(v) m.AutoCorrect = v end)
		onActivated(Util_CreateButton(parent, "Build / Rebuild Stand", 14), function() X.buildStand() end)
		onActivated(Util_CreateButton(parent, "Destroy Stand", 12), function() X.destroyStand() end)
		onActivated(Util_CreateButton(parent, "Reset Limb Rotations", 12), function() X.resetLimbRots() end)
		onActivated(Util_CreateButton(parent, "Reset Limb Offsets", 12), function() X.resetLimbOffsets() end)
		onActivated(Util_CreateButton(parent, "Apply Perfect Big Rig Pose", 14), function()
			m.BigRigFix = true
			m.FixAnyRigPose = true
			X.resetLimbRots()
			X.resetLimbOffsets()
			X.refreshAllLimbOffsets()
			NeedRebuild = true
			pcall(X.buildStand)
			warn("[HatStand] Perfect pose applied (BigRig + AnyRig) — toggle off to disable")
		end)

		local idleDD = Util_CreateDropdown(parent, "Idle Style", m.IdleStyleNames, m.IdleStyle)
		if idleDD and idleDD.Changed then
			idleDD.Changed:Connect(function(val)
				if type(val) == "number" then m.IdleStyle = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.IdleStyleNames) do
						if n == val then m.IdleStyle = i break end
					end
				end
			end)
		end

		local standNames = X.dropdownNamesStand()
		local function limbDD(label, key)
			local start = 1
			for i, n in ipairs(standNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					start = i break
				end
			end
			local dd = Util_CreateDropdown(parent, label, standNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and standNames[val] or tostring(val))
					NeedRebuild = true
				end)
			end
		end
		limbDD("Head", "HatHead")
		limbDD("Torso", "HatTorso")
		limbDD("Left Arm", "HatLeftArm")
		limbDD("Right Arm", "HatRightArm")
		limbDD("Left Leg", "HatLeftLeg")
		limbDD("Right Leg", "HatRightLeg")

		Util_CreateText(parent, "LIMB ROTATION (saved)", 13, Enum.TextXAlignment.Left)
		local function rotSliders(label, limb)
			local keys = LIMB_ROT_KEYS[limb]
			if not keys then return end
			Util_CreateText(parent, label, 12, Enum.TextXAlignment.Left)
			onChanged(Util_CreateSlider(parent, label .. " X", m[keys[1]], -180, 180, 1), function(v)
				m[keys[1]] = v X.refreshAllLimbOffsets() X.updateLimbPreview()
			end)
			onChanged(Util_CreateSlider(parent, label .. " Y", m[keys[2]], -180, 180, 1), function(v)
				m[keys[2]] = v X.refreshAllLimbOffsets() X.updateLimbPreview()
			end)
			onChanged(Util_CreateSlider(parent, label .. " Z", m[keys[3]], -180, 180, 1), function(v)
				m[keys[3]] = v X.refreshAllLimbOffsets() X.updateLimbPreview()
			end)
		end
		rotSliders("Head", "Head")
		rotSliders("Torso", "Torso")
		rotSliders("Left Arm", "LeftArm")
		rotSliders("Right Arm", "RightArm")
		rotSliders("Left Leg", "LeftLeg")
		rotSliders("Right Leg", "RightLeg")

		Util_CreateText(parent, "LIMB POSITION OFFSET (side / up / forward)", 13, Enum.TextXAlignment.Left)
		Util_CreateText(parent, "Move each limb up, down, or to the side independently", 11, Enum.TextXAlignment.Left)
		local function offSliders(label, limb)
			local keys = LIMB_OFF_KEYS[limb]
			if not keys then return end
			Util_CreateText(parent, label .. " Offset", 12, Enum.TextXAlignment.Left)
			onChanged(Util_CreateSlider(parent, label .. " Side (X)", m[keys[1]], -5, 5, 0.05), function(v)
				m[keys[1]] = v X.refreshAllLimbOffsets() X.updateLimbPreview()
			end)
			onChanged(Util_CreateSlider(parent, label .. " Up (Y)", m[keys[2]], -5, 5, 0.05), function(v)
				m[keys[2]] = v X.refreshAllLimbOffsets() X.updateLimbPreview()
			end)
			onChanged(Util_CreateSlider(parent, label .. " Forward (Z)", m[keys[3]], -5, 5, 0.05), function(v)
				m[keys[3]] = v X.refreshAllLimbOffsets() X.updateLimbPreview()
			end)
		end
		offSliders("Head", "Head")
		offSliders("Torso", "Torso")
		offSliders("Left Arm", "LeftArm")
		offSliders("Right Arm", "RightArm")
		offSliders("Left Leg", "LeftLeg")
		offSliders("Right Leg", "RightLeg")
		onActivated(Util_CreateButton(parent, "Reset Limb Offsets", 12), function()
			X.resetLimbOffsets()
		end)
		onChanged(Util_CreateSwitch(parent, "Show Limb Layout Preview", m.ShowLimbPreview), function(v)
			m.ShowLimbPreview = v
			if v then X.updateLimbPreview() else X.clearLimbPreview() end
		end)

		local methodDD = Util_CreateDropdown(parent, "Stand Mode (Walk OFF)", m.MethodNames, m.MethodIndex)
		if methodDD and methodDD.Changed then
			methodDD.Changed:Connect(function(val)
				if type(val) == "number" then m.MethodIndex = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.MethodNames) do
						if n == val then m.MethodIndex = i break end
					end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Side Offset", m.SideOffset, -15, 15, 0.5), function(v) m.SideOffset = v end)
		onChanged(Util_CreateSlider(parent, "Forward Offset", m.ForwardOffset, -15, 15, 0.5), function(v) m.ForwardOffset = v end)
		onChanged(Util_CreateSlider(parent, "Height Offset", m.HeightOffset, -10, 10, 0.5), function(v) m.HeightOffset = v end)
		onChanged(Util_CreateSlider(parent, "Follow Smoothness", m.Smoothness, 5, 90, 1), function(v) m.Smoothness = v end)
		onChanged(Util_CreateSlider(parent, "Auto Correct Dist", m.AutoCorrectDist, 5, 80, 1), function(v) m.AutoCorrectDist = v end)
		onChanged(Util_CreateSlider(parent, "Stand Scale", m.StandScale, 0.4, 2.5, 0.05), function(v)
			m.StandScale = v X.refreshAllLimbOffsets()
		end)
		onChanged(Util_CreateSwitch(parent, "Face Same Way", m.FaceSameWay), function(v) m.FaceSameWay = v end)

		-- PLACE
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── PLACE / BTOOLS (REAL hats) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "E = Yeet nearest  |  T = Place back  |  Backspace = REMOVE nearest  |  R = cycle slot", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Place Mode ON", m.PlaceEnabled), function(v)
			m.PlaceEnabled = v
			if not v then X.clearPlacePreview() end
		end)
		onChanged(Util_CreateSwitch(parent, "Show Place Preview", m.PlacePreviewOn), function(v)
			m.PlacePreviewOn = v
			if not v then X.clearPlacePreview() end
		end)
		onChanged(Util_CreateSwitch(parent, "Persist on Respawn", m.PlacePersist), function(v) m.PlacePersist = v end)
		onChanged(Util_CreateSwitch(parent, "Build Animation", m.PlaceBuildAnim), function(v) m.PlaceBuildAnim = v end)
		onChanged(Util_CreateSwitch(parent, "Custom Place / Pickup Anim", m.PlaceCustomAnim), function(v) m.PlaceCustomAnim = v end)
		onChanged(Util_CreateSwitch(parent, "Spin Placed Hats", m.PlaceSpin), function(v) m.PlaceSpin = v end)
		onChanged(Util_CreateSwitch(parent, "Bob Placed Hats", m.PlaceBob), function(v) m.PlaceBob = v end)
		onChanged(Util_CreateSlider(parent, "Active Place Slot (1-10)", m.PlaceActiveSlot, 1, 10, 1), function(v)
			m.PlaceActiveSlot = math.clamp(math.floor(v + 0.5), 1, 10)
			X.clearPlacePreview()
		end)
		onChanged(Util_CreateSlider(parent, "Build Anim Speed", m.PlaceBuildAnimSpeed, 0.3, 3, 0.1), function(v) m.PlaceBuildAnimSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Spin Speed", m.PlaceSpinSpeed, 0, 10, 0.1), function(v) m.PlaceSpinSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bob Speed", m.PlaceBobSpeed, 0.2, 5, 0.1), function(v) m.PlaceBobSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bob Height", m.PlaceBobHeight, 0, 3, 0.05), function(v) m.PlaceBobHeight = v end)
		onChanged(Util_CreateSlider(parent, "Snap Grid (0=free)", m.PlaceSnapGrid, 0, 5, 0.5), function(v) m.PlaceSnapGrid = v end)
		onChanged(Util_CreateSlider(parent, "Max Placed", m.PlaceMax, 1, 120, 1), function(v) m.PlaceMax = v end)
		onChanged(Util_CreateSlider(parent, "Yeet Force", m.PlaceYeetForce, 20, 200, 5), function(v) m.PlaceYeetForce = v end)
		onChanged(Util_CreateSlider(parent, "Yeet Up Force", m.PlaceYeetUp, 0, 100, 5), function(v) m.PlaceYeetUp = v end)

		local placeNames = X.dropdownNames(true)
		for slot = 1, 10 do
			local key = "PlaceHat" .. slot
			local start = 1
			for i, n in ipairs(placeNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					start = i break
				end
			end
			local dd = Util_CreateDropdown(parent, "Place Slot " .. slot, placeNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and placeNames[val] or tostring(val))
					X.clearPlacePreview()
				end)
			end
			local function setOff(axis, v)
				local old = X.getPlaceSlotRot(slot)
				m["PlaceOff" .. slot .. axis] = v
				local delta = old:Inverse() * X.getPlaceSlotRot(slot)
				for _, e in ipairs(PlacedHats) do
					if e.Slot == slot and e.BaseCF then e.BaseCF = e.BaseCF * delta end
				end
			end
			onChanged(Util_CreateSlider(parent, "S" .. slot .. " Side (left/right)", m["PlaceOff" .. slot .. "X"], -30, 30, 0.1), function(v) setOff("X", v) end)
			onChanged(Util_CreateSlider(parent, "S" .. slot .. " Up/Down", m["PlaceOff" .. slot .. "Y"], -30, 30, 0.1), function(v) setOff("Y", v) end)
			onChanged(Util_CreateSlider(parent, "S" .. slot .. " Forward/Back", m["PlaceOff" .. slot .. "Z"], -30, 30, 0.1), function(v) setOff("Z", v) end)
			onChanged(Util_CreateSlider(parent, "S" .. slot .. " Rot X", m["PlaceRot" .. slot .. "X"], -180, 180, 1), function(v)
				m["PlaceRot" .. slot .. "X"] = v
			end)
			onChanged(Util_CreateSlider(parent, "S" .. slot .. " Rot Y", m["PlaceRot" .. slot .. "Y"], -180, 180, 1), function(v)
				m["PlaceRot" .. slot .. "Y"] = v
			end)
			onChanged(Util_CreateSlider(parent, "S" .. slot .. " Rot Z", m["PlaceRot" .. slot .. "Z"], -180, 180, 1), function(v)
				m["PlaceRot" .. slot .. "Z"] = v
			end)
		end
		onChanged(Util_CreateSwitch(parent, "LOCK PLACED HATS (stay put, re-grab real hat)", m.PlaceLock), function(v)
			m.PlaceLock = v
		end)
		onChanged(Util_CreateSwitch(parent, "SOLID Placed Hats (walk / stand on them)", m.PlaceSolid), function(v)
			m.PlaceSolid = v
			pcall(X.solidStep)
		end)
		onChanged(Util_CreateSwitch(parent, "Stay After Loop Respawn", m.PlaceStayAfterRespawn), function(v)
			m.PlaceStayAfterRespawn = v
		end)
		onChanged(Util_CreateSwitch(parent, "Underground On Slot Select (BTools stash)", m.PlaceUndergroundOnSelect), function(v)
			m.PlaceUndergroundOnSelect = v
		end)
		onChanged(Util_CreateSlider(parent, "Place Stash Depth", m.PlaceUndergroundDepth, 2, 40, 1), function(v)
			m.PlaceUndergroundDepth = v
		end)
		onChanged(Util_CreateSlider(parent, "Place Stash Rise/Sink Time", m.PlaceUndergroundSpeed, 0.05, 2, 0.05), function(v)
			m.PlaceUndergroundSpeed = v
		end)
		onActivated(Util_CreateButton(parent, "Re-grab Lost Placed Hats Now", 12), function()
			for _, e in ipairs(PlacedHats) do
				if e.Lost then e.ReclaimT = 0 pcall(X.reclaim, e) end
			end
		end)
		onActivated(Util_CreateButton(parent, "Remove Nearest Placed Hat", 12), function() X.removeNearest() end)
		onActivated(Util_CreateButton(parent, "Clear All Placed Hats", 12), function() X.clearAllPlaced() end)

		-- BTOOLS BUILD MODES
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── BTOOLS BUILD MODES (presets + save/carry) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "1) Pick hats in Place Slot 1-10 above.  2) Pick a mode.  3) Click the world (Place Mode ON) or press Y, or hit BUILD NOW. Every slot that has a hat is used.", 11, Enum.TextXAlignment.Left)
		local btDD = Util_CreateDropdown(parent, "Build Mode", m.BToolsModeNames, m.BToolsMode)
		if btDD and btDD.Changed then
			btDD.Changed:Connect(function(val)
				if type(val) == "number" then m.BToolsMode = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.BToolsModeNames) do if n == val then m.BToolsMode = i break end end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Build Scale", m.BToolsScale, 0.3, 3, 0.05), function(v) m.BToolsScale = v end)
		onChanged(Util_CreateSlider(parent, "Build Spacing", m.BToolsSpacing, 0.5, 8, 0.25), function(v) m.BToolsSpacing = v end)
		onChanged(Util_CreateSwitch(parent, "Preview Full Structure", m.BToolsPreviewAll), function(v)
			m.BToolsPreviewAll = v
			if not v then X.clearStructGhosts() end
		end)
		onChanged(Util_CreateSwitch(parent, "Click / Y Builds Whole Structure (modes 2-25)", m.BToolsClickBuild), function(v)
			m.BToolsClickBuild = v
			X.clearStructGhosts()
		end)
		onChanged(Util_CreateSwitch(parent, "CARRY Build (move whole structure)", m.BToolsCarry), function(v)
			m.BToolsCarry = v
			if not v then BToolsCarryCF = nil end
			if v then
				for _, e in ipairs(PlacedHats) do e.CarryOff = nil end
			end
		end)
		onChanged(Util_CreateSlider(parent, "Carry Smoothness", m.BToolsCarrySmooth, 3, 30, 1), function(v) m.BToolsCarrySmooth = v end)
		onActivated(Util_CreateButton(parent, "BUILD NOW (in front of me, all filled slots)", 14), function()
			X.buildStructure(false)
		end)
		onActivated(Util_CreateButton(parent, "APPLY Build Mode (set Place offsets)", 14), function()
			X.applyBToolsMode()
		end)
		onActivated(Util_CreateButton(parent, "SAVE Current Build (uses name below)", 14), function()
			X.saveBToolsBuild(m.BToolsBuildName or "MyBuild")
		end)
		onActivated(Util_CreateButton(parent, "LOAD Last Saved Build", 12), function()
			local n = m.BToolsLastSaved ~= "" and m.BToolsLastSaved or m.BToolsBuildName
			X.loadBToolsBuild(n)
		end)
		Util_CreateText(parent, "Build name is set via Save (default MyBuild). Last saved: check console.", 11, Enum.TextXAlignment.Left)

		-- ORBIT
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── HAT ORBIT (modes + Finale + per-slot rot) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Orbit Enabled", m.OrbitEnabled), function(v)
			m.OrbitEnabled = v NeedOrbitRebuild = true if not v then X.clearOrbit() else task.defer(X.rebuildOrbit) end
		end)
		onChanged(Util_CreateSwitch(parent, "Auto Rebuild Orbit", m.OrbitAutoRebuild), function(v) m.OrbitAutoRebuild = v end)
		local omDD = Util_CreateDropdown(parent, "Orbit Mode", m.OrbitModeNames, m.OrbitMode)
		if omDD and omDD.Changed then
			omDD.Changed:Connect(function(val)
				if type(val) == "number" then m.OrbitMode = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.OrbitModeNames) do if n == val then m.OrbitMode = i break end end
				end
			end)
		end
		onChanged(Util_CreateSwitch(parent, "Face Outward", m.OrbitFaceOut), function(v) m.OrbitFaceOut = v end)
		onChanged(Util_CreateSwitch(parent, "Spin Self", m.OrbitSpinSelf), function(v) m.OrbitSpinSelf = v end)
		onChanged(Util_CreateSwitch(parent, "Vertical Motion (up/down)", m.OrbitVertical), function(v) m.OrbitVertical = v end)
		onChanged(Util_CreateSwitch(parent, "Finale Pulse Radius", m.OrbitFinalePulse), function(v) m.OrbitFinalePulse = v end)
		onChanged(Util_CreateSlider(parent, "Orbit Radius (base)", m.OrbitRad, 1, 30, 0.5), function(v) m.OrbitRad = v end)
		onChanged(Util_CreateSlider(parent, "Orbit Speed (base)", m.OrbitSpd, 0.1, 5, 0.1), function(v) m.OrbitSpd = v end)
		onChanged(Util_CreateSlider(parent, "Orbit Height", m.OrbitH, -5, 15, 0.5), function(v) m.OrbitH = v end)
		onChanged(Util_CreateSlider(parent, "Self Spin Speed", m.OrbitSpinSelfSpd, 0.5, 12, 0.5), function(v) m.OrbitSpinSelfSpd = v end)
		onChanged(Util_CreateSlider(parent, "Vertical Amplitude", m.OrbitVertAmp, 0, 6, 0.1), function(v) m.OrbitVertAmp = v end)
		onChanged(Util_CreateSlider(parent, "Vertical Speed", m.OrbitVertSpd, 0.1, 5, 0.1), function(v) m.OrbitVertSpd = v end)
		onChanged(Util_CreateSlider(parent, "Finale Pulse Amount", m.OrbitFinalePulseAmt, 0, 5, 0.1), function(v) m.OrbitFinalePulseAmt = v end)
		onChanged(Util_CreateSlider(parent, "Finale Pulse Speed", m.OrbitFinalePulseSpd, 0.5, 8, 0.1), function(v) m.OrbitFinalePulseSpd = v end)
		local orbitNames = X.dropdownNames(true)
		for i = 1, 10 do
			local key = ORBIT_HAT_KEYS[i]
			local start = 1
			for j, n in ipairs(orbitNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					start = j break
				end
			end
			local dd = Util_CreateDropdown(parent, "Orbit Slot " .. i, orbitNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and orbitNames[val] or tostring(val))
					NeedOrbitRebuild = true
					if m.OrbitAutoRebuild then task.defer(X.rebuildOrbit) end
				end)
			end
			onChanged(Util_CreateSlider(parent, "O" .. i .. " Speed Mult", m["OrbitSpdMult" .. i], 0.1, 5, 0.1), function(v)
				m["OrbitSpdMult" .. i] = v
				if OrbitSlots[i] then OrbitSlots[i].SpdMult = v end
			end)
			onChanged(Util_CreateSlider(parent, "O" .. i .. " Radius Offset", m["OrbitRadOff" .. i], -10, 20, 0.5), function(v)
				m["OrbitRadOff" .. i] = v
				if OrbitSlots[i] then OrbitSlots[i].RadOff = v end
			end)
			onChanged(Util_CreateSlider(parent, "O" .. i .. " Vert Offset", m["OrbitVertOff" .. i], -10, 10, 0.25), function(v)
				m["OrbitVertOff" .. i] = v
				if OrbitSlots[i] then OrbitSlots[i].VertOff = v end
			end)
			onChanged(Util_CreateSlider(parent, "O" .. i .. " Rot X", m["OrbitRotX" .. i], -180, 180, 1), function(v)
				m["OrbitRotX" .. i] = v
				if OrbitSlots[i] then
					OrbitSlots[i].Rot = CFrame.Angles(math.rad(v), math.rad(m["OrbitRotY" .. i] or 0), math.rad(m["OrbitRotZ" .. i] or 0))
				end
			end)
			onChanged(Util_CreateSlider(parent, "O" .. i .. " Rot Y", m["OrbitRotY" .. i], -180, 180, 1), function(v)
				m["OrbitRotY" .. i] = v
				if OrbitSlots[i] then
					OrbitSlots[i].Rot = CFrame.Angles(math.rad(m["OrbitRotX" .. i] or 0), math.rad(v), math.rad(m["OrbitRotZ" .. i] or 0))
				end
			end)
			onChanged(Util_CreateSlider(parent, "O" .. i .. " Rot Z", m["OrbitRotZ" .. i], -180, 180, 1), function(v)
				m["OrbitRotZ" .. i] = v
				if OrbitSlots[i] then
					OrbitSlots[i].Rot = CFrame.Angles(math.rad(m["OrbitRotX" .. i] or 0), math.rad(m["OrbitRotY" .. i] or 0), math.rad(v))
				end
			end)
		end
		onActivated(Util_CreateButton(parent, "Apply / Rebuild Orbit", 14), function() X.rebuildOrbit() end)
		onActivated(Util_CreateButton(parent, "Clear Orbit", 12), function()
			for _, key in ipairs(ORBIT_HAT_KEYS) do m[key] = "" end
			X.clearOrbit()
		end)

		-- SANS MASTER (Gaster + Bone + Omega)
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── SANS MODE (Gaster + Bone + Omega) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "ON = every Sans hat hides underground; firing raises it, attacks, then sinks. OFF = they float up.", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "SANS UNDERGROUND (all attacks)", m.SansUnderground), function(v)
			X.setSansUnderground(v)
		end)
		keyDropdown("Sans Underground Toggle Key", "KeySansToggle")
		keyDropdown("Sans Fire-All Key (Gaster+Bone+Omega)", "KeySans")
		onChanged(Util_CreateSlider(parent, "Sans Stash Depth (studs)", m.SansStashDepth, 2, 40, 1), function(v) m.SansStashDepth = v end)
		onChanged(Util_CreateSlider(parent, "Sans Rise Time", m.SansStashRise, 0.1, 1.5, 0.05), function(v) m.SansStashRise = v end)
		onChanged(Util_CreateSlider(parent, "Sans Stay Up After Attack", m.SansStashHold, 0.2, 5, 0.1), function(v) m.SansStashHold = v end)

		-- GASTER (5 slots)
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── GASTER BLASTER x5 (rebindable keys below) ──", 14, Enum.TextXAlignment.Center)
		keyDropdown("Gaster Fire Key", "KeyGaster")
		keyDropdown("Gaster Cycle Slot Key", "KeyGasterCycle")
		onChanged(Util_CreateSwitch(parent, "Gaster Enabled", m.GasterEnabled), function(v)
			m.GasterEnabled = v
			if v then X.rebuildGaster() else X.clearGaster() end
		end)
		onChanged(Util_CreateSwitch(parent, "Gaster Track Mouse (aim blast)", m.GasterTrackMouse), function(v)
			m.GasterTrackMouse = v
		end)
		onChanged(Util_CreateSwitch(parent, "Track Mouse Only While Firing", m.GasterTrackOnlyFire), function(v)
			m.GasterTrackOnlyFire = v
		end)
		local gfmDD = Util_CreateDropdown(parent, "Gaster Fire Mode", m.GasterFireModeNames, m.GasterFireMode)
		if gfmDD and gfmDD.Changed then
			gfmDD.Changed:Connect(function(val)
				if type(val) == "number" then m.GasterFireMode = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.GasterFireModeNames) do if n == val then m.GasterFireMode = i break end end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Active Gaster Slot", m.GasterActiveSlot, 1, 5, 1), function(v)
			m.GasterActiveSlot = math.clamp(math.floor(v + 0.5), 1, 5)
		end)
		local gNames = X.dropdownNames(true)
		for i = 1, 5 do
			local key = "GasterHat" .. i
			local startI = 1
			for j, n in ipairs(gNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					startI = j break
				end
			end
			local dd = Util_CreateDropdown(parent, "Gaster Slot " .. i, gNames, startI)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and gNames[val] or tostring(val))
					if i == 1 then m.GasterHat = m[key] end
					X.rebuildGaster()
				end)
			end
			onChanged(Util_CreateSwitch(parent, "Fire Slot " .. i, m["GasterFire" .. i]), function(v)
				m["GasterFire" .. i] = v
			end)
			onChanged(Util_CreateSlider(parent, "G" .. i .. " Side", m["GasterSide" .. i], -10, 10, 0.25), function(v) m["GasterSide" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "G" .. i .. " Height", m["GasterHeight" .. i], -5, 8, 0.25), function(v) m["GasterHeight" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "G" .. i .. " Forward", m["GasterForward" .. i], -8, 8, 0.25), function(v) m["GasterForward" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "G" .. i .. " Rot X", m["GasterRotX" .. i], -180, 180, 1), function(v) m["GasterRotX" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "G" .. i .. " Rot Y", m["GasterRotY" .. i], -180, 180, 1), function(v) m["GasterRotY" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "G" .. i .. " Rot Z", m["GasterRotZ" .. i], -180, 180, 1), function(v) m["GasterRotZ" .. i] = v end)
		end
		onChanged(Util_CreateSlider(parent, "Gaster Size", m.GasterSize, 0.5, 3, 0.1), function(v) m.GasterSize = v end)
		onChanged(Util_CreateSlider(parent, "Laser Length", m.GasterLaserLength, 20, 150, 5), function(v) m.GasterLaserLength = v end)
		onChanged(Util_CreateSlider(parent, "Laser Thickness", m.GasterLaserThick, 0.3, 4, 0.1), function(v) m.GasterLaserThick = v end)
		onChanged(Util_CreateSlider(parent, "Cooldown", m.GasterCooldown, 0.3, 5, 0.1), function(v) m.GasterCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Charge Time", m.GasterChargeTime, 0.05, 1.5, 0.05), function(v) m.GasterChargeTime = v end)
		onChanged(Util_CreateSlider(parent, "Push Force", m.GasterPush, 0, 120, 5), function(v) m.GasterPush = v end)
		Util_CreateText(parent, "GASTER HAT BULLET + TRAIL OSC", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Use Hat Bullet (with laser)", m.GasterUseHatBullet), function(v) m.GasterUseHatBullet = v end)
		do
			local gbStart = 1
			for i, n in ipairs(gNames) do
				if m.GasterHatBullet ~= "" and string.find(string.lower(n), string.lower(m.GasterHatBullet), 1, true) then
					gbStart = i break
				end
			end
			local gbDD = Util_CreateDropdown(parent, "Gaster Bullet Hat", gNames, gbStart)
			if gbDD and gbDD.Changed then
				gbDD.Changed:Connect(function(val)
					m.GasterHatBullet = X.cleanLabel(type(val) == "number" and gNames[val] or tostring(val))
				end)
			end
		end
		onChanged(Util_CreateSwitch(parent, "Trail Oscillation (back & forth)", m.GasterTrailOsc), function(v) m.GasterTrailOsc = v end)
		onChanged(Util_CreateSlider(parent, "Osc Speed", m.GasterTrailOscSpeed, 4, 40, 1), function(v) m.GasterTrailOscSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Osc Distance", m.GasterTrailOscDist, 2, 40, 0.5), function(v) m.GasterTrailOscDist = v end)
		onChanged(Util_CreateSlider(parent, "Osc Duration", m.GasterTrailOscTime, 0.2, 4, 0.1), function(v) m.GasterTrailOscTime = v end)
		onChanged(Util_CreateSwitch(parent, "Gaster SFX", m.GasterSFX), function(v) m.GasterSFX = v end)
		onChanged(Util_CreateSlider(parent, "Gaster Volume", m.GasterVolume, 0, 2, 0.05), function(v) m.GasterVolume = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Gaster", 12), function() X.rebuildGaster() end)

		-- BONE ATTACK
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── BONE ATTACK (uses hat) ──", 14, Enum.TextXAlignment.Center)
		keyDropdown("Bone Fire Key", "KeyBone")
		onChanged(Util_CreateSwitch(parent, "Bone Enabled", m.BoneEnabled), function(v)
			m.BoneEnabled = v
			if v then X.rebuildBone() else X.clearBone() end
		end)
		do
			local bStart = 1
			for i, n in ipairs(gNames) do
				if m.BoneHat ~= "" and string.find(string.lower(n), string.lower(m.BoneHat), 1, true) then
					bStart = i break
				end
			end
			local bDD = Util_CreateDropdown(parent, "Bone Hat", gNames, bStart)
			if bDD and bDD.Changed then
				bDD.Changed:Connect(function(val)
					m.BoneHat = X.cleanLabel(type(val) == "number" and gNames[val] or tostring(val))
					X.rebuildBone()
				end)
			end
		end
		onChanged(Util_CreateSwitch(parent, "Bone Track Mouse", m.BoneTrackMouse), function(v) m.BoneTrackMouse = v end)
		onChanged(Util_CreateSwitch(parent, "Bone Use Real Hat (1st projectile)", m.BoneUseRealHat), function(v) m.BoneUseRealHat = v end)
		onChanged(Util_CreateSlider(parent, "Bone Side", m.BoneSide, -10, 10, 0.25), function(v) m.BoneSide = v end)
		onChanged(Util_CreateSlider(parent, "Bone Height", m.BoneHeight, -5, 8, 0.25), function(v) m.BoneHeight = v end)
		onChanged(Util_CreateSlider(parent, "Bone Forward", m.BoneForward, -8, 8, 0.25), function(v) m.BoneForward = v end)
		onChanged(Util_CreateSlider(parent, "Bone Count", m.BoneCount, 1, 12, 1), function(v) m.BoneCount = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Bone Spread", m.BoneSpread, 0.5, 8, 0.25), function(v) m.BoneSpread = v end)
		onChanged(Util_CreateSlider(parent, "Bone Speed", m.BoneSpeed, 20, 200, 5), function(v) m.BoneSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bone Lifetime", m.BoneLife, 0.3, 5, 0.1), function(v) m.BoneLife = v end)
		onChanged(Util_CreateSlider(parent, "Bone Cooldown", m.BoneCooldown, 0.2, 4, 0.1), function(v) m.BoneCooldown = v end)
		onChanged(Util_CreateSwitch(parent, "Bone SFX", m.BoneSFX), function(v) m.BoneSFX = v end)
		onChanged(Util_CreateSlider(parent, "Bone Volume", m.BoneVolume, 0, 2, 0.05), function(v) m.BoneVolume = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Bone", 12), function() X.rebuildBone() end)
		onActivated(Util_CreateButton(parent, "FIRE BONE NOW", 14), function() X.fireBone() end)

		-- OMEGA BLASTER
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── OMEGA BLASTER ──", 14, Enum.TextXAlignment.Center)
		keyDropdown("Omega Fire Key", "KeyOmega")
		onChanged(Util_CreateSwitch(parent, "Omega Enabled", m.OmegaEnabled), function(v)
			m.OmegaEnabled = v
			if v then X.rebuildOmega() else X.clearOmega() end
		end)
		keyDropdown("Omega Cycle Slot Key", "KeyOmegaCycle")
		onChanged(Util_CreateSwitch(parent, "Omega Track Mouse", m.OmegaTrackMouse), function(v) m.OmegaTrackMouse = v end)
		local ofmDD = Util_CreateDropdown(parent, "Omega Fire Mode", m.OmegaFireModeNames, m.OmegaFireMode)
		if ofmDD and ofmDD.Changed then
			ofmDD.Changed:Connect(function(val)
				if type(val) == "number" then m.OmegaFireMode = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.OmegaFireModeNames) do if n == val then m.OmegaFireMode = i break end end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Active Omega Slot", m.OmegaActiveSlot, 1, 5, 1), function(v)
			m.OmegaActiveSlot = math.clamp(math.floor(v + 0.5), 1, 5)
		end)
		Util_CreateText(parent, "OMEGA HAT BULLET (hat flies down the beam)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Omega Use Hat Bullet", m.OmegaUseHatBullet), function(v)
			m.OmegaUseHatBullet = v
			X.rebuildOmega()
		end)
		onChanged(Util_CreateSlider(parent, "Omega Bullet Speed", m.OmegaBulletSpeed, 40, 500, 10), function(v) m.OmegaBulletSpeed = v end)
		onChanged(Util_CreateSwitch(parent, "Omega Bullet Spin", m.OmegaBulletSpin), function(v) m.OmegaBulletSpin = v end)
		onChanged(Util_CreateSwitch(parent, "Omega Bullet Trail", m.OmegaBulletTrail), function(v)
			m.OmegaBulletTrail = v
			X.rebuildOmega()
		end)
		onChanged(Util_CreateSwitch(parent, "Omega Trail Oscillation (back & forth)", m.OmegaTrailOsc), function(v) m.OmegaTrailOsc = v end)
		onChanged(Util_CreateSlider(parent, "Omega Osc Speed", m.OmegaTrailOscSpeed, 4, 40, 1), function(v) m.OmegaTrailOscSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Omega Osc Distance", m.OmegaTrailOscDist, 2, 40, 0.5), function(v) m.OmegaTrailOscDist = v end)
		onChanged(Util_CreateSlider(parent, "Omega Osc Duration", m.OmegaTrailOscTime, 0.2, 4, 0.1), function(v) m.OmegaTrailOscTime = v end)
		Util_CreateText(parent, "OMEGA SLOTS (hat + bullet hat + position per slot)", 13, Enum.TextXAlignment.Left)
		for i = 1, 5 do
			local hatKey, bulKey = X.omegaHatKey(i), X.omegaBulletKey(i)
			local hStart, bStart = 1, 1
			for j, n in ipairs(gNames) do
				if m[hatKey] ~= "" and string.find(string.lower(n), string.lower(m[hatKey]), 1, true) then hStart = j end
				if m[bulKey] ~= "" and string.find(string.lower(n), string.lower(m[bulKey]), 1, true) then bStart = j end
			end
			local hdd = Util_CreateDropdown(parent, "Omega Slot " .. i .. " Hat", gNames, hStart)
			if hdd and hdd.Changed then
				hdd.Changed:Connect(function(val)
					m[hatKey] = X.cleanLabel(type(val) == "number" and gNames[val] or tostring(val))
					X.rebuildOmega()
				end)
			end
			local bdd = Util_CreateDropdown(parent, "Omega Slot " .. i .. " Bullet Hat", gNames, bStart)
			if bdd and bdd.Changed then
				bdd.Changed:Connect(function(val)
					m[bulKey] = X.cleanLabel(type(val) == "number" and gNames[val] or tostring(val))
					X.rebuildOmega()
				end)
			end
			onChanged(Util_CreateSwitch(parent, "Omega Fire Slot " .. i, m["OmegaFire" .. i]), function(v) m["OmegaFire" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "OM" .. i .. " Side", m["OmegaSide" .. i], -10, 10, 0.25), function(v) m["OmegaSide" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "OM" .. i .. " Height", m["OmegaHeight" .. i], -5, 10, 0.25), function(v) m["OmegaHeight" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "OM" .. i .. " Forward", m["OmegaForward" .. i], -10, 8, 0.25), function(v) m["OmegaForward" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "OM" .. i .. " Rot X", m["OmegaRotX" .. i], -180, 180, 1), function(v) m["OmegaRotX" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "OM" .. i .. " Rot Y", m["OmegaRotY" .. i], -180, 180, 1), function(v) m["OmegaRotY" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "OM" .. i .. " Rot Z", m["OmegaRotZ" .. i], -180, 180, 1), function(v) m["OmegaRotZ" .. i] = v end)
		end
		onChanged(Util_CreateSlider(parent, "Omega Size", m.OmegaSize, 0.5, 4, 0.1), function(v) m.OmegaSize = v end)
		onChanged(Util_CreateSlider(parent, "Omega Laser Length", m.OmegaLaserLength, 40, 250, 5), function(v) m.OmegaLaserLength = v end)
		onChanged(Util_CreateSlider(parent, "Omega Laser Thick", m.OmegaLaserThick, 0.5, 6, 0.1), function(v) m.OmegaLaserThick = v end)
		onChanged(Util_CreateSlider(parent, "Omega Cooldown", m.OmegaCooldown, 0.5, 6, 0.1), function(v) m.OmegaCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Omega Charge Time", m.OmegaChargeTime, 0.1, 2, 0.05), function(v) m.OmegaChargeTime = v end)
		onChanged(Util_CreateSlider(parent, "Omega Push", m.OmegaPush, 0, 200, 5), function(v) m.OmegaPush = v end)
		Util_CreateText(parent, "OMEGA ROTATION / AIM", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSlider(parent, "Omega Rot X", m.OmegaRotX, -180, 180, 1), function(v) m.OmegaRotX = v end)
		onChanged(Util_CreateSlider(parent, "Omega Rot Y", m.OmegaRotY, -180, 180, 1), function(v) m.OmegaRotY = v end)
		onChanged(Util_CreateSlider(parent, "Omega Rot Z", m.OmegaRotZ, -180, 180, 1), function(v) m.OmegaRotZ = v end)
		onChanged(Util_CreateSwitch(parent, "Omega Track Only While Firing", m.OmegaTrackOnlyFire), function(v) m.OmegaTrackOnlyFire = v end)
		Util_CreateText(parent, "OMEGA UNDERGROUND STASH (overrides Sans depth if > 0)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Omega Rise Before Fire (wait until up)", m.OmegaRiseBeforeFire), function(v) m.OmegaRiseBeforeFire = v end)
		onChanged(Util_CreateSwitch(parent, "Omega Keep Up During Charge", m.OmegaKeepUpWhileCharge), function(v) m.OmegaKeepUpWhileCharge = v end)
		onChanged(Util_CreateSlider(parent, "Omega Stash Depth (0 = use Sans)", m.OmegaStashDepth, 0, 40, 1), function(v) m.OmegaStashDepth = v end)
		onChanged(Util_CreateSlider(parent, "Omega Rise Time (0 = use Sans)", m.OmegaStashRise, 0, 2, 0.05), function(v) m.OmegaStashRise = v end)
		onChanged(Util_CreateSlider(parent, "Omega Stay Up After (0 = use Sans)", m.OmegaStashHold, 0, 5, 0.1), function(v) m.OmegaStashHold = v end)
		onChanged(Util_CreateSwitch(parent, "Omega SFX", m.OmegaSFX), function(v) m.OmegaSFX = v end)
		onChanged(Util_CreateSlider(parent, "Omega Volume", m.OmegaVolume, 0, 2, 0.05), function(v) m.OmegaVolume = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Omega", 12), function() X.rebuildOmega() end)
		onActivated(Util_CreateButton(parent, "FIRE OMEGA NOW", 14), function() X.fireOmega() end)

		-- WEAPONS
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── WEAPONS (10 slots, all float; B fires active, N cycles) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Weapon Enabled", m.WeaponEnabled), function(v)
			m.WeaponEnabled = v
			if v then X.rebuildWeapon() else X.clearWeapon() end
		end)
		onChanged(Util_CreateSwitch(parent, "Weapons STAY UP (raised until off)", m.WeaponStayUp), function(v)
			m.WeaponStayUp = v
		end)
		onChanged(Util_CreateSlider(parent, "Stay Up Height", m.WeaponStayUpHeight, 0.5, 12, 0.25), function(v)
			m.WeaponStayUpHeight = v
		end)
		Util_CreateText(parent, "MOUSE TRACK + FEEL", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "WEAPONS TRACK MOUSE", m.WeaponTrackMouse), function(v) m.WeaponTrackMouse = v end)
		local tmDD = Util_CreateDropdown(parent, "Track When", m.WeaponTrackModeNames, m.WeaponTrackMode)
		if tmDD and tmDD.Changed then
			tmDD.Changed:Connect(function(val)
				if type(val) == "number" then m.WeaponTrackMode = val
				elseif type(val) == "string" then
					for k, n in ipairs(m.WeaponTrackModeNames) do
						if n == val then m.WeaponTrackMode = k break end
					end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Track Strength", m.WeaponTrackStrength, 0, 1, 0.05), function(v) m.WeaponTrackStrength = v end)
		onChanged(Util_CreateSlider(parent, "Track Smooth (higher = snappier)", m.WeaponTrackSmooth, 2, 40, 1), function(v) m.WeaponTrackSmooth = v end)
		onChanged(Util_CreateSlider(parent, "Keep Tracking After Fire (sec)", m.WeaponTrackHold, 0, 6, 0.1), function(v) m.WeaponTrackHold = v end)
		onChanged(Util_CreateSwitch(parent, "Track Up/Down (pitch)", m.WeaponTrackPitch), function(v) m.WeaponTrackPitch = v end)
		onChanged(Util_CreateSwitch(parent, "Bullets Aim At Mouse (off = straight ahead)", m.WeaponAimMouse), function(v) m.WeaponAimMouse = v end)
		onChanged(Util_CreateSwitch(parent, "Hold B = Auto Fire", m.WeaponAutoFire), function(v) m.WeaponAutoFire = v end)
		onChanged(Util_CreateSwitch(parent, "Muzzle Flash", m.WeaponMuzzleFlash), function(v) m.WeaponMuzzleFlash = v end)
		onChanged(Util_CreateSlider(parent, "Recoil Kick", m.WeaponRecoil, 0, 4, 0.1), function(v) m.WeaponRecoil = v end)
		onChanged(Util_CreateSlider(parent, "Recoil Recover Speed", m.WeaponRecoilSpeed, 1, 20, 0.5), function(v) m.WeaponRecoilSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Float Bob Amount", m.WeaponBobAmt, 0, 1.5, 0.05), function(v) m.WeaponBobAmt = v end)
		onChanged(Util_CreateSlider(parent, "Float Bob Speed", m.WeaponBobSpeed, 0.5, 8, 0.1), function(v) m.WeaponBobSpeed = v end)
		local fmDD = Util_CreateDropdown(parent, "Fire Mode", m.WeaponFireModeNames, m.WeaponFireMode)
		if fmDD and fmDD.Changed then
			fmDD.Changed:Connect(function(val)
				if type(val) == "number" then m.WeaponFireMode = val
				elseif type(val) == "string" then
					for k, n in ipairs(m.WeaponFireModeNames) do
						if n == val then m.WeaponFireMode = k break end
					end
				end
				X.FireIdx = 0
			end)
		end
		onActivated(Util_CreateButton(parent, "FIRE WEAPON NOW (test, same as B)", 14), function() X.fireWeapon() end)
		Util_CreateText(parent, "UNDERGROUND STASH (weapons, hat bullets, Gaster, blaster)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "STASH UNDERGROUND until used (rise + fire + sink)", m.UndergroundStash), function(v)
			m.UndergroundStash = v
		end)
		onChanged(Util_CreateSlider(parent, "Stash Depth (studs)", m.StashDepth, 2, 40, 1), function(v) m.StashDepth = v end)
		onChanged(Util_CreateSlider(parent, "Rise / Sink Time", m.StashRise, 0.1, 1.5, 0.05), function(v) m.StashRise = v end)
		onChanged(Util_CreateSlider(parent, "Stay Up After Use", m.StashHold, 0.3, 5, 0.1), function(v) m.StashHold = v end)
		Util_CreateText(parent, "GASTER BLASTER / LASER (bullet styles 5 and 6)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSlider(parent, "Blaster Scale", m.WeaponBlasterScale, 0.3, 4, 0.1), function(v) m.WeaponBlasterScale = v end)
		onChanged(Util_CreateSlider(parent, "Blaster Charge Time", m.WeaponBlasterCharge, 0.1, 2, 0.05), function(v) m.WeaponBlasterCharge = v end)
		onChanged(Util_CreateSlider(parent, "Beam Length", m.WeaponLaserLength, 20, 600, 10), function(v) m.WeaponLaserLength = v end)
		onChanged(Util_CreateSlider(parent, "Laser Fade Time", m.WeaponLaserTime, 0.05, 1.5, 0.05), function(v) m.WeaponLaserTime = v end)
		onChanged(Util_CreateSlider(parent, "Active (firing) Weapon Slot", m.WeaponActiveSlot, 1, 10, 1), function(v)
			m.WeaponActiveSlot = math.clamp(math.floor(v + 0.5), 1, 10)
			WeaponHeld = X.activeWeapon()
		end)
		onChanged(Util_CreateSlider(parent, "Float Side", m.WeaponFloatSide, -5, 5, 0.1), function(v) m.WeaponFloatSide = v end)
		onChanged(Util_CreateSlider(parent, "Float Height", m.WeaponFloatHeight, -3, 5, 0.1), function(v) m.WeaponFloatHeight = v end)
		onChanged(Util_CreateSlider(parent, "Float Forward", m.WeaponFloatForward, -5, 5, 0.1), function(v) m.WeaponFloatForward = v end)
		onChanged(Util_CreateSlider(parent, "Weapon Rot X", m.WeaponRotX, -180, 180, 1), function(v) m.WeaponRotX = v end)
		onChanged(Util_CreateSlider(parent, "Weapon Rot Y", m.WeaponRotY, -180, 180, 1), function(v) m.WeaponRotY = v end)
		onChanged(Util_CreateSlider(parent, "Weapon Rot Z", m.WeaponRotZ, -180, 180, 1), function(v) m.WeaponRotZ = v end)
		onChanged(Util_CreateSlider(parent, "Fire Speed", m.WeaponFireSpeed, 40, 250, 5), function(v) m.WeaponFireSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Fire Cooldown", m.WeaponFireCooldown, 0.05, 2, 0.05), function(v) m.WeaponFireCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Lifetime", m.WeaponBulletLife, 0.5, 6, 0.1), function(v) m.WeaponBulletLife = v end)
		Util_CreateText(parent, "BULLETS (style 4 Hat = hat bullet)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "ANTI-SNAP (stop hats sticking to my rig)", m.WeaponAntiSnap), function(v)
			m.WeaponAntiSnap = v
		end)
		onChanged(Util_CreateSwitch(parent, "Hat Bullets = REAL FE hat (off = local clones)", m.WeaponRealHat), function(v)
			m.WeaponRealHat = v
			X.rebuildWeapon()
		end)
		onChanged(Util_CreateSlider(parent, "Bullet Size", m.WeaponBulletSize, 0.2, 5, 0.1), function(v) m.WeaponBulletSize = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Spin (deg/s)", m.WeaponBulletSpin, 0, 1440, 30), function(v) m.WeaponBulletSpin = v end)
		onChanged(Util_CreateSlider(parent, "Homing (to mouse)", m.WeaponHoming, 0, 3, 0.1), function(v) m.WeaponHoming = v end)
		onChanged(Util_CreateSlider(parent, "Gravity Drop", m.WeaponGravity, 0, 200, 5), function(v) m.WeaponGravity = v end)
		onChanged(Util_CreateSlider(parent, "Default Burst Shots", m.WeaponBurst, 1, 12, 1), function(v) m.WeaponBurst = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Max Burst Cap", m.WeaponMaxBurst, 1, 12, 1), function(v) m.WeaponMaxBurst = math.floor(v + 0.5) end)
		onChanged(Util_CreateSwitch(parent, "Weapon SFX", m.WeaponSFX), function(v) m.WeaponSFX = v end)
		onChanged(Util_CreateSlider(parent, "Weapon Volume", m.WeaponVolume, 0, 2, 0.05), function(v) m.WeaponVolume = v end)
		onChanged(Util_CreateSlider(parent, "Spread (degrees)", m.WeaponSpread, 0, 45, 1), function(v) m.WeaponSpread = v end)
		onChanged(Util_CreateSlider(parent, "Real Hat Return Speed", m.WeaponReturnSpeed, 40, 400, 10), function(v) m.WeaponReturnSpeed = v end)
		onChanged(Util_CreateSwitch(parent, "Stop On Hit", m.WeaponStopOnHit), function(v) m.WeaponStopOnHit = v end)
		onChanged(Util_CreateSwitch(parent, "Hit Effect", m.WeaponHitFX), function(v) m.WeaponHitFX = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Color R", m.WeaponBulletR, 0, 255, 5), function(v) m.WeaponBulletR = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Color G", m.WeaponBulletG, 0, 255, 5), function(v) m.WeaponBulletG = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Color B", m.WeaponBulletB, 0, 255, 5), function(v) m.WeaponBulletB = v end)
		Util_CreateText(parent, "TRAILS (visible to you only)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Bullet Trail", m.WeaponTrail), function(v)
			m.WeaponTrail = v
			X.rebuildWeapon()
		end)
		onChanged(Util_CreateSwitch(parent, "Rainbow (trail + bullet)", m.WeaponRainbow), function(v)
			m.WeaponRainbow = v
			X.refreshTrails()
		end)
		onChanged(Util_CreateSlider(parent, "Trail Lifetime", m.WeaponTrailLife, 0.1, 3, 0.05), function(v) m.WeaponTrailLife = v X.refreshTrails() end)
		onChanged(Util_CreateSlider(parent, "Trail Width", m.WeaponTrailWidth, 0.1, 4, 0.1), function(v) m.WeaponTrailWidth = v X.refreshTrails() end)
		onChanged(Util_CreateSlider(parent, "Trail Color R", m.WeaponTrailR, 0, 255, 5), function(v) m.WeaponTrailR = v X.refreshTrails() end)
		onChanged(Util_CreateSlider(parent, "Trail Color G", m.WeaponTrailG, 0, 255, 5), function(v) m.WeaponTrailG = v X.refreshTrails() end)
		onChanged(Util_CreateSlider(parent, "Trail Color B", m.WeaponTrailB, 0, 255, 5), function(v) m.WeaponTrailB = v X.refreshTrails() end)
		local wNames = X.dropdownNames(true)
		for i = 1, 10 do
			local key = "WeaponHat" .. i
			local start = 1
			for j, n in ipairs(wNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					start = j break
				end
			end
			local dd = Util_CreateDropdown(parent, "Weapon Slot " .. i, wNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and wNames[val] or tostring(val))
					X.rebuildWeapon()
				end)
			end
			local bDD = Util_CreateDropdown(parent, "Bullet Style S" .. i, m.WeaponBulletNames, m["WeaponBullet" .. i] or 1)
			if bDD and bDD.Changed then
				bDD.Changed:Connect(function(val)
					if type(val) == "number" then m["WeaponBullet" .. i] = val
					elseif type(val) == "string" then
						for k, n in ipairs(m.WeaponBulletNames) do
							if n == val then m["WeaponBullet" .. i] = k break end
						end
					end
					X.rebuildWeapon()
				end)
			end
			onChanged(Util_CreateSwitch(parent, "Fire Slot " .. i .. " (in rotation, max 6)", m["WeaponFire" .. i]), function(v)
				m["WeaponFire" .. i] = v
				local on = 0
				for s = 1, 10 do if m["WeaponFire" .. s] then on = on + 1 end end
				if on > 6 then
					warn("[HatStand] max 6 fire slots: only the first 6 enabled slots (lowest numbers) will fire")
				end
			end)
			onChanged(Util_CreateSlider(parent, "S" .. i .. " Burst Count (1-12)", m["WeaponBurst" .. i], 1, 12, 1), function(v)
				m["WeaponBurst" .. i] = math.floor(v + 0.5)
			end)
			onChanged(Util_CreateSlider(parent, "S" .. i .. " Hat-Bullet Count", m["WeaponHatBulletCount" .. i], 1, 4, 1), function(v)
				m["WeaponHatBulletCount" .. i] = math.floor(v + 0.5)
			end)
			do
				local bkey = "WeaponBulletHat" .. i
				local bstart = 1
				for j, n in ipairs(wNames) do
					if m[bkey] ~= "" and string.find(string.lower(n), string.lower(m[bkey]), 1, true) then
						bstart = j break
					end
				end
				local bhd = Util_CreateDropdown(parent, "Bullet Hat S" .. i .. " (style 4)", wNames, bstart)
				if bhd and bhd.Changed then
					bhd.Changed:Connect(function(val)
						m[bkey] = X.cleanLabel(type(val) == "number" and wNames[val] or tostring(val))
						X.rebuildWeapon()
					end)
				end
			end
			onChanged(Util_CreateSlider(parent, "W" .. i .. " Side (left/right)", m["WeaponOffsetX" .. i], -10, 10, 0.1), function(v) m["WeaponOffsetX" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "W" .. i .. " Up/Down", m["WeaponOffsetY" .. i], -10, 10, 0.1), function(v) m["WeaponOffsetY" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "W" .. i .. " Forward/Back", m["WeaponOffsetZ" .. i], -10, 10, 0.1), function(v) m["WeaponOffsetZ" .. i] = v end)
			onChanged(Util_CreateSlider(parent, "W" .. i .. " Rot X", m["WeaponRot" .. i .. "X"], -180, 180, 1), function(v) m["WeaponRot" .. i .. "X"] = v end)
			onChanged(Util_CreateSlider(parent, "W" .. i .. " Rot Y", m["WeaponRot" .. i .. "Y"], -180, 180, 1), function(v) m["WeaponRot" .. i .. "Y"] = v end)
			onChanged(Util_CreateSlider(parent, "W" .. i .. " Rot Z", m["WeaponRot" .. i .. "Z"], -180, 180, 1), function(v) m["WeaponRot" .. i .. "Z"] = v end)
		end
		onActivated(Util_CreateButton(parent, "Rebuild Weapon", 12), function() X.rebuildWeapon() end)

		-- SHIELD
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── SHIELD ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Shield Enabled", m.ShieldEnabled), function(v)
			m.ShieldEnabled = v
			if v then X.rebuildShield() else X.clearShield() end
		end)
		local sNames = X.dropdownNames(true)
		local sStart = 1
		for i, n in ipairs(sNames) do
			if m.ShieldHat ~= "" and string.find(string.lower(n), string.lower(m.ShieldHat), 1, true) then
				sStart = i break
			end
		end
		local sDD = Util_CreateDropdown(parent, "Shield Hat", sNames, sStart)
		if sDD and sDD.Changed then
			sDD.Changed:Connect(function(val)
				m.ShieldHat = X.cleanLabel(type(val) == "number" and sNames[val] or tostring(val))
				X.rebuildShield()
			end)
		end
		local smDD = Util_CreateDropdown(parent, "Shield Mode", m.ShieldModeNames, m.ShieldMode)
		if smDD and smDD.Changed then
			smDD.Changed:Connect(function(val)
				if type(val) == "number" then m.ShieldMode = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.ShieldModeNames) do
						if n == val then m.ShieldMode = i break end
					end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Shield Side", m.ShieldSide, -5, 5, 0.1), function(v) m.ShieldSide = v end)
		onChanged(Util_CreateSlider(parent, "Shield Height", m.ShieldHeight, -3, 5, 0.1), function(v) m.ShieldHeight = v end)
		onChanged(Util_CreateSlider(parent, "Shield Forward", m.ShieldForward, -8, 4, 0.1), function(v) m.ShieldForward = v end)
		onChanged(Util_CreateSlider(parent, "Shield Rot X", m.ShieldRotX, -180, 180, 1), function(v) m.ShieldRotX = v end)
		onChanged(Util_CreateSlider(parent, "Shield Rot Y", m.ShieldRotY, -180, 180, 1), function(v) m.ShieldRotY = v end)
		onChanged(Util_CreateSlider(parent, "Shield Rot Z", m.ShieldRotZ, -180, 180, 1), function(v) m.ShieldRotZ = v end)
		onChanged(Util_CreateSwitch(parent, "Shield Auto Face", m.ShieldAutoFace), function(v) m.ShieldAutoFace = v end)
		onChanged(Util_CreateSwitch(parent, "Shield Bob", m.ShieldBob), function(v) m.ShieldBob = v end)
		onChanged(Util_CreateSlider(parent, "Shield Bob Speed", m.ShieldBobSpeed, 0.2, 5, 0.1), function(v) m.ShieldBobSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Shield Bob Amount", m.ShieldBobAmt, 0, 2, 0.05), function(v) m.ShieldBobAmt = v end)
		onChanged(Util_CreateSwitch(parent, "Shield Spin", m.ShieldSpin), function(v) m.ShieldSpin = v end)
		onChanged(Util_CreateSlider(parent, "Shield Spin Speed", m.ShieldSpinSpeed, 0.2, 10, 0.1), function(v) m.ShieldSpinSpeed = v end)
		onChanged(Util_CreateSwitch(parent, "Shield Underground Stash (key raises/lowers)", m.ShieldUnderground), function(v)
			m.ShieldUnderground = v
			if ShieldHeld then
				if v then X.initSansStash(ShieldHeld) else ShieldHeld.UpUntil = 0 ShieldHeld.Up = 1 end
			end
		end)
		onChanged(Util_CreateSlider(parent, "Shield Stash Depth (studs)", m.ShieldStashDepth, 2, 40, 1), function(v) m.ShieldStashDepth = v end)
		onChanged(Util_CreateSlider(parent, "Shield Rise Time", m.ShieldStashRise, 0.1, 1.5, 0.05), function(v) m.ShieldStashRise = v end)
		onChanged(Util_CreateSlider(parent, "Shield Stay Up (0 = until key again)", m.ShieldStashHold, 0, 10, 0.5), function(v) m.ShieldStashHold = v end)
		keyDropdown("Shield Raise/Lower Key", "KeyShield")
		keyDropdown("Shield Place Key", "KeyShieldPlace")
		onActivated(Util_CreateButton(parent, "Rebuild Shield", 12), function() X.rebuildShield() end)

		-- RAVENGER CLAWS
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── RAVENGER CLAWS (claws/arms + head) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "Pick Left + Right (claw or arm) + optional Head. Place each with Side/Up/Forward + Rot. Z combo, X push, C spin, H laser, I slam. F6 keys ON/OFF, F7 mouse tracking, F8 rage (all changeable).", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Claws Enabled", m.ClawsEnabled), function(v)
			m.ClawsEnabled = v
			if v then rebuildClaws() else clearClaws() end
		end)
		onChanged(Util_CreateSwitch(parent, "Claws Attack Keys ON/OFF", m.ClawsKeysEnabled), function(v) m.ClawsKeysEnabled = v end)
		keyDropdown("Claws Keys Toggle Key", "KeyClawsKeysToggle")
		onChanged(Util_CreateSwitch(parent, "Claws Animations (idle/walk/run/jump/fall)", m.ClawsAnims), function(v) m.ClawsAnims = v end)
		onChanged(Util_CreateSlider(parent, "Claws Anim Strength", m.ClawsAnimStrength, 0, 2.5, 0.05), function(v) m.ClawsAnimStrength = v end)
		onChanged(Util_CreateSlider(parent, "Claws Anim Blend", m.ClawsAnimBlend, 2, 30, 1), function(v) m.ClawsAnimBlend = v end)
		keyDropdown("Claws Combo Key", "KeyClawsCombo")
		keyDropdown("Claws Push Key", "KeyClawsPush")
		keyDropdown("Claws Spin Key", "KeyClawsSpin")
		keyDropdown("Claws Laser Key", "KeyClawsLaser")
		keyDropdown("Claws Slam Key", "KeyClawsSlam")
		onChanged(Util_CreateSwitch(parent, "Mouse Tracking (arms follow mouse) ON/OFF", m.ClawsTrackMouse), function(v) m.ClawsTrackMouse = v end)
		keyDropdown("Mouse Tracking Toggle Key", "KeyClawsTrackToggle")
		onChanged(Util_CreateSwitch(parent, "RAGE MODE (faster cooldowns + anims)", m.ClawsRage), function(v) m.ClawsRage = v end)
		onChanged(Util_CreateSlider(parent, "Rage Multiplier", m.ClawsRageMul, 1, 3, 0.1), function(v) m.ClawsRageMul = v end)
		keyDropdown("Rage Toggle Key", "KeyClawsRage")
		do
			local cNames = X.dropdownNames(true)
			local function clawDD(label, key)
				local start = 1
				for i, n in ipairs(cNames) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
						start = i break
					end
				end
				local dd = Util_CreateDropdown(parent, label, cNames, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and cNames[val] or tostring(val))
						rebuildClaws()
					end)
				end
			end
			clawDD("Left Claw / Arm Hat", "ClawsLeftHat")
			clawDD("Right Claw / Arm Hat", "ClawsRightHat")
			clawDD("Head Hat (optional)", "ClawsHeadHat")
			clawDD("Laser Bullet Hat (optional, different hat)", "ClawsLaserHat")
		end
		Util_CreateText(parent, "GLOBAL BASE", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSlider(parent, "Claws Scale", m.ClawsScale, 0.5, 4, 0.1), function(v) m.ClawsScale = v end)
		onChanged(Util_CreateSlider(parent, "Claws Side (base)", m.ClawsSide, 0.5, 6, 0.1), function(v) m.ClawsSide = v end)
		onChanged(Util_CreateSlider(parent, "Claws Height (base)", m.ClawsHeight, -3, 5, 0.1), function(v) m.ClawsHeight = v end)
		onChanged(Util_CreateSlider(parent, "Claws Forward (base)", m.ClawsForward, -5, 3, 0.1), function(v) m.ClawsForward = v end)
		onChanged(Util_CreateSlider(parent, "Claws Global Rot X", m.ClawsRotX, -180, 180, 1), function(v) m.ClawsRotX = v end)
		onChanged(Util_CreateSlider(parent, "Claws Global Rot Y", m.ClawsRotY, -180, 180, 1), function(v) m.ClawsRotY = v end)
		onChanged(Util_CreateSlider(parent, "Claws Global Rot Z", m.ClawsRotZ, -180, 180, 1), function(v) m.ClawsRotZ = v end)
		Util_CreateText(parent, "LEFT — place up/down/side + rot", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSlider(parent, "Left Side (X)", m.ClawsLeftOffX, -8, 8, 0.05), function(v) m.ClawsLeftOffX = v end)
		onChanged(Util_CreateSlider(parent, "Left Up (Y)", m.ClawsLeftOffY, -8, 8, 0.05), function(v) m.ClawsLeftOffY = v end)
		onChanged(Util_CreateSlider(parent, "Left Forward (Z)", m.ClawsLeftOffZ, -8, 8, 0.05), function(v) m.ClawsLeftOffZ = v end)
		onChanged(Util_CreateSlider(parent, "Left Rot X", m.ClawsLeftRotX, -180, 180, 1), function(v) m.ClawsLeftRotX = v end)
		onChanged(Util_CreateSlider(parent, "Left Rot Y", m.ClawsLeftRotY, -180, 180, 1), function(v) m.ClawsLeftRotY = v end)
		onChanged(Util_CreateSlider(parent, "Left Rot Z", m.ClawsLeftRotZ, -180, 180, 1), function(v) m.ClawsLeftRotZ = v end)
		Util_CreateText(parent, "RIGHT — place up/down/side + rot", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSlider(parent, "Right Side (X)", m.ClawsRightOffX, -8, 8, 0.05), function(v) m.ClawsRightOffX = v end)
		onChanged(Util_CreateSlider(parent, "Right Up (Y)", m.ClawsRightOffY, -8, 8, 0.05), function(v) m.ClawsRightOffY = v end)
		onChanged(Util_CreateSlider(parent, "Right Forward (Z)", m.ClawsRightOffZ, -8, 8, 0.05), function(v) m.ClawsRightOffZ = v end)
		onChanged(Util_CreateSlider(parent, "Right Rot X", m.ClawsRightRotX, -180, 180, 1), function(v) m.ClawsRightRotX = v end)
		onChanged(Util_CreateSlider(parent, "Right Rot Y", m.ClawsRightRotY, -180, 180, 1), function(v) m.ClawsRightRotY = v end)
		onChanged(Util_CreateSlider(parent, "Right Rot Z", m.ClawsRightRotZ, -180, 180, 1), function(v) m.ClawsRightRotZ = v end)
		Util_CreateText(parent, "HEAD — place up/down/side + rot", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSlider(parent, "Head Side (X)", m.ClawsHeadOffX, -8, 8, 0.05), function(v) m.ClawsHeadOffX = v end)
		onChanged(Util_CreateSlider(parent, "Head Up (Y)", m.ClawsHeadOffY, -8, 8, 0.05), function(v) m.ClawsHeadOffY = v end)
		onChanged(Util_CreateSlider(parent, "Head Forward (Z)", m.ClawsHeadOffZ, -8, 8, 0.05), function(v) m.ClawsHeadOffZ = v end)
		onChanged(Util_CreateSlider(parent, "Head Rot X", m.ClawsHeadRotX, -180, 180, 1), function(v) m.ClawsHeadRotX = v end)
		onChanged(Util_CreateSlider(parent, "Head Rot Y", m.ClawsHeadRotY, -180, 180, 1), function(v) m.ClawsHeadRotY = v end)
		onChanged(Util_CreateSlider(parent, "Head Rot Z", m.ClawsHeadRotZ, -180, 180, 1), function(v) m.ClawsHeadRotZ = v end)
		onChanged(Util_CreateSwitch(parent, "Idle Bob", m.ClawsIdleBob), function(v) m.ClawsIdleBob = v end)
		onChanged(Util_CreateSlider(parent, "Bob Speed", m.ClawsBobSpeed, 0.5, 6, 0.1), function(v) m.ClawsBobSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bob Amount", m.ClawsBobAmt, 0, 1, 0.02), function(v) m.ClawsBobAmt = v end)
		onChanged(Util_CreateSwitch(parent, "Blood Trail (local)", m.ClawsBloodTrail), function(v) m.ClawsBloodTrail = v end)
		onChanged(Util_CreateSlider(parent, "Combo Cooldown", m.ClawsComboCooldown, 0.1, 1.5, 0.05), function(v) m.ClawsComboCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Push Cooldown", m.ClawsPushCooldown, 0.3, 4, 0.1), function(v) m.ClawsPushCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Spin Cooldown", m.ClawsSpinCooldown, 0.5, 6, 0.1), function(v) m.ClawsSpinCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Combo Range", m.ClawsComboRange, 3, 20, 0.5), function(v) m.ClawsComboRange = v end)
		onChanged(Util_CreateSlider(parent, "Push Force", m.ClawsPushForce, 10, 150, 5), function(v) m.ClawsPushForce = v end)
		onChanged(Util_CreateSlider(parent, "Push Up Force", m.ClawsPushUp, 0, 80, 2), function(v) m.ClawsPushUp = v end)
		onChanged(Util_CreateSlider(parent, "Spin Speed", m.ClawsSpinSpeed, 4, 30, 1), function(v) m.ClawsSpinSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Spin Duration", m.ClawsSpinDuration, 0.3, 3, 0.05), function(v) m.ClawsSpinDuration = v end)
		onChanged(Util_CreateSlider(parent, "Spin Radius", m.ClawsSpinRadius, 1, 12, 0.25), function(v) m.ClawsSpinRadius = v end)
		onChanged(Util_CreateSwitch(parent, "Claws SFX", m.ClawsSFX), function(v) m.ClawsSFX = v end)
		onChanged(Util_CreateSlider(parent, "Claws Volume", m.ClawsVolume, 0, 2, 0.05), function(v) m.ClawsVolume = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Claws", 12), function() rebuildClaws() end)
		onActivated(Util_CreateButton(parent, "COMBO NOW", 12), function() fireClawsCombo() end)
		onActivated(Util_CreateButton(parent, "PUSH NOW", 12), function() fireClawsPush() end)
		onActivated(Util_CreateButton(parent, "SPIN NOW", 12), function() fireClawsSpin() end)
		onActivated(Util_CreateButton(parent, "LASER NOW", 12), function() X.fireClawsLaser() end)
		onActivated(Util_CreateButton(parent, "SLAM NOW", 12), function() X.fireClawsSlam() end)
		Util_CreateText(parent, "CLAWS LASER / SLAM", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Laser uses Bullet Hat", m.ClawsLaserUseHat), function(v) m.ClawsLaserUseHat = v; rebuildClaws() end)
		onChanged(Util_CreateSwitch(parent, "Laser from BOTH claws (off = alternate)", m.ClawsLaserDual), function(v) m.ClawsLaserDual = v end)
		onChanged(Util_CreateSwitch(parent, "Laser aims at mouse", m.ClawsLaserAim), function(v) m.ClawsLaserAim = v end)
		onChanged(Util_CreateSlider(parent, "Laser Cooldown", m.ClawsLaserCooldown, 0.2, 8, 0.1), function(v) m.ClawsLaserCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Laser Charge Time", m.ClawsLaserCharge, 0, 2, 0.05), function(v) m.ClawsLaserCharge = v end)
		onChanged(Util_CreateSlider(parent, "Laser Length", m.ClawsLaserLength, 20, 400, 5), function(v) m.ClawsLaserLength = v end)
		onChanged(Util_CreateSlider(parent, "Laser Thickness", m.ClawsLaserThick, 0.2, 8, 0.1), function(v) m.ClawsLaserThick = v end)
		onChanged(Util_CreateSlider(parent, "Laser Color R", m.ClawsLaserR, 0, 255, 1), function(v) m.ClawsLaserR = v end)
		onChanged(Util_CreateSlider(parent, "Laser Color G", m.ClawsLaserG, 0, 255, 1), function(v) m.ClawsLaserG = v end)
		onChanged(Util_CreateSlider(parent, "Laser Color B", m.ClawsLaserB, 0, 255, 1), function(v) m.ClawsLaserB = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Hat Speed", m.ClawsLaserBulletSpeed, 40, 600, 10), function(v) m.ClawsLaserBulletSpeed = v end)
		onChanged(Util_CreateSwitch(parent, "Bullet Hat Spin", m.ClawsLaserBulletSpin), function(v) m.ClawsLaserBulletSpin = v end)
		onChanged(Util_CreateSwitch(parent, "Bullet Hat Trail", m.ClawsLaserTrail), function(v) m.ClawsLaserTrail = v; rebuildClaws() end)
		onChanged(Util_CreateSwitch(parent, "Bullet Back & Forth at end", m.ClawsLaserTrailOsc), function(v) m.ClawsLaserTrailOsc = v end)
		onChanged(Util_CreateSlider(parent, "Back & Forth Distance", m.ClawsLaserTrailOscDist, 2, 60, 1), function(v) m.ClawsLaserTrailOscDist = v end)
		onChanged(Util_CreateSlider(parent, "Back & Forth Speed", m.ClawsLaserTrailOscSpeed, 4, 40, 1), function(v) m.ClawsLaserTrailOscSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Back & Forth Time", m.ClawsLaserTrailOscTime, 0.2, 5, 0.1), function(v) m.ClawsLaserTrailOscTime = v end)
		onChanged(Util_CreateSlider(parent, "Slam Cooldown", m.ClawsSlamCooldown, 0.3, 8, 0.1), function(v) m.ClawsSlamCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Slam Shockwave Radius", m.ClawsSlamRadius, 4, 40, 1), function(v) m.ClawsSlamRadius = v end)

		-- CAR
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── CAR (custom hat parts) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Car Enabled", m.CarEnabled), function(v)
			m.CarEnabled = v
			if v then X.rebuildCar() else X.clearCar() end
		end)
		onChanged(Util_CreateSwitch(parent, "Ride Car (boost speed)", m.CarRide), function(v) m.CarRide = v end)
		onChanged(Util_CreateSlider(parent, "Speed Boost Mult", m.CarSpeedBoost, 1, 3, 0.05), function(v) m.CarSpeedBoost = v end)
		onChanged(Util_CreateSlider(parent, "Car Side (when not riding)", m.CarSide, -15, 15, 0.5), function(v) m.CarSide = v end)
		onChanged(Util_CreateSlider(parent, "Car Height", m.CarHeight, -5, 8, 0.25), function(v) m.CarHeight = v end)
		onChanged(Util_CreateSlider(parent, "Car Forward", m.CarForward, -10, 10, 0.25), function(v) m.CarForward = v end)
		onChanged(Util_CreateSlider(parent, "Car Rot Y", m.CarRotY, -180, 180, 1), function(v) m.CarRotY = v end)
		onChanged(Util_CreateSlider(parent, "Car Follow Smooth", m.CarSmooth, 3, 30, 1), function(v) m.CarSmooth = v end)
		local cNames = X.dropdownNames(true)
		for i = 1, 8 do
			local key = "CarHat" .. i
			local start = 1
			for j, n in ipairs(cNames) do
				if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then
					start = j break
				end
			end
			local dd = Util_CreateDropdown(parent, "Car Part " .. i, cNames, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m[key] = X.cleanLabel(type(val) == "number" and cNames[val] or tostring(val))
					X.rebuildCar()
				end)
			end
			onChanged(Util_CreateSlider(parent, "C" .. i .. " Off X", m["CarOffX" .. i], -8, 8, 0.25), function(v)
				m["CarOffX" .. i] = v
				if CarSlots[i] then CarSlots[i].Off = Vector3.new(v, CarSlots[i].Off.Y, CarSlots[i].Off.Z) end
			end)
			onChanged(Util_CreateSlider(parent, "C" .. i .. " Off Y", m["CarOffY" .. i], -5, 5, 0.25), function(v)
				m["CarOffY" .. i] = v
				if CarSlots[i] then CarSlots[i].Off = Vector3.new(CarSlots[i].Off.X, v, CarSlots[i].Off.Z) end
			end)
			onChanged(Util_CreateSlider(parent, "C" .. i .. " Off Z", m["CarOffZ" .. i], -8, 8, 0.25), function(v)
				m["CarOffZ" .. i] = v
				if CarSlots[i] then CarSlots[i].Off = Vector3.new(CarSlots[i].Off.X, CarSlots[i].Off.Y, v) end
			end)
			onChanged(Util_CreateSlider(parent, "C" .. i .. " Rot X", m["CarRotX" .. i], -180, 180, 5), function(v)
				m["CarRotX" .. i] = v
				if CarSlots[i] then
					CarSlots[i].Rot = CFrame.Angles(math.rad(v), math.rad(m["CarRotY" .. i] or 0), math.rad(m["CarRotZ" .. i] or 0))
				end
			end)
			onChanged(Util_CreateSlider(parent, "C" .. i .. " Rot Y", m["CarRotY" .. i], -180, 180, 5), function(v)
				m["CarRotY" .. i] = v
				if CarSlots[i] then
					CarSlots[i].Rot = CFrame.Angles(math.rad(m["CarRotX" .. i] or 0), math.rad(v), math.rad(m["CarRotZ" .. i] or 0))
				end
			end)
			onChanged(Util_CreateSlider(parent, "C" .. i .. " Rot Z", m["CarRotZ" .. i], -180, 180, 5), function(v)
				m["CarRotZ" .. i] = v
				if CarSlots[i] then
					CarSlots[i].Rot = CFrame.Angles(math.rad(m["CarRotX" .. i] or 0), math.rad(m["CarRotY" .. i] or 0), math.rad(v))
				end
			end)
		end
		onActivated(Util_CreateButton(parent, "Rebuild Car", 12), function() X.rebuildCar() end)
		Util_CreateText(parent, "CAR WHEELS (4) + ENGINE", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Wheel Spin", m.CarWheelSpin), function(v) m.CarWheelSpin = v end)
		onChanged(Util_CreateSlider(parent, "Wheel Spin Speed", m.CarWheelSpinSpd, 1, 40, 1), function(v) m.CarWheelSpinSpd = v end)
		do
			local wNames = X.dropdownNames(true)
			for i = 1, 4 do
				local key = "CarWheelHat" .. i
				local start = 1
				for j, n in ipairs(wNames) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Wheel " .. i .. " Hat", wNames, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and wNames[val] or tostring(val))
						X.rebuildCar()
					end)
				end
				onChanged(Util_CreateSlider(parent, "Wheel" .. i .. " Off X", m["CarWheelOffX" .. i], -8, 8, 0.1), function(v)
					m["CarWheelOffX" .. i] = v
					if CarWheels[i] then CarWheels[i].Off = Vector3.new(v, CarWheels[i].Off.Y, CarWheels[i].Off.Z) end
				end)
				onChanged(Util_CreateSlider(parent, "Wheel" .. i .. " Off Y", m["CarWheelOffY" .. i], -5, 5, 0.1), function(v)
					m["CarWheelOffY" .. i] = v
					if CarWheels[i] then CarWheels[i].Off = Vector3.new(CarWheels[i].Off.X, v, CarWheels[i].Off.Z) end
				end)
				onChanged(Util_CreateSlider(parent, "Wheel" .. i .. " Off Z", m["CarWheelOffZ" .. i], -8, 8, 0.1), function(v)
					m["CarWheelOffZ" .. i] = v
					if CarWheels[i] then CarWheels[i].Off = Vector3.new(CarWheels[i].Off.X, CarWheels[i].Off.Y, v) end
				end)
			end
			local eStart = 1
			for j, n in ipairs(wNames) do
				if m.CarEngineHat ~= "" and string.find(string.lower(n), string.lower(m.CarEngineHat), 1, true) then eStart = j break end
			end
			local eDD = Util_CreateDropdown(parent, "Engine Hat", wNames, eStart)
			if eDD and eDD.Changed then
				eDD.Changed:Connect(function(val)
					m.CarEngineHat = X.cleanLabel(type(val) == "number" and wNames[val] or tostring(val))
					X.rebuildCar()
				end)
			end
			onChanged(Util_CreateSlider(parent, "Engine Off X", m.CarEngineOffX, -8, 8, 0.1), function(v) m.CarEngineOffX = v end)
			onChanged(Util_CreateSlider(parent, "Engine Off Y", m.CarEngineOffY, -5, 5, 0.1), function(v) m.CarEngineOffY = v end)
			onChanged(Util_CreateSlider(parent, "Engine Off Z", m.CarEngineOffZ, -8, 8, 0.1), function(v) m.CarEngineOffZ = v end)
			onChanged(Util_CreateSwitch(parent, "Engine Bob", m.CarEngineBob), function(v) m.CarEngineBob = v end)
			onChanged(Util_CreateSlider(parent, "Engine Bob Amount", m.CarEngineBobAmt, 0, 0.5, 0.01), function(v) m.CarEngineBobAmt = v end)
			onChanged(Util_CreateSlider(parent, "Engine Bob Speed", m.CarEngineBobSpd, 2, 40, 1), function(v) m.CarEngineBobSpd = v end)
		end

		-- BALL SYSTEM UI
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── BALL SYSTEM (10 slots, yeet + mouse track) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Ball Enabled", m.BallEnabled), function(v)
			m.BallEnabled = v
			if v then X.rebuildBall() else X.clearBall() end
		end)
		keyDropdown("Ball Yeet Key", "BallKey")
		onChanged(Util_CreateSwitch(parent, "Ball Track Mouse", m.BallTrackMouse), function(v) m.BallTrackMouse = v end)
		onChanged(Util_CreateSlider(parent, "Track Strength", m.BallTrackStrength, 0, 1, 0.05), function(v) m.BallTrackStrength = v end)
		onChanged(Util_CreateSlider(parent, "Active Ball Slot", m.BallActiveSlot, 1, 10, 1), function(v)
			m.BallActiveSlot = math.clamp(math.floor(v + 0.5), 1, 10)
		end)
		onChanged(Util_CreateSlider(parent, "Float Side", m.BallFloatSide, -8, 8, 0.1), function(v) m.BallFloatSide = v end)
		onChanged(Util_CreateSlider(parent, "Float Height", m.BallFloatHeight, -3, 8, 0.1), function(v) m.BallFloatHeight = v end)
		onChanged(Util_CreateSlider(parent, "Float Forward", m.BallFloatForward, -8, 8, 0.1), function(v) m.BallFloatForward = v end)
		onChanged(Util_CreateSlider(parent, "Yeet Force", m.BallYeetForce, 20, 250, 5), function(v) m.BallYeetForce = v end)
		onChanged(Util_CreateSlider(parent, "Yeet Up Force", m.BallYeetUp, 0, 120, 5), function(v) m.BallYeetUp = v end)
		onChanged(Util_CreateSlider(parent, "Gravity", m.BallGravity, 0, 120, 5), function(v) m.BallGravity = v end)
		onChanged(Util_CreateSlider(parent, "Bounce", m.BallBounce, 0, 1, 0.05), function(v) m.BallBounce = v end)
		onChanged(Util_CreateSlider(parent, "Flight Life (sec)", m.BallLife, 0.5, 12, 0.25), function(v) m.BallLife = v end)
		onChanged(Util_CreateSwitch(parent, "Return After Life", m.BallReturn), function(v) m.BallReturn = v end)
		onChanged(Util_CreateSlider(parent, "Return Speed", m.BallReturnSpeed, 20, 300, 10), function(v) m.BallReturnSpeed = v end)
		onChanged(Util_CreateSwitch(parent, "Ball Spin", m.BallSpin), function(v) m.BallSpin = v end)
		onChanged(Util_CreateSlider(parent, "Spin Speed", m.BallSpinSpd, 0, 30, 1), function(v) m.BallSpinSpd = v end)
		onActivated(Util_CreateButton(parent, "YEET ACTIVE BALL", 14), function() X.yeetBall(m.BallActiveSlot or 1) end)
		onActivated(Util_CreateButton(parent, "Rebuild Balls", 12), function() X.rebuildBall() end)
		do
			local bNames = X.dropdownNames(true)
			for i = 1, 10 do
				local key = "BallHat" .. i
				local start = 1
				for j, n in ipairs(bNames) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Ball Slot " .. i, bNames, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and bNames[val] or tostring(val))
						X.rebuildBall()
					end)
				end
				local kDD = Util_CreateDropdown(parent, "Ball" .. i .. " Kind", m.BallKindNames, m["BallKind" .. i] or 1)
				if kDD and kDD.Changed then
					kDD.Changed:Connect(function(val)
						if type(val) == "number" then m["BallKind" .. i] = val
						elseif type(val) == "string" then
							for k, n in ipairs(m.BallKindNames) do if n == val then m["BallKind" .. i] = k break end end
						end
					end)
				end
				onChanged(Util_CreateSlider(parent, "B" .. i .. " Off X", m["BallOffX" .. i], -8, 8, 0.1), function(v) m["BallOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "B" .. i .. " Off Y", m["BallOffY" .. i], -8, 8, 0.1), function(v) m["BallOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "B" .. i .. " Off Z", m["BallOffZ" .. i], -8, 8, 0.1), function(v) m["BallOffZ" .. i] = v end)
			end
		end


		-- PLANETS
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── PLANETS (10 slots, solar system) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "Each slot is a planet: set radius, height, speed, phase, offsets, rotation, incline. Spins around you.", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Planet Enabled", m.PlanetEnabled), function(v)
			m.PlanetEnabled = v
			if v then X.rebuildPlanet() else X.clearPlanet() end
		end)
		onChanged(Util_CreateSwitch(parent, "Planet AUTO REBUILD", m.PlanetAutoRebuild), function(v)
			m.PlanetAutoRebuild = v
			if v and m.PlanetEnabled then NeedPlanetRebuild = true end
		end)
		onChanged(Util_CreateSwitch(parent, "Planet Orbit Spin", m.PlanetSpin), function(v) m.PlanetSpin = v end)
		onChanged(Util_CreateSwitch(parent, "Planet Self-Spin", m.PlanetSelfSpin), function(v) m.PlanetSelfSpin = v end)
		onChanged(Util_CreateSlider(parent, "Orbit Spin Speed", m.PlanetSpinSpd, 0.05, 4, 0.05), function(v) m.PlanetSpinSpd = v end)
		onChanged(Util_CreateSlider(parent, "Self-Spin Speed", m.PlanetSelfSpinSpd, 0, 20, 0.5), function(v) m.PlanetSelfSpinSpd = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Planets", 12), function() X.rebuildPlanet() end)
		do
			local pNames = X.dropdownNames(true)
			for i = 1, 10 do
				local key = "PlanetHat" .. i
				local start = 1
				for j, n in ipairs(pNames) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Planet " .. i .. " Hat", pNames, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and pNames[val] or tostring(val))
						X.rebuildPlanet()
					end)
				end
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Radius", m["PlanetRad" .. i], 1, 40, 0.25), function(v)
					m["PlanetRad" .. i] = v
					if PlanetSlots[i] then PlanetSlots[i].Rad = v end
				end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Height", m["PlanetHeight" .. i], -10, 15, 0.25), function(v)
					m["PlanetHeight" .. i] = v
					if PlanetSlots[i] then PlanetSlots[i].Height = v end
				end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Speed Mult", m["PlanetSpeed" .. i], 0.05, 5, 0.05), function(v)
					m["PlanetSpeed" .. i] = v
					if PlanetSlots[i] then PlanetSlots[i].Speed = v end
				end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Phase", m["PlanetPhase" .. i], 0, 6.28, 0.05), function(v)
					m["PlanetPhase" .. i] = v
					if PlanetSlots[i] then PlanetSlots[i].Phase = v end
				end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Side Off", m["PlanetOffX" .. i], -10, 10, 0.1), function(v) m["PlanetOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Up Off", m["PlanetOffY" .. i], -10, 10, 0.1), function(v) m["PlanetOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Forward Off", m["PlanetOffZ" .. i], -10, 10, 0.1), function(v) m["PlanetOffZ" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Rot X", m["PlanetRotX" .. i], -180, 180, 1), function(v) m["PlanetRotX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Rot Y", m["PlanetRotY" .. i], -180, 180, 1), function(v) m["PlanetRotY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Rot Z", m["PlanetRotZ" .. i], -180, 180, 1), function(v) m["PlanetRotZ" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "P" .. i .. " Incline (deg)", m["PlanetIncline" .. i], -45, 45, 1), function(v)
					m["PlanetIncline" .. i] = v
					if PlanetSlots[i] then PlanetSlots[i].Incline = math.rad(v) end
				end)
			end
		end

		-- MOTORCYCLE
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── MOTORCYCLE (lean + wheels + engine SFX) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Motorcycle Enabled", m.MotoEnabled), function(v)
			m.MotoEnabled = v
			if v then X.rebuildMoto() else X.clearMoto() end
		end)
		onChanged(Util_CreateSwitch(parent, "Moto AUTO REBUILD", m.MotoAutoRebuild), function(v)
			m.MotoAutoRebuild = v
			if v and m.MotoEnabled then NeedMotoRebuild = true end
		end)
		onChanged(Util_CreateSwitch(parent, "Ride Motorcycle", m.MotoRide), function(v)
			m.MotoRide = v
			if v and m.MotoEnterAnim then MotoEnterT = m.MotoEnterTime or 0.85 end
		end)
		keyDropdown("Moto Ride Toggle Key", "KeyMotoRide")
		onChanged(Util_CreateSwitch(parent, "Enter Animation", m.MotoEnterAnim), function(v) m.MotoEnterAnim = v end)
		onChanged(Util_CreateSlider(parent, "Enter Time", m.MotoEnterTime, 0.2, 2.5, 0.05), function(v) m.MotoEnterTime = v end)
		onChanged(Util_CreateSwitch(parent, "Lean on Turn", m.MotoLean), function(v) m.MotoLean = v end)
		onChanged(Util_CreateSlider(parent, "Lean Amount (deg)", m.MotoLeanAmt, 0, 40, 1), function(v) m.MotoLeanAmt = v end)
		onChanged(Util_CreateSlider(parent, "Speed Boost", m.MotoSpeedBoost, 1, 3, 0.05), function(v) m.MotoSpeedBoost = v end)
		onChanged(Util_CreateSlider(parent, "Moto Side", m.MotoSide, -15, 15, 0.5), function(v) m.MotoSide = v end)
		onChanged(Util_CreateSlider(parent, "Moto Height", m.MotoHeight, -5, 8, 0.25), function(v) m.MotoHeight = v end)
		onChanged(Util_CreateSlider(parent, "Moto Forward", m.MotoForward, -10, 10, 0.25), function(v) m.MotoForward = v end)
		onChanged(Util_CreateSwitch(parent, "Wheel Spin", m.MotoWheelSpin), function(v) m.MotoWheelSpin = v end)
		onChanged(Util_CreateSlider(parent, "Wheel Spin Speed", m.MotoWheelSpinSpd, 1, 40, 1), function(v) m.MotoWheelSpinSpd = v end)
		onChanged(Util_CreateSwitch(parent, "Engine SFX", m.MotoEngineSFX), function(v) m.MotoEngineSFX = v end)
		onChanged(Util_CreateSlider(parent, "Engine Volume", m.MotoVolume, 0, 2, 0.05), function(v) m.MotoVolume = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Motorcycle", 12), function() X.rebuildMoto() end)
		do
			local names = X.dropdownNames(true)
			for i = 1, 6 do
				local key = "MotoHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Moto Body " .. i, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildMoto()
					end)
				end
				onChanged(Util_CreateSlider(parent, "MB" .. i .. " Off X", m["MotoOffX" .. i], -8, 8, 0.1), function(v) m["MotoOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "MB" .. i .. " Off Y", m["MotoOffY" .. i], -5, 5, 0.1), function(v) m["MotoOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "MB" .. i .. " Off Z", m["MotoOffZ" .. i], -8, 8, 0.1), function(v) m["MotoOffZ" .. i] = v end)
			end
			for i = 1, 2 do
				local key = "MotoWheelHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Moto Wheel " .. i, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildMoto()
					end)
				end
			end
			local eStart = 1
			for j, n in ipairs(names) do
				if m.MotoEngineHat ~= "" and string.find(string.lower(n), string.lower(m.MotoEngineHat), 1, true) then eStart = j break end
			end
			local eDD = Util_CreateDropdown(parent, "Moto Engine Hat", names, eStart)
			if eDD and eDD.Changed then
				eDD.Changed:Connect(function(val)
					m.MotoEngineHat = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
					X.rebuildMoto()
				end)
			end
		end


		-- HAT TOOLS
		onChanged(Util_CreateSwitch(parent, "Tools Enabled", m.ToolEnabled), function(v)
			m.ToolEnabled = v
			if v then X.rebuildTool() else X.clearTool() end
		end)
		onChanged(Util_CreateSwitch(parent, "Tools AUTO REBUILD", m.ToolAutoRebuild), function(v)
			m.ToolAutoRebuild = v
			if v and m.ToolEnabled then NeedToolRebuild = true end
		end)
		local toolModeDD = Util_CreateDropdown(parent, "Tool Mode", m.ToolModeNames, m.ToolMode)
		if toolModeDD and toolModeDD.Changed then
			toolModeDD.Changed:Connect(function(val)
				if type(val) == "number" then m.ToolMode = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.ToolModeNames) do if n == val then m.ToolMode = i break end end
				end
			end)
		end
		keyDropdown("Tool Swing Key", "KeyToolSwing")
		keyDropdown("Tool Cycle Slot Key", "KeyToolCycle")
		onChanged(Util_CreateSwitch(parent, "Track Mouse", m.ToolTrackMouse), function(v) m.ToolTrackMouse = v end)
		onChanged(Util_CreateSlider(parent, "Active Tool Slot", m.ToolActiveSlot, 1, 6, 1), function(v) m.ToolActiveSlot = math.clamp(math.floor(v + 0.5), 1, 6) end)
		onChanged(Util_CreateSlider(parent, "Swing Cooldown", m.ToolSwingCooldown, 0.1, 2, 0.05), function(v) m.ToolSwingCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Swing Force", m.ToolSwingForce, 5, 120, 5), function(v) m.ToolSwingForce = v end)
		onChanged(Util_CreateSlider(parent, "Swing Range", m.ToolSwingRange, 2, 20, 0.5), function(v) m.ToolSwingRange = v end)
		onChanged(Util_CreateSwitch(parent, "Tool SFX", m.ToolSFX), function(v) m.ToolSFX = v end)
		onActivated(Util_CreateButton(parent, "SWING NOW", 14), function() X.swingTool() end)
		onActivated(Util_CreateButton(parent, "Rebuild Tools", 12), function() X.rebuildTool() end)
		do
			local names = X.dropdownNames(true)
			for i = 1, 6 do
				local key = "ToolHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Tool Slot " .. i, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildTool()
					end)
				end
				onChanged(Util_CreateSlider(parent, "T" .. i .. " Off X", m["ToolOffX" .. i], -5, 5, 0.1), function(v) m["ToolOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "T" .. i .. " Off Y", m["ToolOffY" .. i], -5, 5, 0.1), function(v) m["ToolOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "T" .. i .. " Off Z", m["ToolOffZ" .. i], -5, 5, 0.1), function(v) m["ToolOffZ" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "T" .. i .. " Rot Y", m["ToolRotY" .. i], -180, 180, 1), function(v) m["ToolRotY" .. i] = v end)
			end
		end

		-- PLANE
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── PLANE (frames + 2 props + 2 engines + guns + fly) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "FULL PLANE: pick one hat (triplane pack etc), set Off/Rot. Ride mounts you. Fly = free flight: W/S throttle, A/D turn, Q/E or mouse pitch, Space/Ctrl climb/dive, auto-bank. Cam lock + speedo. LMB guns while riding.", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Plane Enabled", m.PlaneEnabled), function(v)
			m.PlaneEnabled = v
			if v then X.rebuildPlane() else X.clearPlane() end
		end)
		onChanged(Util_CreateSwitch(parent, "Plane AUTO REBUILD (put hats back)", m.PlaneAutoRebuild), function(v)
			m.PlaneAutoRebuild = v
			if v and m.PlaneEnabled then NeedPlaneRebuild = true end
		end)
		onChanged(Util_CreateSwitch(parent, "Plane LOCK (force hats in place every frame)", m.PlaneLock), function(v)
			m.PlaneLock = v
		end)
		Util_CreateText(parent, "FULL PLANE (one accessory = whole aircraft, e.g. red triplane pack)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Full Plane Mode (single hat body)", m.PlaneFullMode), function(v)
			m.PlaneFullMode = v
			if m.PlaneEnabled then X.rebuildPlane() end
		end)
		do
			local names = X.dropdownNames(true)
			local start = 1
			for j, n in ipairs(names) do
				if m.PlaneFullHat ~= "" and string.find(string.lower(n), string.lower(m.PlaneFullHat), 1, true) then start = j break end
			end
			local dd = Util_CreateDropdown(parent, "Full Plane Hat", names, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m.PlaneFullHat = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
					X.rebuildPlane()
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Full Plane Side (X)", m.PlaneFullOffX, -15, 15, 0.1), function(v) m.PlaneFullOffX = v end)
		onChanged(Util_CreateSlider(parent, "Full Plane Up (Y)", m.PlaneFullOffY, -10, 10, 0.1), function(v) m.PlaneFullOffY = v end)
		onChanged(Util_CreateSlider(parent, "Full Plane Forward (Z)", m.PlaneFullOffZ, -15, 15, 0.1), function(v) m.PlaneFullOffZ = v end)
		onChanged(Util_CreateSlider(parent, "Full Plane Rot X", m.PlaneFullRotX, -180, 180, 1), function(v) m.PlaneFullRotX = v end)
		onChanged(Util_CreateSlider(parent, "Full Plane Rot Y", m.PlaneFullRotY, -180, 180, 1), function(v) m.PlaneFullRotY = v end)
		onChanged(Util_CreateSlider(parent, "Full Plane Rot Z", m.PlaneFullRotZ, -180, 180, 1), function(v) m.PlaneFullRotZ = v end)
		onChanged(Util_CreateSwitch(parent, "Ride Plane", m.PlaneRide), function(v)
			m.PlaneRide = v
			if v and m.PlaneEnterAnim then PlaneEnterT = m.PlaneEnterTime or 1.0 end
		end)
		onChanged(Util_CreateSwitch(parent, "Fly Mode (free flight)", m.PlaneFly), function(v) m.PlaneFly = v end)
		keyDropdown("Plane Ride Toggle Key", "KeyPlaneRide")
		keyDropdown("Plane Fly Toggle Key", "KeyPlaneFly")
		onChanged(Util_CreateSwitch(parent, "Enter Animation", m.PlaneEnterAnim), function(v) m.PlaneEnterAnim = v end)
		onChanged(Util_CreateSwitch(parent, "Camera Lock to Frame", m.PlaneCamLock), function(v) m.PlaneCamLock = v end)
		onChanged(Util_CreateSwitch(parent, "Speedometer HUD", m.PlaneSpeedo), function(v) m.PlaneSpeedo = v end)
		onChanged(Util_CreateSlider(parent, "Base Speed", m.PlaneSpeed, 10, 150, 5), function(v) m.PlaneSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Max Speed", m.PlaneMaxSpeed, 40, 300, 5), function(v) m.PlaneMaxSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Acceleration", m.PlaneAccel, 5, 100, 5), function(v) m.PlaneAccel = v end)
		onChanged(Util_CreateSlider(parent, "Pitch Rate", m.PlanePitchRate, 0.2, 3, 0.1), function(v) m.PlanePitchRate = v end)
		onChanged(Util_CreateSlider(parent, "Yaw Rate", m.PlaneYawRate, 0.2, 3, 0.1), function(v) m.PlaneYawRate = v end)
		onChanged(Util_CreateSlider(parent, "Roll Rate", m.PlaneRollRate, 0.2, 4, 0.1), function(v) m.PlaneRollRate = v end)
		onChanged(Util_CreateSwitch(parent, "Mouse Steer (aim to turn/pitch)", m.PlaneMouseSteer), function(v) m.PlaneMouseSteer = v end)
		onChanged(Util_CreateSlider(parent, "Mouse Sens", m.PlaneMouseSens, 0.05, 1.5, 0.05), function(v) m.PlaneMouseSens = v end)
		onChanged(Util_CreateSwitch(parent, "Auto Bank into Turns", m.PlaneBank), function(v) m.PlaneBank = v end)
		onChanged(Util_CreateSlider(parent, "Bank Amount (deg)", m.PlaneBankAmt, 0, 60, 1), function(v) m.PlaneBankAmt = v end)
		onChanged(Util_CreateSlider(parent, "Min Fly Speed (stall below)", m.PlaneMinFlySpeed, 0, 40, 1), function(v) m.PlaneMinFlySpeed = v end)
		onChanged(Util_CreateSlider(parent, "Gravity / Stall Pull", m.PlaneGravity, 0, 80, 1), function(v) m.PlaneGravity = v end)
		onChanged(Util_CreateSlider(parent, "Seat Height Offset", m.PlaneSeatOffY, -5, 3, 0.1), function(v) m.PlaneSeatOffY = v end)
		onChanged(Util_CreateSlider(parent, "Lift Mult", m.PlaneLift, 0.2, 3, 0.1), function(v) m.PlaneLift = v end)
		onChanged(Util_CreateSlider(parent, "Plane Side (parked)", m.PlaneSide, -20, 20, 0.5), function(v) m.PlaneSide = v end)
		onChanged(Util_CreateSlider(parent, "Plane Height (parked)", m.PlaneHeight, -5, 15, 0.25), function(v) m.PlaneHeight = v end)
		onChanged(Util_CreateSwitch(parent, "Engine SFX", m.PlaneEngineSFX), function(v) m.PlaneEngineSFX = v end)
		onChanged(Util_CreateSlider(parent, "Engine Volume", m.PlaneVolume, 0, 2, 0.05), function(v) m.PlaneVolume = v end)
		Util_CreateText(parent, "PLANE GUNS — aim, fire style, bullet, place/rot", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Guns Enabled", m.PlaneGunEnabled), function(v) m.PlaneGunEnabled = v end)
		onChanged(Util_CreateSwitch(parent, "Guns TRACK MOUSE (aim at anything under cursor)", m.PlaneGunTrackMouse), function(v)
			m.PlaneGunTrackMouse = v
		end)
		onChanged(Util_CreateSwitch(parent, "Track Only While Firing", m.PlaneGunTrackOnlyFire), function(v)
			m.PlaneGunTrackOnlyFire = v
		end)
		onChanged(Util_CreateSlider(parent, "Gun Aim Smooth", m.PlaneGunTrackSmooth, 2, 40, 1), function(v) m.PlaneGunTrackSmooth = v end)
		do
			local fsDD = Util_CreateDropdown(parent, "Fire Style", m.PlaneGunFireStyleNames, m.PlaneGunFireStyle or 1)
			if fsDD and fsDD.Changed then
				fsDD.Changed:Connect(function(val)
					if type(val) == "number" then m.PlaneGunFireStyle = val
					elseif type(val) == "string" then
						for i, n in ipairs(m.PlaneGunFireStyleNames) do
							if n == val then m.PlaneGunFireStyle = i break end
						end
					end
				end)
			end
			local bsDD = Util_CreateDropdown(parent, "Bullet Style", m.PlaneGunBulletStyleNames, m.PlaneGunBulletStyle or 1)
			if bsDD and bsDD.Changed then
				bsDD.Changed:Connect(function(val)
					if type(val) == "number" then m.PlaneGunBulletStyle = val
					elseif type(val) == "string" then
						for i, n in ipairs(m.PlaneGunBulletStyleNames) do
							if n == val then m.PlaneGunBulletStyle = i break end
						end
					end
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Gun Cooldown (Beam)", m.PlaneGunCooldown, 0.05, 1.5, 0.05), function(v) m.PlaneGunCooldown = v end)
		onChanged(Util_CreateSlider(parent, "AK Cooldown", m.PlaneGunAKCooldown, 0.05, 0.5, 0.01), function(v) m.PlaneGunAKCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Minigun Cooldown", m.PlaneGunMiniCooldown, 0.02, 0.2, 0.01), function(v) m.PlaneGunMiniCooldown = v end)
		onChanged(Util_CreateSlider(parent, "AK Burst Count", m.PlaneGunBurst, 1, 8, 1), function(v) m.PlaneGunBurst = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Spread (AK/Minigun deg)", m.PlaneGunSpread, 0, 25, 0.5), function(v) m.PlaneGunSpread = v end)
		onChanged(Util_CreateSlider(parent, "Gun Bullet Speed", m.PlaneGunSpeed, 40, 500, 10), function(v) m.PlaneGunSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Lifetime", m.PlaneGunLife, 0.3, 6, 0.1), function(v) m.PlaneGunLife = v end)
		onChanged(Util_CreateSlider(parent, "Beam Length (Gaster)", m.PlaneGunBeamLength, 20, 400, 5), function(v) m.PlaneGunBeamLength = v end)
		onChanged(Util_CreateSlider(parent, "Beam Thickness", m.PlaneGunBeamThick, 0.2, 6, 0.1), function(v) m.PlaneGunBeamThick = v end)
		onChanged(Util_CreateSwitch(parent, "Trail Oscillation (out then back & forth fast)", m.PlaneGunTrailOsc), function(v) m.PlaneGunTrailOsc = v end)
		onChanged(Util_CreateSlider(parent, "Osc Speed", m.PlaneGunTrailOscSpeed, 4, 50, 1), function(v) m.PlaneGunTrailOscSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Osc Distance", m.PlaneGunTrailOscDist, 2, 40, 0.5), function(v) m.PlaneGunTrailOscDist = v end)
		onChanged(Util_CreateSlider(parent, "Osc Duration", m.PlaneGunTrailOscTime, 0.2, 4, 0.1), function(v) m.PlaneGunTrailOscTime = v end)
		onChanged(Util_CreateSwitch(parent, "Bullet Trail", m.PlaneGunTrail), function(v) m.PlaneGunTrail = v end)
		onChanged(Util_CreateSwitch(parent, "Bullet Spin", m.PlaneGunBulletSpin), function(v) m.PlaneGunBulletSpin = v end)
		onChanged(Util_CreateSwitch(parent, "Hat Bullet = REAL FE hat", m.PlaneGunRealHat), function(v) m.PlaneGunRealHat = v end)
		onChanged(Util_CreateSwitch(parent, "Gun SFX", m.PlaneGunSFX), function(v) m.PlaneGunSFX = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Color R", m.PlaneGunR, 0, 255, 5), function(v) m.PlaneGunR = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Color G", m.PlaneGunG, 0, 255, 5), function(v) m.PlaneGunG = v end)
		onChanged(Util_CreateSlider(parent, "Bullet Color B", m.PlaneGunB, 0, 255, 5), function(v) m.PlaneGunB = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Plane", 12), function() X.rebuildPlane() end)
		onActivated(Util_CreateButton(parent, "FIRE GUNS NOW", 12), function() X.firePlaneGuns() end)
		do
			local names = X.dropdownNames(true)
			Util_CreateText(parent, "PLANE FRAMES (10)", 13, Enum.TextXAlignment.Left)
			for i = 1, 10 do
				local key = "PlaneFrameHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Frame " .. i, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildPlane()
					end)
				end
				onChanged(Util_CreateSlider(parent, "F" .. i .. " Off X", m["PlaneFrameOffX" .. i], -12, 12, 0.1), function(v) m["PlaneFrameOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "F" .. i .. " Off Y", m["PlaneFrameOffY" .. i], -8, 8, 0.1), function(v) m["PlaneFrameOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "F" .. i .. " Off Z", m["PlaneFrameOffZ" .. i], -12, 12, 0.1), function(v) m["PlaneFrameOffZ" .. i] = v end)
			end
			Util_CreateText(parent, "PROPELLERS (2)", 13, Enum.TextXAlignment.Left)
			for i = 1, 2 do
				local key = "PlanePropHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Propeller " .. i, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildPlane()
					end)
				end
				onChanged(Util_CreateSlider(parent, "Prop" .. i .. " Spin Speed", m["PlanePropSpinSpd" .. i], 5, 60, 1), function(v) m["PlanePropSpinSpd" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "Prop" .. i .. " Off X", m["PlanePropOffX" .. i], -10, 10, 0.1), function(v) m["PlanePropOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "Prop" .. i .. " Off Y", m["PlanePropOffY" .. i], -5, 5, 0.1), function(v) m["PlanePropOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "Prop" .. i .. " Off Z", m["PlanePropOffZ" .. i], -10, 10, 0.1), function(v) m["PlanePropOffZ" .. i] = v end)
			end
			Util_CreateText(parent, "ENGINES (2)", 13, Enum.TextXAlignment.Left)
			for i = 1, 2 do
				local key = "PlaneEngineHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Engine " .. i, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildPlane()
					end)
				end
				onChanged(Util_CreateSlider(parent, "Eng" .. i .. " Off X", m["PlaneEngineOffX" .. i], -10, 10, 0.1), function(v) m["PlaneEngineOffX" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "Eng" .. i .. " Off Y", m["PlaneEngineOffY" .. i], -5, 5, 0.1), function(v) m["PlaneEngineOffY" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "Eng" .. i .. " Off Z", m["PlaneEngineOffZ" .. i], -10, 10, 0.1), function(v) m["PlaneEngineOffZ" .. i] = v end)
			end
			Util_CreateText(parent, "PLANE GUNS (4) — hat + place/rot per gun", 13, Enum.TextXAlignment.Left)
			do
				local bStart = 1
				for j, n in ipairs(names) do
					if m.PlaneGunBulletHat ~= "" and string.find(string.lower(n), string.lower(m.PlaneGunBulletHat), 1, true) then
						bStart = j break
					end
				end
				local bDD = Util_CreateDropdown(parent, "Bullet Hat (style 4 Hat Bullet)", names, bStart)
				if bDD and bDD.Changed then
					bDD.Changed:Connect(function(val)
						m.PlaneGunBulletHat = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
					end)
				end
			end
			for i = 1, 4 do
				local key = "PlaneGunHat" .. i
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, "Gun " .. i .. " Hat", names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						X.rebuildPlane()
					end)
				end
				onChanged(Util_CreateSwitch(parent, "Gun " .. i .. " Fires", m["PlaneGunFire" .. i]), function(v) m["PlaneGunFire" .. i] = v end)
				onChanged(Util_CreateSlider(parent, "Gun" .. i .. " Side (X)", m["PlaneGunOffX" .. i], -15, 15, 0.1), function(v)
					m["PlaneGunOffX" .. i] = v
					if PlaneGuns[i] then PlaneGuns[i].Off = Vector3.new(v, PlaneGuns[i].Off.Y, PlaneGuns[i].Off.Z) end
				end)
				onChanged(Util_CreateSlider(parent, "Gun" .. i .. " Up/Down (Y)", m["PlaneGunOffY" .. i], -10, 10, 0.1), function(v)
					m["PlaneGunOffY" .. i] = v
					if PlaneGuns[i] then PlaneGuns[i].Off = Vector3.new(PlaneGuns[i].Off.X, v, PlaneGuns[i].Off.Z) end
				end)
				onChanged(Util_CreateSlider(parent, "Gun" .. i .. " Forward/Back (Z)", m["PlaneGunOffZ" .. i], -15, 15, 0.1), function(v)
					m["PlaneGunOffZ" .. i] = v
					if PlaneGuns[i] then PlaneGuns[i].Off = Vector3.new(PlaneGuns[i].Off.X, PlaneGuns[i].Off.Y, v) end
				end)
				onChanged(Util_CreateSlider(parent, "Gun" .. i .. " Rot X", m["PlaneGunRotX" .. i], -180, 180, 1), function(v)
					m["PlaneGunRotX" .. i] = v
					if PlaneGuns[i] then
						PlaneGuns[i].Rot = CFrame.Angles(
							math.rad(v),
							math.rad(m["PlaneGunRotY" .. i] or 0),
							math.rad(m["PlaneGunRotZ" .. i] or 0)
						)
					end
				end)
				onChanged(Util_CreateSlider(parent, "Gun" .. i .. " Rot Y", m["PlaneGunRotY" .. i], -180, 180, 1), function(v)
					m["PlaneGunRotY" .. i] = v
					if PlaneGuns[i] then
						PlaneGuns[i].Rot = CFrame.Angles(
							math.rad(m["PlaneGunRotX" .. i] or 0),
							math.rad(v),
							math.rad(m["PlaneGunRotZ" .. i] or 0)
						)
					end
				end)
				onChanged(Util_CreateSlider(parent, "Gun" .. i .. " Rot Z", m["PlaneGunRotZ" .. i], -180, 180, 1), function(v)
					m["PlaneGunRotZ" .. i] = v
					if PlaneGuns[i] then
						PlaneGuns[i].Rot = CFrame.Angles(
							math.rad(m["PlaneGunRotX" .. i] or 0),
							math.rad(m["PlaneGunRotY" .. i] or 0),
							math.rad(v)
						)
					end
				end)
			end
		end

		-- PLANE ORDNANCE: 5 attacks (Guns already above) + Bomb / Package / Missile / Bomb2
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── PLANE ATTACKS (5 toggles + keybinds) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent,
			"Attack 1 = Guns (above). 2 Bomb, 3 Package/crate, 4 Missile, 5 Bomb bay 2.\n"
			.. "Pick ANY hat for bomb/package (Bomb Hat, box body, etc). Missile needs launcher hat + missile hat (e.g. AIM-54).\n"
			.. "Underground: hats hide under the map until you press the attack key → rise → drop/fire → return/sink.",
			11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Ordnance UNDERGROUND until used", m.PlaneOrdnanceUnderground), function(v)
			m.PlaneOrdnanceUnderground = v
			if m.PlaneEnabled then X.rebuildPlane() end
		end)
		onChanged(Util_CreateSlider(parent, "Ordnance Stash Depth", m.PlaneOrdnanceStashDepth, 2, 40, 1), function(v) m.PlaneOrdnanceStashDepth = v end)
		onChanged(Util_CreateSlider(parent, "Ordnance Rise Time", m.PlaneOrdnanceStashRise, 0.1, 1.5, 0.05), function(v) m.PlaneOrdnanceStashRise = v end)
		onChanged(Util_CreateSlider(parent, "Ordnance Stay Up After Fire", m.PlaneOrdnanceStashHold, 0.2, 5, 0.1), function(v) m.PlaneOrdnanceStashHold = v end)

		-- Attack 2 BOMB
		Util_CreateText(parent, "ATTACK 2 — BOMB (drop any hat)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Bomb Enabled", m.PlaneBombEnabled), function(v)
			m.PlaneBombEnabled = v
			if m.PlaneEnabled then X.rebuildPlane() end
		end)
		keyDropdown("Bomb Keybind", "PlaneBombKey")
		do
			local names = X.dropdownNames(true)
			local start = 1
			for j, n in ipairs(names) do
				if m.PlaneBombHat ~= "" and string.find(string.lower(n), string.lower(m.PlaneBombHat), 1, true) then start = j break end
			end
			local dd = Util_CreateDropdown(parent, "Bomb Hat (any)", names, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m.PlaneBombHat = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
					if m.PlaneEnabled then X.rebuildPlane() end
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Bomb Cooldown", m.PlaneBombCooldown, 0.2, 6, 0.1), function(v) m.PlaneBombCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Count per drop", m.PlaneBombCount, 1, 6, 1), function(v) m.PlaneBombCount = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Bomb Spread", m.PlaneBombSpread, 0, 12, 0.25), function(v) m.PlaneBombSpread = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Fall Speed", m.PlaneBombFallSpeed, 20, 200, 5), function(v) m.PlaneBombFallSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Life (sec)", m.PlaneBombLife, 0.5, 30, 0.5), function(v) m.PlaneBombLife = v end)
		onChanged(Util_CreateSwitch(parent, "Bomb Return to plane", m.PlaneBombReturn), function(v) m.PlaneBombReturn = v end)
		onChanged(Util_CreateSwitch(parent, "Bomb STAY IN PLACE (keeps place/rot after you change it)", m.PlaneBombStay ~= false), function(v) X.setPlaneStay("PlaneBombStay", v) end)
		onChanged(Util_CreateSlider(parent, "Bomb Side", m.PlaneBombSide, -12, 12, 0.1), function(v) m.PlaneBombSide = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Up/Down", m.PlaneBombHeight, -10, 8, 0.1), function(v) m.PlaneBombHeight = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Forward/Back", m.PlaneBombForward, -12, 12, 0.1), function(v) m.PlaneBombForward = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Rot X", m.PlaneBombRotX, -180, 180, 1), function(v) m.PlaneBombRotX = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Rot Y", m.PlaneBombRotY, -180, 180, 1), function(v) m.PlaneBombRotY = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Rot Z", m.PlaneBombRotZ, -180, 180, 1), function(v) m.PlaneBombRotZ = v end)
		onChanged(Util_CreateSwitch(parent, "Bomb Bounce Off Ground", m.PlaneBombBounce), function(v) m.PlaneBombBounce = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Bounce Amount", m.PlaneBombBounceAmt, 0, 1, 0.05), function(v) m.PlaneBombBounceAmt = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Bounce Friction", m.PlaneBombBounceFriction, 0.2, 1, 0.02), function(v) m.PlaneBombBounceFriction = v end)
		onChanged(Util_CreateSlider(parent, "Bomb Min Bounce Speed", m.PlaneBombMinBounce, 1, 30, 1), function(v) m.PlaneBombMinBounce = v end)
		onActivated(Util_CreateButton(parent, "DROP BOMB NOW", 12), function() X.firePlaneBomb() end)

		-- Attack 3 PACKAGE
		Util_CreateText(parent, "ATTACK 3 — PACKAGE / CRATE / BOX (any hat)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Package Enabled", m.PlanePackageEnabled), function(v)
			m.PlanePackageEnabled = v
			if m.PlaneEnabled then X.rebuildPlane() end
		end)
		keyDropdown("Package Keybind", "PlanePackageKey")
		do
			local names = X.dropdownNames(true)
			local start = 1
			for j, n in ipairs(names) do
				if m.PlanePackageHat ~= "" and string.find(string.lower(n), string.lower(m.PlanePackageHat), 1, true) then start = j break end
			end
			local dd = Util_CreateDropdown(parent, "Package Hat (box body / crate / any)", names, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m.PlanePackageHat = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
					if m.PlaneEnabled then X.rebuildPlane() end
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Package Cooldown", m.PlanePackageCooldown, 0.2, 8, 0.1), function(v) m.PlanePackageCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Package Count", m.PlanePackageCount, 1, 6, 1), function(v) m.PlanePackageCount = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Package Fall Speed", m.PlanePackageFallSpeed, 15, 180, 5), function(v) m.PlanePackageFallSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Package Life (sec)", m.PlanePackageLife, 0.5, 30, 0.5), function(v) m.PlanePackageLife = v end)
		onChanged(Util_CreateSwitch(parent, "Package Return", m.PlanePackageReturn), function(v) m.PlanePackageReturn = v end)
		onChanged(Util_CreateSwitch(parent, "Package Bounce Off Ground", m.PlanePackageBounce), function(v) m.PlanePackageBounce = v end)
		onChanged(Util_CreateSlider(parent, "Package Bounce Amount", m.PlanePackageBounceAmt, 0, 1, 0.05), function(v) m.PlanePackageBounceAmt = v end)
		onChanged(Util_CreateSlider(parent, "Package Bounce Friction", m.PlanePackageBounceFriction, 0.2, 1, 0.02), function(v) m.PlanePackageBounceFriction = v end)
		onChanged(Util_CreateSwitch(parent, "Package STAY IN PLACE (keeps place/rot after you change it)", m.PlanePackageStay ~= false), function(v) X.setPlaneStay("PlanePackageStay", v) end)
		onChanged(Util_CreateSlider(parent, "Package Side", m.PlanePackageSide, -12, 12, 0.1), function(v) m.PlanePackageSide = v end)
		onChanged(Util_CreateSlider(parent, "Package Up/Down", m.PlanePackageHeight, -10, 8, 0.1), function(v) m.PlanePackageHeight = v end)
		onChanged(Util_CreateSlider(parent, "Package Forward/Back", m.PlanePackageForward, -12, 12, 0.1), function(v) m.PlanePackageForward = v end)
		onChanged(Util_CreateSlider(parent, "Package Rot X", m.PlanePackageRotX, -180, 180, 1), function(v) m.PlanePackageRotX = v end)
		onChanged(Util_CreateSlider(parent, "Package Rot Y", m.PlanePackageRotY, -180, 180, 1), function(v) m.PlanePackageRotY = v end)
		onChanged(Util_CreateSlider(parent, "Package Rot Z", m.PlanePackageRotZ, -180, 180, 1), function(v) m.PlanePackageRotZ = v end)
		onActivated(Util_CreateButton(parent, "DROP PACKAGE NOW", 12), function() X.firePlanePackage() end)

		-- Attack 4 MISSILE
		Util_CreateText(parent, "ATTACK 4 — MISSILE LAUNCHER", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Missile Enabled", m.PlaneMissileEnabled), function(v)
			m.PlaneMissileEnabled = v
			if m.PlaneEnabled then X.rebuildPlane() end
		end)
		keyDropdown("Missile Keybind", "PlaneMissileKey")
		keyDropdown("Missile Cycle Tube Key", "PlaneMissileCycleKey")
		do
			local names = X.dropdownNames(true)
			local function mslDD(label, key)
				local start = 1
				for j, n in ipairs(names) do
					if m[key] ~= "" and string.find(string.lower(n), string.lower(m[key]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, label, names, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[key] = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
						if m.PlaneEnabled then X.rebuildPlane() end
					end)
				end
			end
			mslDD("Launcher Hat (on plane)", "PlaneMissileLauncherHat")
			Util_CreateText(parent, "5 MISSILE TUBES — fire cycles 1→2→3→4→5 (slot 5 auto AIM-54)", 12, Enum.TextXAlignment.Left)
			onChanged(Util_CreateSwitch(parent, "Auto-Detect AIM-54 / Phoenix into empty tubes", m.PlaneMissileAutoDetect ~= false), function(v)
				m.PlaneMissileAutoDetect = v
				if v and m.PlaneEnabled then pcall(X.autoDetectMissileHats); X.rebuildPlane() end
			end)
			onActivated(Util_CreateButton(parent, "Scan AIM-54 Now", 12), function()
				pcall(X.autoDetectMissileHats)
				if m.PlaneEnabled then X.rebuildPlane() end
			end)
			for ti = 1, 5 do
				local key = "PlaneMissileHat" .. ti
				-- keep legacy PlaneMissileHat in sync with tube 1
				mslDD("Missile Tube " .. ti .. " Hat", key)
			end
			-- sync legacy field when tube 1 changes via rebuild
		end
		onChanged(Util_CreateSwitch(parent, "Auto-Cycle Tubes after fire", m.PlaneMissileAutoCycle ~= false), function(v)
			m.PlaneMissileAutoCycle = v
		end)
		onChanged(Util_CreateSlider(parent, "Active Tube (1-5)", m.PlaneMissileActiveSlot or 1, 1, 5, 1), function(v)
			m.PlaneMissileActiveSlot = math.clamp(math.floor(v + 0.5), 1, 5)
			if X.PlaneMissileAmmoSlots then
				X.PlaneMissileAmmo = X.PlaneMissileAmmoSlots[m.PlaneMissileActiveSlot] or X.PlaneMissileAmmo
			end
		end)
		onChanged(Util_CreateSlider(parent, "Shot Cooldown (between tubes)", m.PlaneMissileShotCooldown or 0.22, 0.05, 1.5, 0.05), function(v)
			m.PlaneMissileShotCooldown = v
		end)
		onChanged(Util_CreateSwitch(parent, "Missile Track Mouse (homing)", m.PlaneMissileTrackMouse), function(v) m.PlaneMissileTrackMouse = v end)
		onChanged(Util_CreateSlider(parent, "Missile Homing Strength", m.PlaneMissileHoming, 0, 4, 0.1), function(v) m.PlaneMissileHoming = v end)
		onChanged(Util_CreateSlider(parent, "Full Mag Reload (all tubes empty)", m.PlaneMissileCooldown, 0.2, 6, 0.1), function(v) m.PlaneMissileCooldown = v end)
		onChanged(Util_CreateSlider(parent, "Missile Speed", m.PlaneMissileSpeed, 40, 400, 10), function(v) m.PlaneMissileSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Missile Life", m.PlaneMissileLife, 0.5, 10, 0.25), function(v) m.PlaneMissileLife = v end)
		onChanged(Util_CreateSlider(parent, "Missile Count", m.PlaneMissileCount, 1, 4, 1), function(v) m.PlaneMissileCount = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Missile Spread (deg)", m.PlaneMissileSpread, 0, 20, 0.5), function(v) m.PlaneMissileSpread = v end)
		onChanged(Util_CreateSwitch(parent, "Missile Trail", m.PlaneMissileTrail), function(v) m.PlaneMissileTrail = v end)
		onChanged(Util_CreateSwitch(parent, "Missile Spin", m.PlaneMissileSpin), function(v) m.PlaneMissileSpin = v end)
		onChanged(Util_CreateSwitch(parent, "Missile Return", m.PlaneMissileReturn), function(v) m.PlaneMissileReturn = v end)
		Util_CreateText(parent, "LAUNCHER place / rot (live — no rebuild needed)", 12, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Launcher STAY IN PLACE (only missile fires out)", m.PlaneMissileLauncherLock ~= false), function(v)
			m.PlaneMissileLauncherLock = v
			if v and X.PlaneMissileLauncher then
				X.PlaneMissileLauncher._flying = false
				if X.PlaneMissileLauncher.Held then
					X.PlaneMissileLauncher.Held.Up = 1
					X.PlaneMissileLauncher.Held.UpUntil = math.huge
				end
			end
		end)
		onChanged(Util_CreateSwitch(parent, "Launcher Force-Lock every frame", m.PlaneMissileLauncherLockForce ~= false), function(v)
			m.PlaneMissileLauncherLockForce = v
		end)
		onChanged(Util_CreateSlider(parent, "Launcher Side", m.PlaneMissileLauncherSide, -12, 12, 0.1), function(v) m.PlaneMissileLauncherSide = v end)
		onChanged(Util_CreateSlider(parent, "Launcher Up/Down", m.PlaneMissileLauncherHeight, -10, 8, 0.1), function(v) m.PlaneMissileLauncherHeight = v end)
		onChanged(Util_CreateSlider(parent, "Launcher Forward", m.PlaneMissileLauncherForward, -12, 12, 0.1), function(v) m.PlaneMissileLauncherForward = v end)
		onChanged(Util_CreateSlider(parent, "Launcher Rot X", m.PlaneMissileLauncherRotX, -180, 180, 1), function(v) m.PlaneMissileLauncherRotX = v end)
		onChanged(Util_CreateSlider(parent, "Launcher Rot Y", m.PlaneMissileLauncherRotY, -180, 180, 1), function(v) m.PlaneMissileLauncherRotY = v end)
		onChanged(Util_CreateSlider(parent, "Launcher Rot Z", m.PlaneMissileLauncherRotZ, -180, 180, 1), function(v) m.PlaneMissileLauncherRotZ = v end)
		Util_CreateText(parent, "SHARED missile place / rot (fallback)", 12, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Missile STAY IN PLACE (ammo tubes keep place/rot after you change it)", m.PlaneMissileStay ~= false), function(v) X.setPlaneStay("PlaneMissileStay", v) end)
		onChanged(Util_CreateSlider(parent, "Missile Side", m.PlaneMissileSide, -12, 12, 0.1), function(v) m.PlaneMissileSide = v end)
		onChanged(Util_CreateSlider(parent, "Missile Up/Down", m.PlaneMissileHeight, -10, 8, 0.1), function(v) m.PlaneMissileHeight = v end)
		onChanged(Util_CreateSlider(parent, "Missile Forward", m.PlaneMissileForward, -12, 12, 0.1), function(v) m.PlaneMissileForward = v end)
		onChanged(Util_CreateSlider(parent, "Missile Rot X", m.PlaneMissileRotX, -180, 180, 1), function(v) m.PlaneMissileRotX = v end)
		onChanged(Util_CreateSlider(parent, "Missile Rot Y", m.PlaneMissileRotY, -180, 180, 1), function(v) m.PlaneMissileRotY = v end)
		onChanged(Util_CreateSlider(parent, "Missile Rot Z", m.PlaneMissileRotZ, -180, 180, 1), function(v) m.PlaneMissileRotZ = v end)
		Util_CreateText(parent, "PER-TUBE place (live) — each missile sits on its own hardpoint", 12, Enum.TextXAlignment.Left)
		for ti = 1, 5 do
			onChanged(Util_CreateSwitch(parent, "Tube " .. ti .. " Enabled", m["PlaneMissileSlotEnabled" .. ti] ~= false), function(v)
				m["PlaneMissileSlotEnabled" .. ti] = v
			end)
			onChanged(Util_CreateSlider(parent, "Tube" .. ti .. " Side", m["PlaneMissileSlotSide" .. ti] or 0, -12, 12, 0.1), function(v)
				m["PlaneMissileSlotSide" .. ti] = v
			end)
			onChanged(Util_CreateSlider(parent, "Tube" .. ti .. " Up/Down", m["PlaneMissileSlotHeight" .. ti] or 0, -10, 8, 0.1), function(v)
				m["PlaneMissileSlotHeight" .. ti] = v
			end)
			onChanged(Util_CreateSlider(parent, "Tube" .. ti .. " Forward", m["PlaneMissileSlotForward" .. ti] or 0, -12, 12, 0.1), function(v)
				m["PlaneMissileSlotForward" .. ti] = v
			end)
			onChanged(Util_CreateSlider(parent, "Tube" .. ti .. " Rot X", m["PlaneMissileSlotRotX" .. ti] or 0, -180, 180, 1), function(v)
				m["PlaneMissileSlotRotX" .. ti] = v
			end)
			onChanged(Util_CreateSlider(parent, "Tube" .. ti .. " Rot Y", m["PlaneMissileSlotRotY" .. ti] or 0, -180, 180, 1), function(v)
				m["PlaneMissileSlotRotY" .. ti] = v
			end)
			onChanged(Util_CreateSlider(parent, "Tube" .. ti .. " Rot Z", m["PlaneMissileSlotRotZ" .. ti] or 0, -180, 180, 1), function(v)
				m["PlaneMissileSlotRotZ" .. ti] = v
			end)
		end
		onActivated(Util_CreateButton(parent, "FIRE MISSILE NOW", 12), function() X.firePlaneMissile() end)
		onActivated(Util_CreateButton(parent, "CYCLE TUBE", 12), function()
			local cur = math.clamp(math.floor(m.PlaneMissileActiveSlot or 1), 1, 5)
			m.PlaneMissileActiveSlot = (cur % 5) + 1
			if X.PlaneMissileAmmoSlots then
				X.PlaneMissileAmmo = X.PlaneMissileAmmoSlots[m.PlaneMissileActiveSlot] or X.PlaneMissileAmmo
			end
			warn("[HatStand] active missile tube = " .. tostring(m.PlaneMissileActiveSlot))
		end)

		-- Attack 5 BOMB2
		Util_CreateText(parent, "ATTACK 5 — BOMB BAY 2 (extra drop)", 13, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Bomb2 Enabled", m.PlaneBomb2Enabled), function(v)
			m.PlaneBomb2Enabled = v
			if m.PlaneEnabled then X.rebuildPlane() end
		end)
		keyDropdown("Bomb2 Keybind", "PlaneBomb2Key")
		do
			local names = X.dropdownNames(true)
			local start = 1
			for j, n in ipairs(names) do
				if m.PlaneBomb2Hat ~= "" and string.find(string.lower(n), string.lower(m.PlaneBomb2Hat), 1, true) then start = j break end
			end
			local dd = Util_CreateDropdown(parent, "Bomb2 Hat (any)", names, start)
			if dd and dd.Changed then
				dd.Changed:Connect(function(val)
					m.PlaneBomb2Hat = X.cleanLabel(type(val) == "number" and names[val] or tostring(val))
					if m.PlaneEnabled then X.rebuildPlane() end
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Bomb2 Cooldown", m.PlaneBomb2Cooldown, 0.2, 6, 0.1), function(v) m.PlaneBomb2Cooldown = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Count", m.PlaneBomb2Count, 1, 8, 1), function(v) m.PlaneBomb2Count = math.floor(v + 0.5) end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Spread", m.PlaneBomb2Spread, 0, 14, 0.25), function(v) m.PlaneBomb2Spread = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Fall Speed", m.PlaneBomb2FallSpeed, 20, 200, 5), function(v) m.PlaneBomb2FallSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Life (sec)", m.PlaneBomb2Life, 0.5, 30, 0.5), function(v) m.PlaneBomb2Life = v end)
		onChanged(Util_CreateSwitch(parent, "Bomb2 Bounce Off Ground", m.PlaneBomb2Bounce), function(v) m.PlaneBomb2Bounce = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Bounce Amount", m.PlaneBomb2BounceAmt, 0, 1, 0.05), function(v) m.PlaneBomb2BounceAmt = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Bounce Friction", m.PlaneBomb2BounceFriction, 0.2, 1, 0.02), function(v) m.PlaneBomb2BounceFriction = v end)
		onChanged(Util_CreateSwitch(parent, "Bomb2 STAY IN PLACE (keeps place/rot after you change it)", m.PlaneBomb2Stay ~= false), function(v) X.setPlaneStay("PlaneBomb2Stay", v) end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Side", m.PlaneBomb2Side, -12, 12, 0.1), function(v) m.PlaneBomb2Side = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Up/Down", m.PlaneBomb2Height, -10, 8, 0.1), function(v) m.PlaneBomb2Height = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Forward", m.PlaneBomb2Forward, -12, 12, 0.1), function(v) m.PlaneBomb2Forward = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Rot X", m.PlaneBomb2RotX, -180, 180, 1), function(v) m.PlaneBomb2RotX = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Rot Y", m.PlaneBomb2RotY, -180, 180, 1), function(v) m.PlaneBomb2RotY = v end)
		onChanged(Util_CreateSlider(parent, "Bomb2 Rot Z", m.PlaneBomb2RotZ, -180, 180, 1), function(v) m.PlaneBomb2RotZ = v end)
		onActivated(Util_CreateButton(parent, "DROP BOMB2 NOW", 12), function() X.firePlaneBomb2() end)
		onActivated(Util_CreateButton(parent, "Rebuild Plane (apply ordnance hats)", 12), function() X.rebuildPlane() end)

		-- HELLCOPTER
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── HELLCOPTER (your frames + propellers + weapons, physics ride) ──", 14, Enum.TextXAlignment.Center)
		Util_CreateText(parent, "Pick hats for the body frames and the propellers, set place/rot. Ride (default F6) mounts you, Engine (F7) spools the rotor. W/S forward-back, A/D strafe, Q/E turn, Space up, Shift/Ctrl down. LMB or F8 fires the weapons at the mouse. Without engine power it drops.", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Hellcopter Enabled", m.HeliEnabled), function(v)
			m.HeliEnabled = v
			if v then X.rebuildHeli() else X.clearHeli() m.HeliRide = false end
		end)

		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── TITAN (limbs place on body + CORE FIRE) ──", 14, Enum.TextXAlignment.Center)
		onChanged(Util_CreateSwitch(parent, "Titan Enabled", m.TitanEnabled == true), function(v)
			m.TitanEnabled = v
			if v then X.rebuildTitan() else X.clearTitan() end
		end)
		onChanged(Util_CreateSwitch(parent, "Titan AUTO REBUILD (fast put hats back)", m.TitanAutoRebuild ~= false), function(v)
			m.TitanAutoRebuild = v
		end)
		onChanged(Util_CreateSlider(parent, "Titan Rebuild Speed (sec, lower = faster)", m.TitanRebuildDelay or 0.08, 0.02, 2, 0.01), function(v)
			m.TitanRebuildDelay = v
		end)
		onChanged(Util_CreateSlider(parent, "Titan Scale", m.TitanScale or 3.5, 1, 12, 0.1), function(v)
			m.TitanScale = v
			if m.TitanEnabled then X.rebuildTitan() end
		end)
		onChanged(Util_CreateSlider(parent, "Titan Height", m.TitanHeight or 0, -25, 30, 0.25), function(v) m.TitanHeight = v end)
		onChanged(Util_CreateSlider(parent, "Titan Side", m.TitanSide or 0, -20, 20, 0.25), function(v) m.TitanSide = v end)
		onChanged(Util_CreateSlider(parent, "Titan Forward", m.TitanForward or 0, -20, 20, 0.25), function(v) m.TitanForward = v end)
		onChanged(Util_CreateSlider(parent, "Titan Rot X", m.TitanRotX or 0, -180, 180, 1), function(v) m.TitanRotX = v end)
		onChanged(Util_CreateSlider(parent, "Titan Rot Y", m.TitanRotY or 0, -180, 180, 1), function(v) m.TitanRotY = v end)
		onChanged(Util_CreateSlider(parent, "Titan Rot Z", m.TitanRotZ or 0, -180, 180, 1), function(v) m.TitanRotZ = v end)
		onChanged(Util_CreateSlider(parent, "Titan Follow Smooth", m.TitanSmooth or 22, 4, 60, 1), function(v) m.TitanSmooth = v end)
		onChanged(Util_CreateSwitch(parent, "Titan Animations (idle/walk/run/jump/fall/fly)", m.TitanAnim ~= false), function(v) m.TitanAnim = v end)
		onChanged(Util_CreateSlider(parent, "Titan Anim Speed", m.TitanAnimSpeed or 1, 0.2, 3, 0.05), function(v) m.TitanAnimSpeed = v end)
		onChanged(Util_CreateSwitch(parent, "Titan Fly", m.TitanFly == true), function(v) m.TitanFly = v end)
		onChanged(Util_CreateSlider(parent, "Titan Fly Speed", m.TitanFlySpeed or 70, 20, 200, 5), function(v) m.TitanFlySpeed = v end)
		keyDropdown("Titan Fly Key", "KeyTitanFly")
		keyDropdown("Titan Core Fire Key", "KeyTitanCoreFire")
		onChanged(Util_CreateSwitch(parent, "Core Fire Enabled", m.TitanCoreFireEnabled ~= false), function(v) m.TitanCoreFireEnabled = v end)
		onChanged(Util_CreateSlider(parent, "Core Fire Distance", m.TitanCoreFireDist or 40, 5, 120, 1), function(v) m.TitanCoreFireDist = v end)
		onChanged(Util_CreateSlider(parent, "Core Fire Out Speed", m.TitanCoreFireSpeed or 180, 40, 400, 5), function(v) m.TitanCoreFireSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Core Fire Return Speed", m.TitanCoreFireReturn or 220, 40, 500, 5), function(v) m.TitanCoreFireReturn = v end)
		onChanged(Util_CreateSlider(parent, "Core Fire Cooldown", m.TitanCoreFireCooldown or 0.45, 0.1, 3, 0.05), function(v) m.TitanCoreFireCooldown = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Titan Now", 13), function() X.rebuildTitan() end)
		onActivated(Util_CreateButton(parent, "Core Fire Now", 12), function() X.titanCoreFire() end)
		do
			local names = X.dropdownNames and X.dropdownNames(true) or { "(none)" }
			local function limbDD(label, field)
				local d = Util_CreateDropdown(parent, label, names, 1)
				if d and d.Changed then
					d.Changed:Connect(function(val)
						local lab = type(val) == "number" and names[val] or tostring(val)
						m[field] = X.cleanLabel and X.cleanLabel(lab) or lab
						if m.TitanEnabled then X.rebuildTitan() end
					end)
				end
			end
			local function placeRotSliders(tag, offX, offY, offZ, rotX, rotY, rotZ, offRange)
				offRange = offRange or 20
				Util_CreateText(parent, tag .. " — place (side / up-down / forward) + rotation", 12, Enum.TextXAlignment.Left)
				onChanged(Util_CreateSlider(parent, tag .. " Side (X)", m[offX] or 0, -offRange, offRange, 0.05), function(v) m[offX] = v end)
				onChanged(Util_CreateSlider(parent, tag .. " Up / Down (Y)", m[offY] or 0, -offRange, offRange, 0.05), function(v) m[offY] = v end)
				onChanged(Util_CreateSlider(parent, tag .. " Forward / Back (Z)", m[offZ] or 0, -offRange, offRange, 0.05), function(v) m[offZ] = v end)
				onChanged(Util_CreateSlider(parent, tag .. " Rot X", m[rotX] or 0, -180, 180, 1), function(v) m[rotX] = v end)
				onChanged(Util_CreateSlider(parent, tag .. " Rot Y", m[rotY] or 0, -180, 180, 1), function(v) m[rotY] = v end)
				onChanged(Util_CreateSlider(parent, tag .. " Rot Z", m[rotZ] or 0, -180, 180, 1), function(v) m[rotZ] = v end)
			end
			limbDD("Titan CORE (body core)", "TitanHatCore")
			placeRotSliders("CORE", "TitanCoreOffX", "TitanCoreOffY", "TitanCoreOffZ", "TitanCoreRotX", "TitanCoreRotY", "TitanCoreRotZ", 25)
			limbDD("Titan Head", "TitanHatHead")
			placeRotSliders("HEAD", "TitanOffHeadX", "TitanOffHeadY", "TitanOffHeadZ", "TitanRotHeadX", "TitanRotHeadY", "TitanRotHeadZ", 20)
			limbDD("Titan Torso", "TitanHatTorso")
			placeRotSliders("TORSO", "TitanOffTorsoX", "TitanOffTorsoY", "TitanOffTorsoZ", "TitanRotTorsoX", "TitanRotTorsoY", "TitanRotTorsoZ", 20)
			limbDD("Titan Left Arm", "TitanHatLeftArm")
			placeRotSliders("LEFT ARM", "TitanOffLeftArmX", "TitanOffLeftArmY", "TitanOffLeftArmZ", "TitanRotLeftArmX", "TitanRotLeftArmY", "TitanRotLeftArmZ", 20)
			limbDD("Titan Right Arm", "TitanHatRightArm")
			placeRotSliders("RIGHT ARM", "TitanOffRightArmX", "TitanOffRightArmY", "TitanOffRightArmZ", "TitanRotRightArmX", "TitanRotRightArmY", "TitanRotRightArmZ", 20)
			limbDD("Titan Left Leg", "TitanHatLeftLeg")
			placeRotSliders("LEFT LEG", "TitanOffLeftLegX", "TitanOffLeftLegY", "TitanOffLeftLegZ", "TitanRotLeftLegX", "TitanRotLeftLegY", "TitanRotLeftLegZ", 20)
			limbDD("Titan Right Leg", "TitanHatRightLeg")
			placeRotSliders("RIGHT LEG", "TitanOffRightLegX", "TitanOffRightLegY", "TitanOffRightLegZ", "TitanRotRightLegX", "TitanRotRightLegY", "TitanRotRightLegZ", 20)
			limbDD("Titan Jetpack", "TitanHatJetpack")
			placeRotSliders("JETPACK", "TitanJetpackOffX", "TitanJetpackOffY", "TitanJetpackOffZ", "TitanJetpackRotX", "TitanJetpackRotY", "TitanJetpackRotZ", 20)
			limbDD("Core FIRE hat (flame burst)", "TitanCoreFireHat")
			limbDD("Core TRAIL hat (behind burst)", "TitanCoreTrailHat")
		end
		Util_CreateText(parent, "1) Titan Enabled  2) pick limb / core hats  3) use place/rot sliders (live, no rebuild needed for move/rotate). Auto Rebuild puts lost hats back fast. Anims: idle breathe, walk/run swing, jump/fall, fly pose. Core Fire (Y): hat shoots forward then snaps back with trail.", 11, Enum.TextXAlignment.Left)

		onChanged(Util_CreateSwitch(parent, "Heli Ride (mount it)", m.HeliRide), function(v)
			if v ~= m.HeliRide then X.toggleHeliRide() end
		end)
		keyDropdown("Heli Ride Key (rebindable)", "KeyHeliRide")
		Util_CreateText(parent, "Press the Heli Ride key to mount/dismount. Change the key above anytime.", 11, Enum.TextXAlignment.Left)
		onChanged(Util_CreateSwitch(parent, "Heli Engine On", m.HeliEngine), function(v) m.HeliEngine = v end)
		onChanged(Util_CreateSwitch(parent, "Engine auto-starts when you ride", m.HeliAutoStart), function(v) m.HeliAutoStart = v end)
		onChanged(Util_CreateSwitch(parent, "Physics (needs rotor power to hold up, falls without)", m.HeliPhysics), function(v) m.HeliPhysics = v end)
		onChanged(Util_CreateSwitch(parent, "Hover Assist (off = manual collective: Space adds lift)", m.HeliHoverAssist), function(v) m.HeliHoverAssist = v end)
		onChanged(Util_CreateSwitch(parent, "Auto Rebuild (put hats back)", m.HeliAutoRebuild), function(v) m.HeliAutoRebuild = v end)
		onChanged(Util_CreateSlider(parent, "Auto Rebuild Speed (seconds, lower = faster)", m.HeliRebuildDelay or 0.1, 0.02, 3, 0.01), function(v) m.HeliRebuildDelay = v end)
		onChanged(Util_CreateSwitch(parent, "Chase Camera", m.HeliCamLock), function(v) m.HeliCamLock = v end)
		onChanged(Util_CreateSwitch(parent, "Engine Sound", m.HeliSFX), function(v) m.HeliSFX = v end)
		do
			local sfxDD = Util_CreateDropdown(parent, "Engine Sound Source", m.HeliEngineModeNames, m.HeliEngineMode or 1)
			if sfxDD and sfxDD.Changed then
				sfxDD.Changed:Connect(function(val)
					local idx = (type(val) == "number") and val or nil
					if not idx then
						for j, n in ipairs(m.HeliEngineModeNames) do if n == val then idx = j break end end
					end
					if idx then m.HeliEngineMode = idx X.HeliForceGen = false X.resetHeliEngine() end
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Engine Volume", m.HeliVolume or 1, 0.1, 3, 0.05), function(v) m.HeliVolume = v end)
		onChanged(Util_CreateSlider(parent, "Engine Pitch / Chop Speed", m.HeliPitch or 1, 0.5, 2, 0.05), function(v) m.HeliPitch = v end)
		onChanged(Util_CreateSwitch(parent, "Minigun Sounds (loop while firing + stop clip)", m.HeliMiniSFX), function(v) m.HeliMiniSFX = v X.HeliMiniBad = false end)
		onChanged(Util_CreateSlider(parent, "Minigun Volume", m.HeliMiniVolume or 1, 0.1, 3, 0.05), function(v) m.HeliMiniVolume = v end)
		keyDropdown("Heli Ride Key", "KeyHeliRide")
		keyDropdown("Heli Engine Key", "KeyHeliEngine")
		keyDropdown("Heli Fire Key", "KeyHeliFire")
		keyDropdown("Fire Missile Key (default R, can be a mouse button)", "KeyHeliMissile")
		keyDropdown("Missile Launcher ON/OFF Key (default T)", "KeyHeliLauncher")
		onChanged(Util_CreateSwitch(parent, "Hellcopter Fly ON/OFF (off = can't ride, engine stops)", m.HeliFly ~= false), function(v) X.setHeliFly(v) end)
		keyDropdown("Heli Fly ON/OFF Key (default P)", "KeyHeliOff")
		onChanged(Util_CreateSwitch(parent, "Mouse Flight Control (steer the hellcopter with the mouse)", m.HeliMouseCtl), function(v) m.HeliMouseCtl = v end)
		keyDropdown("Mouse Control ON/OFF Key (default F9)", "KeyHeliMouse")
		do
			local mmDD = Util_CreateDropdown(parent, "Mouse Control Mode", m.HeliMouseModeNames, m.HeliMouseMode or 1)
			if mmDD and mmDD.Changed then
				mmDD.Changed:Connect(function(val)
					local idx = (type(val) == "number") and val or nil
					if not idx then
						for j, n in ipairs(m.HeliMouseModeNames) do if n == val then idx = j break end end
					end
					if idx then m.HeliMouseMode = idx end
				end)
			end
		end
		onChanged(Util_CreateSlider(parent, "Mouse Turn Sensitivity", m.HeliMouseSens or 1.5, 0.2, 4, 0.1), function(v) m.HeliMouseSens = v end)
		onChanged(Util_CreateSlider(parent, "Mouse Dead Zone (center area that does nothing)", m.HeliMouseDead or 0.12, 0, 0.6, 0.01), function(v) m.HeliMouseDead = v end)
		onChanged(Util_CreateSwitch(parent, "Mouse Up/Down also climbs / descends (cursor above / below center)", m.HeliMouseClimb == true), function(v) m.HeliMouseClimb = v end)
		onChanged(Util_CreateSlider(parent, "Heli Max Speed", m.HeliMaxSpeed, 20, 300, 5), function(v) m.HeliMaxSpeed = v end)
		onChanged(Util_CreateSlider(parent, "Heli Climb Speed", m.HeliClimb, 10, 150, 1), function(v) m.HeliClimb = v end)
		onChanged(Util_CreateSlider(parent, "Heli Turn Rate", m.HeliYawRate, 0.3, 5, 0.1), function(v) m.HeliYawRate = v end)
		onChanged(Util_CreateSlider(parent, "Heli Acceleration", m.HeliAccel, 0.5, 8, 0.1), function(v) m.HeliAccel = v end)
		onChanged(Util_CreateSlider(parent, "Heli Tilt (deg)", m.HeliTilt, 0, 45, 1), function(v) m.HeliTilt = v end)
		onChanged(Util_CreateSlider(parent, "Rotor Spool-Up (sec)", m.HeliSpoolUp, 0.3, 8, 0.1), function(v) m.HeliSpoolUp = v end)
		onChanged(Util_CreateSlider(parent, "Rotor Spool-Down (sec)", m.HeliSpoolDown, 0.5, 15, 0.1), function(v) m.HeliSpoolDown = v end)
		onChanged(Util_CreateSlider(parent, "Fall Gravity Multiplier", m.HeliGravity, 0.5, 3, 0.05), function(v) m.HeliGravity = v end)
		onChanged(Util_CreateSlider(parent, "Heli Follow Smooth", m.HeliSmooth, 4, 40, 1), function(v) m.HeliSmooth = v end)
		onChanged(Util_CreateSlider(parent, "Heli Seat Height (ride)", m.HeliSeatOffY, -8, 8, 0.1), function(v) m.HeliSeatOffY = v end)
		onChanged(Util_CreateSlider(parent, "Parked Side", m.HeliSide, -20, 20, 0.25), function(v) m.HeliSide = v end)
		onChanged(Util_CreateSlider(parent, "Parked Up/Down", m.HeliHeight, -10, 10, 0.25), function(v) m.HeliHeight = v end)
		onChanged(Util_CreateSlider(parent, "Parked Forward", m.HeliForward, -20, 20, 0.25), function(v) m.HeliForward = v end)
		onChanged(Util_CreateSlider(parent, "Parked Rot Y", m.HeliRotY, -180, 180, 1), function(v) m.HeliRotY = v end)
		onActivated(Util_CreateButton(parent, "Rebuild Hellcopter", 14), function() X.rebuildHeli() end)
		onActivated(Util_CreateButton(parent, "Toggle Ride Now", 12), function() X.toggleHeliRide() end)
		onActivated(Util_CreateButton(parent, "Toggle Engine Now", 12), function() X.toggleHeliEngine() end)

		do
			local heliNames = X.dropdownNames(true)
			local function heliHatDD(label, field)
				local start = 1
				for j, n in ipairs(heliNames) do
					if m[field] ~= "" and string.find(string.lower(n), string.lower(m[field]), 1, true) then start = j break end
				end
				local dd = Util_CreateDropdown(parent, label, heliNames, start)
				if dd and dd.Changed then
					dd.Changed:Connect(function(val)
						m[field] = X.cleanLabel(type(val) == "number" and heliNames[val] or tostring(val))
						X.rebuildHeli()
					end)
				end
			end
			local function slotSliders(tag, prefix, i, offR, rotR)
				-- clearly named position sliders (relative to the hellcopter body), fine step so you can nudge
				local axes = {
					{ "X", "Side (- left / + right)" },
					{ "Y", "Up / Down (+ up)" },
					{ "Z", "Forward / Back (- forward / + back)" },
				}
				for _, a in ipairs(axes) do
					onChanged(Util_CreateSlider(parent, tag .. " " .. a[2], m[prefix .. "Off" .. a[1] .. i] or 0, -offR, offR, 0.05), function(v)
						m[prefix .. "Off" .. a[1] .. i] = v
					end)
				end
				for _, ax in ipairs({ "X", "Y", "Z" }) do
					onChanged(Util_CreateSlider(parent, tag .. " Rot " .. ax, m[prefix .. "Rot" .. ax .. i] or 0, -rotR, rotR, 1), function(v)
						m[prefix .. "Rot" .. ax .. i] = v
					end)
				end
			end

			local function groupSliders(label, key, range)
				Util_CreateText(parent, label, 12, Enum.TextXAlignment.Left)
				onChanged(Util_CreateSlider(parent, label .. " - Side", m[key .. "X"] or 0, -range, range, 0.05), function(v) m[key .. "X"] = v end)
				onChanged(Util_CreateSlider(parent, label .. " - Up / Down", m[key .. "Y"] or 0, -range, range, 0.05), function(v) m[key .. "Y"] = v end)
				onChanged(Util_CreateSlider(parent, label .. " - Forward / Back", m[key .. "Z"] or 0, -range, range, 0.05), function(v) m[key .. "Z"] = v end)
			end

			Util_CreateText(parent, "MOVE EVERYTHING IN A GROUP AT ONCE (added on top of each piece's own position)", 13, Enum.TextXAlignment.Left)
			groupSliders("ALL FRAMES", "HeliFramesAll", 40)
			groupSliders("ALL PROPELLERS", "HeliPropsAll", 40)
			groupSliders("ALL WEAPONS", "HeliWpnsAll", 40)

			Util_CreateText(parent, "HELLCOPTER FRAMES (12) - body, tail, skids, cockpit...", 13, Enum.TextXAlignment.Left)
			for i = 1, 12 do
				heliHatDD("Heli Frame " .. i, "HeliFrameHat" .. i)
				slotSliders("HF" .. i, "HeliFrame", i, 40, 180)
			end

			Util_CreateText(parent, "HELLCOPTER PROPELLERS (4) - main rotor, tail rotor...", 13, Enum.TextXAlignment.Left)
			for i = 1, 4 do
				heliHatDD("Heli Propeller " .. i, "HeliPropHat" .. i)
				local adr = Util_CreateDropdown(parent, "Prop " .. i .. " Spin Axis", m.HeliAxisNames, m["HeliPropAxis" .. i] or 2)
				if adr and adr.Changed then
					adr.Changed:Connect(function(val)
						local idx = (type(val) == "number") and val or nil
						if not idx then
							for j, n in ipairs(m.HeliAxisNames) do if n == val then idx = j break end end
						end
						if idx then m["HeliPropAxis" .. i] = idx end
					end)
				end
				onChanged(Util_CreateSlider(parent, "Prop " .. i .. " Spin Speed (neg = reverse)", m["HeliPropSpd" .. i] or 40, -120, 120, 1), function(v)
					m["HeliPropSpd" .. i] = v
				end)
				slotSliders("HP" .. i, "HeliProp", i, 40, 180)
			end

			Util_CreateText(parent, "HELLCOPTER WEAPONS (4) - pick the gun hat and the hat that is shot as the bullet", 13, Enum.TextXAlignment.Left)
			local fsDD = Util_CreateDropdown(parent, "Heli Fire Style", m.HeliFireStyleNames, m.HeliFireStyle or 2)
			if fsDD and fsDD.Changed then
				fsDD.Changed:Connect(function(val)
					local idx = (type(val) == "number") and val or nil
					if not idx then
						for j, n in ipairs(m.HeliFireStyleNames) do if n == val then idx = j break end end
					end
					if idx then m.HeliFireStyle = idx end
				end)
			end
			onChanged(Util_CreateSlider(parent, "Bullet Speed", m.HeliBulletSpeed, 40, 600, 5), function(v) m.HeliBulletSpeed = v end)
			onChanged(Util_CreateSlider(parent, "Bullet Range", m.HeliBulletRange, 30, 800, 10), function(v) m.HeliBulletRange = v end)
			onChanged(Util_CreateSlider(parent, "Fire Cooldown", m.HeliCooldown, 0.03, 1.5, 0.01), function(v) m.HeliCooldown = v end)
			onChanged(Util_CreateSlider(parent, "Spread (deg)", m.HeliSpread, 0, 12, 0.1), function(v) m.HeliSpread = v end)
			onChanged(Util_CreateSwitch(parent, "Spin Hat Bullet", m.HeliBulletSpin), function(v) m.HeliBulletSpin = v end)
			onChanged(Util_CreateSwitch(parent, "Bullet Trail", m.HeliTrail), function(v) m.HeliTrail = v end)
			onChanged(Util_CreateSwitch(parent, "Neon bullet when hat bullets are busy", m.HeliBulletFallback), function(v) m.HeliBulletFallback = v end)
			onChanged(Util_CreateSwitch(parent, "Aim guns at mouse", m.HeliAimMouse), function(v) m.HeliAimMouse = v end)
			onChanged(Util_CreateSwitch(parent, "Fire Sound", m.HeliFireSFX), function(v) m.HeliFireSFX = v end)
			onChanged(Util_CreateSwitch(parent, "Mouse Tracker (bullets curve toward the mouse)", m.HeliHoming ~= false), function(v) m.HeliHoming = v end)
			onChanged(Util_CreateSwitch(parent, "Hat Rig Collision (hit / push NPCs & dummies)", m.HeliSolid == true), function(v) m.HeliSolid = v end)
			onChanged(Util_CreateSwitch(parent, "  Solid: Frame hats", m.HeliSolidFrames ~= false), function(v) m.HeliSolidFrames = v end)
			onChanged(Util_CreateSwitch(parent, "  Solid: Propeller hats", m.HeliSolidProps ~= false), function(v) m.HeliSolidProps = v end)
			onChanged(Util_CreateSwitch(parent, "  Solid: Weapon / Launcher hats", m.HeliSolidWpns ~= false), function(v) m.HeliSolidWpns = v end)
			onChanged(Util_CreateSlider(parent, "  Push Strength", m.HeliSolidPush or 1, 0, 3, 0.1), function(v) m.HeliSolidPush = v end)
			onChanged(Util_CreateSwitch(parent, "  Ignore other players (only NPCs / map)", m.HeliSolidIgnorePlayers ~= false), function(v) m.HeliSolidIgnorePlayers = v end)
			onChanged(Util_CreateSwitch(parent, "  Boost simulation radius (own nearby NPCs)", m.HeliSolidBoost ~= false), function(v) m.HeliSolidBoost = v end)
			onChanged(Util_CreateSwitch(parent, "Aim Assist (lock bullets onto players / missiles near cursor)", m.HeliAimAssist ~= false), function(v) m.HeliAimAssist = v end)
			onChanged(Util_CreateSlider(parent, "Aim Assist Radius (px)", m.HeliAimAssistRadius or 90, 20, 300, 5), function(v) m.HeliAimAssistRadius = v end)
			onChanged(Util_CreateSlider(parent, "Tracking Strength", m.HeliHomingStrength or 4, 0.5, 20, 0.5), function(v) m.HeliHomingStrength = v end)
			local tcDD = Util_CreateDropdown(parent, "Bullet Trail Color", m.HeliTrailColorNames, m.HeliTrailColor or 1)
			if tcDD and tcDD.Changed then
				tcDD.Changed:Connect(function(val)
					local idx = (type(val) == "number") and val or nil
					if not idx then
						for j, n in ipairs(m.HeliTrailColorNames) do if n == val then idx = j break end end
					end
					if idx then m.HeliTrailColor = idx end
				end)
			end
			onChanged(Util_CreateSlider(parent, "Trail Length (seconds)", m.HeliTrailLife or 0.35, 0.05, 2, 0.05), function(v) m.HeliTrailLife = v end)
			onChanged(Util_CreateSlider(parent, "Trail Width", m.HeliTrailWidth or 1.2, 0.2, 6, 0.1), function(v) m.HeliTrailWidth = v end)
			Util_CreateText(parent, "SHARED BULLET HATS (up to 8, pick ANY hat - e.g. a rock / shoulder hat. Every weapon shoots these; more hats = faster hat-fire before the neon fallback kicks in)", 12, Enum.TextXAlignment.Left)
			for i = 1, 8 do
				heliHatDD("Shared Bullet Hat " .. i, "HeliAmmoHat" .. i)
			end

			Util_CreateText(parent, "MISSILE LAUNCHER - hold the cursor over a player to lock on (beeps, then locked), press the missile key to fire. No lock = the missile flies toward the mouse point. Missiles launch from your weapon mounts.", 12, Enum.TextXAlignment.Left)
			onChanged(Util_CreateSwitch(parent, "Missile Launcher ON", m.HeliMissileEnabled ~= false), function(v) m.HeliMissileEnabled = v if not v then X.msClearLock() end end)
			Util_CreateText(parent, "MISSILE LAUNCHER HATS (the launcher itself - pick any hat, then place it: Side / Up-Down / Forward-Back + rotation. It stays where you put it.)", 12, Enum.TextXAlignment.Left)
			for i = 1, 2 do
				heliHatDD("Missile Launcher Hat " .. i, "HeliLaunchHat" .. i)
				slotSliders("LAUNCHER " .. i, "HeliLaunch", i, 40, 180)
			end
			onChanged(Util_CreateSwitch(parent, "Launchers swing toward lock target / mouse", m.HeliLaunchAim ~= false), function(v) m.HeliLaunchAim = v end)
			onChanged(Util_CreateSwitch(parent, "Launcher SMOOTH FOLLOW (off = stays rigidly in place)", m.HeliLaunchSmooth == true), function(v) m.HeliLaunchSmooth = v end)
			onChanged(Util_CreateSlider(parent, "Smooth Follow Speed (lower = floatier)", m.HeliLaunchSmoothSpeed or 6, 1, 30, 0.5), function(v) m.HeliLaunchSmoothSpeed = v end)
			Util_CreateText(parent, "MISSILE HATS (the missile that flies out) - each one has its own position + rotation, relative to the missile's flight path", 12, Enum.TextXAlignment.Left)
			for i = 1, 4 do
				heliHatDD("Missile Hat " .. i, "HeliMissileHat" .. i)
				slotSliders("MISSILE " .. i, "HeliMissile", i, 20, 180)
			end
			onChanged(Util_CreateSwitch(parent, "Missile Sounds (lock beep, flying loop, explosion)", m.HeliMissileSFX ~= false), function(v) m.HeliMissileSFX = v end)
			onChanged(Util_CreateSlider(parent, "Missile Volume (master)", m.HeliMissileVolume or 1, 0, 3, 0.05), function(v) m.HeliMissileVolume = v end)
			onChanged(Util_CreateSwitch(parent, "Lock-on sound keeps playing while locked (off = stops when locked)", m.HeliMissileLockKeep ~= false), function(v) m.HeliMissileLockKeep = v end)
			onChanged(Util_CreateSlider(parent, "Lock-On Sound Speed (1 = normal)", m.HeliMissileLockSpeed or 1, 0.3, 2, 0.05), function(v) m.HeliMissileLockSpeed = v if X.MsLoop then pcall(function() X.MsLoop.PlaybackSpeed = v end) end end)
			onChanged(Util_CreateSlider(parent, "Lock-On Beep Volume", m.HeliMissileLockVol or 0.8, 0, 3, 0.05), function(v) m.HeliMissileLockVol = v end)
			onChanged(Util_CreateSlider(parent, "Missile Flying Loop Volume", m.HeliMissileLoopVol or 1, 0, 3, 0.05), function(v) m.HeliMissileLoopVol = v end)
			onChanged(Util_CreateSlider(parent, "Missile Explosion Volume", m.HeliMissileExplodeVol or 1, 0, 3, 0.05), function(v) m.HeliMissileExplodeVol = v end)
			onChanged(Util_CreateSlider(parent, "Missile Reload (seconds)", m.HeliMissileCooldown or 1.5, 0.2, 10, 0.1), function(v) m.HeliMissileCooldown = v end)
			onChanged(Util_CreateSlider(parent, "Missile Speed", m.HeliMissileSpeed or 150, 40, 500, 5), function(v) m.HeliMissileSpeed = v end)
			onChanged(Util_CreateSlider(parent, "Missile Turn / Homing Strength", m.HeliMissileTurn or 3.5, 0.5, 15, 0.5), function(v) m.HeliMissileTurn = v end)
			onChanged(Util_CreateSlider(parent, "Missile Flight Time (seconds)", m.HeliMissileLife or 8, 1, 30, 0.5), function(v) m.HeliMissileLife = v end)
			onChanged(Util_CreateSlider(parent, "Lock Range (studs)", m.HeliMissileRange or 600, 50, 3000, 10), function(v) m.HeliMissileRange = v end)
			onChanged(Util_CreateSlider(parent, "Lock Time (seconds)", m.HeliMissileLockTime or 1, 0.1, 5, 0.1), function(v) m.HeliMissileLockTime = v end)
			onChanged(Util_CreateSlider(parent, "Lock Radius Around Mouse (pixels)", m.HeliMissileLockRadius or 140, 30, 500, 5), function(v) m.HeliMissileLockRadius = v end)
			onChanged(Util_CreateSwitch(parent, "Lock onto NPCs / dummies too", m.HeliMissileNPC == true), function(v) m.HeliMissileNPC = v end)
			onChanged(Util_CreateSwitch(parent, "Explosion Effect (visual only)", m.HeliMissileExplosion ~= false), function(v) m.HeliMissileExplosion = v end)
			onChanged(Util_CreateSlider(parent, "Explosion Size", m.HeliMissileExplosionSize or 12, 2, 40, 1), function(v) m.HeliMissileExplosionSize = v end)
			onChanged(Util_CreateSlider(parent, "ALL Missiles Rot X", m.HeliMissileRotX or 0, -180, 180, 1), function(v) m.HeliMissileRotX = v end)
			onChanged(Util_CreateSlider(parent, "ALL Missiles Rot Y", m.HeliMissileRotY or 0, -180, 180, 1), function(v) m.HeliMissileRotY = v end)
			onChanged(Util_CreateSlider(parent, "ALL Missiles Rot Z", m.HeliMissileRotZ or 0, -180, 180, 1), function(v) m.HeliMissileRotZ = v end)
			onChanged(Util_CreateSlider(parent, "Hat Bullet Rot X", m.HeliBulletRotX, -180, 180, 1), function(v) m.HeliBulletRotX = v end)
			onChanged(Util_CreateSlider(parent, "Hat Bullet Rot Y", m.HeliBulletRotY, -180, 180, 1), function(v) m.HeliBulletRotY = v end)
			onChanged(Util_CreateSlider(parent, "Hat Bullet Rot Z", m.HeliBulletRotZ, -180, 180, 1), function(v) m.HeliBulletRotZ = v end)
			onActivated(Util_CreateButton(parent, "FIRE HELI WEAPONS NOW", 12), function() X.fireHeli(true) end)
			for i = 1, 4 do
				heliHatDD("Heli Weapon " .. i .. " Hat", "HeliWpnHat" .. i)
				heliHatDD("Weapon " .. i .. " Bullet Hat", "HeliWpnBullet" .. i)
				heliHatDD("Weapon " .. i .. " Bullet Hat 2", "HeliWpnBullet2" .. i)
				onChanged(Util_CreateSwitch(parent, "Weapon " .. i .. " Fires", m["HeliWpnFire" .. i]), function(v) m["HeliWpnFire" .. i] = v end)
				slotSliders("HW" .. i, "HeliWpn", i, 40, 180)
			end
		end


		-- CAR ENTER / ENGINE SFX UI additions
		Util_CreateSeparator(parent)
		Util_CreateText(parent, "── CAR ENTER + ENGINE (GTA-style) ──", 14, Enum.TextXAlignment.Center)
		keyDropdown("Car Ride / Enter Key", "KeyCarRide")
		onChanged(Util_CreateSwitch(parent, "Car AUTO REBUILD", m.CarAutoRebuild), function(v)
			m.CarAutoRebuild = v
			if v and m.CarEnabled then NeedCarRebuild = true end
		end)
		onChanged(Util_CreateSwitch(parent, "Car Enter Animation", m.CarEnterAnim), function(v) m.CarEnterAnim = v end)
		onChanged(Util_CreateSlider(parent, "Enter Time", m.CarEnterTime, 0.2, 2.5, 0.05), function(v) m.CarEnterTime = v end)
		onChanged(Util_CreateSwitch(parent, "Car Engine SFX (client)", m.CarEngineSFX), function(v) m.CarEngineSFX = v end)
		local cetDD = Util_CreateDropdown(parent, "Engine Type", m.CarEngineTypeNames, m.CarEngineType)
		if cetDD and cetDD.Changed then
			cetDD.Changed:Connect(function(val)
				if type(val) == "number" then m.CarEngineType = val
				elseif type(val) == "string" then
					for i, n in ipairs(m.CarEngineTypeNames) do if n == val then m.CarEngineType = i break end end
				end
			end)
		end
		onChanged(Util_CreateSlider(parent, "Engine Volume", m.CarEngineVolume, 0, 2, 0.05), function(v) m.CarEngineVolume = v end)

		Util_CreateSeparator(parent)
		local movesetNames = X.scanWorkspaceMovesets()
		if #movesetNames == 0 then movesetNames = { "(none)" } end
		local mdd = Util_CreateDropdown(parent, "Other Moveset", movesetNames, 1)
		if mdd and mdd.Changed then
			mdd.Changed:Connect(function(val)
				if type(val) == "number" then m.SelectedOtherMoveset = movesetNames[val] or ""
				elseif type(val) == "string" then m.SelectedOtherMoveset = val end
			end)
		end
		onActivated(Util_CreateButton(parent, "Apply Moveset (keep stand)", 14), function()
			m.UseWithOtherMovesets = true
			X.refreshState()
			X.findAndClickMoveset(m.SelectedOtherMoveset ~= "" and m.SelectedOtherMoveset or movesetNames[1])
		end)

		Util_CreateSeparator(parent)
		Util_CreateText(parent,
			"KEYBINDS:\n" ..
			"Z/X/C = Ravenger Claws (when ON) else combat  V/F/G = combat  H = force dance  R = place slot\n" ..
			"E = yeet placed  T = place back  B = weapon fire  N = weapon slot\n" ..
			"Sans/Shield keys are rebindable in their sections.\n" ..
			"Defaults: Q Gaster, M cycle, L Bone, K Omega, O Omega cycle, P all Sans, U Sans underground on/off, J shield up/down, Y place shield\n" ..
			"NEW: - = car, = = moto, ] = plane ride, \\ = plane fly, V = tool swing (if tools ON)\n" ..
			"Orbit modes now go to 80. Planets / Moto / Tools / Plane have their own sections.\n" ..
			"Refresh checks avatar + reports NEW/GONE hats.\n" ..
			"Auto Refresh every 1s when toggle is ON.",
			11, Enum.TextXAlignment.Left)
		end)
		if not okUI then
			warn("[HatStand] Config UI error: " .. tostring(errUI))
			pcall(function()
				Util_CreateText(parent, "CONFIG ERROR: " .. tostring(errUI), 12, Enum.TextXAlignment.Left)
			end)
		end
	end


	-- SAVE_KEYS + Load/SaveConfig in nested fn to avoid 200-local limit on outer function
	do
	function X._hsSetupSave()
		local SAVE_KEYS = {
			"Enabled", "UseWithOtherMovesets", "FEMode", "ActiveMode", "StandInOrbitMode",
			"SideOffset", "ForwardOffset", "HeightOffset",
			"Smoothness", "FaceSameWay", "OrbitStand", "AutoBuild", "AutoLimbHats", "AutoSpareHats", "AllowUsedHats",
			"Keybinds", "StandScale", "AnimSpeed", "ShowHatNames", "IdleStyle", "MethodIndex",
			"HatHead", "HatTorso", "HatLeftArm", "HatRightArm", "HatLeftLeg", "HatRightLeg",
			"SelectedOtherMoveset",
			"RotHeadX", "RotHeadY", "RotHeadZ",
			"RotTorsoX", "RotTorsoY", "RotTorsoZ",
			"RotLeftArmX", "RotLeftArmY", "RotLeftArmZ",
			"RotRightArmX", "RotRightArmY", "RotRightArmZ",
			"RotLeftLegX", "RotLeftLegY", "RotLeftLegZ",
			"RotRightLegX", "RotRightLegY", "RotRightLegZ",
			"OffHeadX", "OffHeadY", "OffHeadZ",
			"OffTorsoX", "OffTorsoY", "OffTorsoZ",
			"OffLeftArmX", "OffLeftArmY", "OffLeftArmZ",
			"OffRightArmX", "OffRightArmY", "OffRightArmZ",
			"OffLeftLegX", "OffLeftLegY", "OffLeftLegZ",
			"OffRightLegX", "OffRightLegY", "OffRightLegZ",
			"ShowLimbPreview",
			"AutoCorrect", "AutoCorrectDist",
			"WalkWithMe", "WalkSideOffset", "WalkForwardOffset", "WalkHeightOffset", "WalkSmoothness",
			"WalkStrength", "RunStrength", "JumpStrength", "WalkCycleSpeed", "RunCycleSpeed", "RunThreshold",
			"DanceSync", "DanceStrength", "DanceKey", "BallerMode",
			"BigRigFix", "BigRigArmSpread", "BigRigLegSpread", "BigRigHeight", "FixAnyRigPose", "DanceMirrorCharacter",
			"PlaceEnabled", "PlacePreviewOn", "PlaceSpin", "PlaceSpinSpeed",
			"PlaceBob", "PlaceBobSpeed", "PlaceBobHeight", "PlaceSnapGrid", "PlaceMax",
			"PlaceActiveSlot", "PlaceBuildAnim", "PlaceBuildAnimSpeed", "PlacePersist", "PlaceLock",
			"PlaceCustomAnim", "PlaceYeetForce", "PlaceYeetUp",
			"PlaceSolid", "BToolsMode", "BToolsScale", "BToolsSpacing", "BToolsPreviewAll", "BToolsClickBuild",
			"OrbitEnabled", "OrbitRad", "OrbitSpd", "OrbitH", "OrbitFaceOut", "OrbitSpinSelf", "OrbitSpinSelfSpd",
			"OrbitMode", "OrbitVertical", "OrbitVertAmp", "OrbitVertSpd", "OrbitFinalePulse", "OrbitFinalePulseAmt", "OrbitFinalePulseSpd", "OrbitAutoRebuild",
			"GasterEnabled", "GasterHat", "GasterSide", "GasterHeight", "GasterForward",
			"GasterSize", "GasterLaserLength", "GasterLaserThick", "GasterCooldown", "GasterChargeTime", "GasterPush",
			"GasterUseHatBullet", "GasterHatBullet", "GasterTrailOsc", "GasterTrailOscSpeed", "GasterTrailOscDist", "GasterTrailOscTime",
			"GasterSFX", "GasterSFXId", "GasterFireSFXId", "GasterVolume",
			"WeaponAntiSnap", "WeaponTrackMouse", "WeaponTrackMode", "WeaponTrackStrength", "WeaponTrackSmooth", "WeaponTrackPitch", "WeaponTrackHold",
			"WeaponAimMouse", "WeaponAutoFire", "WeaponMuzzleFlash", "WeaponRecoil", "WeaponRecoilSpeed", "WeaponBobAmt", "WeaponBobSpeed",
			"WeaponFireMode", "UndergroundStash", "StashDepth", "StashRise", "StashHold", "WeaponBlasterScale", "WeaponBlasterCharge", "WeaponLaserLength", "WeaponLaserTime",
			"WeaponRealHat", "WeaponBulletSize", "WeaponBulletR", "WeaponBulletG", "WeaponBulletB", "WeaponBulletSpin",
			"WeaponHoming", "WeaponGravity", "WeaponBurst", "WeaponSpread", "WeaponStopOnHit", "WeaponHitFX", "WeaponReturnSpeed",
			"WeaponTrail", "WeaponRainbow", "WeaponTrailLife", "WeaponTrailWidth", "WeaponTrailR", "WeaponTrailG", "WeaponTrailB",
			"WeaponMaxBurst", "WeaponSFX", "WeaponFireSFXId", "WeaponHitSFXId", "WeaponVolume",
			"WeaponEnabled", "WeaponActiveSlot", "WeaponFloatSide", "WeaponFloatHeight", "WeaponFloatForward",
			"WeaponRotX", "WeaponRotY", "WeaponRotZ", "WeaponFireSpeed", "WeaponFireCooldown", "WeaponBulletLife",
			"ShieldEnabled", "ShieldHat", "ShieldMode", "ShieldSide", "ShieldHeight", "ShieldForward",
			"ShieldRotX", "ShieldRotY", "ShieldRotZ", "ShieldScale",
			"ShieldAutoFace", "ShieldBob", "ShieldBobSpeed", "ShieldBobAmt", "ShieldSpin", "ShieldSpinSpeed", "ShieldUnderground",
			"ShieldStashDepth", "ShieldStashRise", "ShieldStashHold",
			"KeyGaster", "KeyGasterCycle", "KeyBone", "KeyOmega", "KeyShield", "KeyShieldPlace", "KeySans",
			"ClawsEnabled", "ClawsLeftHat", "ClawsRightHat", "ClawsHeadHat", "ClawsScale", "ClawsSide", "ClawsHeight", "ClawsForward",
			"ClawsRotX", "ClawsRotY", "ClawsRotZ",
			"ClawsLeftOffX", "ClawsLeftOffY", "ClawsLeftOffZ", "ClawsLeftRotX", "ClawsLeftRotY", "ClawsLeftRotZ",
			"ClawsRightOffX", "ClawsRightOffY", "ClawsRightOffZ", "ClawsRightRotX", "ClawsRightRotY", "ClawsRightRotZ",
			"ClawsHeadOffX", "ClawsHeadOffY", "ClawsHeadOffZ", "ClawsHeadRotX", "ClawsHeadRotY", "ClawsHeadRotZ",
			"ClawsIdleBob", "ClawsBobSpeed", "ClawsBobAmt",
			"ClawsComboCooldown", "ClawsPushCooldown", "ClawsSpinCooldown", "ClawsComboRange",
			"ClawsPushForce", "ClawsPushUp", "ClawsSpinSpeed", "ClawsSpinDuration", "ClawsSpinRadius",
			"ClawsTrackMouse", "ClawsBloodTrail", "ClawsSFX", "ClawsSlashSFXId", "ClawsPushSFXId", "ClawsSpinSFXId", "ClawsVolume",
			"KeyClawsCombo", "KeyClawsPush", "KeyClawsSpin",
			"ClawsAnims", "ClawsAnimStrength", "ClawsAnimBlend", "ClawsKeysEnabled", "KeyClawsKeysToggle", "KeyClawsTrackToggle", "KeyClawsRage",
			"KeyClawsLaser", "KeyClawsSlam", "ClawsRage", "ClawsRageMul", "ClawsLaserUseHat", "ClawsLaserHat", "ClawsLaserDual", "ClawsLaserAim",
			"ClawsLaserCooldown", "ClawsLaserCharge", "ClawsLaserLength", "ClawsLaserThick", "ClawsLaserR", "ClawsLaserG", "ClawsLaserB",
			"ClawsLaserBulletSpeed", "ClawsLaserBulletSpin", "ClawsLaserTrail", "ClawsLaserTrailOsc", "ClawsLaserTrailOscDist",
			"ClawsLaserTrailOscSpeed", "ClawsLaserTrailOscTime", "ClawsSlamCooldown", "ClawsSlamRadius",
			"PlaceUndergroundOnSelect", "PlaceUndergroundDepth", "PlaceUndergroundSpeed", "PlaceStayAfterRespawn",
			"CarEnabled", "CarRide", "CarSpeedBoost", "CarSide", "CarHeight", "CarForward", "CarRotY", "CarSmooth",
			"AutoRefresh", "AutoRefreshInterval",
			"SelectFirst", "LinkRigs", "LinkStrength", "LinkSmooth", "LinkSource", "StrictHats", "StandMoveset", "ProcDance",
			"SelectedDance", "JojoLoco", "LocoBlend", "LocoLean", "LocoBob", "LocoArmOut", "FallSpread", "LandSquash",
			"SansUnderground", "SansStashDepth", "SansStashRise", "SansStashHold",
			"OmegaRotX", "OmegaRotY", "OmegaRotZ", "OmegaTrackOnlyFire",
			"OmegaStashDepth", "OmegaStashRise", "OmegaStashHold",
			"OmegaRiseBeforeFire", "OmegaKeepUpWhileCharge",
			"OmegaUseHatBullet", "OmegaBulletHat", "OmegaBulletHat2", "OmegaBulletSpeed", "OmegaBulletSpin", "OmegaBulletTrail",
			"CloneEnabled", "CloneSide", "CloneForward", "CloneHeight", "CloneSmooth", "CloneFaceSame", "CloneAutoHats",
			"CloneHatHead", "CloneHatTorso", "CloneHatLeftArm", "CloneHatRightArm", "CloneHatLeftLeg", "CloneHatRightLeg",
			"CloneRotHeadX", "CloneRotHeadY", "CloneRotHeadZ",
			"CloneRotTorsoX", "CloneRotTorsoY", "CloneRotTorsoZ",
			"CloneRotLeftArmX", "CloneRotLeftArmY", "CloneRotLeftArmZ",
			"CloneRotRightArmX", "CloneRotRightArmY", "CloneRotRightArmZ",
			"CloneRotLeftLegX", "CloneRotLeftLegY", "CloneRotLeftLegZ",
			"CloneRotRightLegX", "CloneRotRightLegY", "CloneRotRightLegZ",
			"CloneOffHeadX", "CloneOffHeadY", "CloneOffHeadZ",
			"CloneOffTorsoX", "CloneOffTorsoY", "CloneOffTorsoZ",
			"CloneOffLeftArmX", "CloneOffLeftArmY", "CloneOffLeftArmZ",
			"CloneOffRightArmX", "CloneOffRightArmY", "CloneOffRightArmZ",
			"CloneOffLeftLegX", "CloneOffLeftLegY", "CloneOffLeftLegZ",
			"CloneOffRightLegX", "CloneOffRightLegY", "CloneOffRightLegZ",
		}
		for i = 1, 10 do
			table.insert(SAVE_KEYS, "PlaceHat" .. i)
			table.insert(SAVE_KEYS, "PlaceRot" .. i .. "X")
			table.insert(SAVE_KEYS, "PlaceRot" .. i .. "Y")
			table.insert(SAVE_KEYS, "PlaceRot" .. i .. "Z")
			table.insert(SAVE_KEYS, "PlaceOff" .. i .. "X")
			table.insert(SAVE_KEYS, "PlaceOff" .. i .. "Y")
			table.insert(SAVE_KEYS, "PlaceOff" .. i .. "Z")
			table.insert(SAVE_KEYS, "OrbitHat" .. i)
			table.insert(SAVE_KEYS, "OrbitSpdMult" .. i)
			table.insert(SAVE_KEYS, "OrbitRadOff" .. i)
			table.insert(SAVE_KEYS, "OrbitRotX" .. i)
			table.insert(SAVE_KEYS, "OrbitRotY" .. i)
			table.insert(SAVE_KEYS, "OrbitRotZ" .. i)
			table.insert(SAVE_KEYS, "OrbitVertOff" .. i)
			table.insert(SAVE_KEYS, "CloneSlotHat" .. i)
			table.insert(SAVE_KEYS, "CloneSlotOffX" .. i)
			table.insert(SAVE_KEYS, "CloneSlotOffY" .. i)
			table.insert(SAVE_KEYS, "CloneSlotOffZ" .. i)
			table.insert(SAVE_KEYS, "CloneSlotRotX" .. i)
			table.insert(SAVE_KEYS, "CloneSlotRotY" .. i)
			table.insert(SAVE_KEYS, "CloneSlotRotZ" .. i)
			table.insert(SAVE_KEYS, "CloneSlotKind" .. i)
		end
		for i = 11, 15 do
			for _, f in ipairs({ "Hat", "OffX", "OffY", "OffZ", "RotX", "RotY", "RotZ", "Kind" }) do
				table.insert(SAVE_KEYS, "CloneSlot" .. f .. i)
			end
		end
		for _, k in ipairs({
			"StopOnExit", "OwnDanceSpeed", "OwnDanceLoop", "OwnDanceSounds", "OwnDanceBlend", "OwnDanceRecSecs", "LowLag", "LowLagSkip",
			"HeliEnabled", "HeliAutoStart", "HeliPhysics", "HeliHoverAssist", "HeliAutoRebuild", "HeliSide", "HeliHeight",
			"HeliForward", "HeliRotY", "HeliSeatOffY", "HeliSmooth", "HeliMaxSpeed", "HeliClimb", "HeliYawRate", "HeliAccel",
			"HeliTilt", "HeliSpoolUp", "HeliSpoolDown", "HeliGravity", "HeliCamLock", "HeliCamSmooth", "HeliSFX", "HeliVolume", "HeliPitch", "HeliEngineMode", "HeliMiniSFX", "HeliMiniVolume",
			"KeyHeliRide", "KeyHeliEngine", "KeyHeliFire", "HeliFireStyle", "HeliBulletSpeed", "HeliBulletRange", "HeliCooldown",
			"HeliSpread", "HeliBulletSpin", "HeliTrail", "HeliBulletFallback", "HeliAimMouse", "HeliFireSFX",
			"HeliBulletRotX", "HeliBulletRotY", "HeliBulletRotZ",
			"HeliAimAssist", "HeliAimAssistRadius", "HeliSolid", "HeliSolidFrames", "HeliSolidProps", "HeliSolidWpns", "HeliSolidPush", "HeliSolidIgnorePlayers", "HeliSolidBoost",
			"HatsSolid", "HatsSolidPush", "HatsSolidIgnorePlayers", "HatsSolidBoost",
		}) do
			table.insert(SAVE_KEYS, k)
		end
		for i = 1, 12 do
			table.insert(SAVE_KEYS, "HeliFrameHat" .. i)
			for _, f in ipairs({ "OffX", "OffY", "OffZ", "RotX", "RotY", "RotZ" }) do table.insert(SAVE_KEYS, "HeliFrame" .. f .. i) end
		end
		for i = 1, 4 do
			table.insert(SAVE_KEYS, "HeliPropHat" .. i)
			table.insert(SAVE_KEYS, "HeliPropAxis" .. i)
			table.insert(SAVE_KEYS, "HeliPropSpd" .. i)
			table.insert(SAVE_KEYS, "HeliWpnHat" .. i)
			table.insert(SAVE_KEYS, "HeliWpnBullet" .. i)
			table.insert(SAVE_KEYS, "HeliWpnBullet2" .. i)
			table.insert(SAVE_KEYS, "HeliWpnFire" .. i)
			for _, f in ipairs({ "OffX", "OffY", "OffZ", "RotX", "RotY", "RotZ" }) do
				table.insert(SAVE_KEYS, "HeliProp" .. f .. i)
				table.insert(SAVE_KEYS, "HeliWpn" .. f .. i)
			end
		end
		for i = 1, 10 do
			table.insert(SAVE_KEYS, "WeaponRot" .. i .. "X")
			table.insert(SAVE_KEYS, "WeaponRot" .. i .. "Y")
			table.insert(SAVE_KEYS, "WeaponRot" .. i .. "Z")
			table.insert(SAVE_KEYS, "WeaponHat" .. i)
			table.insert(SAVE_KEYS, "WeaponBulletHat" .. i)
			table.insert(SAVE_KEYS, "WeaponFire" .. i)
			table.insert(SAVE_KEYS, "WeaponBullet" .. i)
			table.insert(SAVE_KEYS, "WeaponOffsetX" .. i)
			table.insert(SAVE_KEYS, "WeaponOffsetY" .. i)
			table.insert(SAVE_KEYS, "WeaponOffsetZ" .. i)
			table.insert(SAVE_KEYS, "WeaponBurst" .. i)
			table.insert(SAVE_KEYS, "WeaponHatBulletCount" .. i)
		end
		for i = 1, 8 do
			table.insert(SAVE_KEYS, "CarHat" .. i)
			table.insert(SAVE_KEYS, "CarOffX" .. i)
			table.insert(SAVE_KEYS, "CarOffY" .. i)
			table.insert(SAVE_KEYS, "CarOffZ" .. i)
			table.insert(SAVE_KEYS, "CarRotX" .. i)
			table.insert(SAVE_KEYS, "CarRotY" .. i)
			table.insert(SAVE_KEYS, "CarRotZ" .. i)
		end

		-- save EVERYTHING that is a plain setting (every hat slot, bullet hat, position, key, slider...)
		do
			local have = {}
			for _, k in ipairs(SAVE_KEYS) do have[k] = true end
			local skip = { Name = true, Description = true, InternalName = true, ModuleType = true }
			for k, v in pairs(m) do
				local t = type(v)
				if type(k) == "string" and not have[k] and not skip[k] and (t == "string" or t == "number" or t == "boolean") then
					have[k] = true
					table.insert(SAVE_KEYS, k)
				end
			end
		end

		-- rebuild every enabled attack so loaded hats are actually picked up
		X.rebuildEnabled = function()
			pcall(X.refreshAllHats)
			if m.GasterEnabled then pcall(X.rebuildGaster) end
			if m.BoneEnabled then pcall(X.rebuildBone) end
			if m.OmegaEnabled then pcall(X.rebuildOmega) end
			if m.WeaponEnabled then pcall(X.rebuildWeapon) end
			if m.ShieldEnabled then pcall(X.rebuildShield) end
			if m.ClawsEnabled then pcall(rebuildClaws) end
			if m.CarEnabled then pcall(X.rebuildCar) end
			if m.PlanetEnabled then pcall(X.rebuildPlanet) end
			if m.MotoEnabled then pcall(X.rebuildMoto) end
			if m.ToolEnabled then pcall(X.rebuildTool) end
			if m.PlaneEnabled then pcall(X.rebuildPlane) end
			if m.HeliEnabled then pcall(X.rebuildHeli) end
			if m.TitanEnabled then pcall(X.rebuildTitan) end
		end

		-- backup: hat choices are also written to a local file (when the executor has writefile/readfile)
		local HAT_FILE = "HatStand_Hats" .. SUF .. ".json"
		X.hatKeys = function()
			local out = {}
			for _, k in ipairs(SAVE_KEYS) do
				if type(m[k]) == "string" and string.find(k, "Hat", 1, true) then table.insert(out, k) end
			end
			return out
		end
		X.loadHatFile = function()
			if type(readfile) ~= "function" or type(isfile) ~= "function" then return end
			local ok, data = pcall(function()
				if isfile(HAT_FILE) then return game:GetService("HttpService"):JSONDecode(readfile(HAT_FILE)) end
			end)
			if ok and type(data) == "table" then
				for _, k in ipairs(X.hatKeys()) do
					if type(data[k]) == "string" and data[k] ~= "" and (m[k] == nil or m[k] == "") then m[k] = data[k] end
				end
				warn("[HatStand] hat choices restored from " .. HAT_FILE)
			end
		end
		X.startHatAutosave = function()
			if type(writefile) ~= "function" then return end
			local tok = {}
			_G["__HatStandSaveTok" .. SUF] = tok
			task.spawn(function()
				local last = nil
				while _G["__HatStandSaveTok" .. SUF] == tok do
					local ok, json = pcall(function()
						local out = {}
						for _, k in ipairs(X.hatKeys()) do out[k] = m[k] end
						return game:GetService("HttpService"):JSONEncode(out)
					end)
					if ok and json ~= last then
						last = json
						pcall(writefile, HAT_FILE, json)
					end
					task.wait(6)
				end
			end)
		end

		m.LoadConfig = function(save)
			if typeof(save) ~= "table" then return end
			for _, k in ipairs(SAVE_KEYS) do
				if save[k] ~= nil then m[k] = save[k] end
			end
			if cfg.mode ~= 4 then m.ActiveMode = cfg.mode or 1 m.StandInOrbitMode = (cfg.standInOrbit ~= false) end
			X.refreshAllLimbOffsets()
			X.refreshState()
			task.delay(1, function() if m.Enabled then X.rebuildEnabled() end end)
		end

		m.SaveConfig = function()
			local out = {}
			for _, k in ipairs(SAVE_KEYS) do out[k] = m[k] end
			return out
		end
	end
	X._hsSetupSave()
	end

	m.Init = function()
		X.Dead = false
		local ok, err = pcall(function()
			if X.loadHatFile then X.loadHatFile() end
			if X.loadDanceRecs then pcall(X.loadDanceRecs) end
			if X.startHatAutosave then X.startHatAutosave() end
			X.refreshAllHats()
			LastHatFingerprint = X.hatFingerprint()
			X.ensurePlaceFolder()
			X.refreshState()
			task.delay(1.5, function() if m.Enabled and X.rebuildEnabled then X.rebuildEnabled() end end)
			if m.Enabled and X.modeAllowsStand() and m.AutoBuild then task.defer(X.buildStand) end
			if m.Enabled and X.modeAllowsOrbit() and m.OrbitEnabled then task.defer(X.rebuildOrbit) end
		end)
		if not ok then warn("[HatStand] Init error: " .. tostring(err)) end
	end

	m.Update = function(dt)
		if m.Enabled and not X.Dead and not FollowBound then X.stepAll(dt or 1 / 60) end
	end

	m.Destroy = function()
		if m.StopOnExit ~= false or not m.UseWithOtherMovesets then
			X.Dead = true
			pcall(function() _G["__HatStandSaveTok" .. SUF] = nil end)
			pcall(function() X.DanceRec = nil end)
			pcall(function() X.stopOwnDance("Both") end)
			pcall(function() m.HeliRide = false m.HeliEngine = false X.HeliFireHeld = false end)
			X.stopLoop()
			X.destroyStand()
			X.clearOrbit()
			X.clearAllPlaced()
			X.clearGaster()
			X.clearBone()
			X.clearOmega()
			X.clearWeapon()
			X.clearShield()
			clearClaws()
			X.clearCar()
			X.clearBall()
			X.clearPlanet()
			X.clearMoto()
			X.clearTool()
			X.clearPlane()
			X.clearHeli()
			pcall(function() X.clearTitan() end)
			X.clearClone()
			X.clearStructGhosts()
			pcall(function() if X.HeliFolder then X.HeliFolder:Destroy() X.HeliFolder = nil end end)
			pcall(X.releaseHeld, nil)
			pcall(X.clearLabels)
			pcall(X.clearLimbPreview)
		end
	end

	task.defer(function()
		pcall(function()
			X.refreshAllHats()
			LastHatFingerprint = X.hatFingerprint()
			X.ensurePlaceFolder()
			X.refreshState()
		end)
	end)

	return m
end

local cfg = { id = "ALL", mode = 4, suffix = "", name = "Hat Stand: All", internal = "HAT_STAND",
	desc = "Everything in one module: Stand + Clone + Place + Orbit (mode dropdown), plus every extra." }

table.insert(modules, function()
	return makeHatModule(cfg)
end)

return modules
