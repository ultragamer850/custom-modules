-- JX1DX1.lua
-- Created with Moveset Creator V6
-- Place in: UhhhhhhReanim/Modules/JX1DX1.lua

cloneref = cloneref or function(o) return o end

local Debris     = cloneref(game:GetService("Debris"))
local RunService = cloneref(game:GetService("RunService"))
local Players    = cloneref(game:GetService("Players"))

local Player = Players.LocalPlayer

local modules = {}
local function AddModule(m)
    table.insert(modules, m)
end

-- san_lua: convert any string to a valid Lua identifier (no spaces)
-- used only for table keys that are Lua identifiers (mode actions)
local function san_lua(s)
    return (s or ""):gsub("[^%w_]", "_")
end

AddModule(function()
    local m = {}
    m.ModuleType   = "MOVESET"
    m.Name         = "JX1DX1 problem"
    m.Description  = "I WILL- im sorry ill get off your screen 😔"
    m.InternalName = "JX1DX1"

    m.Assets = {
        "JX1DX1 KeyframeSequence_1.anim",
        "JX1DX1 stunloop.anim",
        "JX1DX1 WALK BY F.anim",
        "JX1DX1 new run.anim",
        "JX1DX1 bad.anim",
        "JX1DX1 dignityoutro kill.anim",
        "JX1DX1 hallucination.anim",
        "JX1DX1 poisoned heart.anim",
        "JX1DX1 glitch 2 Idle.anim",
        "JX1DX1 REMINISCENT.mp3",
        "you.are.all.nothing.but.sheep.to.me-made-with-Voicemod.mp3",
        "jx1dx1-laugh.mp3",
        "jx1dx1-rot.mp3",
        "is.this.real.enough.for.(_you_).(___).-made-with-Voicemod.mp3",
        "JX1DX1-win.mp3",
        "jx1-setback.mp3",
        "jx1-interestimng.mp3",
        "jx1-clock.mp3",
        "its-all-your-fault-jx1dx1.mp3",
    }

    m.FlingEnabled = {
        ["M1"] = false,
        ["Kill"] = false,
        ["I SEE YOU"] = false,
        ["Poison"] = false,
        ["GLITCH"] = false,
    }

    m.Config = function(parent)
        Util_CreateText(parent, "JX1DX1 problem", 18, Enum.TextXAlignment.Center)
        Util_CreateSeparator(parent)
    end

    m.SaveConfig = function()
        local t = {}
        return t
    end

    m.LoadConfig = function(save)
    end

    -- STATE
    local baseAnims    = {}
    local actionAnims  = {}
    local animJump     = nil
    local actionStart  = {}
    local currentBase   = "idle"
    local currentAction = nil
    local wasInAir      = false
    local flingActive   = false
    local touchConns    = {}
    local allJoints     = {}
    local figureRef     = nil
    local SPEED_WALK    = 10
    local SPEED_SPRINT  = 30
    local isSprinting   = false
    local bgSound       = nil
    -- Per-animation sounds
    local snd_Kill = nil
    local snd_I_SEE_YOU = nil
    local snd_Poison = nil

    -- Intro (plays once, immediately, on run)
    local introAnim     = nil
    local introSound    = nil
    local introActive   = false
    local introStart    = 0

    -- Freeze state (Kill / Poison / I SEE YOU / GLITCH)
    local originalWalkSpeed = nil
    local originalJumpPower = nil
    local freezeActions = {
        ["Kill"] = true,
        ["Poison"] = true,
        ["I SEE YOU"] = true,
        ["GLITCH"] = true,
    }

    -- Random taunt pool (plays ambiently on its own timer, see below —
    -- not tied to any button)
    local tauntFiles = {
        "JX1DX1-win.mp3",
        "jx1-setback.mp3",
        "jx1-interestimng.mp3",
        "jx1-clock.mp3",
        "its-all-your-fault-jx1dx1.mp3",
    }
    local tauntSounds = {}

    -- Ambient taunt scheduler: fires entirely on its own timer, with no
    -- button press required. Every time the interval elapses we roll a
    -- chance to play a random taunt, then pick a new random interval.
    local TAUNT_INTERVAL = 60 -- seconds; fires every 1 minute
    local tauntTimer     = 0

    -- GLITCH auto-spam/teleport state
    local glitchLooping  = false
    local GLITCH_SPAM_COUNT     = 20
    local GLITCH_SPAM_DISTANCE  = 10
    local GLITCH_SPAM_WAIT      = 0.05
    local GLITCH_BEHIND_DISTANCE = 5 -- how far behind the aimed player we land

    -- HELPERS
    local function makeSound(filename, parent, volume, looped)
        local s = Instance.new("Sound")
        s.SoundId = AssetGetContentId(filename)
        s.Volume  = volume or 0.8
        s.Looped  = looped or false
        s.Parent  = parent
        return s
    end

    local function loadAnim(fig, file, looped)
        local a = AnimLib.Animator.new()
        a.rig    = fig
        a.track  = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
        a.looped = looped or false
        a.speed  = 1
        a.weight = 0
        return a
    end

    local function setSpeed(speed)
        if not figureRef then return end
        local hum = figureRef:FindFirstChildOfClass("Humanoid")
        if hum then hum.WalkSpeed = speed end
    end

    local function clearBase()
        for _, a in pairs(baseAnims) do a.weight = 0 end
    end

    local function setBase(state)
        if currentBase == state then return end
        currentBase = state
        clearBase()
        -- rage overrides locomotion anims
        if baseAnims[state] then baseAnims[state].weight = 1 end
    end

    local function stopAllAnimSounds()
        if snd_Kill then snd_Kill:Stop() end
        if snd_I_SEE_YOU then snd_I_SEE_YOU:Stop() end
        if snd_Poison then snd_Poison:Stop() end
    end

    local function freezePlayer()
        if not figureRef then return end
        local hum = figureRef:FindFirstChildOfClass("Humanoid")
        if not hum then return end
        if originalWalkSpeed == nil then
            originalWalkSpeed = hum.WalkSpeed
            originalJumpPower = hum.JumpPower
        end
        hum.WalkSpeed  = 0
        hum.JumpPower  = 0
    end

    local function unfreezePlayer()
        if not figureRef then return end
        local hum = figureRef:FindFirstChildOfClass("Humanoid")
        if hum then
            hum.WalkSpeed = originalWalkSpeed or SPEED_WALK
            hum.JumpPower = originalJumpPower or 50
        end
        originalWalkSpeed = nil
        originalJumpPower = nil
    end

    -- Plays exactly one random taunt from the pool (stopping any taunt
    -- that's currently playing first, so only one is ever heard at once).
    -- Called only by the ambient scheduler in m.Update, never by a button.
    local function playRandomTaunt()
        if #tauntSounds == 0 then return end
        for _, s in ipairs(tauntSounds) do s:Stop() end
        local snd = tauntSounds[math.random(1, #tauntSounds)]
        if snd then snd:Play() end
    end

    -- Advances the ambient taunt timer; call every frame with dt.
    -- Entirely independent of button presses / actions. Fires a random
    -- taunt from the pool exactly once every TAUNT_INTERVAL seconds.
    local function updateAmbientTaunt(dt)
        tauntTimer = tauntTimer + dt
        if tauntTimer >= TAUNT_INTERVAL then
            tauntTimer = tauntTimer - TAUNT_INTERVAL
            playRandomTaunt()
        end
    end

    -- Highlights every player after a 2 second delay, then removes the
    -- highlights again 15 seconds later
    local function doISeeYouHighlight()
        task.delay(2, function()
            local applied = {}
            for _, plr in ipairs(Players:GetPlayers()) do
                local char = plr.Character
                if char and not char:FindFirstChildOfClass("Highlight") then
                    local hl = Instance.new("Highlight")
                    hl.FillColor    = Color3.fromRGB(255, 0, 0)
                    hl.OutlineColor = Color3.fromRGB(255, 255, 255)
                    hl.Parent       = char
                    table.insert(applied, hl)
                end
            end
            task.delay(15, function()
                for _, hl in ipairs(applied) do
                    if hl and hl.Parent then hl:Destroy() end
                end
            end)
        end)
    end

    -- Picks a random other player roughly in the direction the figure is
    -- facing/aiming, falling back to any other player if none are ahead
    local function pickAimedPlayerHRP(hrp)
        local lookVector = hrp.CFrame.LookVector
        local aimed, any = {}, {}
        for _, plr in ipairs(Players:GetPlayers()) do
            if plr ~= Player and plr.Character then
                local otherHrp = plr.Character:FindFirstChild("HumanoidRootPart")
                if otherHrp then
                    table.insert(any, otherHrp)
                    local dir = otherHrp.Position - hrp.Position
                    if dir.Magnitude > 0.01 then
                        if lookVector:Dot(dir.Unit) > 0.3 then
                            table.insert(aimed, otherHrp)
                        end
                    end
                end
            end
        end
        local pool = (#aimed > 0) and aimed or any
        if #pool == 0 then return nil end
        return pool[math.random(1, #pool)]
    end

    -- GLITCH: rapidly hop 10 studs in a random direction every 0.05s,
    -- 20 times in a row, then finish with a single teleport onto whoever
    -- we're aiming at, and switch the anim into a permanent loop
    local function doGlitchSpam(figure, glitchAnim)
        local hrp = figure:FindFirstChild("HumanoidRootPart")
        if not hrp then
            unfreezePlayer()
            return
        end
        task.spawn(function()
            for i = 1, GLITCH_SPAM_COUNT do
                if currentAction ~= "GLITCH" then break end
                local angle  = math.random() * math.pi * 2
                local offset = Vector3.new(math.cos(angle), 0, math.sin(angle)) * GLITCH_SPAM_DISTANCE
                hrp.CFrame = hrp.CFrame + offset
                task.wait(GLITCH_SPAM_WAIT)
            end
            if currentAction == "GLITCH" then
                -- final teleport: land right behind the player we're aiming at,
                -- facing their back
                local targetHrp = pickAimedPlayerHRP(hrp)
                if targetHrp then
                    local targetCFrame = targetHrp.CFrame
                    local behindPos = targetCFrame.Position - (targetCFrame.LookVector * GLITCH_BEHIND_DISTANCE)
                    hrp.CFrame = CFrame.new(behindPos, targetCFrame.Position)
                end
                -- teleporting is done: stop the loop and end the action
                glitchAnim.looped = false
                glitchAnim.weight = 0
                glitchLooping     = false
                currentAction     = nil
                flingActive       = false
                currentBase       = "none"
                unfreezePlayer()
            end
        end)
    end

    local function stopAction()
        for _, anim in pairs(actionAnims) do anim.weight = 0 end
        stopAllAnimSounds()
        currentAction = nil
        flingActive   = false
    end

    local function playAction(name)
        if introActive then return end
        if currentAction then return end
        local a = actionAnims[name]
        if not a then return end
        stopAction()
        a.weight       = 1
        actionStart[a] = os.clock()
        currentAction  = name
        flingActive    = m.FlingEnabled[name] == true

        -- freeze on Kill / Poison / I SEE YOU / GLITCH
        if freezeActions[name] then freezePlayer() end

        -- per-action audio
        if name == "Kill" and snd_Kill then snd_Kill:Play() end
        if name == "I SEE YOU" and snd_I_SEE_YOU then snd_I_SEE_YOU:Play() end
        if name == "Poison" and snd_Poison then snd_Poison:Play() end

        -- I SEE YOU: highlight all players after a 20 second delay
        if name == "I SEE YOU" then doISeeYouHighlight() end

        -- GLITCH: loop the anim for the whole spam phase (so it can't get
        -- cut off mid-spam), auto-spam teleports, then land behind the
        -- aimed player once done
        if name == "GLITCH" then
            glitchLooping = false
            a.looped = true
            doGlitchSpam(figureRef, a)
        end
    end

    local function toggleSprint()
        if introActive or currentAction then return end
        isSprinting = not isSprinting
        if isSprinting then
            setSpeed( SPEED_SPRINT)
            ContextActions:SetTitle("GM_Sprint", "Walk")
        else
            setSpeed( SPEED_WALK)
            ContextActions:SetTitle("GM_Sprint", "Sprint")
        end
    end

    local function setupFlingTouched(figure)
        local function hookPart(part)
            local conn = part.Touched:Connect(function(hit)
                if not flingActive then return end
                if not hit or not hit.Parent then return end
                local target = hit.Parent
                if target:IsA("Accessory") then target = target.Parent end
                if target == figure then return end
                if not target:FindFirstChildOfClass("Humanoid") then return end
                ReanimateFling(target)
            end)
            table.insert(touchConns, conn)
        end
        for _, part in ipairs(figure:GetDescendants()) do
            if part:IsA("BasePart") then hookPart(part) end
        end
        table.insert(touchConns, figure.DescendantAdded:Connect(function(part)
            if part:IsA("BasePart") then hookPart(part) end
        end))
    end

    -- INIT
    m.Init = function(figure)
        figureRef = figure
        local hrp = figure:FindFirstChild("HumanoidRootPart") or figure
        local hum = figure:FindFirstChildOfClass("Humanoid")

        allJoints = {}
        for _, v in ipairs(figure:GetDescendants()) do
            if v:IsA("Motor6D") then table.insert(allJoints, v) end
        end

        baseAnims = {
        idle = loadAnim(figure, "JX1DX1 stunloop.anim", true),
        walk = loadAnim(figure, "JX1DX1 WALK BY F.anim", true),
        sprint = loadAnim(figure, "JX1DX1 new run.anim", true),
        }
        animJump = baseAnims.jump

        actionAnims = {
        ["M1"] = loadAnim(figure, "JX1DX1 bad.anim", false),
        ["Kill"] = loadAnim(figure, "JX1DX1 dignityoutro kill.anim", false),
        ["I SEE YOU"] = loadAnim(figure, "JX1DX1 hallucination.anim", false),
        ["Poison"] = loadAnim(figure, "JX1DX1 poisoned heart.anim", false),
        ["GLITCH"] = loadAnim(figure, "JX1DX1 glitch 2 Idle.anim", false),
        }

        -- created here but NOT played yet; it starts once the intro
        -- animation finishes (see m.Update)
        bgSound = makeSound("JX1DX1 REMINISCENT.mp3", hrp, 0.5, true)

        -- init per-anim sounds
    snd_Kill = makeSound("you.are.all.nothing.but.sheep.to.me-made-with-Voicemod.mp3", hrp, 1.1, false)
    snd_I_SEE_YOU = makeSound("jx1dx1-laugh.mp3", hrp, 1.1, false)
    snd_Poison = makeSound("jx1dx1-rot.mp3", hrp, 1.1, false)

        -- init random taunt pool
        tauntSounds = {}
        for i, file in ipairs(tauntFiles) do
            tauntSounds[i] = makeSound(file, hrp, 1.1, false)
        end

        setSpeed(SPEED_WALK)
        setupFlingTouched(figure)

        -- INTRO: plays instantly on run, freezes the player, then returns
        -- to normal once it finishes. Only happens this one time.
        introAnim  = loadAnim(figure, "JX1DX1 KeyframeSequence_1.anim", false)
        introSound = makeSound("is.this.real.enough.for.(_you_).(___).-made-with-Voicemod.mp3", hrp, 1.1, false)
        introActive = true
        introStart  = os.clock()
        freezePlayer()
        introAnim.weight = 1
        introSound:Play()

        ContextActions:BindAction("GM_Sprint", function(_, inputState, _)
            if inputState == Enum.UserInputState.Begin then toggleSprint() end
        end, true, Enum.KeyCode.LeftAlt)
        ContextActions:SetTitle("GM_Sprint", "Sprint")
        ContextActions:SetPosition("GM_Sprint", UDim2.new(1, -260, 1, -130))


        ContextActions:BindAction("GM_M1", function(_, inputState, _)
            if inputState == Enum.UserInputState.Begin then playAction("M1") end
        end, true, Enum.KeyCode.Z)
        ContextActions:SetTitle("GM_M1", "M1")
        ContextActions:SetPosition("GM_M1", UDim2.new(1, -210, 1, -130))

        ContextActions:BindAction("GM_Kill", function(_, inputState, _)
            if inputState == Enum.UserInputState.Begin then playAction("Kill") end
        end, true, Enum.KeyCode.Z)
        ContextActions:SetTitle("GM_Kill", "Kill")
        ContextActions:SetPosition("GM_Kill", UDim2.new(1, -210, 1, -170))

        ContextActions:BindAction("GM_I_SEE_YOU", function(_, inputState, _)
            if inputState == Enum.UserInputState.Begin then playAction("I SEE YOU") end
        end, true, Enum.KeyCode.Z)
        ContextActions:SetTitle("GM_I_SEE_YOU", "I SEE YOU")
        ContextActions:SetPosition("GM_I_SEE_YOU", UDim2.new(1, -310, 1, -130))

        ContextActions:BindAction("GM_Poison", function(_, inputState, _)
            if inputState == Enum.UserInputState.Begin then playAction("Poison") end
        end, true, Enum.KeyCode.Z)
        ContextActions:SetTitle("GM_Poison", "Poison")
        ContextActions:SetPosition("GM_Poison", UDim2.new(1, -210, 1, -90))

        ContextActions:BindAction("GM_GLITCH", function(_, inputState, _)
            if inputState == Enum.UserInputState.Begin then
                playAction("GLITCH")
            end
        end, true, Enum.KeyCode.Z)
        ContextActions:SetTitle("GM_GLITCH", "GLITCH")
        ContextActions:SetPosition("GM_GLITCH", UDim2.new(1, -310, 1, -170))
    end

    -- UPDATE
    m.Update = function(dt, figure)
        -- INTRO: step it and unfreeze once it's finished (one-time only)
        if introActive then
            local elapsed  = os.clock() - introStart
            local duration = introAnim.track and introAnim.track.Time or 0
            if introAnim.weight > 0 then introAnim:Step(elapsed) end
            if duration > 0 and elapsed >= duration then
                introAnim.weight = 0
                introActive      = false
                unfreezePlayer()
                setBase("idle")
                -- intro voice line is NOT stopped here, it keeps playing
                -- to completion on its own even though the anim is done
                -- (same behavior as Kill/Poison)
                if bgSound then bgSound:Play() end
            end
            return
        end

        -- ambient taunt pool: runs on its own timer, no button needed
        updateAmbientTaunt(dt)

        local hum = figure:FindFirstChildOfClass("Humanoid")
        if not hum then return end
        local inAir = hum.FloorMaterial == Enum.Material.Air

        -- auto-stop finished actions (skip GLITCH once it's looping)
        if currentAction then
            local a = actionAnims[currentAction]
            if a and actionStart[a] and not a.looped then
                local elapsed  = os.clock() - actionStart[a]
                local duration = a.track and a.track.Time or 0
                if duration > 0 and elapsed >= duration / (a.speed or 1) then
                    a.weight      = 0
                    -- NOTE: intentionally NOT stopping the per-action voice
                    -- line here. The mp3 keeps playing until it's naturally
                    -- done even though the animation/freeze has ended. It
                    -- only gets cut off if a new action starts (see
                    -- stopAction(), which calls stopAllAnimSounds()).
                    if freezeActions[currentAction] then unfreezePlayer() end
                    currentAction = nil
                    flingActive   = false
                    currentBase   = "none"
                end
            end
        end

        -- locomotion state machine
        if not currentAction then
            if inAir then
                if not wasInAir then
                    clearBase()
                    currentBase           = "jump"
                    animJump.weight       = 1
                    actionStart[animJump] = os.clock()
                end
            else
                if wasInAir then animJump.weight = 0 end
                local moving = hum.MoveDirection.Magnitude > 0.1
                if moving then
                    if isSprinting then setBase("sprint") else setBase("walk") end
                else
                    setBase("idle")
                end
            end
        end

        wasInAir = inAir
        local now = os.clock()
        for _, a in pairs(baseAnims) do if a.weight > 0 then a:Step(now) end end
        for a, start in pairs(actionStart) do if a.weight > 0 then a:Step(now - start) end end
    end

    -- DESTROY
    m.Destroy = function(figure)
        ContextActions:UnbindAction("GM_Sprint")
        ContextActions:UnbindAction("GM_M1")
        ContextActions:UnbindAction("GM_Kill")
        ContextActions:UnbindAction("GM_I_SEE_YOU")
        ContextActions:UnbindAction("GM_Poison")
        ContextActions:UnbindAction("GM_GLITCH")

        for _, conn in ipairs(touchConns) do conn:Disconnect() end
        table.clear(touchConns)

        if bgSound then bgSound:Stop() bgSound:Destroy() bgSound = nil end
        stopAllAnimSounds()
    if snd_Kill then snd_Kill:Stop() snd_Kill:Destroy() snd_Kill = nil end
    if snd_I_SEE_YOU then snd_I_SEE_YOU:Stop() snd_I_SEE_YOU:Destroy() snd_I_SEE_YOU = nil end
    if snd_Poison then snd_Poison:Stop() snd_Poison:Destroy() snd_Poison = nil end

        if introSound then introSound:Stop() introSound:Destroy() introSound = nil end
        if introAnim then introAnim.weight = 0 introAnim = nil end
        introActive = false

        for _, s in ipairs(tauntSounds) do
            s:Stop()
            s:Destroy()
        end
        tauntSounds = {}
        tauntTimer = 0

        for _, plr in ipairs(Players:GetPlayers()) do
            local char = plr.Character
            local hl = char and char:FindFirstChildOfClass("Highlight")
            if hl then hl:Destroy() end
        end

        originalWalkSpeed = nil
        originalJumpPower = nil
        glitchLooping     = false

        for _, joint in ipairs(allJoints) do
            if joint and joint.Parent then joint.Transform = CFrame.identity end
        end
        allJoints = {}

        for _, a in pairs(baseAnims)   do a.weight = 0 end
        for _, a in pairs(actionAnims) do a.weight = 0 end

        setSpeed(16)
        actionStart   = {}
        currentAction = nil
        currentBase   = "idle"
        wasInAir      = false
        flingActive   = false
        figureRef     = nil
        animJump      = nil
        baseAnims     = {}
        actionAnims   = {}
        isSprinting = false
    end

    return m
end)

return modules