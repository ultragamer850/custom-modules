-- TestMoveset_NoGUI.lua

local modules = {}

table.insert(modules, function()

local m = {}

m.ModuleType   = "MOVESET"
m.Name         = "KJ Moveset"
m.Description  = "stickman"
m.InternalName = "KJMOVESET"

m.Assets = {
    "Idle.anim",
    "KJ Spawn.anim",
    "Run.anim",
    "KJ Spawn.mp3",
    "Ravage Start.anim",
    "Ravage Hit.anim",
    "KJ Ravage Start.mp3",
    "KJ Ravage Hit.mp3",
    "KJ Ravage Wind.mp3",
    "KJ Ravage FinalHit.mp3",
    "KJ Ravage Victim.mp3",
    "KJ Swift Startup.anim",
    "KJ Swift Hit.anim",
    "KJ Sweep Startup.mp3",
    "KJ Swift Hit1.mp3",
    "KJ Swift Hit2.mp3",
    "KJ Collateral Ruin.anim",
    "KJ Collateral Ruin Windup.mp3",
    "KJ Collateral Ruin Hit.mp3",
    "KJ Spiraling Storm Startup.anim",
    "KJ Spiraling Storm Counter.mp3",
    "KJ Ult.anim",
    "KJ Ult SFX.mp3",
    "KJ Ult Song Startup.mp3",
    "KJ Ult Music.mp3",
    "KJ VFX.rbxm",
}

m.Config = function(parent)
    Util_CreateText(parent, "No GUI loaded.", 18, Enum.TextXAlignment.Center)
end

m.SaveConfig = function()
    return {}
end

m.LoadConfig = function()
end

-- SERVICES
local Players = game:GetService("Players")
local Debris = game:GetService("Debris")

-- VFX
local KJVFX = nil

-- ANIMS
local idleAnim = nil
local runAnim = nil
local spawnAnim = nil
local ravageStartAnim = nil
local ravageHitAnim = nil
local swiftsweepStartupAnim = nil
local swiftsweepHitAnim = nil
local collateralruinAnim = nil
local spiralingstormStartupAnim = nil

-- SOUND
local spawnSound = nil

-- ULTIMATE STATE
local inUlt = false
local ulting = false
local ultAnim= nil

-- STATE
local currentState = "idle"
local currentFigure = nil

local spawning = true
local spawnStart = 0
local spawnLength = 7

local usingMove = false

-- LOAD ANIM
local function loadAnim(fig, file, looped)
    local a = AnimLib.Animator.new()
    a.rig = fig
    a.track = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
    a.looped = looped or false
    a.speed = 1
    a.weight = 1
    return a
end

-- PLAY LOCAL SOUND
local function playSound(file, volume)
    local s = Instance.new("Sound")
    s.Name = "MovesetSound"
    s.SoundId = AssetGetContentId(file)
    s.Volume = volume or 1
    s.Looped = false
    s.Parent = workspace.CurrentCamera or workspace
    s:Play()
    return s
end

-- VFX HELPER FUNCTION
local function emitAll(obj)
    for _, v in pairs(obj:GetDescendants()) do
        if v:IsA("ParticleEmitter") then
            v:Emit(v:GetAttribute("EmitCount") or 25)
        elseif v:IsA("Trail") then
            v.Enabled = true
        elseif v:IsA("Beam") then
            v.Enabled = true
        end
    end
end

local function attachToRoot(fx, root)
    fx.Parent = currentFigure

    if fx:IsA("BasePart") then
        fx.CFrame = root.CFrame
    elseif fx:IsA("Model") and fx.PrimaryPart then
        fx:SetPrimaryPartCFrame(root.CFrame)
    end

    local weld = fx:FindFirstChildWhichIsA("WeldConstraint", true)
    if weld then
        weld.Part0 = root
    end
end

-- GETROOT FUNCTION
local function getRoot(char)
    if not char then return nil end
    return char:FindFirstChild("HumanoidRootPart")
end

-- KJ VFX FUNCTIONS
local function playUltText()
    if not KJVFX and currentFigure then return end

    local root = getRoot(currentFigure)
    if not root then return end

    local fx = KJVFX.Awakening.KJ:Clone()

    attachToRoot(fx, root)
    emitAll(fx)

    Debris:AddItem(fx, 2)
end

local function playUltAura()
    if not KJVFX and currentFigure then return end

    local root = getRoot(currentFigure)
    if not root then return end

    local fx = KJVFX.Awakening.IdleAura:Clone()

    attachToRoot(fx, root)
    emitAll(fx)

    Debris:AddItem(fx, 9)
end

local function playUltEnd()
    if not KJVFX and currentFigure then return end

    local root = getRoot(currentFigure)
    if not root then return end

    local fx = KJVFX.Awakening.IdleEnd:Clone()

    attachToRoot(fx, root)
    emitAll(fx)

    Debris:AddItem(fx, 3)
end

-- MOVEMENT STATE
local function setState(state)
    if currentState == state then return end
    currentState = state

    idleAnim.weight = 0
    runAnim.weight = 0

    if state == "idle" then
        idleAnim.weight = 1
    elseif state == "run" then
        runAnim.weight = 1
    end
end

-- TARGET HELPERS
local function getRoot(char)
    return char and char:FindFirstChild("HumanoidRootPart")
end

local function getNearestTarget(range)
    if not currentFigure then return nil end

    local myRoot = getRoot(currentFigure)
    if not myRoot then return nil end

    local closest = nil
    local closestDist = range

    for _, plr in pairs(Players:GetPlayers()) do
        if plr ~= Players.LocalPlayer then
            local char = plr.Character
            local root = getRoot(char)
            local hum = char and char:FindFirstChildOfClass("Humanoid")

            if root and hum then
                local dist = (root.Position - myRoot.Position).Magnitude

                if dist < closestDist then
                    closestDist = dist
                    closest = char
                end
            end
        end
    end

    return closest
end

-- AWAKENING MOVE
local function activateUlt()
    if inUlt then return end
    if ulting then return end
    if usingMove then return end
    if spawning then return end
    if not currentFigure then return end

    ulting = true
    usingMove = true

    idleAnim.weight = 0
    runAnim.weight = 0

    task.spawn(function()
        
        ultAnim.weight = 1

        playSound("KJ Ult SFX.mp3", 1)
        playSound("KJ Ult Song Startup.mp3", 0.5)

        local startClock = os.clock()

        local textPlayed = false
        local auraPlayed = false
        local endPlayed = false

        while true do
            local t = os.clock() - startClock

            ultAnim:Step(t)

            if not textPlayed then
                textPlayed = true
                playUltText()
            end

            if t >= 0.5 and not auraPlayed then
                auraPlayed = true
                playUltAura()
            end

            if t >= 8 and not endPlayed then
            endPlayed = true
            playUltEnd()
            end

            if t >= 10.017 then
                break
            end

            task.wait()
        end

        ultAnim.weight = 0

        inUlt = true
        ulting = false
        usingMove = false

        SetOverrideMovesetMusic(AssetGetContentId("KJ Ult Music.mp3"), "KJ Ult Theme", 0.5, NumberRange.new(0, 9999))

        setState("idle")
    end)
end

-- SPIRALING STORM MOVE (the anim and sounds of the victim reacting to the counter is missing for now, so this is just a placeholder)
local function playSpiraling()
    if usingMove then return end
    if spawning then return end
    if not currentFigure then return end

    usingMove = true

    idleAnim.weight = 0
    runAnim.weight = 0

    task.spawn(function()

        spiralingstormStartupAnim.weight = 1

        local startClock = os.clock()
        local playedSound = false

        while true do
            local t = os.clock() - startClock

            if not playedSound then
                playedSound = true
                playSound("KJ Spiraling Storm Counter.mp3", 1)
            end

            spiralingstormStartupAnim:Step(t)

            if t >= 1.333 then
                break
            end

            task.wait()
        end

        spiralingstormStartupAnim.weight = 0

        usingMove = false
        setState("idle")
    end)
end

-- COLLATERAL RUIN MOVE (rest of the sounds are missing for now, ill try to find them)
local function playCollateral()
    if usingMove then return end
    if spawning then return end
    if not currentFigure then return end

    usingMove = true

    idleAnim.weight = 0
    runAnim.weight = 0

    task.spawn(function()

        collateralruinAnim.weight = 1

        local startClock = os.clock()

        local playedWindup = false
        local checkedHit = false

        while true do
            local t = os.clock() - startClock

            if not playedWindup then
                playedWindup = true
                playSound("KJ Collateral Ruin Windup.mp3", 1)
            end

            if t >= 1.35 and not checkedHit then
                checkedHit = true

                local target = getNearestTarget(12)

                if target then
                    playSound("KJ Collateral Ruin Hit.mp3", 1)
                end
            end

            collateralruinAnim:Step(t)

            if t >= 2.133 then
                break
            end

            task.wait()
        end

        collateralruinAnim.weight = 0

        usingMove = false
        setState("idle")
    end)
end

-- SWIFT SWEEP MOVE
local function playSwift()
    if usingMove then return end
    if spawning then return end
    if not currentFigure then return end

    usingMove = true
    
    idleAnim.weight = 0
    runAnim.weight = 0

    task.spawn(function()

        swiftsweepStartupAnim.weight = 1

        local startClock = os.clock()
        local playedStart = false

        while true do
            local t = os.clock() - startClock

            if not playedStart then
                playedStart = true
                playSound("KJ Sweep Startup.mp3", 1)
            end

            swiftsweepStartupAnim:Step(t)

            if t >= 0.317 then
                break
            end

            task.wait()
        end

        swiftsweepStartupAnim.weight = 0

        local target = getNearestTarget(8)

        if target then
            swiftsweepHitAnim.weight = 1

            local hitClock = os.clock()

            local playedHit1 = false
            local playedHit2 = false

            while true do
                local t = os.clock() - hitClock

                if t >= 0.08 and not playedHit1 then
                    playedHit1 = true
                    playSound("KJ Swift Hit1.mp3", 1)
                end

                if t >= 0.55 and not playedHit2 then
                    playedHit2 = true
                    playSound("KJ Swift Hit2.mp3", 1)
                end

                swiftsweepHitAnim:Step(t)

                if t >= 0.933 then
                    break
                end

                task.wait()
            end

            swiftsweepHitAnim.weight = 0
        end

        usingMove = false
        setState("idle")
    end)
end

-- RAVAGE MOVE
local function playRavage()
    if usingMove then return end
    if spawning then return end
    if not currentFigure then return end

    usingMove = true

    idleAnim.weight = 0
    runAnim.weight = 0

    task.spawn(function()

        ravageStartAnim.weight = 1

        local startClock = os.clock()
        local playedStart = false

        while true do
            local t = os.clock() - startClock

            if not playedStart then
                playedStart = true
                playSound("KJ Ravage Start.mp3", 1)
            end

            ravageStartAnim:Step(t)

            if t >= 1.2 then
                break
            end

            task.wait()
        end

        ravageStartAnim.weight = 0

        local target = getNearestTarget(8)
        
        if target then
            ravageHitAnim.weight = 1

            local hitClock = os.clock()

            local playedHit = false
            local playedVictim = false
            local playedWind = false
            local playedFinalHit = false

            while true do
                local t = os.clock() - hitClock

                if t >= 0 and not playedVictim then
                    playedVictim = true
                    playSound("KJ Ravage Victim.mp3", 1)
                end

                if t >= 0 and not playedHit then
                    playedHit = true
                    playSound("KJ Ravage Hit.mp3", 1)
                end

                if t >= 0 and not playedWind then
                    playedWind = true
                    playSound("KJ Ravage Wind.mp3", 1)
                end

                if t >= 5 and not playedFinalHit then
                    playedFinalHit = true
                    playSound("KJ Ravage FinalHit.mp3", 1)
                end

                ravageHitAnim:Step(t)

                if t >= 6.133 then
                    break
                end

                task.wait()
            end

            ravageHitAnim.weight = 0
        end

        usingMove = false
        setState("idle")
    end)
end

-- INIT
m.Init = function(figure)

    currentFigure = figure
    KJVFX = game:GetObjects(AssetGetContentId("KJ VFX.rbxm"))[1]

    idleAnim = loadAnim(figure, "Idle.anim", true)
    runAnim = loadAnim(figure, "Run.anim", true)

    spawnAnim = loadAnim(figure, "KJ Spawn.anim", false)

    ravageStartAnim = loadAnim(figure, "Ravage Start.anim", false)
    ravageHitAnim = loadAnim(figure, "Ravage Hit.anim", false)
    swiftsweepStartupAnim = loadAnim(figure, "KJ Swift Startup.anim", false)
    swiftsweepHitAnim = loadAnim(figure, "KJ Swift Hit.anim", false)
    collateralruinAnim = loadAnim(figure, "KJ Collateral Ruin.anim", false)
    spiralingstormStartupAnim = loadAnim(figure, "KJ Spiraling Storm Startup.anim", false)
    ultAnim = loadAnim(figure, "KJ Ult.anim", false)

    idleAnim.weight = 0
    runAnim.weight = 0
    spawnAnim.weight = 1
    ravageHitAnim.weight = 0
    ravageStartAnim.weight = 0
    swiftsweepHitAnim.weight = 0
    swiftsweepStartupAnim.weight = 0
    collateralruinAnim.weight = 0
    spiralingstormStartupAnim.weight = 0
    ultAnim.weight = 0

    spawnSound = playSound("KJ Spawn.mp3", 1)

    spawnStart = os.clock()
    spawning = true

    -- BUTTON POSITION HELPER (same as pursuer)
    local function btnPos(col, row)
        local btnW  = 0.10
        local gapW  = 0.01
        local btnH  = 0.08
        local gapH  = 0.01
        local baseY = 0.12
        local x = 1 - (col + 1) * (btnW + gapW)
        local y = 1 - baseY - row * (btnH + gapH)
        return UDim2.new(x, 0, y, 0)
    end

    -- BUTTONS (ContextActions, mesmo padrão do pursuer)
    ContextActions:BindAction("GM_Ravage", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playRavage() end
    end, true, Enum.KeyCode.One)
    ContextActions:SetTitle("GM_Ravage", "Ravage")
    ContextActions:SetPosition("GM_Ravage", btnPos(17.5, 21))

    ContextActions:BindAction("GM_Swift", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playSwift() end
    end, true, Enum.KeyCode.Two)
    ContextActions:SetTitle("GM_Swift", "Swift")
    ContextActions:SetPosition("GM_Swift", btnPos(14, 21))

    ContextActions:BindAction("GM_Collateral", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playCollateral() end
    end, true, Enum.KeyCode.Three)
    ContextActions:SetTitle("GM_Collateral", "Collateral")
    ContextActions:SetPosition("GM_Collateral", btnPos(10.5, 21))

    ContextActions:BindAction("GM_Spiraling", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playSpiraling() end
    end, true, Enum.KeyCode.Four)
    ContextActions:SetTitle("GM_Spiraling", "Spiraling")
    ContextActions:SetPosition("GM_Spiraling", btnPos(7, 21))

    ContextActions:BindAction("GM_Ult", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then activateUlt() end
    end, true, Enum.KeyCode.G)
    ContextActions:SetTitle("GM_Ult", "Ult")
    ContextActions:SetPosition("GM_Ult", btnPos(3.5, 21))
end

-- UPDATE
m.Update = function(dt, figure)

   local now = os.clock()

   if spawning then
    spawnAnim:Step(now - spawnStart)

    if now - spawnStart >= spawnLength then
        spawning = false
        spawnAnim.weight = 0

        if spawnSound then
            spawnSound:Stop()
            spawnSound:Destroy()
            spawnSound = nil
        end

        setState("idle")
    end
    return
   end

   -- skip movement while attacking
   if usingMove then
    return
   end

   local hum = figure:FindFirstChildOfClass("Humanoid")
   if hum then
    if inUlt then
        hum.WalkSpeed = 20
    else
        hum.WalkSpeed = 16
    end
    local moving = hum.MoveDirection.Magnitude > 0.1

    if moving then
        setState("run")
    else
        setState("idle")
    end
   end

   if idleAnim.weight > 0 then
    idleAnim:Step(now)
   end

   if runAnim.weight > 0 then
    runAnim:Step(now)
   end
end

-- DESTROY
m.Destroy = function()
    -- Unbind all buttons
    ContextActions:UnbindAction("GM_Ravage")
    ContextActions:UnbindAction("GM_Swift")
    ContextActions:UnbindAction("GM_Collateral")
    ContextActions:UnbindAction("GM_Spiraling")
    ContextActions:UnbindAction("GM_Ult")

   if spawnSound then
    spawnSound:Stop()
    spawnSound:Destroy()
    spawnSound = nil
   end

   idleAnim = nil
   runAnim = nil
   spawnAnim = nil
   ravageHitAnim = nil
   ravageStartAnim = nil
   swiftsweepHitAnim = nil
   swiftsweepStartupAnim = nil
   collateralruinAnim = nil
   spiralingstormStartupAnim = nil
   SetOverrideMovesetMusic()
   inUlt = false
   ulting = false
   ultAnim = nil
   KJVFX = nil

   currentFigure = nil
   currentState = "idle"
   spawning = false
   usingMove = false
end

return m
end)

return modules