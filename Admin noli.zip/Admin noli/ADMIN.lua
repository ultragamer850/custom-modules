local modules = {}

table.insert(modules, function()

	local m = {}
	m.ModuleType = "MOVESET"
	m.Name = "Admin Noli"
	m.Description = "Made by Mr Eyes"
	m.InternalName = "admin_noli"

	m.Assets = {
		"ADMINIDLE.anim",
		"ADMINWALK.anim",
		"ADMINRUN.anim",
		"ADMINM1.anim",
		"ADMINNOVA.anim",
		"ADMINKILL.anim",
		"ADMININTRO.anim",
		"ADMINOUTRO.anim",
		"Stunned_Start.anim",
		"Stunned_Loop.anim",
		"Stunned_End.anim",
		"ADMINvictm.anim",
		"OBSERSTART.anim",
		"OBSERLOOP.anim",
		"OBSERTELEPORT.anim",
		"VOIDSTART.anim",
		"VOIDLOOP.anim",
		"VOIDFAIL.anim",
		"VOIDHIT.anim",

		"ADMINM1.mp3",
		"ADMINNOVA.mp3",
		"ADMINSHOUT.mp3",
		"ADMINCHASE.mp3",
		"ADMINIDLEVOICE.mp3",
		"ADMINKILL.mp3",
		"ADMININTRO.mp3",
		"ADMINOUTRO.mp3",
		"ADMINstun.mp3",
		"ADMINstuneffect.mp3",
		"TheAdminKill.mp3",
		"OBSERSTART.mp3",
		"OBSERTELEPORT.mp3",
		"OBSERVOICE.mp3",
		"VOIDSTART.mp3",
		"VOIDLOOP.mp3",
		"VOIDVOICELOOP.mp3",
		"VOIDFAIL.mp3",
		"VOIDHIT.mp3",
	}

	m.Config = function(parent) end

	local Players = game:GetService("Players")
	local Debris = game:GetService("Debris")
	local UIS = game:GetService("UserInputService")
	local Player = Players.LocalPlayer

	local animator = nil
	local tracks = {}
	local currentTrack = nil
	local animationTime = 0
	local lastState = "none"
	local usingSkill = false
	local lastIdleVoice = 0
	local isSprinting = false

	local flingActive = false
	local touchConns = {}
	local figureRef = nil
	local activeVictims = {}

	local observeConn = nil
	local inObserveLoop = false
	local observeTarget = nil

	local voidActive = false
	local voidHit = false

	local function playSound(id, parent)
		local s = Instance.new("Sound")
		s.SoundId = AssetGetContentId(id)
		s.Volume = 1.5
		s.Parent = parent
		s:Play()
		Debris:AddItem(s, 8)
	end

	local function loadAnim(fig, file, looped)
		local a = AnimLib.Animator.new()
		a.rig = fig
		a.track = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
		a.looped = looped or false
		a.speed = 1
		a.weight = 0
		return a
	end

	local function setupFlingTouched(figure)
		local function hookPart(part)
			local conn = part.Touched:Connect(function(hit)
				if not hit or not hit.Parent then return end
				local target = hit.Parent
				if target:IsA("Accessory") then target = target.Parent end
				if target == figure then return end
				if not target:FindFirstChildOfClass("Humanoid") then return end

				if voidActive then
					voidHit = true
				end

				if flingActive then
					ReanimateFling(target)
				end
			end)
			table.insert(touchConns, conn)
		end

		for _, part in ipairs(figure:GetDescendants()) do
			if part:IsA("BasePart") then
				hookPart(part)
			end
		end

		table.insert(touchConns, figure.DescendantAdded:Connect(function(part)
			if part:IsA("BasePart") then
				hookPart(part)
			end
		end))
	end

	local function getRandomPlayer()
		local valid = {}
		for _, p in ipairs(Players:GetPlayers()) do
			if p ~= Player and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
				table.insert(valid, p)
			end
		end
		if #valid > 0 then
			return valid[math.random(1, #valid)]
		end
		return nil
	end

	local function spawnVictimNPC(offsetCFrame, animName, duration)
		if not figureRef then return end

		task.spawn(function()
			local targetPlayer = getRandomPlayer()
			local dummy

			if targetPlayer and targetPlayer.Character then
				pcall(function()
					targetPlayer.Character.Archivable = true
					dummy = targetPlayer.Character:Clone()
					targetPlayer.Character.Archivable = false
				end)
			end

			if not dummy then
				pcall(function()
					figureRef.Archivable = true
					dummy = figureRef:Clone()
					figureRef.Archivable = false
				end)
			end

			if not dummy then
				dummy = Players:CreateHumanoidModelFromDescription(
					Instance.new("HumanoidDescription"),
					Enum.HumanoidRigType.R6
				)
			end

			if not dummy then return end

			dummy.Name = "AdminVictim"
			dummy.Parent = workspace

			for _, v in ipairs(dummy:GetDescendants()) do
				if v:IsA("Script") or v:IsA("LocalScript") or v:IsA("Sound")
				or v:IsA("ScreenGui") or v:IsA("BillboardGui") or v:IsA("SurfaceGui") then
					v:Destroy()
				elseif v:IsA("BasePart") then
					v.Massless = true
					v.CanCollide = false
					v.CanTouch = false
					v.CanQuery = false
					if v.Name == "HumanoidRootPart" then
						v.Anchored = true
					else
						v.Anchored = false
					end
				end
			end

			local root = dummy:FindFirstChild("HumanoidRootPart") or dummy:FindFirstChild("Torso")
			local myRoot = figureRef:FindFirstChild("HumanoidRootPart") or figureRef:FindFirstChild("Torso")

			if root and myRoot then
				if dummy:IsA("Model") then
					dummy.PrimaryPart = root
					dummy:PivotTo(myRoot.CFrame * offsetCFrame)
				else
					root.CFrame = myRoot.CFrame * offsetCFrame
				end
			end

			local ok, dAnim = pcall(function()
				return loadAnim(dummy, animName, false)
			end)

			if ok and dAnim then
				dAnim.weight = 1
				table.insert(activeVictims, {
					anim = dAnim,
					dummy = dummy,
					start = os.clock()
				})
			end

			Debris:AddItem(dummy, duration + 0.3)
		end)
	end

	local function clearObserve()
		inObserveLoop = false
		observeTarget = nil
		if observeConn then
			observeConn:Disconnect()
			observeConn = nil
		end
	end

	m.Init = function(figure)
		figureRef = figure
		local hum = figure:FindFirstChildOfClass("Humanoid")
		local root = figure:FindFirstChild("HumanoidRootPart")
		if not hum or not root then return end

		animator = AnimLib.Animator.new()
		animator.rig = figure
		animator.looped = true

		tracks.idle          = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINIDLE.anim"))
		tracks.walk          = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINWALK.anim"))
		tracks.run           = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINRUN.anim"))
		tracks.m1            = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINM1.anim"))
		tracks.nova          = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINNOVA.anim"))
		tracks.kill          = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINKILL.anim"))
		tracks.intro         = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMININTRO.anim"))
		tracks.outro         = AnimLib.Track.fromfile(AssetGetPathFromFilename("ADMINOUTRO.anim"))
		tracks.stunnedStart  = AnimLib.Track.fromfile(AssetGetPathFromFilename("Stunned_Start.anim"))
		tracks.stunnedLoop   = AnimLib.Track.fromfile(AssetGetPathFromFilename("Stunned_Loop.anim"))
		tracks.stunnedEnd    = AnimLib.Track.fromfile(AssetGetPathFromFilename("Stunned_End.anim"))
		tracks.obserStart    = AnimLib.Track.fromfile(AssetGetPathFromFilename("OBSERSTART.anim"))
		tracks.obserLoop     = AnimLib.Track.fromfile(AssetGetPathFromFilename("OBSERLOOP.anim"))
		tracks.obserTeleport = AnimLib.Track.fromfile(AssetGetPathFromFilename("OBSERTELEPORT.anim"))
		tracks.voidStart     = AnimLib.Track.fromfile(AssetGetPathFromFilename("VOIDSTART.anim"))
		tracks.voidLoop      = AnimLib.Track.fromfile(AssetGetPathFromFilename("VOIDLOOP.anim"))
		tracks.voidFail      = AnimLib.Track.fromfile(AssetGetPathFromFilename("VOIDFAIL.anim"))
		tracks.voidHit       = AnimLib.Track.fromfile(AssetGetPathFromFilename("VOIDHIT.anim"))

		currentTrack = tracks.idle
		animator.track = currentTrack

		SetOverrideMovesetMusic(AssetGetContentId("ADMINCHASE.mp3"), "ADMIN", 1)
		lastIdleVoice = os.clock()
		setupFlingTouched(figure)

		ContextActions:BindAction("admin_m1", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true
			flingActive = true

			playSound("ADMINM1.mp3", root)
			currentTrack = tracks.m1
			animator.track = currentTrack
			animationTime = 0

			task.wait(1)

			flingActive = false
			usingSkill = false
			lastState = "none"
		end, true, Enum.UserInputType.MouseButton1)

		ContextActions:BindAction("admin_nova", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true
			flingActive = true

			playSound("ADMINNOVA.mp3", root)
			playSound("ADMINSHOUT.mp3", root)
			currentTrack = tracks.nova
			animator.track = currentTrack
			animationTime = 0

			task.wait(1.32)

			flingActive = false
			usingSkill = false
			lastState = "none"
		end, true, Enum.KeyCode.E)

		ContextActions:BindAction("admin_kill", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true

			hum.WalkSpeed = 0
			hum.JumpPower = 0

			playSound("ADMINKILL.mp3", root)
			playSound("TheAdminKill.mp3", root)

			currentTrack = tracks.kill
			animator.track = currentTrack
			animationTime = 0

			spawnVictimNPC(
				CFrame.new(0, 0, -2) * CFrame.Angles(0, math.pi, 0),
				"ADMINvictm.anim",
				4.2
			)

			task.wait(4.2)

			usingSkill = false
			hum.WalkSpeed = 8
			hum.JumpPower = 50
			lastState = "none"
		end, true, Enum.KeyCode.Z)

		ContextActions:BindAction("admin_intro", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true

			hum.WalkSpeed = 0
			hum.JumpPower = 0

			playSound("ADMININTRO.mp3", root)
			currentTrack = tracks.intro
			animator.track = currentTrack
			animationTime = 0

			task.wait(5.55)

			usingSkill = false
			hum.WalkSpeed = 8
			hum.JumpPower = 50
			lastState = "none"
		end, true, Enum.KeyCode.One)

		ContextActions:BindAction("admin_outro", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true

			hum.WalkSpeed = 0
			hum.JumpPower = 0

			playSound("ADMINOUTRO.mp3", root)
			currentTrack = tracks.outro
			animator.track = currentTrack
			animationTime = 0

			task.wait(3.55)

			usingSkill = false
			hum.WalkSpeed = 8
			hum.JumpPower = 50
			lastState = "none"
		end, true, Enum.KeyCode.Two)

		ContextActions:BindAction("admin_stun", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true

			hum.WalkSpeed = 0
			hum.JumpPower = 0

			playSound("ADMINstun.mp3", root)
			playSound("ADMINstuneffect.mp3", root)

			currentTrack = tracks.stunnedStart
			animator.track = currentTrack
			animationTime = 0
			task.wait(1.3)

			currentTrack = tracks.stunnedLoop
			animator.track = currentTrack
			animationTime = 0
			task.wait(1.63)

			currentTrack = tracks.stunnedEnd
			animator.track = currentTrack
			animationTime = 0
			task.wait(1)

			usingSkill = false
			hum.WalkSpeed = 8
			hum.JumpPower = 50
			lastState = "none"
		end, true, Enum.KeyCode.Three)

		ContextActions:BindAction("admin_observe", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true
			clearObserve()

			hum.WalkSpeed = 0
			hum.JumpPower = 0

			playSound("OBSERSTART.mp3", root)
			currentTrack = tracks.obserStart
			animator.track = currentTrack
			animationTime = 0
			task.wait(1)

			currentTrack = tracks.obserLoop
			animator.track = currentTrack
			animationTime = 0
			inObserveLoop = true

			observeConn = UIS.InputBegan:Connect(function(input, gp)
				if gp then return end
				if not inObserveLoop then return end

				if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
					local camera = workspace.CurrentCamera
					if not camera then return end

					local screenPos = input.Position
					local unitRay = camera:ViewportPointToRay(screenPos.X, screenPos.Y)

					local raycastParams = RaycastParams.new()
					raycastParams.FilterDescendantsInstances = {figure}
					raycastParams.FilterType = Enum.RaycastFilterType.Exclude

					local result = workspace:Raycast(unitRay.Origin, unitRay.Direction * 1000, raycastParams)

					if result then
						observeTarget = result.Position
					else
						observeTarget = unitRay.Origin + unitRay.Direction * 100
					end

					inObserveLoop = false
					if observeConn then
						observeConn:Disconnect()
						observeConn = nil
					end
				end
			end)

			while inObserveLoop and usingSkill do
				task.wait(0.03)
			end

			if observeTarget and usingSkill then
				playSound("OBSERTELEPORT.mp3", root)
				playSound("OBSERVOICE.mp3", root)

				currentTrack = tracks.obserTeleport
				animator.track = currentTrack
				animationTime = 0

				task.wait(1.55)

				local hrp = figure:FindFirstChild("HumanoidRootPart")
				if hrp and observeTarget then
					local look = hrp.CFrame.LookVector
					hrp.CFrame = CFrame.new(observeTarget + Vector3.new(0, 3, 0), observeTarget + Vector3.new(0, 3, 0) + look)
				end

				task.wait(3.3 - 1.55)
			end

			clearObserve()
			usingSkill = false
			hum.WalkSpeed = 8
			hum.JumpPower = 50
			lastState = "none"
		end, true, Enum.KeyCode.R)

		ContextActions:BindAction("admin_void", function(_, state)
			if state ~= Enum.UserInputState.Begin or usingSkill then return end
			usingSkill = true
			voidHit = false
			voidActive = false

			hum.WalkSpeed = 0
			hum.JumpPower = 0

			playSound("VOIDSTART.mp3", root)
			currentTrack = tracks.voidStart
			animator.track = currentTrack
			animationTime = 0
			task.wait(1)

			local loopSnd = Instance.new("Sound")
			loopSnd.SoundId = AssetGetContentId("VOIDLOOP.mp3")
			loopSnd.Volume = 1.5
			loopSnd.Looped = true
			loopSnd.Parent = root
			loopSnd:Play()

			local voiceSnd = Instance.new("Sound")
			voiceSnd.SoundId = AssetGetContentId("VOIDVOICELOOP.mp3")
			voiceSnd.Volume = 1.5
			voiceSnd.Looped = true
			voiceSnd.Parent = root
			voiceSnd:Play()

			currentTrack = tracks.voidLoop
			animator.track = currentTrack
			animationTime = 0
			voidActive = true

			local hrp = figure:FindFirstChild("HumanoidRootPart")
			local startTime = os.clock()

			hum.WalkSpeed = 35

			while (os.clock() - startTime < 3) and not voidHit and usingSkill do
				if hrp and hum then
					hum:Move(hrp.CFrame.LookVector, true)
				end
				task.wait()
			end

			hum.WalkSpeed = 0
			voidActive = false

			if loopSnd then
				loopSnd:Stop()
				loopSnd:Destroy()
			end
			if voiceSnd then
				voiceSnd:Stop()
				voiceSnd:Destroy()
			end

			if voidHit and usingSkill then
				playSound("VOIDHIT.mp3", root)
				currentTrack = tracks.voidHit
				animator.track = currentTrack
				animationTime = 0
				flingActive = true
				task.wait(3.42)
				flingActive = false
			else
				playSound("VOIDFAIL.mp3", root)
				currentTrack = tracks.voidFail
				animator.track = currentTrack
				animationTime = 0
				task.wait(1)
			end

			usingSkill = false
			hum.WalkSpeed = 8
			hum.JumpPower = 50
			lastState = "none"
		end, true, Enum.KeyCode.Q)

		ContextActions:BindAction("admin_sprint", function(_, state)
			if state == Enum.UserInputState.Begin then
				isSprinting = not isSprinting
				if isSprinting then
					ContextActions:SetTitle("admin_sprint", "Walk")
				else
					ContextActions:SetTitle("admin_sprint", "Sprint")
				end
			end
		end, true, Enum.KeyCode.LeftShift)

		ContextActions:SetTitle("admin_m1", "M1")
		ContextActions:SetTitle("admin_nova", "Nova")
		ContextActions:SetTitle("admin_kill", "Kill")
		ContextActions:SetTitle("admin_void", "Void")
		ContextActions:SetTitle("admin_intro", "Intro")
		ContextActions:SetTitle("admin_outro", "Outro")
		ContextActions:SetTitle("admin_stun", "Stun")
		ContextActions:SetTitle("admin_observe", "Observe")
		ContextActions:SetTitle("admin_sprint", "Sprint")

		ContextActions:SetPosition("admin_m1", UDim2.new(1, -70, 1, -70))
		ContextActions:SetPosition("admin_nova", UDim2.new(1, -140, 1, -70))
		ContextActions:SetPosition("admin_kill", UDim2.new(1, -210, 1, -70))
		ContextActions:SetPosition("admin_void", UDim2.new(1, -280, 1, -70))
		ContextActions:SetPosition("admin_sprint", UDim2.new(1, -350, 1, -70))

		ContextActions:SetPosition("admin_intro", UDim2.new(1, -70, 1, -150))
		ContextActions:SetPosition("admin_outro", UDim2.new(1, -140, 1, -150))
		ContextActions:SetPosition("admin_stun", UDim2.new(1, -210, 1, -150))
		ContextActions:SetPosition("admin_observe", UDim2.new(1, -280, 1, -150))
	end

	m.Update = function(dt, figure)
		if not animator then return end

		local hum = figure:FindFirstChildOfClass("Humanoid")
		local root = figure:FindFirstChild("HumanoidRootPart")
		if not hum then return end

		animationTime += dt
		animator:Step(animationTime)

		local now = os.clock()
		for i = #activeVictims, 1, -1 do
			local data = activeVictims[i]
			if data.dummy and data.dummy.Parent then
				data.anim:Step(now - data.start)
			else
				table.remove(activeVictims, i)
			end
		end

		if usingSkill then return end

		if os.clock() - lastIdleVoice >= 10 then
			lastIdleVoice = os.clock()
			if math.random() <= 0.4 and root then
				playSound("ADMINIDLEVOICE.mp3", root)
			end
		end

		local state = "idle"
		if hum.MoveDirection.Magnitude > 0.1 then
			if isSprinting then
				state = "run"
			else
				state = "walk"
			end
		end

		if lastState ~= state then
			animationTime = 0
			lastState = state
		end

		local newTrack
		if state == "idle" then
			newTrack = tracks.idle
			hum.WalkSpeed = 8
		elseif state == "walk" then
			newTrack = tracks.walk
			hum.WalkSpeed = 8
		elseif state == "run" then
			newTrack = tracks.run
			hum.WalkSpeed = 27.5
		end

		if currentTrack ~= newTrack then
			currentTrack = newTrack
			animator.track = currentTrack
		end

		animator:Step(animationTime)
	end

	m.Destroy = function()
		clearObserve()
		voidActive = false
		voidHit = false
		isSprinting = false

		for _, conn in ipairs(touchConns) do
			conn:Disconnect()
		end
		table.clear(touchConns)

		for _, data in ipairs(activeVictims) do
			if data.dummy then
				data.dummy:Destroy()
			end
		end
		activeVictims = {}

		ContextActions:UnbindAction("admin_m1")
		ContextActions:UnbindAction("admin_nova")
		ContextActions:UnbindAction("admin_kill")
		ContextActions:UnbindAction("admin_intro")
		ContextActions:UnbindAction("admin_outro")
		ContextActions:UnbindAction("admin_stun")
		ContextActions:UnbindAction("admin_observe")
		ContextActions:UnbindAction("admin_void")
		ContextActions:UnbindAction("admin_sprint")

		animator = nil
		tracks = {}
		currentTrack = nil
		figureRef = nil
		flingActive = false
		usingSkill = false
	end

	return m
end)

return modules