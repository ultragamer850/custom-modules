local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local modules = {}

table.insert(modules, function()
    local m = {}

    m.ModuleType  = "MOVESET"
    m.Name        = "JasonMilestone"
    m.Description = "Jason Milestone with 10s Rage, Forward Lunge Swing, E=Gashing, Q=Behead"
    m.InternalName = "jason_milestone"

    m.Assets = {
        "JasonMilestone_Idle.anim",
        "JasonMilestone_Walk.anim",
        "JasonMilestone_Run.anim",
        "JasonMilestone_RagingIdle.anim",
        "JasonMilestone_RageWalk.anim",
        "Rage Start.anim",
        "JasonMilestone_RagingSwing.anim",
        "jason_milestone_behead.anim",
        "GashingWoundWindup.anim",
        "JasonMilestone_Swig.anim",

        -- MUSIC
        "jason.mp3"
    }

    m.Config = function(parent)
        Util_CreateText(
            parent,
            "Jason Milestone Config",
            14,
            Enum.TextXAlignment.Center
        )
    end

    m.SaveConfig = function()
        return {}
    end

    m.LoadConfig = function(save)
    end

    --------------------------------------------------
    -- ANIMATIONS
    --------------------------------------------------

    local animIdle       = nil
    local animWalk       = nil
    local animRun        = nil
    local animRagingIdle = nil
    local animRageWalk   = nil
    local animRageStart  = nil
    local animSwing      = nil
    local animBehead     = nil
    local animGashing    = nil
    local animSwig       = nil

    local activeAnim     = nil
    local animStartTime  = 0
    local animDuration   = 0

    local walkTime       = 0
    local idleTime       = 0

    local isRunning      = false
    local isRaging       = false
    local rageEndTime    = 0
    local flingActive    = false
    local touchConns     = {}
    local usingSkill     = false

    --------------------------------------------------
    -- FLING
    --------------------------------------------------

    local function setupFlingTouched(figure)

        local function hookPart(part)

            local conn = part.Touched:Connect(function(hit)

                if not hit or not hit.Parent then
                    return
                end

                local target = hit.Parent

                if target:IsA("Accessory") then
                    target = target.Parent
                end

                if target == figure then
                    return
                end

                local targetHum =
                    target:FindFirstChildOfClass("Humanoid")

                if not targetHum then
                    return
                end

                if flingActive
                and typeof(ReanimateFling) == "function" then

                    local root =
                        figure:FindFirstChild("HumanoidRootPart")

                    local targetRoot =
                        target:FindFirstChild("HumanoidRootPart")

                    if root and targetRoot then

                        local forwardPos =
                            root.Position +
                            root.CFrame.LookVector * 2

                        local distanceToHitbox =
                            (forwardPos - targetRoot.Position).Magnitude

                        if distanceToHitbox <= 5
                        or (root.Position - targetRoot.Position).Magnitude <= 6 then

                            ReanimateFling(target)
                        end
                    end
                end
            end)

            table.insert(touchConns, conn)
        end

        for _, part in ipairs(figure:GetDescendants()) do

            if part:IsA("BasePart") then
                hookPart(part)
            end
        end

        table.insert(
            touchConns,

            figure.DescendantAdded:Connect(function(part)

                if part:IsA("BasePart") then
                    hookPart(part)
                end
            end)
        )
    end

    --------------------------------------------------
    -- INIT
    --------------------------------------------------

    m.Init = function(figure)

        local hum =
            figure:FindFirstChildOfClass("Humanoid")

        local root =
            figure:FindFirstChild("HumanoidRootPart")

        if not hum or not root then
            return
        end

        --------------------------------------------------
        -- JASON MUSIC
        --------------------------------------------------

        SetOverrideMovesetMusic(
            AssetGetContentId("jason.mp3"),
            "JASON",
            1
        )

        --------------------------------------------------
        -- LOAD ANIMATION
        --------------------------------------------------

        local function loadAnim(filename, looped)

            local success, anim = pcall(function()

                local a =
                    AnimLib.Animator.new()

                a.rig =
                    figure

                a.track =
                    AnimLib.Track.fromfile(
                        AssetGetPathFromFilename(filename)
                    )

                a.looped =
                    looped

                a.speed =
                    1

                return a
            end)

            return success and anim or nil
        end

        animIdle =
            loadAnim(
                "JasonMilestone_Idle.anim",
                true
            )

        animWalk =
            loadAnim(
                "JasonMilestone_Walk.anim",
                true
            )

        animRun =
            loadAnim(
                "JasonMilestone_Run.anim",
                true
            )
            or animWalk

        animRagingIdle =
            loadAnim(
                "JasonMilestone_RagingIdle.anim",
                true
            )
            or animIdle

        animRageWalk =
            loadAnim(
                "JasonMilestone_RageWalk.anim",
                true
            )
            or animWalk

        animRageStart =
            loadAnim(
                "Rage Start.anim",
                false
            )

        animSwing =
            loadAnim(
                "JasonMilestone_RagingSwing.anim",
                false
            )

        animBehead =
            loadAnim(
                "jason_milestone_behead.anim",
                false
            )

        animGashing =
            loadAnim(
                "GashingWoundWindup.anim",
                false
            )

        animSwig =
            loadAnim(
                "JasonMilestone_Swig.anim",
                false
            )

        setupFlingTouched(figure)

        --------------------------------------------------
        -- M1
        --------------------------------------------------

        ContextActions:BindAction(
            "jason_m1",
            function(_, state)

                if state ~= Enum.UserInputState.Begin
                or usingSkill
                or activeAnim then

                    return
                end

                usingSkill = true
                flingActive = true

                if isRaging then

                    isRaging = false

                    activeAnim =
                        animSwing

                    animDuration =
                        0.9

                    local rootPart =
                        figure:FindFirstChild(
                            "HumanoidRootPart"
                        )

                    if rootPart then

                        local bv =
                            Instance.new("BodyVelocity")

                        bv.MaxForce =
                            Vector3.new(
                                40000,
                                0,
                                40000
                            )

                        bv.Velocity =
                            rootPart.CFrame.LookVector * 30

                        bv.Parent =
                            rootPart

                        task.delay(
                            0.25,
                            function()

                                if bv then
                                    bv:Destroy()
                                end
                            end
                        )
                    end

                else

                    activeAnim =
                        animSwig

                    animDuration =
                        0.8
                end

                animStartTime =
                    os.clock()

                task.wait(animDuration)

                flingActive = false
                usingSkill = false
            end,
            true,
            Enum.UserInputType.MouseButton1
        )

        ContextActions:SetTitle(
            "jason_m1",
            "Attack"
        )

        ContextActions:SetPosition(
            "jason_m1",
            UDim2.new(
                1,
                -70,
                1,
                -70
            )
        )

        --------------------------------------------------
        -- KEYBOARD
        --------------------------------------------------

        UserInputService.InputBegan:Connect(
            function(input, gameProcessed)

                if gameProcessed then
                    return
                end

                ------------------------------------------------
                -- Q = Behead
                ------------------------------------------------

                if input.KeyCode == Enum.KeyCode.Q
                and not activeAnim
                and not usingSkill then

                    usingSkill = true
                    flingActive = true

                    activeAnim =
                        animBehead

                    animStartTime =
                        os.clock()

                    animDuration =
                        1.0

                    task.wait(1.0)

                    flingActive = false
                    usingSkill = false

                ------------------------------------------------
                -- E = Gashing
                ------------------------------------------------

                elseif input.KeyCode == Enum.KeyCode.E
                and not activeAnim
                and not usingSkill then

                    usingSkill = true
                    flingActive = true

                    activeAnim =
                        animGashing

                    animStartTime =
                        os.clock()

                    animDuration =
                        0.9

                    task.wait(0.9)

                    flingActive = false
                    usingSkill = false

                ------------------------------------------------
                -- R = Rage
                ------------------------------------------------

                elseif input.KeyCode == Enum.KeyCode.R
                and not activeAnim
                and not usingSkill then

                    usingSkill = true
                    isRaging = true

                    rageEndTime =
                        os.clock() + 10

                    activeAnim =
                        animRageStart

                    animStartTime =
                        os.clock()

                    animDuration =
                        1.2

                    task.wait(1.2)

                    usingSkill = false

                ------------------------------------------------
                -- CTRL = RUN
                ------------------------------------------------

                elseif input.KeyCode == Enum.KeyCode.LeftControl
                or input.KeyCode == Enum.KeyCode.RightControl then

                    if not usingSkill then

                        isRunning =
                            not isRunning

                        if hum then

                            hum.WalkSpeed =
                                isRunning
                                and 28
                                or 16
                        end
                    end
                end
            end
        )
    end

    --------------------------------------------------
    -- UPDATE
    --------------------------------------------------

    m.Update = function(dt, figure)

        local hum =
            figure:FindFirstChildOfClass(
                "Humanoid"
            )

        local moving =
            hum
            and hum.MoveDirection.Magnitude > 0.1

        local now =
            os.clock()

        --------------------------------------------------
        -- RAGE TIMER
        --------------------------------------------------

        if isRaging
        and now >= rageEndTime then

            isRaging = false
        end

        --------------------------------------------------
        -- ACTIVE ANIMATION
        --------------------------------------------------

        if activeAnim then

            local elapsed =
                now - animStartTime

            if elapsed < animDuration then

                activeAnim:Step(
                    elapsed
                )

                return

            else

                activeAnim = nil
            end
        end

        --------------------------------------------------
        -- MOVEMENT ANIMATIONS
        --------------------------------------------------

        if moving then

            idleTime = 0

            walkTime =
                walkTime + dt

            if isRaging
            and animRageWalk then

                animRageWalk:Step(
                    walkTime
                )

            elseif isRunning
            and animRun then

                animRun:Step(
                    walkTime
                )

            elseif animWalk then

                animWalk:Step(
                    walkTime
                )
            end

        else

            walkTime = 0

            idleTime =
                idleTime + dt

            if isRaging
            and animRagingIdle then

                animRagingIdle:Step(
                    idleTime
                )

            elseif animIdle then

                animIdle:Step(
                    idleTime
                )
            end
        end
    end

    --------------------------------------------------
    -- DESTROY
    --------------------------------------------------

    m.Destroy = function(figure)

        local hum =
            figure:FindFirstChildOfClass(
                "Humanoid"
            )

        if hum then
            hum.WalkSpeed = 16
        end

        for _, conn in ipairs(touchConns) do
            conn:Disconnect()
        end

        table.clear(touchConns)

        ContextActions:UnbindAction(
            "jason_m1"
        )

        animIdle = nil
        animWalk = nil
        animRun = nil
        animRagingIdle = nil
        animRageWalk = nil
        animRageStart = nil
        animSwing = nil
        animBehead = nil
        animGashing = nil
        animSwig = nil

        activeAnim = nil
        flingActive = false
        usingSkill = false
        isRaging = false
        isRunning = false

        --------------------------------------------------
        -- MUSIC RESET
        --------------------------------------------------

        pcall(function()
            SetOverrideMovesetMusic(nil, "JASON", 0)
        end)
    end

    return m
end)

return modules