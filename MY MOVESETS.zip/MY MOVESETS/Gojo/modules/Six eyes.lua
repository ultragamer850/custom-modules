-- six_eyes.lua

local modules = {}

table.insert(modules, function()

local m = {}

m.ModuleType  = "MOVESET"
m.Name        = "Six eyes"
m.Description = "nah id win"
m.InternalName = "six_eyes"

m.Assets = {
    -- BASE
    "gojo idle.anim",
    "gojo sprint.anim",
    "gojo jump.anim",

    -- SWAP ANIMATION
    "gojo awake.anim",

    -- MODE A actions
    "reversal red.anim",
    "lapse blue.anim",
    "rapid punches.anim",
    "twofold kick.anim",

    -- MODE B actions
    "hollow purple.anim",
    "infinite void.anim",
    "lapse blue max.anim",
    "reversal red max.anim",

    -- LMB combo
    "gojo lmb1.anim",
    "gojo lmb2.anim",
    "gojo lmb3.anim",
    "gojo lmb4.anim",

    -- SOUNDS
    "reversal red.mp3",
    "lapse blue.mp3",
    "rapid punches.mp3",
    "twofold kick.mp3",
    "hollow purple.mp3",
    "infinite void.mp3",
    "lapse blue max.mp3",
    "reversal red max.mp3",
    "gojo music.mp3",
}

m.Config = function(parent)
    Util_CreateText(parent, "Six Eyes", 18, Enum.TextXAlignment.Center)
end

m.SaveConfig = function() return {} end
m.LoadConfig = function() end

-- SERVICES
local Players = game:GetService("Players")
local ContextActionService = game:GetService("ContextActionService")

-- ANIMATORS
local baseAnimator   = nil
local actionAnimator = nil

-- ANIMS
local baseAnims   = {}
local actionAnims = {}
local modeAAnims  = {}
local modeBAnims  = {}
local lmbAnims    = {}
local animJump    = nil
local animSwap    = nil

-- SOUNDS
local actionSounds       = {}
local modeASounds        = {}
local modeBSounds        = {}
local bgSound            = nil
local currentActionSound = nil

-- STATE
local currentBase   = "idle"
local actionStart   = {}
local currentAction = nil
local modeB         = false

-- JUMP STATE
local wasInAir    = false
local swapPlaying = false
local swapStart   = 0

-- LMB STATE
local lmbStep        = 1
local lmbResetTimer  = 0
local LMB_RESET_TIME = 3.0

local figureRef = nil

-- ── sound helper ─────────────────────────────────────────────
local function makeSound(filename, parent, volume, looped)
    local s = Instance.new("Sound")
    s.SoundId = AssetGetContentId(filename)
    s.Volume  = volume or 0.8
    s.Looped  = looped or false
    s.Parent  = parent
    return s
end

-- LOAD ANIM
local function loadAnim(fig, file, looped)
    local a = AnimLib.Animator.new()
    a.rig    = fig
    a.track  = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
    a.looped = looped or false
    a.speed  = 1
    a.weight = 0
    return a
end

-- stop all base anims
local function clearBase()
    for _, a in pairs(baseAnims) do a.weight = 0 end
end

-- BASE SWITCH
local function setBase(state)
    if currentBase == state then return end
    currentBase = state
    clearBase()
    if baseAnims[state] then baseAnims[state].weight = 1 end
end

-- STOP ACTION SOUND
local function stopActionSound()
    if currentActionSound then
        currentActionSound:Stop()
        currentActionSound = nil
    end
end

-- STOP ACTION
local function stopAction()
    for _, anim in pairs(modeAAnims) do anim.weight = 0 end
    for _, anim in pairs(modeBAnims) do anim.weight = 0 end
    for _, anim in pairs(lmbAnims)   do anim.weight = 0 end
    stopActionSound()
    currentAction = nil
end

-- GET ANIM OBJECT FOR CURRENT ACTION
local function getActionAnim(name)
    if not name then return nil end
    local isLmb = name:sub(1, 3) == "lmb"
    if isLmb then
        local step = tonumber(name:sub(4))
        return lmbAnims[step], isLmb
    else
        return actionAnims[name], false
    end
end

-- PLAY ACTION
local function playAction(name)
    local a = actionAnims[name]
    if not a then return end

    stopAction()

    a.weight = 1
    actionStart[a] = os.clock()
    currentAction = name

    local snd = actionSounds[name]
    if snd then
        snd:Play()
        currentActionSound = snd
    end
end

-- PLAY LMB STEP
local function playLmb(step)
    local a = lmbAnims[step]
    if not a then return end

    stopAction()

    a.weight = 1
    actionStart[a] = os.clock()
    currentAction = "lmb" .. step
end

-- SWAP MODE
local function swapMode()
    stopAction()

    if animSwap then
        clearBase()
        currentBase           = "swap"
        animSwap.weight       = 1
        actionStart[animSwap] = os.clock()
        swapPlaying           = true
        swapStart             = os.clock()
    end

    modeB = not modeB

    if modeB then
        actionAnims  = modeBAnims
        actionSounds = modeBSounds
        ContextActionService:SetTitle("SixEyes_Red",     "hollow")
        ContextActionService:SetTitle("SixEyes_Blue",    "Infinite")
        ContextActionService:SetTitle("SixEyes_Punches", "lapse blue")
        ContextActionService:SetTitle("SixEyes_Kick",    "reversal")
        ContextActionService:SetTitle("SixEyes_Swap",    "unAwake")
    else
        actionAnims  = modeAAnims
        actionSounds = modeASounds
        ContextActionService:SetTitle("SixEyes_Red",     "Red")
        ContextActionService:SetTitle("SixEyes_Blue",    "Blue")
        ContextActionService:SetTitle("SixEyes_Punches", "Punch")
        ContextActionService:SetTitle("SixEyes_Kick",    "Kick")
        ContextActionService:SetTitle("SixEyes_Swap",    "AWAKE")
    end
end

-- INIT
m.Init = function(figure)
    figureRef = figure

    baseAnimator       = AnimLib.Animator.new()
    baseAnimator.rig   = figure
    actionAnimator     = AnimLib.Animator.new()
    actionAnimator.rig = figure

    local hrp = figure:FindFirstChild("HumanoidRootPart") or figure

    -- BASE ANIMS
    baseAnims = {
        idle = loadAnim(figure, "gojo idle.anim",   true),
        walk = loadAnim(figure, "gojo sprint.anim", true),
        jump = loadAnim(figure, "gojo jump.anim",   false),
    }

    animJump = baseAnims.jump
    animSwap = loadAnim(figure, "gojo awake.anim", false)

    -- MODE A ANIMS
    modeAAnims = {
        ["reversal red"]  = loadAnim(figure, "reversal red.anim",  false),
        ["lapse blue"]    = loadAnim(figure, "lapse blue.anim",    false),
        ["rapid punches"] = loadAnim(figure, "rapid punches.anim", false),
        ["twofold kick"]  = loadAnim(figure, "twofold kick.anim",  false),
    }

    -- MODE B ANIMS
    modeBAnims = {
        ["hollow purple"]      = loadAnim(figure, "hollow purple.anim",      false),
        ["infinite void"]      = loadAnim(figure, "infinite void.anim",      false),
        ["lapse blue max"]     = loadAnim(figure, "lapse blue max.anim",     false),
        ["reversal red max"]   = loadAnim(figure, "reversal red max.anim",   false),
    }

    -- LMB ANIMS
    lmbAnims = {
        [1] = loadAnim(figure, "gojo lmb1.anim", false),
        [2] = loadAnim(figure, "gojo lmb2.anim", false),
        [3] = loadAnim(figure, "gojo lmb3.anim", false),
        [4] = loadAnim(figure, "gojo lmb4.anim", false),
    }

    -- MODE A SOUNDS
    modeASounds = {
        ["reversal red"]  = makeSound("reversal red.mp3",  hrp, 0.8, false),
        ["lapse blue"]    = makeSound("lapse blue.mp3",    hrp, 0.8, false),
        ["rapid punches"] = makeSound("rapid punches.mp3", hrp, 0.8, false),
        ["twofold kick"]  = makeSound("twofold kick.mp3",  hrp, 0.8, false),
    }

    -- MODE B SOUNDS
    modeBSounds = {
        ["hollow purple"]    = makeSound("hollow purple.mp3",    hrp, 0.8, false),
        ["infinite void"]    = makeSound("infinite void.mp3",    hrp, 0.8, false),
        ["lapse blue max"]   = makeSound("lapse blue max.mp3",   hrp, 0.8, false),
        ["reversal red max"] = makeSound("reversal red max.mp3", hrp, 0.8, false),
    }

    -- BACKGROUND SOUND
    bgSound = makeSound("gojo music.mp3", hrp, 0.5, true)
    bgSound:Play()

    -- start in mode A
    actionAnims  = modeAAnims
    actionSounds = modeASounds

    setBase("idle")

    -- ── BUTTONS ──────────────────────────────────────────────

    -- LMB
    ContextActionService:BindAction("SixEyes_LMB", function(_, inputState, _)
        if inputState ~= Enum.UserInputState.Begin then return end
        playLmb(lmbStep)
        if lmbStep < 4 then
            lmbStep = lmbStep + 1
            lmbResetTimer = LMB_RESET_TIME
        else
            lmbStep = 1
            lmbResetTimer = 0
        end
    end, true, Enum.UserInputType.MouseButton1, Enum.KeyCode.T)
    ContextActionService:SetTitle("SixEyes_LMB", "LMB")
    ContextActionService:SetPosition("SixEyes_LMB", UDim2.new(1, -130, 1, -230))

    -- SWAP
    ContextActionService:BindAction("SixEyes_Swap", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then swapMode() end
    end, true, Enum.KeyCode.G)
    ContextActionService:SetTitle("SixEyes_Swap", "AWAKE")
    ContextActionService:SetPosition("SixEyes_Swap", UDim2.new(1, -280, 1, -130))

    -- RED
    ContextActionService:BindAction("SixEyes_Red", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then
            local name = modeB and "hollow purple" or "reversal red"
            playAction(name)
        end
    end, true, Enum.KeyCode.E)
    ContextActionService:SetTitle("SixEyes_Red", "Red")
    ContextActionService:SetPosition("SixEyes_Red", UDim2.new(1, -180, 1, -130))

    -- BLUE
    ContextActionService:BindAction("SixEyes_Blue", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then
            local name = modeB and "infinite void" or "lapse blue"
            playAction(name)
        end
    end, true, Enum.KeyCode.Q)
    ContextActionService:SetTitle("SixEyes_Blue", "Blue")
    ContextActionService:SetPosition("SixEyes_Blue", UDim2.new(1, -230, 1, -130))

    -- PUNCHES
    ContextActionService:BindAction("SixEyes_Punches", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then
            local name = modeB and "lapse blue max" or "rapid punches"
            playAction(name)
        end
    end, true, Enum.KeyCode.R)
    ContextActionService:SetTitle("SixEyes_Punches", "Punch")
    ContextActionService:SetPosition("SixEyes_Punches", UDim2.new(1, -130, 1, -130))

    -- KICK
    ContextActionService:BindAction("SixEyes_Kick", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then
            local name = modeB and "reversal red max" or "twofold kick"  -- fixed typo: "mac" -> "max"
            playAction(name)
        end
    end, true, Enum.KeyCode.F)
    ContextActionService:SetTitle("SixEyes_Kick", "Kick")
    ContextActionService:SetPosition("SixEyes_Kick", UDim2.new(1, -130, 1, -180))
end

-- UPDATE
m.Update = function(dt, figure)

    local hum = figure:FindFirstChildOfClass("Humanoid")
    if not hum then return end

    local inAir = hum.FloorMaterial == Enum.Material.Air

    -- ── SWAP ANIMATION auto-finish ────────────────────────────
    if swapPlaying and animSwap then
        local elapsed  = os.clock() - swapStart
        local duration = animSwap.track and animSwap.track.Time or 1.0
        if elapsed >= duration / (animSwap.speed or 1) then
            animSwap.weight = 0
            swapPlaying     = false
            currentBase     = "none"  -- force setBase to re-apply
        end
    end

    -- ── LMB COMBO RESET TIMER ────────────────────────────────
    if lmbResetTimer > 0 and currentAction == nil then
        lmbResetTimer = lmbResetTimer - dt
        if lmbResetTimer <= 0 then
            lmbResetTimer = 0
            lmbStep = 1
        end
    end

    -- ── AUTO-STOP current action and return to idle ───────────
    if currentAction then
        local a, isLmb = getActionAnim(currentAction)

        if a and actionStart[a] then
            local elapsed  = os.clock() - actionStart[a]
            local duration = a.track and a.track.Time or 0

            if duration > 0 and elapsed >= duration / (a.speed or 1) then
                -- zero the finished anim
                a.weight = 0
                stopActionSound()
                currentAction = nil

                if isLmb then
                    lmbResetTimer = LMB_RESET_TIME
                end

                -- immediately force idle so there's no blank frame
                currentBase = "none"
            end
        end
    end

    -- ── BASE STATE (idle / walk / jump) ───────────────────────
    if not currentAction and not swapPlaying then
        if inAir then
            if not wasInAir then
                clearBase()
                currentBase           = "jump"
                animJump.weight       = 1
                actionStart[animJump] = os.clock()
            end
        else
            if wasInAir then
                animJump.weight = 0
            end
            local moving = hum.MoveDirection.Magnitude > 0.1
            if moving then
                setBase("walk")
            else
                setBase("idle")
            end
        end
    end

    wasInAir = inAir

    -- ── STEP ALL ANIMS ────────────────────────────────────────
    local now = os.clock()

    for _, a in pairs(baseAnims) do
        if a.weight > 0 then a:Step(now) end
    end

    if animSwap and animSwap.weight > 0 then
        animSwap:Step(now - swapStart)
    end

    for a, start in pairs(actionStart) do
        if a.weight > 0 then a:Step(now - start) end
    end
end

-- CLEANUP
m.Destroy = function()
    ContextActionService:UnbindAction("SixEyes_LMB")
    ContextActionService:UnbindAction("SixEyes_Swap")
    ContextActionService:UnbindAction("SixEyes_Red")
    ContextActionService:UnbindAction("SixEyes_Blue")
    ContextActionService:UnbindAction("SixEyes_Punches")
    ContextActionService:UnbindAction("SixEyes_Kick")

    if bgSound then bgSound:Stop() bgSound:Destroy() bgSound = nil end
    stopActionSound()

    for _, s in pairs(modeASounds) do s:Stop() s:Destroy() end
    for _, s in pairs(modeBSounds) do s:Stop() s:Destroy() end

    baseAnimator   = nil
    actionAnimator = nil
    actionStart    = {}
    currentAction  = nil
    currentBase    = "idle"
    modeB          = false
    lmbStep        = 1
    lmbResetTimer  = 0
    figureRef      = nil
    wasInAir       = false
    swapPlaying    = false
    animJump       = nil
    animSwap       = nil
    modeAAnims     = {}
    modeBAnims     = {}
    lmbAnims       = {}
    modeASounds    = {}
    modeBSounds    = {}
    actionAnims    = {}
    actionSounds   = {}
end

return m
end)

return modules
