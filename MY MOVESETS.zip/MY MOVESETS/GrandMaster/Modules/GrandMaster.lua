-- GrandMaster.lua

local modules = {}

table.insert(modules, function()

local m = {}

m.ModuleType  = "MOVESET"
m.Name        = "Grandmaster"
m.Description = "z - Combo 1\nx - Combo 2\nc - Combo 3\nv - Combo 4\nb - Combo 5\ne - Front Flip\nq - Back Flip\nLeft Alt - Sprint"
m.InternalName = "GrandMaster"

m.Assets = {
    -- BASE
    "GrandMasterIdle.anim",
    "GrandMasterWalk.anim",
    "GrandMasterRun.anim",
    "GrandMaster Jump.anim",

    -- ATTACKS
    "Combo1.anim",
    "Combo2.anim",
    "Combo3.anim",
    "Combo4.anim",
    "Combo5.anim",
    "FrontFlip.anim",
    "BackFlip.anim",

    -- BACKGROUND SOUND
    "GrandMaster.mp3",

}

-- Which attacks are allowed to fling (true = flings, false = no fling)
m.FlingEnabled = {
    ["Combo1"]    = true,
    ["Combo2"]    = true,
    ["Combo3"]    = true,
    ["Combo4"]    = true,
    ["Combo5"]    = true,
    ["FrontFlip"] = false,
    ["BackFlip"]  = false,
}

m.Config = function(parent)
    Util_CreateText(parent, "GrandMaster", 18, Enum.TextXAlignment.Center)
    Util_CreateSeparator(parent)
    Util_CreateText(parent, "Fling on Hit", 15, Enum.TextXAlignment.Center)
    Util_CreateSwitch(parent, "Combo1 flings",    m.FlingEnabled["Combo1"]).Changed:Connect(function(v)    m.FlingEnabled["Combo1"]    = v end)
    Util_CreateSwitch(parent, "Combo2 flings",    m.FlingEnabled["Combo2"]).Changed:Connect(function(v)    m.FlingEnabled["Combo2"]    = v end)
    Util_CreateSwitch(parent, "Combo3 flings",    m.FlingEnabled["Combo3"]).Changed:Connect(function(v)    m.FlingEnabled["Combo3"]    = v end)
    Util_CreateSwitch(parent, "Combo4 flings",    m.FlingEnabled["Combo4"]).Changed:Connect(function(v)    m.FlingEnabled["Combo4"]    = v end)
    Util_CreateSwitch(parent, "Combo5 flings",    m.FlingEnabled["Combo5"]).Changed:Connect(function(v)    m.FlingEnabled["Combo5"]    = v end)
    Util_CreateSwitch(parent, "FrontFlip flings", m.FlingEnabled["FrontFlip"]).Changed:Connect(function(v) m.FlingEnabled["FrontFlip"] = v end)
    Util_CreateSwitch(parent, "BackFlip flings",  m.FlingEnabled["BackFlip"]).Changed:Connect(function(v)  m.FlingEnabled["BackFlip"]  = v end)
    
end

m.SaveConfig = function()
    return { FlingEnabled = m.FlingEnabled }
end
m.LoadConfig = function(save)
    if type(save.FlingEnabled) == "table" then
        for k, v in pairs(save.FlingEnabled) do
            if m.FlingEnabled[k] ~= nil then
                m.FlingEnabled[k] = v
            end
        end
    end
end

-- SERVICES
local Players = game:GetService("Players")

-- ANIMATORS
local baseAnimator   = nil
local actionAnimator = nil

-- ANIMS
local baseAnims   = {}
local actionAnims = {}
local animJump    = nil

-- SOUNDS
local bgSound = nil

-- SPEEDS
local SPEED_WALK   = 16
local SPEED_SPRINT = 26

-- STATE
local currentBase   = "idle"
local actionStart   = {}
local currentAction = nil
local isSprinting   = false
local wasInAir      = false

-- FLING STATE
local flingActive = false
local touchConns  = {}

-- Joint references for cleanup
local figureRef   = nil
local allJoints   = {}   -- collected on Init, reset on Destroy

-- ── sound helper ─────────────────────────────────────────────
local function makeSound(filename, parent, volume, looped)
    local s = Instance.new("Sound")
    s.SoundId = AssetGetContentId(filename)
    s.Volume  = volume or 0.8
    s.Looped  = looped or false
    s.Parent  = parent
    return s
end

-- LOAD ANIM
local function loadAnim(fig, file, looped)
    local a = AnimLib.Animator.new()
    a.rig    = fig
    a.track  = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
    a.looped = looped or false
    a.speed  = 1
    a.weight = 0
    return a
end

-- SET SPEED
local function setSpeed(speed)
    if not figureRef then return end
    local hum = figureRef:FindFirstChildOfClass("Humanoid")
    if hum then hum.WalkSpeed = speed end
end

-- CLEAR BASE ANIMS
local function clearBase()
    for _, a in pairs(baseAnims) do a.weight = 0 end
end

-- BASE SWITCH
local function setBase(state)
    if currentBase == state then return end
    currentBase = state
    clearBase()
    if baseAnims[state] then baseAnims[state].weight = 1 end
end

-- STOP ACTION
local function stopAction()
    for _, anim in pairs(actionAnims) do anim.weight = 0 end
    currentAction = nil
    flingActive   = false
end

-- PLAY ACTION (locked while another plays)
local function playAction(name)
    if currentAction then return end
    local a = actionAnims[name]
    if not a then return end

    stopAction()

    a.weight       = 1
    actionStart[a] = os.clock()
    currentAction  = name
    flingActive    = m.FlingEnabled[name] == true
end

-- TOGGLE SPRINT
local function toggleSprint()
    isSprinting = not isSprinting
    if isSprinting then
        setSpeed(SPEED_SPRINT)
        ContextActions:SetTitle("GM_Sprint", "Walk")
    else
        setSpeed(SPEED_WALK)
        ContextActions:SetTitle("GM_Sprint", "Sprint")
    end
end

-- BUTTON POSITION HELPER (scale-based, adapts to all screens)
local function btnPos(col, row)
    local btnW  = 0.10
    local gapW  = 0.01
    local btnH  = 0.08
    local gapH  = 0.01
    local baseY = 0.12

    local x = 1 - (col + 1) * (btnW + gapW)
    local y = 1 - baseY - row * (btnH + gapH)

    return UDim2.new(x, 0, y, 0)
end

-- SETUP FLING TOUCH CONNECTIONS
local function setupFlingTouched(figure)
    for _, part in ipairs(figure:GetDescendants()) do
        if part:IsA("BasePart") then
            local conn = part.Touched:Connect(function(hit)
                if not flingActive then return end
                if not hit or not hit.Parent then return end
                local target = hit.Parent
                if target:IsA("Accessory") then target = target.Parent end
                if target == figure then return end
                if not target:FindFirstChildOfClass("Humanoid") then return end
                ReanimateFling(target)
            end)
            table.insert(touchConns, conn)
        end
    end

    local descConn = figure.DescendantAdded:Connect(function(part)
        if part:IsA("BasePart") then
            local conn = part.Touched:Connect(function(hit)
                if not flingActive then return end
                if not hit or not hit.Parent then return end
                local target = hit.Parent
                if target:IsA("Accessory") then target = target.Parent end
                if target == figure then return end
                if not target:FindFirstChildOfClass("Humanoid") then return end
                ReanimateFling(target)
            end)
            table.insert(touchConns, conn)
        end
    end)
    table.insert(touchConns, descConn)
end

-- INIT
m.Init = function(figure)
    figureRef = figure

    baseAnimator       = AnimLib.Animator.new()
    baseAnimator.rig   = figure
    actionAnimator     = AnimLib.Animator.new()
    actionAnimator.rig = figure

    local hrp = figure:FindFirstChild("HumanoidRootPart") or figure

    -- Collect all Motor6D joints so we can reset them on Destroy
    allJoints = {}
    for _, v in ipairs(figure:GetDescendants()) do
        if v:IsA("Motor6D") then
            table.insert(allJoints, v)
        end
    end

    -- BASE ANIMS
    baseAnims = {
        idle   = loadAnim(figure, "GrandMasterIdle.anim",  true),
        walk   = loadAnim(figure, "GrandMasterWalk.anim",  true),
        sprint = loadAnim(figure, "GrandMasterRun.anim",   true),
        jump   = loadAnim(figure, "GrandMaster Jump.anim", true),
    }

    animJump = baseAnims.jump

    -- ACTION ANIMS
    actionAnims = {
        ["Combo1"]    = loadAnim(figure, "Combo1.anim",    false),
        ["Combo2"]    = loadAnim(figure, "Combo2.anim",    false),
        ["Combo3"]    = loadAnim(figure, "Combo3.anim",    false),
        ["Combo4"]    = loadAnim(figure, "Combo4.anim",    false),
        ["Combo5"]    = loadAnim(figure, "Combo5.anim",    false),
        ["FrontFlip"] = loadAnim(figure, "FrontFlip.anim", false),
        ["BackFlip"]  = loadAnim(figure, "BackFlip.anim",  false),
        
    }

    -- BACKGROUND SOUND
    bgSound = makeSound("GrandMaster.mp3", hrp, 0.5, true)
    bgSound:Play()

    setSpeed(SPEED_WALK)
    setBase("idle")

    -- FLING TOUCH SETUP
    setupFlingTouched(figure)

    -- ── BUTTONS ──────────────────────────────────────────────
    -- Row layout guide:
    --   btnPos(col, row)
    --   col 0 = rightmost,  increases leftward
    --   row 0 = bottom row, increases upward
    --
    -- Current layout:
    --   Row 1: [C1] [C2] [C3] [BFlip] [FFlip] [Sprint]
    --   Row 0:                         [C4]    [C5]
    --
    -- To add a new button, pick a free slot and add a BindAction block.
    -- Free slots in current layout:
    --   btnPos(5, 0), btnPos(4, 0), btnPos(3, 0)   ← row 0 left side
    --   btnPos(6, 0), btnPos(6, 1)                  ← extra column left
    --   btnPos(0, 2), btnPos(1, 2) etc              ← row 2 above current

    -- Row 1
    ContextActions:BindAction("GM_Combo1", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("Combo1") end
    end, true, Enum.KeyCode.Z)
    ContextActions:SetTitle("GM_Combo1", "Combo1")
    ContextActions:SetPosition("GM_Combo1", btnPos(21, 20))

    ContextActions:BindAction("GM_Combo2", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("Combo2") end
    end, true, Enum.KeyCode.X)
    ContextActions:SetTitle("GM_Combo2", "Combo2")
    ContextActions:SetPosition("GM_Combo2", btnPos(17.5, 20))

    ContextActions:BindAction("GM_Combo3", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("Combo3") end
    end, true, Enum.KeyCode.C)
    ContextActions:SetTitle("GM_Combo3", "Combo3")
    ContextActions:SetPosition("GM_Combo3", btnPos(14, 20))

    ContextActions:BindAction("GM_BackFlip", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("BackFlip") end
    end, true, Enum.KeyCode.Q)
    ContextActions:SetTitle("GM_BackFlip", "BFlip")
    ContextActions:SetPosition("GM_BackFlip", btnPos(10.5, 20))

    ContextActions:BindAction("GM_FrontFlip", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("FrontFlip") end
    end, true, Enum.KeyCode.E)
    ContextActions:SetTitle("GM_FrontFlip", "FFlip")
    ContextActions:SetPosition("GM_FrontFlip", btnPos(7, 20))

    ContextActions:BindAction("GM_Sprint", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then toggleSprint() end
    end, true, Enum.KeyCode.LeftAlt)
    ContextActions:SetTitle("GM_Sprint", "Sprint")
    ContextActions:SetPosition("GM_Sprint", btnPos(3.5, 20))

    -- Row 0
    ContextActions:BindAction("GM_Combo4", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("Combo4") end
    end, true, Enum.KeyCode.V)
    ContextActions:SetTitle("GM_Combo4", "Combo4")
    ContextActions:SetPosition("GM_Combo4", btnPos(7, 16))

    ContextActions:BindAction("GM_Combo5", function(_, inputState, _)
        if inputState == Enum.UserInputState.Begin then playAction("Combo5") end
    end, true, Enum.KeyCode.B)
    ContextActions:SetTitle("GM_Combo5", "Combo5")
    ContextActions:SetPosition("GM_Combo5", btnPos(3.5, 16))

end

-- UPDATE
m.Update = function(dt, figure)

    local hum = figure:FindFirstChildOfClass("Humanoid")
    if not hum then return end

    local inAir = hum.FloorMaterial == Enum.Material.Air

    -- AUTO-STOP current action
    if currentAction then
        local a = actionAnims[currentAction]
        if a and actionStart[a] then
            local elapsed  = os.clock() - actionStart[a]
            local duration = a.track and a.track.Time or 0
            if duration > 0 and elapsed >= duration / (a.speed or 1) then
                a.weight      = 0
                currentAction = nil
                flingActive   = false
                currentBase   = "none"
            end
        end
    end

    -- BASE STATE
    if not currentAction then
        if inAir then
            if not wasInAir then
                clearBase()
                currentBase           = "jump"
                animJump.weight       = 1
                actionStart[animJump] = os.clock()
            end
        else
            if wasInAir then animJump.weight = 0 end
            local moving = hum.MoveDirection.Magnitude > 0.1
            if moving then
                if isSprinting then setBase("sprint") else setBase("walk") end
            else
                setBase("idle")
            end
        end
    end

    wasInAir = inAir

    -- STEP ALL ANIMS
    local now = os.clock()

    for _, a in pairs(baseAnims) do
        if a.weight > 0 then a:Step(now) end
    end

    for a, start in pairs(actionStart) do
        if a.weight > 0 then a:Step(now - start) end
    end
end

-- CLEANUP
m.Destroy = function()
    -- Unbind all buttons
    ContextActions:UnbindAction("GM_Sprint")
    ContextActions:UnbindAction("GM_Combo1")
    ContextActions:UnbindAction("GM_Combo2")
    ContextActions:UnbindAction("GM_Combo3")
    ContextActions:UnbindAction("GM_Combo4")
    ContextActions:UnbindAction("GM_Combo5")
    ContextActions:UnbindAction("GM_FrontFlip")
    ContextActions:UnbindAction("GM_BackFlip")
    
    -- Disconnect fling touch events
    for _, conn in ipairs(touchConns) do conn:Disconnect() end
    table.clear(touchConns)

    -- Stop and destroy background sound
    if bgSound then bgSound:Stop() bgSound:Destroy() bgSound = nil end

    -- !! KEY FIX: reset all Motor6D transforms so the next moveset's
    -- animations are not stuck fighting leftover transforms from our anims.
    for _, joint in ipairs(allJoints) do
        if joint and joint.Parent then
            joint.Transform = CFrame.identity
        end
    end
    allJoints = {}

    -- Zero out all anim weights so AnimLib stops driving transforms
    for _, a in pairs(baseAnims) do a.weight = 0 end
    for _, a in pairs(actionAnims) do a.weight = 0 end

    setSpeed(16)

    baseAnimator   = nil
    actionAnimator = nil
    actionStart    = {}
    currentAction  = nil
    currentBase    = "idle"
    isSprinting    = false
    wasInAir       = false
    flingActive    = false
    figureRef      = nil
    animJump       = nil
    baseAnims      = {}
    actionAnims    = {}
end

return m
end)

return modules